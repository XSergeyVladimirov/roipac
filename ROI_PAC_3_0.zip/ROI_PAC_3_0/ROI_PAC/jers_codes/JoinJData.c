/*  PROGRAM    :  JoinJData                                                   */
/*  DESCRIPTION:  concatenate two north-south adjacent level0 data of JERS-1  */
/*  AUTHOR     :  Hiroyuki Nakagawa                                           */
/*  DATE       :  3/27/2001                                                   */
/*  UPDATE     :                                                              */

/* compile:  gcc -lm JoinJData.c -o JoinJData   (Linux)  */
/* compile:  cc JoinJData.c -lm -o JoinJData   (Unix WS)  */


#include <stdio.h>  
#include <string.h>
#include <math.h>

#define MAX_FILE 8
#define MAX_LINE 20000  

/* offset of the position of the time value when obtained the record from the record head (byte) */
/* (data begins from 45th byte)  		*/
/*    Milisecond from the begining of the day. 	*/
/* you might change it if you use a data other than NASDA's */ 
#define MSEC_OFFSET 44
#define BYTE_LENGTH 4


main(int argc, char *argv[]){
	
	int i;   /* just a counter */
	long int line_cnt_out, line_cnt_in;			/* line counter of input/output file  */
	int hdr_byte, rec_byte, rec_hdr; 	/* length of file header, record, record header (in bytes) */
	int c_offset = MSEC_OFFSET;		/* byte offset of the clock data in record from the head  */
	int b_len = BYTE_LENGTH;		/* lenght of the clock data (in bytes) */
	int nfile;				/* number of inputn file */
	long int  ln_num;
	long int  bnd[MAX_FILE];	/* boundary line of merging (of file file[i-1] ) */
	
	char *buf;		/*  buffer to contain data  */
	size_t st;		/*  returned value of fread/fwrite  */
	
	FILE *fin[MAX_FILE], *fout, *fpara;
	
	long int findline();
	
	if (argc<4){
		fprintf(stderr,"Usage: %s <file header size> <record length> <record header size> <file 1> [file 2]...\n",argv[0]);
		fprintf(stderr,"    file header size, record length, record header size: in byte\n");
		fprintf(stderr,"    Output file: tmp_IMAGERY.raw (data), merge.out (parameter) \n");
		fprintf(stderr,"    File header is removed. \n");
		exit(1);
	}
	
	sscanf(argv[1],"%d", &hdr_byte);
	sscanf(argv[2],"%d", &rec_byte);
	sscanf(argv[3],"%d", &rec_hdr);
	
	nfile= argc-4;
	fprintf(stdout,"Number of input files: %d\n",nfile);

/*  file open  */	    
	fprintf(stdout,"File open\n");
	fprintf(stdout,"  input file\t");
	for (i=0; i<nfile; i++){
		fprintf(stdout,"%d\t",i+1);
		if ((fin[i]=fopen(argv[i+4], "rb")) == NULL) {
			fprintf(stderr,"File open error !!  %s\n",argv[i+4]);
			exit(-1);
		}
	}
	fprintf(stdout,"\n  output file\n");
	if ((fout=fopen("tmp_IMAGERY.raw", "wb")) == NULL) {
			fprintf(stderr,"File open error !!  tmp_IMAGERY.raw\n");
			exit(-1);
	}
	if ((fpara=fopen("merge.out", "w")) == NULL) {
			fprintf(stderr,"File open error !!  merge.out\n");
			exit(-1);
	}
	
	
	
/*  BODY  */
	if ((buf=(char *)malloc((size_t)rec_byte))==NULL){
		fprintf(stderr,"Memory allocation error in buf1\n");
		exit(-1);
	}
	
	/*  write out file 1 to output file  */
	if (fseek(fin[0],hdr_byte,SEEK_SET)){
		fprintf(stderr, "fseek error in file 1\n");
		exit(-1);
	}
	for (line_cnt_out=0,line_cnt_in=0; line_cnt_in<MAX_LINE ; line_cnt_out++,line_cnt_in++){
		if ((st=fread(buf, (size_t)rec_byte, 1, fin[0])) != 1){
			if (ferror(fin[0])) {
				fprintf(stderr, "Read data error in file 1, line %d\n",line_cnt_in+1);
				exit(-1);
			}
			if (feof(fin[0])){
				fprintf(stdout, "\nReached the end of the file 1\n");
				if (fseek(fin[0],0,SEEK_SET)){
					fprintf(stderr, "fseek error in file 1\n");
					exit(-1);
				}
				break;
			}
		}
		if((st=fwrite(buf, (size_t)(rec_byte), 1, fout)) != 1){
			fprintf(stderr, "Write error of the data of file 1, line %d\n",line_cnt_out+1);
			exit(-1);
		}
		if((line_cnt_out+1)%1000==0){
			fprintf(stdout,"Write output file: line %d\r",line_cnt_out+1);
		}
	}
	
	if(line_cnt_in >= MAX_LINE){
		fprintf(stderr, "\nError: Too much lines %d.  Something Wrong\n",line_cnt_in+1);
		exit(-1);
	}
		
	/* Merge */
	for (i=0; i<nfile-1; i++){
	
		/*  Search line  */
		fprintf(stdout,"Comparing file %s and %s\n",argv[i+4],argv[i+4+1]);
		ln_num=findline(fin[i],fin[i+1],hdr_byte,rec_byte,rec_hdr, c_offset, b_len);
		if(ln_num<0){		/*  Error  */
			fprintf(stderr, "Warning: Cannot find boundary\n");
			fprintf(stderr, "         Merge w/o overlap...may be wrong.\n");
			ln_num=0;
		}
			
		fprintf(stdout,"Boundary: line %d of file %s\n",ln_num,argv[i+4+1]);
		bnd[i]=ln_num;

		/* Merge file */
		fprintf(stdout,"Merge\n");
		if (fseek(fin[i+1],(hdr_byte+rec_byte*ln_num),SEEK_SET)){
			fprintf(stderr, "fseek error in file 1\n");
			exit(-1);
		}
		for (line_cnt_in=0; line_cnt_in<MAX_LINE ; line_cnt_out++,line_cnt_in++){
			if ((st=fread(buf, (size_t)rec_byte, 1, fin[i+1])) != 1){
				if (ferror(fin[i+1])) {
					fprintf(stderr, "Read data error in file 1, line %d\n",line_cnt_in+1);
					exit(-1);
				}
				if (feof(fin[i+1])){
					fprintf(stdout, "\nRearch the end of the file 1\n");
					if (fseek(fin[i+1],0,SEEK_SET)){
						fprintf(stderr, "fseek error in file 1\n");
						exit(-1);
					}
					break;
				}
			}
			if((st=fwrite(buf, (size_t)(rec_byte), 1, fout)) != 1){
				fprintf(stderr, "Write error of the data of file 1, line %d\n",line_cnt_out+1);
				exit(-1);
			}
			if((line_cnt_out+1)%1000==0){
				fprintf(stdout,"Write output file: line %d\r",line_cnt_out+1);
			}
		}
		fprintf(stdout,"\n");
		if(line_cnt_in >= MAX_LINE){
			fprintf(stderr, "Error: Too much lines %d.  Something Wrong\n",line_cnt_in+1);
			exit(-1);
		}    
	}	
	
/*  write parameter file  */	
	fprintf(fpara, "FILE_LENGTH      %d\n",line_cnt_out);
	fprintf(fpara, "YMAX             %d\n",line_cnt_out);
	for(i=0;i<nfile-1;i++){
	  fprintf(fpara, "BOUNDARY%d         %d\n",i+1,bnd[i]);
	}
	
/*  file close  */
	for (i=0; i<nfile; i++) fclose(fin[i]);
	fclose(fout);
	fclose(fpara);
	
	fprintf(stdout,"Lines in Output File: %d\n", line_cnt_out);
	
}




long int findline(FILE *f1, FILE *f2, int hdr_byte, int rec_byte, int rec_hdr, int c_offset, int b_len)
{

/*  Minimun correlation threshold to correlate two lines  */
#define  CC_THR 0.3

	int i,j,k;					/*  counter  */

	int width;					/*  image line width (in byte)  */
	int rec_num1,rec_num2;		/*  record number (line number) of file 1 and 2  */
	int cl1,cl2;				/*  clock value */

	int check_length = 1024;	/*  compare 1024 lines.  Actually, the clock value is updated every 1024 lines */
	double sx2,sy2,sxy[2];			/*  sum of square and sum(x*conj(y)) of each line  */
	double r, r_max;			/*  correlation coefficient of two lines  */
	long int ln_num;			/*  line number with maxmum correlation  (return)  */
	size_t st;					/*  returned value of fread/fwrite  */	

	double *x, *y;				/*  offset corrected data array  */
	char *buf1, *buf2; 
	unsigned char *buf_c;	               /*  buffers */

	/* constant */
	double sval = -3.5;				/*  A/D offset. -3.5 for JERS-1. -15.5 for ERS */
	
	
/* calculate total record number of each files */
	if (fseek(f1,0,SEEK_END)){
		fprintf(stderr, "+findline()  fseek error f1\n");
		exit(-1);
	}
	rec_num1=(ftell(f1)-hdr_byte)/rec_byte;
	fseek(f1,0,SEEK_SET);
	fprintf(stdout,"+findline()  Total Record in f1: %d\n",rec_num1);
	
	if (fseek(f2,0,SEEK_END)){
		fprintf(stderr, "+findline()  fseek error f2\n");
		exit(-1);
	}
	rec_num2=(ftell(f2)-hdr_byte)/rec_byte;
	fseek(f2,0,SEEK_SET);
	fprintf(stdout,"+findline()  Total Record in f2: %d\n",rec_num2);

	width = rec_byte - rec_hdr ;
	
/*  memory allocation  */
	if ((buf1=(char *)malloc((size_t)rec_byte))==NULL){
		fprintf(stderr,"+findline()  Memory allocation error in buf1\n");
		exit(-1);
	}
	if ((buf2=(char *)malloc((size_t)rec_byte))==NULL){
		fprintf(stderr,"+findline()  Memory allocation error in buf2\n");
		exit(-1);
	}
	if ((buf_c=(unsigned char *)malloc((size_t)b_len))==NULL){
		fprintf(stderr,"+findline()  Memory allocation error in buf_c\n");
		exit(-1);
	}

	if ((x=(double *)malloc(sizeof(double)*width))==NULL){
		fprintf(stderr,"+findline()  Memory allocation error in x\n");
		exit(-1);
	}
	if ((y=(double *)malloc(sizeof(double)*width))==NULL){
		fprintf(stderr,"+findline()  Memory allocation error in y\n");
		exit(-1);
	}
	

/*  get the last line of file 1  */
	if (fseek(f1,(-1)*rec_byte, SEEK_END)){
		fprintf(stderr, "+findline()  fseek error f1\n");
		exit(-1);
	}
	if ((st=fread(buf1, (size_t)rec_byte, 1, f1)) != 1){
		fprintf(stderr, "+findline()  fread error f1\n");
		exit(-1);
	}
	
	/* get clock */
	fprintf(stdout,"+findline()  Check Clock\n");

	for(i=0; i<b_len;i++) buf_c[i]=buf1[c_offset+i];

	/*  It somehow wrong.  */
	/*  #ifdef LITTLE_ENDIAN */
	/*  	for(i=0; i<b_len;i++) buf_c[i]=buf1[c_offset+b_len-i];		/*  change byte order  */
	/*  #endif */

	cl1=0;
	for(i=0; i<b_len;i++){
	  cl1=cl1*16*16+buf_c[i];
	}

	fprintf(stdout,"+findline()  clock of the last line of file 1 is %d (ms)\n",cl1);
	for(i=0; i<b_len;i++) buf_c[i]=0;	/*  clear the buffer  buf_c */
	
	/* calculate sum square the last line of file 1 */
	width=rec_byte-rec_hdr;	
	sx2=0;
	for(j=0; j<width; j++) {
	  x[j]=(double)(buf1[j+rec_hdr]+sval);
	  sx2 += (x[j]*x[j]);
	}
	
/*  loop for lines of f2  */

	ln_num=0; 	/* line number of file 2 which is same as the last line of line 1.  return value */
	r_max=0.0;	/* maximum correlation between the last line of file 1 and line in file 2 */
	
	if (fseek(f2,hdr_byte, SEEK_SET)){		/*   skip file header */
		fprintf(stderr, "+findline()  fseek error f2\n");
		exit(-1);
	}
	

	for (i=0; i<rec_num2; i++){
		if ((st=fread(buf2, (size_t)rec_byte, 1, f2)) != 1){			/* read a line */
			fprintf(stderr, "+findline()  fread error f2\n");
			exit(-1);
		}
		

	/*  check clock  */
		for(j=0; j<b_len;j++) buf_c[j]=buf2[c_offset+j];

		/*    It somehow is wrong */
		/*  #ifndef BIG_ENDIAN */
		/*  		for(j=0; j<b_len;j++) buf_c[j]=buf2[c_offset+b_len-j];		/*  change byte order  */
		/*  #endif */

		cl2=0;
		for(j=0; j<b_len;j++){
		  cl2=cl2*16*16+buf_c[j];
		}

		fprintf(stdout,"+findline()  clock of the %d th line of file 2 is %d (ms)\r",i,cl2);
		for(j=0; j<b_len;j++) buf_c[j]=0;	/*  clear buffer */
	
		if(cl2 == cl1) {
			fprintf(stdout,"\n");
			fseek(f2,(-1)*rec_byte,SEEK_CUR);	/*  rewind one line  */
			break;
		}
		if(cl2 > cl1){
			fprintf(stdout,"\n");
			fprintf(stderr,"+findline()  Warning: clock is inconsistent between file 1 and file 2\n");
			fprintf(stderr,"             Clock of last line in file 1 is %d\n",cl1);
			fprintf(stderr,"             and clock of line %d in file 2 is %d\n",i,cl2);
			fprintf(stderr,"             Rewind %d lines and continue.\n",check_length);
			
			if(i>check_length+1){
			  fseek(f2,(-1)*rec_byte*(check_length+1),SEEK_CUR);
			  i-=(check_length+1);
			}else{
			  fseek(f2,hdr_byte,SEEK_SET);
			  i=0;
			}

			check_length=rec_num2;
			break;
		}
	}
	if (i==rec_num2){
		fprintf(stderr,"+findline()  Cannot find proper clock in file 2\n");
		fprintf(stderr,"+findline()  Make correlation check from the begining to the end of the file\n");
		if (fseek(f2,hdr_byte, SEEK_SET)){		/*   skip file header */
			fprintf(stderr, "+findline()  fseek error f2\n");
			exit(-1);
		}
		check_length=rec_num2;
		i=0;
	}
		
	/* Correlation check */
		 	
	for(k=0; k<check_length; k++){
		if ((st=fread(buf2, (size_t)rec_byte, 1, f2)) != 1){			/* read a line */
			if(feof(f2)) {
				fprintf(stdout,"+findline()  End of file at line %d\n",i);
				break;
			} 
			if(ferror(f2)){
				fprintf(stderr, "+findline()  fread error f2\n");
				exit(-1);
			}
		}
				
		sy2=0.0; 
		sxy[0]=0.0;  sxy[1]=0.0;        /* sxy=x*conjg(y)   sxy[0]: real part  sxy[1]: imagenary part   */
		for(j=0; j<width; j+=2){
		  y[j]  =(double)(buf2[rec_hdr+j]  +sval);
		  y[j+1]=(double)(buf2[rec_hdr+j+1]+sval);


		  sy2 += (y[j]*y[j]+y[j+1]*y[j+1]);          /* y[j]: real part  y[j+1]: imagenary part   */
		  sxy[0] += (x[j]*y[j]+x[j+1]*y[j+1]);
		  sxy[1] += (-x[j]*y[j+1]+x[j+1]*y[j]);
#ifdef DEBUG2
		  fprintf(stderr,"%d  x: %f + i %f, y: %f + i %f  sy2: %f\n"
			  ,j+rec_hdr,x[j],x[j+1],y[j],y[j+1],sy2);
#endif
		}

		
		r = sqrt(sxy[0]*sxy[0]+sxy[1]*sxy[1])/sqrt(sx2*sy2);

#ifdef DEBUG
		fprintf(stdout,"line %d   sxy: %f + i %f  sx2: %f  sy2: %f\n"
			,i+1,sxy[0],sxy[1],sx2,sy2 ); 
		fprintf(stdout,"          correlation %f\n",r);
#endif
#ifndef DEBUG
		fprintf(stdout,"line %d   correlation %f\r",i+1,r);
#endif
			
		if (r>r_max) {
			ln_num=i;
			r_max=r;
		}
		
		i++;	
	}
	fprintf(stdout,"Correlation peak %f at line %d\n",r_max,i+1);
	fprintf(stdout,"\n");
	
	if(r_max<CC_THR){
		fprintf(stderr,"+findline()  ERROR: Maximum correlation coefficient is too low\n");
		fprintf(stderr,"                    at line %d   r= %f  < threshold CC_THR\n",i+1,r_max);
		ln_num=-1;
	}

/*  return  */
	if (fseek(f1,0, SEEK_SET)){
		fprintf(stderr, "+findline()  fseek error f1\n");
		exit(-1);
	}
	if (fseek(f2,0, SEEK_SET)){
		fprintf(stderr, "+findline()  fseek error f2\n");
		exit(-1);
	}
	
	return ln_num+1;
}
