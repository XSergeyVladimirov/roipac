/*  *** JPL/Caltech Repeat Orbit Interferometry (ROI) Package ***   */

#include <stdio.h>
#include <math.h>
#include <string.h>

#define MaxWidth  6000
#define MaxLength 9000
 
main(int argc, char *argv[]){

   char   InFile0[1000];
   char   InLine0[10000];
   FILE   *InFP0;
   char   InFile1[1000],       InFile2[1000],      OutFile[1000];
   FILE   *InFP1,              *InFP2,             *OutFP;
   float  InLine1[MaxWidth*2], InLine2[MaxWidth*2],OutLine[MaxWidth*2];
   double Coeff;
   double Pi;
   int    Width,Length;
   int    i,j;
   float Phi1, Phi2, Amp;
   
   Pi=4*atan2(1,1);

/********************************************************************************/
/****************************  Reading      Parameters  *************************/
/********************************************************************************/
   sscanf(argv[1],"%s",InFile1);
   sscanf(argv[2],"%s",InFile2);
   sscanf(argv[3],"%s",OutFile);
   sscanf(argv[4],"%d",&Width);
   sscanf(argv[5],"%d",&Length);
   sscanf(argv[6],"%lf",&Coeff);
/*       printf("%lf\n",Coeff); exit(1); */
/********************************************************************************/
/****************************                           *************************/
/********************************************************************************/
   if((InFP1=fopen(InFile1,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile1);
      exit(0);
      }
   if((InFP2=fopen(InFile2,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile2);
      exit(0);
      }
   if((OutFP=fopen(OutFile,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile);
      exit(0);
      }

   for(i=0;i<Length;i++){
      if(i%1000==0)printf("\rline %d\n",i);
      fread(InLine1,sizeof(InLine1[0]),Width*2,InFP1);
      fread(InLine2,sizeof(InLine2[0]),Width*2,InFP2);
      for(j=0;j<Width;j++){
	/*	OutLine[2*j]=InLine1[2*j]+Coeff*InLine2[2*j];
	OutLine[2*j+1]=InLine1[2*j+1]+Coeff*InLine2[2*j+1];*/
	Amp=hypot(InLine1[2*j],InLine1[2*j+1]);
	Phi1=atan2(InLine1[2*j+1],InLine1[2*j]);
	Phi2=atan2(InLine2[2*j+1],InLine2[2*j]);
	OutLine[2*j]=Amp*cos(Phi1+Coeff*Phi2);
	OutLine[2*j+1]=Amp*sin(Phi1+Coeff*Phi2);
      }
      fwrite(OutLine,sizeof(OutLine[0]),Width*2,OutFP);
      }
   close(InFP1);
   close(InFP2);
   close(OutFP);
   }
//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage: add_phs Infile1 Infile2 Outfile Width Length Coeff     
//POD Infile1: file1, data  c*8/complex                           
//POD Infile2: file2, data  c*8/complex                               
//POD Outfile: output, amp1 *exp[i*(phase1 + phase2*coef)] c*8 data;                                  
//POD Width: number of pixels in each record for all imput and output files                     
//POD Length: number of records to collect from file1 & file2 and to process/dump to outfile
//POD Coeff: factor to the file2
//POD
//POD//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "add_cpx" collects data (c*8/complex)from two sepate files,
//POD Infile1 and Infile2 respectively, and writes amp1 *exp[i*(phase1 + phase2*coef)] c*8 data
//POD to Outfile (r*4complex), 
//POD In all these files the record length is "width".
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Two input files "Infile1" & "Infile2" each containing an c*8/complex arrays (Width X Length).
//POD
//POD=head1 FILES CREATED
//POD
//POD New Complex data amp1 *exp[i*(phase1 + phase2*coef)] stored as c*8/complex .
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD POD comments trm Feb 3rd '04
//POD=cut

