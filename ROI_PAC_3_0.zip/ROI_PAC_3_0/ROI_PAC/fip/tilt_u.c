#include <stdio.h>
#include <math.h>
#include <string.h>

#define MaxWidth  6000
#define MaxLength 9000
 
main(int argc, char *argv[]){

   char   InFile[1000],       OutFile[1000];
   FILE   *InFP,              *OutFP;
   float  InLine[MaxWidth*2], OutLine[MaxWidth*2];
   float  DPhaseRange;
   float  DPhaseAzimuth;
   float  PhaseOffset;
   double Pi;
   int    Width,Length;
   int    i,j;
   
   sprintf(InFile,"%s",argv[1]);
   sprintf(OutFile,"%s",argv[2]);
   sscanf(argv[3],"%d",&Width);
   sscanf(argv[4],"%f",&DPhaseRange);
   sscanf(argv[5],"%f",&DPhaseAzimuth);
   if(argc>6) sscanf(argv[6],"%f",&PhaseOffset);
   Pi=4*atan2(1,1);

/********************************************************************************/
/****************************                           *************************/
/********************************************************************************/
   if((InFP=fopen(InFile,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile);
      exit(0);
      }
   if((OutFP=fopen(OutFile,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile);
      exit(0);
      }
      
   fseek(InFP,0L,SEEK_END);
   Length=ftell(InFP)/(2*sizeof(float)*Width);
   rewind(InFP);
   
   for(i=0;i<Length;i++){
      if(i%1000==0)printf("\rline %d\n",i);
      fread(InLine,sizeof(InLine[0]),Width*2,InFP);
      for(j=0;j<Width;j++){
         if(InLine[j+Width]*InLine[j]==0){
            OutLine[j]=InLine[j];
            OutLine[j+Width]=0;
            }else{
            OutLine[j]  =InLine[j];
            OutLine[j+Width]=InLine[j+Width]+j*DPhaseRange/Width+i*DPhaseAzimuth/Length+PhaseOffset;
            }
         }
      fwrite(OutLine,sizeof(OutLine[0]),Width*2,OutFP);
      }
   close(InFP);
   close(OutFP);
   }

//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage: tilt_i InFile(str) 
//POD               OutFile(str) 
//POD               Width(int) 
//POD               DPhaseRange(float) 
//POD               DPhaseAzimuth(float)
//POD    optional:  PhaseOffset(float)
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  tilt_i reads each record  of an input file "InFile" 
//POD --these input records are made up of a number (Width) of complex values stored
//POD --as Width X r*4(float) amplitude folowed by Width X r*4(float) phases
//POD and writes these records to a file "OutFile" after a scalar multiplication  by
//POD the complex record exp[I*j*DPhaseRange/Width+i*DPhaseAzimuth/Length+PhaseOffset] 
//POD where:
//POD    -- I is Sqrt(-1)
//POD    -- j is a ramp of "Width" successive integers from 0 to Width-1
//POD    -- Length is the total number of records in the file (total file size 2*Width*Length*4 bytes)
//POD    -- i is the record number, from 0 to Length-1
//POD Note: if an input record element is real(imaginary part == 0) or 0 nothing is done before output
//POD
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Input file "InFile" contains an array of complex values Z(0:Width-1,0:Length-1) (first index fastest)
//POD    InFile file structure: record length: 2*Width*4 bytes, first half amplitudes, second half phases
//POD
//POD=head1 FILES CREATED
//POD
//POD Output file "OutFile" will be ZZ(0:Width-1,0:Length-1) (same file structure as InFile) 
//POD       where:
//POD             ZZ(i,j) = Z(i,j)*exp[I*i*DPhaseRange/Width+j*DPhaseAzimuth/Length+PhaseOffset] 
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD: trm Jan 29th '04
//POD=cut
