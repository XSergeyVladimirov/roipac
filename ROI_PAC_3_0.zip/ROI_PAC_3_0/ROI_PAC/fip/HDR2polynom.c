#include <stdio.h>
#include <string.h>

#ifndef NDEBUG
#define CHECK printf("%s past line %d \n", __FILE__, __LINE__ );
#else
#define CHECK /*Do nothing*/ ;
#endif

/* Create a polynome to interpolate state vector values
   Creation: Frederic Crampe & Francois Rogez 1998 */

/*-----------------------------------------------------------------*/
struct StateVector_struct {
  double Date;
  double x[6];
  struct StateVector_struct *Next;
  };
typedef struct StateVector_struct StateVector_type;

#define STATE_VECTOR_FORMAT "%lf %lf %lf %lf %lf %lf %lf"
#define OUTPUT_FORMAT "%lf %lf %lf %lf %lf %lf"

/*-----------------------------------------------------------------*/
void Interpolate( StateVector_type *SV, double TargetDate, StateVector_type *NewSV);
void ReadStateVectorFile(char *FileName, StateVector_type **Root);

/*-----------------------------------------------------------------*/
void main(int argc, char **argv){

  StateVector_type *SV = NULL;
  StateVector_type TargetSV;
  double Date;

  if(argc<3){
    fprintf(stderr,"Usage: %s <State Vector FileName> <Target Date>\n",argv[0]);
    fprintf(stderr,"SV format: time x , y , z , vx , vy ,vz\n");
    exit(-1);
    }
  
  ReadStateVectorFile(argv[1],&SV);
  sscanf(argv[2],"%lf",&Date);
  
  Interpolate(SV,Date,&TargetSV);
  printf(OUTPUT_FORMAT,
                 TargetSV.x[0],TargetSV.x[1],TargetSV.x[2],
                 TargetSV.x[3],TargetSV.x[4],TargetSV.x[5]);
  printf("\n");
  
  }

/*-----------------------------------------------------------------*/
void ReadStateVectorFile(char *FileName, StateVector_type **Root){

  char StrBuf[BUFSIZ];
  FILE *FP;
  int Count;
  StateVector_type *NewSV;
  StateVector_type *SV_ptr;
    
  FP=fopen(FileName,"r");
  if(FP==NULL){
    fprintf(stderr,"Cannot read file '%s'\n",FileName);
    return;
    }

  for(SV_ptr=*Root; SV_ptr!=NULL && SV_ptr->Next!=NULL; SV_ptr=SV_ptr->Next);
  
  while(fgets(StrBuf, BUFSIZ, FP) != NULL){
    NewSV=(StateVector_type *)calloc(1,sizeof(StateVector_type));
    Count=sscanf(StrBuf,STATE_VECTOR_FORMAT,&(NewSV->Date),
                 &(NewSV->x[0]),&(NewSV->x[1]),&(NewSV->x[2]),
                 &(NewSV->x[3]),&(NewSV->x[4]),&(NewSV->x[5]));
    if(Count!=7){
      free(NewSV);
      continue;
      }
   if(*Root==NULL){
     *Root=NewSV;
     SV_ptr=NewSV;
     }else{
     SV_ptr->Next=NewSV;
     SV_ptr=SV_ptr->Next;
     }
   }
   return;
   }
                 
 /*-----------------------------------------------------------------*/
void Interpolate( StateVector_type *SV, double TargetDate, StateVector_type *NewSV){

  StateVector_type *SV_ptr1;
  StateVector_type *SV_ptr2;
  int i;
  double tmp;
              
  NewSV->Date=TargetDate;
  for(i=0;i<6;i++){
    NewSV->x[i]=0;
    for(SV_ptr1 = SV; SV_ptr1!=NULL; SV_ptr1=SV_ptr1->Next){
      tmp=1;
      for(SV_ptr2 = SV; SV_ptr2!=NULL; SV_ptr2=SV_ptr2->Next){
        if(SV_ptr2==SV_ptr1)continue;
        tmp *= (SV_ptr2->Date-NewSV->Date)/(SV_ptr2->Date-SV_ptr1->Date);
        }
      NewSV->x[i] += (SV_ptr1->x[i]*tmp);  
      }
    }
  return;
  }
       
                 
                 
                 
                 
                 
/*-----------------------------------------------------------------*/

//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage: HDR2polynom <State Vector FileName> <Target Date>
//POD                SV format: time x , y , z , vx , vy ,vz                         
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  HDR2polynom
//POD Create a polynome to interpolate state vector values
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD State Vector File
//POD
//POD=head1 FILES CREATED
//POD
//POD State Vector File at a new (Target) date
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Frederic Crampe & Francois Rogez 1998
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD POD comments trm Feb 3rd '04
//POD=cut
