/*
################################################################
#Francois Rogez 6-17-96
#
################################################################
*/
/******************************************************************************/
/* Read the sampling window start time(SWST) in the signal data record        */
/*       and Shift the lines accordingly.  (ERS)                              */
/* The SWST value is therefore set to a constant value throughout the file    */
/*                                                                            */
/* modified to use the "off_t" calls (fseeko and ftello)                      */
/*  to process large (>2 GB) raw files when compiled with the necessary flags */
/*    EJF 2006/2/21                                                           */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>  
#include <sys/types.h>  /* off_t is hidden here under Mac OS 10.4 */
#include <string.h>

#define MaxPathLength   50

#define MaxCounterValue  1500
#define MinCounterValue  500

main(int argc, char *argv[]){
   FILE *infp, *outfp, *paramfp;
   char infile[MaxPathLength],outfile[MaxPathLength],paramfile[MaxPathLength];
   unsigned char *LineBufferIn, *LineBufferOut;
   int line,swst_counter,swst_counter_min,swst_counter_max,swst_counter_old;
   int line_number,actsizer,actsizew,no_header_flag,ok_flag,shift_max;
   int i,k;
   char pad[500];
   double i_bias=15.5;
   double q_bias=15.5;
   int SWSToffset;
   int swst_counter_first, PixelShift, end_k;
   int InWidth, OutWidth, xmin, xmax;
   int pad_top, pad_bottom;
   int ReferenceCounter;
   /*   double Pi=asin(1)*2.;*/

  if(argc < 3) {
    printf(" USAGE: delay_shift infile(str) outfile(str) param_file(str) SWSToffset(int) ReferenceCounter(int), \n ");
    printf("                    InWidth(int) xmin(int) xmax(int) pad_top(int) pad_bottom(int)\n");
    printf("  file:Image data\n");
    printf("  SWSToffset:Offset to the SWST counter\n");
    exit(1);
    }

  strcpy(infile,argv[1]); 
  strcpy(outfile,argv[2]); 
  strcpy(paramfile,argv[3]); 
  sscanf(argv[4],"%d",&SWSToffset);
  sscanf(argv[5],"%d",&ReferenceCounter);
  sscanf(argv[6],"%d",&InWidth);
  sscanf(argv[7],"%d",&xmin);
  sscanf(argv[8],"%d",&xmax);
  sscanf(argv[9],"%d",&pad_top);
  sscanf(argv[10],"%d",&pad_bottom);

  LineBufferIn=(unsigned char *)malloc(InWidth);

  if((infp=fopen(infile,"r")) == NULL){
      printf("%s file not open\n", infile);
      exit(1);
      }
  if((outfp=fopen(outfile,"w")) == NULL){
      printf("%s file not open\n", outfile);
      exit(1);
      }
  if((paramfp=fopen(paramfile,"w")) == NULL){
      printf("%s file not open\n", paramfile);
      exit(1);
      }
      
  fseeko(infp,0L,SEEK_END);
  line_number=(int)(ftello(infp)/(off_t)InWidth);
  printf("\n%d lines in file %s\n",line_number,infile);


  /*****************************/
  /*Check the min and max value*/
  /*****************************/
  swst_counter_old=0;
  swst_counter_min=MaxCounterValue;
  swst_counter_max=MinCounterValue;

  for (i=0;i<line_number;i++) {
    fseeko(infp,(off_t)InWidth*i+SWSToffset,0);
      swst_counter=var_B(2,infp);
      if (swst_counter!=swst_counter_old){
         printf("new counter: %d %d\n",swst_counter,swst_counter_old);
         if ((swst_counter<MaxCounterValue)&&(swst_counter>MinCounterValue)&& \
             (((swst_counter-ReferenceCounter)%22) == 0)){
             if (swst_counter == 0) swst_counter_first=swst_counter; 
             if (swst_counter<swst_counter_min)swst_counter_min=swst_counter;
             if (swst_counter>swst_counter_max)swst_counter_max=swst_counter;
             swst_counter_old=swst_counter;
            }
         }
      }

   if (swst_counter_old == 0){
      printf("No good range counter found\n");
      fclose(infp);
      exit(1);
      }
      
  /*****************/
  /*               */
  /*****************/
  OutWidth=xmax+(swst_counter_max-swst_counter_min)*8;
  fprintf(paramfp,"WIDTH         %d\n",OutWidth);
  fprintf(paramfp,"SWST_COUNTER  %d\n",swst_counter_min);
  LineBufferOut=(unsigned char *)malloc(OutWidth);
  fclose(paramfp);

  /***********************/
  /*Add some lines at top*/
  /***********************/
  rewind(infp);
  fread(LineBufferIn,1,InWidth,infp);
  for(k=0;k<xmin;k++){
     LineBufferOut[k]=LineBufferIn[k];
     end_k=k;
     }
  for(i=0;i<pad_top;i++){
     for(k=0;k<500;k=k+2){
        pad[k]=(int)i_bias;
        if(rand()%1000<1000*(i_bias-pad[k]))pad[k]=pad[k]+1;
        pad[k+1]=(int)q_bias;
        if(rand()%1000<1000*(q_bias-pad[k+1]))pad[k+1]=pad[k+1]+1;
        }
     for(k=end_k+1;k<OutWidth;k++){
        LineBufferOut[k]=pad[k%500];
        }
     fwrite(LineBufferOut,1,OutWidth,outfp);
     }

  /*****************/
  /*Shift the lines*/
  /*****************/
  swst_counter_old=swst_counter_first;
  rewind(infp);
  for (i=0;i<line_number;i++) {
    fseeko(infp,(off_t)InWidth*i+SWSToffset,0);
      swst_counter=var_B(2,infp);
      if (swst_counter!=swst_counter_old){
         if ((swst_counter<MaxCounterValue)&&(swst_counter>MinCounterValue)&& \
             (((swst_counter-ReferenceCounter)%22) == 0)){
            printf("New swst_counter: %d at line %d\n",(swst_counter_old=swst_counter),i);
	    }else{
            printf("Bad swst_counter: %d at line %d\n",swst_counter,i);
            }
         }

     for(k=0;k<500;k=k+2){
        pad[k]=(int)i_bias;
        if(rand()%1000<1000*(i_bias-pad[k]))pad[k]=pad[k]+1;
        pad[k+1]=(int)q_bias;
        if(rand()%1000<1000*(q_bias-pad[k+1]))pad[k+1]=pad[k+1]+1;
        }

     fseeko(infp,(off_t)InWidth*i,0);
     fread(LineBufferIn,1,InWidth,infp);
     PixelShift=8*(swst_counter_old-swst_counter_min);

     for(k=0;k<xmin;k++){
        LineBufferOut[k]=LineBufferIn[k];
        end_k=k;
        }
     LineBufferOut[SWSToffset]=(int)(swst_counter_min/256);
     LineBufferOut[SWSToffset+1]=swst_counter_min % 256;
     for(k=end_k+1;k<(xmin+PixelShift); k++){
        LineBufferOut[k]=pad[k%500];
        end_k=k;
        }
     for(k=end_k+1;k<(xmax+PixelShift); k++){
        LineBufferOut[k]=LineBufferIn[k-PixelShift];
        end_k=k;
        }
     for(k=end_k+1;k<OutWidth;k++){
        LineBufferOut[k]=pad[k%500];
        end_k=k;
        }
     fwrite(LineBufferOut,1,OutWidth,outfp);
     if ((i % 10000)==0)fprintf(stderr,"\rshifting line %d  \n",i   );
     }

   printf("\n");

  /**************************/
  /*Add some lines at bottom*/
  /**************************/
   fseeko(infp,(off_t)InWidth*(line_number-1),0);
  fread(LineBufferIn,1,InWidth,infp);
  for(k=0;k<xmin;k++){
     LineBufferOut[k]=LineBufferIn[k];
     end_k=k;
     }
  for(i=0;i<pad_bottom;i++){
     for(k=0;k<500;k=k+2){
        pad[k]=(int)i_bias;
        if(rand()%1000<1000*(i_bias-pad[k]))pad[k]=pad[k]+1;
        pad[k+1]=(int)q_bias;
        if(rand()%1000<1000*(q_bias-pad[k+1]))pad[k+1]=pad[k+1]+1;
        }
     for(k=end_k+1;k<OutWidth;k++){
        LineBufferOut[k]=pad[k%500];
        }
     fwrite(LineBufferOut,1,OutWidth,outfp);
     }

   fclose(infp);
   fclose(outfp);
   }


int var_B(int i,FILE *infp)
 {
  int k,c;
  int n;
  n=0;
  for (k=i;k>0;k--) n=n*256+fgetc(infp);
  return(n);
 }

/* not used anymore EJF 2006 */
/* int fReadBinary(off_t FirstByte, off_t LastByte,FILE *infp) */
/*  { */
/*   int k; */
/*   unsigned n; */
/*   n=0; */
/*   fseeko(infp,FirstByte-1,0); */
/*   for (k=LastByte-FirstByte;k>=0;k--) n=n*256+fgetc(infp); */
/*   return(n); */
/*  } */

//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD USAGE: delay_shift infile(str) outfile(str) param_file(str) SWSToffset(int) ReferenceCounter(int) \
//POD                    nWidth(int) xmin(int) xmax(int) pad_top(int) pad_bottom(int)
//POD              where, file:       Image data
//POD                     SWSToffset: Offset to the SWST counter [sampling window start time(SWST)]
//POD 
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION: "delay_shift"    
//POD  Read the sampling window start time(SWST) in the signal data record      
//POD  and Shift the lines accordingly.  (ERS)                            
//POD  The SWST value is therefore set to a constant value throughout the file  
//POD
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD ROI_PAC/INT_SCR/make_raw.pl
//POD
//POD=head1 FILES USED
//POD
//POD "Infile": binary Byte/char data array 
//POD
//POD=head1 FILES CREATED
//POD
//POD "OutFile" contains the shifted, cropped and padded version of "Infile"
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD "param_file" with the New, output, WIDTH  and WST_COUNTER of Outfile
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez 6-17-96
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD POD comments trm Feb 3rd '04
//POD=cut
