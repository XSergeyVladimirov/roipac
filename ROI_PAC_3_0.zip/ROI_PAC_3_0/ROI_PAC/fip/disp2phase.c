/*  *** JPL/Caltech Repeat Orbit Interferometry (ROI) Package ***   */

#include <stdio.h>
#include <math.h>
#include <string.h>

/*Right Looking SAR*/

main(int argc, char *argv[]){
  /***************************/
  /***  Input Variables    ***/
  /***************************/
  double RangeStart, RangeStep;
  double EarthRadius, Height, Heading, Wavelength;
  int Width;
  char OutFile[1000];
  char EastFile[1000];
  char NorthFile[1000];
  char UpFile[1000];
  /***************************/
  /***  Local Variables    ***/
  /***************************/
  FILE *OutFP, *EastFP, *NorthFP, *UpFP;
  float *Out, *East, *North, *Up;
  int i,j;
  int UpData;
  double Pi=4*atan2(1,1);
  double dr,dh,r;
  double sini;
  double *Incidence;
  int Length;
  /***************************/
  /***    Get  Input       ***/
  /***************************/
  UpData=0;
  if(argc>11)UpData=1;
  if(argc < 10){
    printf("   usage:%s RangeStart RangeStep EarthRadius Height Heading\
    WaveLength Width OutFile EastFile NorthFile [UpFile]\n",argv[0]);
    exit(0);
    }
  sscanf(argv[1],"%lf",&RangeStart);
  sscanf(argv[2],"%lf",&RangeStep);
  sscanf(argv[3],"%lf",&EarthRadius);
  sscanf(argv[4],"%lf",&Height);
  sscanf(argv[5],"%lf",&Heading);
  sscanf(argv[6],"%lf",&Wavelength);
  sscanf(argv[7],"%d",&Width);
  sprintf(OutFile,"%s",argv[8]);
  sprintf(EastFile,"%s",argv[9]);
  sprintf(NorthFile,"%s",argv[10]);
  if(UpData){
    sprintf(UpFile,"%s",argv[11]);
    printf("Upfile: %s\n",UpFile);
    }
  /***************************/
  /***      Open Files     ***/
  /***************************/
  if((OutFP=fopen(OutFile,"w"))==NULL){
    fprintf(stderr,"OutFile %s not open\n",OutFile);
    exit(1);
    }
  if((EastFP=fopen(EastFile,"r"))==NULL){
    fprintf(stderr,"EastFile %s not open\n",EastFile);
    exit(1);
    }
  fseek(EastFP,0L,SEEK_END);
  Length=ftell(EastFP)/(sizeof(float)*Width);
  rewind(EastFP);
  if((NorthFP=fopen(NorthFile,"r"))==NULL){
    fprintf(stderr,"NorthFile %s not open\n",NorthFile);
    exit(1);
    }
  if(UpData){
    if((UpFP=fopen(UpFile,"r"))==NULL){
      fprintf(stderr,"UpFile %s not open\n",UpFile);
      exit(1);
      }
    }
Incidence=(double *)malloc(sizeof(double)*Width);
Out=(float *)malloc(sizeof(float)*Width);
East=(float *)malloc(sizeof(float)*Width);
North=(float *)malloc(sizeof(float)*Width);
if(UpData)Up=(float *)malloc(sizeof(float)*Width);
  /***************************/
  /***    Compute phase    ***/
  /***************************/
  for(i=0;i<Width;i++){
    r=RangeStart+i*RangeStep;
    sini=Height/r-r/(2*EarthRadius)*(1.-(Height/r)*(Height/r));
    Incidence[i]=atan2(sini,sqrt(1.-sini*sini));
    }
  for(j=0;j<Length;j++){
    fread(East,sizeof(float),Width,EastFP);
    fread(North,sizeof(float),Width,NorthFP);
    if(UpData)fread(Up,sizeof(float),Width,UpFP);
    for(i=0;i<Width;i++){
      dh=East[i]*cos(Heading)-North[i]*sin(Heading);
      dr=dh*cos(Incidence[i]);
      if(UpData)dr+=-1.*Up[i]*sin(Incidence[i]);
      Out[i]=dr*4.*Pi/Wavelength; 
      }
    fwrite(Out,sizeof(float),Width,OutFP);
    }

  /***************************/
  /***         End         ***/
  /***************************/
  return(0);
}

//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage:disp2phase RangeStart(dbl) RangeStep(dbl) EarthRadius(dbl)
//POD                  Height(dbl) Heading(dbl) WaveLength(dbl) Width(int)
//POD    OutFile(str) EastFile(str) NorthFile(str) [UpFile(str)]
//POD 
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION: "disp2phase" computes phase change   
//POD from a displacement field [NorthFile,EastFile], with optional 
//POD uplift [UpFile], and an angle of incidence computed from
//POD orbit data. All input (2 or 3) and output files have the same 
//POD record length: "Width".
//POD
//POD r=RangeStart+i*RangeStep;  
//POD sini=Height/r-r/(2*EarthRadius)*(1.-(Height/r)*(Height/r));
//POD Incidence[i]=atan2(sini,sqrt(1.-sini*sini));
//POD
//POD dh=East[i]*cos(Heading)-North[i]*sin(Heading);
//POD dr=dh*cos(Incidence[i]);
//POD if(UpData)dr+=-1.*Up[i]*sin(Incidence[i]);
//POD Out[i]=dr*4.*Pi/Wavelength; 
//POD
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Two files containg shifts in "Northing & Easting" directions as flat r*4/float binary files.
//POD
//POD=head1 FILES CREATED
//POD
//POD "OutFile" contains the simulated phased (r*4/float) due to the displacements field [EastFile,NorthFile,[UpFile]]
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD POD comments trm Jan 29th '04
//POD=cut
