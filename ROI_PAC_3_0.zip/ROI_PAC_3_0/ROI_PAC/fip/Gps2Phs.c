#include <stdio.h>  
#include <string.h>
#include <math.h>

main(int argc, char *argv[])
{
  /*****************************/
  /*****  Input  variables  ****/
  /*****************************/
  char GpsFileName[1000];
  char DispFileName[1000];
  float Long0;
  float Lat0;
  float DeltaLong;
  float DeltaLat;
  float Radius;
  int Width;
  int Length;
  float Incidence=23;
  float Heading=193;

  /*****************************/
  /*****  Output variables  ****/
  /*****************************/
  
  /*****************************/
  /*****  Local  variables  ****/
  /*****************************/
  FILE *GpsFp;
  FILE *DispFp;
  float GpsLong[10000];
  float GpsLat[10000];
  float GpsDispLong[10000];
  float GpsDispLat[10000];
  float GpsDispV[10000];
  int GpsNumber;
  int nx;
  int ny;
  float DispLong;
  float DispLat;
  float *Disp;
  int GpsIndex;
  int GpsClosest;
  float GpsDistance;
  float GpsDistanceMin;
  float Degres=asin(1)/90;
  /*****************************/
  /***** Arguments reading  ****/
  /*****************************/
  sscanf(argv[1],"%s",GpsFileName);
  sscanf(argv[2],"%s",DispFileName);
  sscanf(argv[3],"%g",&Long0);
  sscanf(argv[4],"%g",&Lat0);
  sscanf(argv[5],"%g",&DeltaLong);
  sscanf(argv[6],"%g",&DeltaLat);
  sscanf(argv[7],"%g",&Radius);
  sscanf(argv[8],"%d",&Width);
  sscanf(argv[9],"%d",&Length);

  if((GpsFp=fopen(GpsFileName,"r"))==NULL){
    fprintf(stderr,"file %s not open\n",GpsFileName);
    exit(1);
  }
  if((DispFp=fopen(DispFileName,"w"))==NULL){
    fprintf(stderr,"file %s not open\n",DispFileName);
    exit(1);
  }
  if((Disp=(float *)malloc(Width*sizeof(float)))==NULL){
    fprintf(stderr,"Unable to allocate memory");
    exit(1);
  }
  /*****************************/
  /***** Gps File  reading  ****/
  /*****************************/
  GpsNumber=0;
  while(fscanf(GpsFp,"%g %g %g %g %g\n",&GpsLong[GpsNumber],&GpsLat[GpsNumber], \
               &GpsDispLong[GpsNumber],&GpsDispLat[GpsNumber],&GpsDispV[GpsNumber])==5) GpsNumber++;
  printf("%d GpsDataPoint\n",GpsNumber);
  /*****************************/
  /***** Disp File  filling  ****/
  /*****************************/
  for(ny=0;ny<Length;ny++){
    if((ny % 1) == 0)fprintf(stderr,"\r%d",ny); 
    DispLat=Lat0+ny*DeltaLat;
    for(nx=0;nx<Width;nx++){
      DispLong=Long0+nx*DeltaLong;

      GpsClosest=-1;
      GpsDistanceMin=nx*DeltaLong*10000;
      for(GpsIndex=0;GpsIndex<GpsNumber;GpsIndex++){
        GpsDistance=sqrt(pow(DispLong-GpsLong[GpsIndex],2)+pow(DispLat-GpsLat[GpsIndex],2));
        /*  printf("%f\n", GpsDistance); */
        if(GpsDistance<GpsDistanceMin){
          GpsDistanceMin=GpsDistance;
          GpsClosest=GpsIndex;
/*   printf("%d %f\n",GpsClosest, GpsDistance);  */
        }
      }
      /*   printf("%d %f\n",GpsClosest, GpsDistance); */ 

      if(GpsDistanceMin<Radius){
        Disp[nx]=(GpsDispLong[GpsClosest]*cos(Heading*Degres)-GpsDispLat[GpsClosest]*sin(Heading*Degres))
          *sin(Incidence*Degres)+GpsDispV[GpsClosest]*cos(Incidence*Degres);
        Disp[nx]=-1.*Disp[nx]*360*Degres/.028;
      }else{
        Disp[nx]=0;
      }
    }
      fwrite(Disp,sizeof(float),Width,DispFp);
      fflush(DispFp);
  }
  fclose(DispFp);
  fclose(GpsFp);
}
//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage: GPS2Phs GpsFileName DispFileName Long0 Lat0 DeltaLong DeltaLat Radius Width Length
//POD                string  GpsFileName
//POD                string  DispFileName
//POD                float Long0
//POD                float Lat0
//POD                float DeltaLong
//POD                float DeltaLat
//POD                float Radius
//POD                int   Width
//POD                int   Length
//POD
//POD//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION: Transform GPS data consisting of lat/lon points with
//POD lat/lon displacement into a lat/lon raster file of displacement phases of the closest GPS point 
//POD 
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Two input files "GpsFileName"
//POD
//POD=head1 FILES CREATED
//POD
//POD New float/r*4 "DispFileName" arrays (Width X Length)..
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez ?
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD POD comments trm Feb 3rd '04
//POD=cut



