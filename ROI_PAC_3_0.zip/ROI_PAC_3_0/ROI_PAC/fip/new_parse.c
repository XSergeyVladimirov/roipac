#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define MaxGap 10000

int Buffer2Integer(int ,unsigned char *);

main(int argc, char *argv[]){
  /***********************************/
  /*******   Input Variables   *******/
  /***********************************/
  int  LineLength;
  int  LineCounterOffset;
  int  LineCounterLength;
  int  RemoveInputFiles;
  char InFile[100][1000];
  char OutFile[1000];
  /***********************************/
  /*******   Local Variables   *******/
  /***********************************/
  int GoodInit;
  int NumberOfInputFile;
  int InputFileIndex;
  char ReportFile[1000];
  FILE *InFP, *OutFP, *ReFP;
  char HeaderFlagStr[4];
  char LineCounterStr[4];
  int  HeaderFlag;
  int  LineCounter,OldLineCounter,LineGap;
  int  InputLineIndex, OutputLineIndex;
  unsigned char *BufferLine;
  int OverLapFlag;
  double Pi=asin(1)*2.;
  
  int  i;
  /***********************************/
  /*******   Initialisation    *******/
  /***********************************/
  GoodInit=1;
  NumberOfInputFile=argc-6;
  if(!GoodInit || (NumberOfInputFile < 1)){
    printf("\nUsage: %s <line length><line counter offset><line counter length><remove input Files><input File>[input Files...]<output File>\n",argv[0]);
    printf("line length:          number of byte per line\n");
    printf("line counter offset:  0 for the first byte of the line\n");
    printf("line counter length:  in byte\n");
    printf("remove input Files:   1 to remove them, 0 to keep them\n");
    printf("input File(s):        raw data File(s)\n");
    printf("output File(s):       raw data File\n");
    exit(-1);
  }
  if(GoodInit)GoodInit*=sscanf(argv[1],"%d",&LineLength);
  if(GoodInit)GoodInit*=sscanf(argv[2],"%d",&LineCounterOffset);
  if(GoodInit)GoodInit*=sscanf(argv[3],"%d",&LineCounterLength);
  if(GoodInit)GoodInit*=sscanf(argv[4],"%d",&RemoveInputFiles);
  if(!GoodInit || (NumberOfInputFile < 1)){
    printf("\nUsage: %s <line length><line counter offset><line counter length><remove input Files><input File>[input Files...]<output File>\n",argv[0]);
    printf("line length:          number of byte per line\n");
    printf("line counter offset:  0 for the first byte of the line\n");
    printf("line counter length:  in byte\n");
    printf("remove input Files:   1 to remove them, 0 to keep them\n");
    printf("input File(s):        raw data File(s)\n");
    printf("output File(s):       raw data File\n");
    exit(-1);
  }
  for(InputFileIndex=0;InputFileIndex<NumberOfInputFile;InputFileIndex++){
    strcpy(InFile[InputFileIndex],argv[InputFileIndex+5]);
    printf("File%d: %s\n",InputFileIndex,InFile[InputFileIndex]);
  }
  strcpy(OutFile,argv[NumberOfInputFile+5]);
  sprintf(ReportFile,"%s_parse_line.out\0",OutFile);
  
  if((OutFP=fopen(OutFile,"w")) == NULL){
    printf("output File (%s) cannot be open for writing",OutFile);
    exit(-1);
  }
  if((ReFP=fopen(ReportFile,"w")) == NULL){
    printf("report File (%s) cannot be open for writing",ReportFile);
    exit(-1);
  }
  
  BufferLine=(unsigned char *)malloc(LineLength);
  LineCounter=007;
  OldLineCounter=006;
  OutputLineIndex=0;
  /***********************************/
  /*******   Line Checking     *******/
  /***********************************/
  for(InputFileIndex=0;InputFileIndex<NumberOfInputFile;InputFileIndex++){
    fprintf(stderr,"\n%d",InputLineIndex);
    if((InFP=fopen(InFile[InputFileIndex],"r")) == NULL){
      printf("input File (%s) cannot be open for reading",InFile[InputFileIndex]);
      exit(-1);
    }
    InputLineIndex=(-1);
    while(fread(BufferLine,1,LineLength,InFP) == LineLength){
      InputLineIndex++;
      if((InputLineIndex % 1000) == 0)fprintf(stderr,"\r%d",InputLineIndex);
      
      HeaderFlag=Buffer2Integer(4,BufferLine);
      if(HeaderFlag==1)continue;
      
      LineCounter=Buffer2Integer(LineCounterLength,BufferLine+LineCounterOffset);
 /*     printf("%d\n",LineCounter); */
      if((InputFileIndex == 0) && (InputLineIndex < 3)){
	if(fwrite(BufferLine,1,LineLength,OutFP) == LineLength)OutputLineIndex++;
	OldLineCounter=LineCounter;
	continue;
      }
      if(LineCounter == 0){
	fwrite(BufferLine,1,LineLength,OutFP);
	OldLineCounter++;
	fprintf(ReFP,"%s line %d : line counter jumps to 0\n",InFile[InputFileIndex],InputLineIndex);
	continue;
      }
      LineGap=LineCounter-OldLineCounter-1;
      
      switch(LineGap){
      case -1 : if(OverLapFlag != 1){
	fprintf(ReFP,"%s line %d : DuplicatedLine(s) removed\n",InFile[InputFileIndex],InputLineIndex);
	break;
      }
      case 0  : if(fwrite(BufferLine,1,LineLength,OutFP) == LineLength)OutputLineIndex++;
	/*    printf("%d\n",LineCounter);*/
	OldLineCounter++;
	break;
      default : if((LineGap > 0) &&(LineGap < MaxGap)){
	fprintf(ReFP,"%s line %d : %d missing lines\n",InFile[InputFileIndex],InputLineIndex,LineGap);
	for(i=0;i<LineGap;i++){
	  if(fwrite(BufferLine,1,LineLength,OutFP) == LineLength)OutputLineIndex++;  
	  OldLineCounter++;
	  fprintf(ReFP,"%s line %d : line duplicated to output line %d\n",InFile[InputFileIndex],InputLineIndex,LineGap,OutputLineIndex);
	}
	if(fwrite(BufferLine,1,LineLength,OutFP) == LineLength)OutputLineIndex++;  
	OldLineCounter++;
      }
      if((LineGap > 0) &&(LineGap >= MaxGap)){
	fprintf(ReFP,"Bad counter value(%d) at line %d\n",LineCounter,InputLineIndex);
      }
      }
    }
    fclose(InFP);
    fprintf(stderr,"\n");
  }
  fprintf(ReFP,"%s now has %d lines\n",OutFile,OutputLineIndex);
  fclose(OutFP);
  fflush(ReFP);
  fclose(ReFP);
}

int Buffer2Integer(int i,unsigned char *p){
  int k;
  int n=0;
  for(k=i;k>0;k--) {
    n=n*256+(*p);
    p++;
  }
  return(n);
}


