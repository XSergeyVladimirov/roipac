#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#define OrbitLineLength 130
#define MaxPolynomOrder  4
#define PolynomNumber 6

double date2J2000(double,double,double,double,double,double);

main(int argc, char *argv[]){
   /*****************************/
   /*****  Input  variables  ****/
   /*****************************/
   char OrbitFile[1000];
   double UTC_Ref_s_of_day;
   double UTC_Ref_day_of_month;
   double UTC_Ref_month_of_year;
   double UTC_Ref_year;
   /*****************************/
   /*****  Output variables  ****/
   /*****************************/
   double Coeff[PolynomNumber][MaxPolynomOrder+1];
   /*****************************/
   /*****  Local  variables  ****/
   /*****************************/
   double Values[PolynomNumber][MaxPolynomOrder+1];
   double SampleTime[MaxPolynomOrder+1];
   int ActualPolynomOrder;
   FILE *OrbitFP;
   double TDToffset_UTC;
   double FirstDataJulDay,FirstDataTDT,LastDataJulDay,LastDataTDT,DataTimeInterval;
   double RefJulDay,RefTDT;
   int PosLine;
   int d,dd,i,k,l;
   int result;
   char StrArcStart[10],StrArcEnd[10],StrRmsFit[10],StrSigmaX[10],StrSigmaV[10];
   char StrQuality[10],StrTDTUTC[10];
   int ThisArcStart,ThisArcEnd,ThisRmsFit,ThisSigmaX,ThisSigmaV,ThisQuality,ThisTDTUTC ;
   char StrJD[15],StrTDT[15],StrX[15],StrY[15],StrZ[15],StrVX[15],StrVY[15],StrVZ[15],StrDR[15];
   int ThisJD,ThisDR;
   double ThisTDT,ThisX,ThisY,ThisZ,ThisVX,ThisVY,ThisVZ;
   char ObservationStr[7],ObsLevelStr[7],CommentStr[80];
   double Step[PolynomNumber];
   double StepCoeff[PolynomNumber][MaxPolynomOrder+1];
   char s[1000];
   int FirstDataLine,LastDataLine;  
   double Pi=asin(1)*2.;
   
   char PolynomName[PolynomNumber][100];
   sprintf(PolynomName[0],"STATE_VECTOR_X");
   sprintf(PolynomName[1],"STATE_VECTOR_Y");
   sprintf(PolynomName[2],"STATE_VECTOR_Z");
   sprintf(PolynomName[3],"STATE_VECTOR_VX");
   sprintf(PolynomName[4],"STATE_VECTOR_VY");
   sprintf(PolynomName[5],"STATE_VECTOR_VZ");

   /* Zero out Variables */
   FirstDataLine = 0;
   memset(StrArcStart,0,sizeof(StrArcStart));
   memset(StrArcEnd,0,sizeof(StrArcEnd));
   memset(ObservationStr,0,sizeof(ObservationStr));
   memset(ObsLevelStr,0,sizeof(ObsLevelStr));
   memset(StrRmsFit,0,sizeof(StrRmsFit));
   memset(StrSigmaX,0,sizeof(StrSigmaX));
   memset(StrSigmaV,0,sizeof(StrSigmaV));
   memset(StrQuality,0,sizeof(StrQuality));
   memset(StrTDTUTC,0,sizeof(StrTDTUTC));
   memset(CommentStr,0,sizeof(CommentStr));

   /*****************************/
   /***** Arguments reading  ****/
   /*****************************/
   sprintf(OrbitFile,argv[1]);
   if((OrbitFP=fopen(OrbitFile,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",OrbitFile);
      exit(1);
      }
   sscanf(argv[2],"%lf",&UTC_Ref_s_of_day);
   sscanf(argv[3],"%lf",&UTC_Ref_day_of_month);
   sscanf(argv[4],"%lf",&UTC_Ref_month_of_year);
   sscanf(argv[5],"%lf",&UTC_Ref_year);
   /*****************************/
   /*****Orbit header reading****/
   /*****************************/
   fseek(OrbitFP,OrbitLineLength,SEEK_SET);
   result=fscanf(OrbitFP,"STATE%*1c%6c%6c%6c%6c%*2c%*2c%4c%4c%4c%1c%5c%78c",
                 StrArcStart,StrArcEnd,ObservationStr,ObsLevelStr,StrRmsFit,
                 StrSigmaX,StrSigmaV,StrQuality,StrTDTUTC,CommentStr);
   sscanf(StrArcStart,"%6d",&ThisArcStart);
   sscanf(StrArcEnd,"%6d",&ThisArcEnd);
   sscanf(StrTDTUTC,"%5d",&ThisTDTUTC);
   sscanf(StrRmsFit,"%4d",&ThisRmsFit);
   sscanf(StrSigmaX,"%4d",&ThisSigmaX);
   sscanf(StrSigmaV,"%4d",&ThisSigmaV);
   sscanf(StrQuality,"%1d",&ThisQuality);
   if(result != 10){
      fprintf(stderr,"The orbit file cannot be read properly.\n");
      fprintf(stderr,"Check the OrbitLineLength.\n");
      }
   /**/sscanf(StrArcStart,"%6d",&ThisArcStart);
   fprintf(stderr,"ThisArcStart:%d\n",ThisArcStart);
   fprintf(stderr,"ThisArcEnd:%d\n",ThisArcEnd);
   fprintf(stderr,"ObservationStr:%s\n",ObservationStr);
   fprintf(stderr,"ObsLevelStr:%s\n",ObsLevelStr);
   fprintf(stderr,"ThisRmsFit:%d mm\n",ThisRmsFit);
   fprintf(stderr,"ThisSigmaX:%d mm\n",ThisSigmaX);
   fprintf(stderr,"ThisSigmaV:%d mm\n",ThisSigmaV);
   fprintf(stderr,"ThisQuality:%d\n",ThisQuality);
   fprintf(stderr,"ThisTDTUTC:%d\n",ThisTDTUTC);
   fprintf(stderr,"ThisTDTUTC:%8.3f\n",ThisTDTUTC/1000.);
   fprintf(stderr,"CommentStr:%s\n",CommentStr);/**/
      
   /*The previous readings may not be available. Here are the usefull parameters:*/
   
   fseek(OrbitFP,OrbitLineLength,SEEK_SET);
   result=fscanf(OrbitFP,"STATE%*1c%6c%6c%*6c%*6c%*2c%*2c%*4c%*4c%*4c%*1c%5c%*78c",
                 StrArcStart,StrArcEnd,StrTDTUTC);
   sscanf(StrArcStart,"%6d",&ThisArcStart);
   sscanf(StrArcEnd,"%6d",&ThisArcEnd);
   sscanf(StrTDTUTC,"%5d",&ThisTDTUTC);
   if(result != 3){
      fprintf(stderr,"The orbit file cannot be read properly.\n");
      fprintf(stderr,"Check the OrbitLineLength.\n");
      exit(2);
      }
   TDToffset_UTC=ThisTDTUTC/1000.;
   FirstDataJulDay=ThisArcStart/10.;  /*These are the conservative estimates from the header*/
   LastDataJulDay=ThisArcEnd/10.;     /*We need more precise data to select the "good" lines*/
   
   /*****************************/
   /***** Orbit file reading ****/
   /*****************************/
   rewind(OrbitFP);i=0;
   while(!feof(OrbitFP)){
      fseek(OrbitFP,i*OrbitLineLength,SEEK_SET);
      fscanf(OrbitFP,"%6c",s);s[6]='\0';
      if(!strcmp(s,"STTERR") && (FirstDataLine == 0))FirstDataLine=i;
      if( strcmp(s,"STTERR") && (FirstDataLine != 0)){
         LastDataLine=i-1;
         break;
         }
      i++;
      }
   fprintf(stderr,"first-last: %d %d\n",FirstDataLine,LastDataLine);
      
   fseek(OrbitFP,OrbitLineLength*FirstDataLine,SEEK_SET);
   result=fscanf(OrbitFP,"STTERR%*7d%*1c%6c%11c",StrJD,StrTDT);
   sscanf(StrJD,"%6d",&ThisJD);
   sscanf(StrTDT,"%11lf",&ThisTDT);
   if(result != 2){
      fprintf(stderr,"The orbit file cannot be read properly.\n");
      exit(3);
      }
   FirstDataJulDay=ThisJD/10.;
   FirstDataTDT=ThisTDT/1000000.;

   fseek(OrbitFP,OrbitLineLength*(FirstDataLine+1),SEEK_SET);
   result=fscanf(OrbitFP,"STTERR%*7d%*1c%6c%11c",StrJD,StrTDT);
   sscanf(StrJD,"%6d",&ThisJD);
   sscanf(StrTDT,"%11lf",&ThisTDT);
   if(result != 2){
      fprintf(stderr,"The orbit file cannot be read properly.\n");
      exit(4);
      }
   DataTimeInterval=(ThisJD/10.-FirstDataJulDay)*86400+ThisTDT/1000000.-FirstDataTDT;
   
   fseek(OrbitFP,OrbitLineLength*LastDataLine,SEEK_SET);
   result=fscanf(OrbitFP,"STTERR%*7d%*1c%6c%11c",StrJD,StrTDT);
   sscanf(StrJD,"%6d",&ThisJD);
   sscanf(StrTDT,"%11lf",&ThisTDT);
   if(result != 2){
      fprintf(stderr,"The orbit file cannot be read properly.\n");
      exit(5);
      }
   LastDataJulDay=ThisJD/10.;
   LastDataTDT=ThisTDT/1000000.;

   /*****************************/
   /***** Orbit data reading ****/
   /*****************************/
   RefJulDay=date2J2000(UTC_Ref_year,UTC_Ref_month_of_year,UTC_Ref_day_of_month,0.,0.,0.);
   RefTDT=UTC_Ref_s_of_day+TDToffset_UTC;
   
   fprintf(stderr,"Reference:%f %f\n",RefJulDay,RefTDT);
   fprintf(stderr,"Data     :%f %f\n",FirstDataJulDay,FirstDataTDT);
   fprintf(stderr,"Data     :%f %f\n",LastDataJulDay,LastDataTDT);
   
   if((RefJulDay < FirstDataJulDay) || 
     ((RefJulDay == FirstDataJulDay) && (RefTDT < FirstDataTDT))){
      fprintf(stderr,"The reference time cannot be found in : %s\n",OrbitFile);
      fprintf(stderr,"You need to use an orbit file for an earlier arc.\n");
      exit(6);
      }
   if((RefJulDay > LastDataJulDay) || 
     ((RefJulDay == LastDataJulDay) && (RefTDT > LastDataTDT))){
      fprintf(stderr,"The reference time cannot be found in : %s\n",OrbitFile);
      fprintf(stderr,"You need to use an orbit file for a later arc.\n");
      exit(7);
      }

   PosLine=(int)(((RefJulDay-FirstDataJulDay)*86400+(RefTDT-FirstDataTDT))
                       /DataTimeInterval+FirstDataLine-MaxPolynomOrder/2);
   ActualPolynomOrder=-1;
   for(i=0;i<MaxPolynomOrder+1;i++){
      fseek(OrbitFP,(PosLine+i)*OrbitLineLength,SEEK_SET);
      result=fscanf(OrbitFP,"STTERR%*7d%*1c%6c%11c%12c%12c%12c%11c%11c%11c%*6c%*6c%*6c%*2c%*3c%1c%4c%*2c",
             StrJD,StrTDT,StrX,StrY,StrZ,StrVX,StrVY,StrVZ,StrQuality,StrDR);
      StrX[12] = '\0'; StrY[12] = '\0'; StrZ[12] = '\0';
      StrVX[12] = '\0'; StrVY[12] = '\0'; StrVZ[12] = '\0';
      sscanf(StrJD,"%6d",&ThisJD);
      sscanf(StrTDT,"%11lf",&ThisTDT);
      sscanf(StrX,"%12lf",&ThisX); 
      sscanf(StrY,"%12lf",&ThisY); 
      sscanf(StrZ,"%12lf",&ThisZ); 
      sscanf(StrVX,"%11lf",&ThisVX);
      sscanf(StrVY,"%11lf",&ThisVY);
      sscanf(StrVZ,"%11lf",&ThisVZ);
      sscanf(StrQuality,"%1d",&ThisQuality);
     if((result == 10) && (abs(ThisJD/10.-RefJulDay)< 0.000001) && (ThisQuality == 0)){
         ActualPolynomOrder++;
         SampleTime[ActualPolynomOrder]=ThisTDT/1000000.-TDToffset_UTC;
         Values[0][ActualPolynomOrder]=ThisX/1000.;
         Values[1][ActualPolynomOrder]=ThisY/1000.;
         Values[2][ActualPolynomOrder]=ThisZ/1000.; 
         Values[3][ActualPolynomOrder]=ThisVX/1000000.;
         Values[4][ActualPolynomOrder]=ThisVY/1000000.;
         Values[5][ActualPolynomOrder]=ThisVZ/1000000.; 
         }
      if((result == 10) && (abs(ThisJD/10.-RefJulDay)< 0.000001) && (ThisQuality == 1)){
         fprintf(stderr,"By manoeuvre degraded state\n");
         }
      if((result != 10) || (abs(ThisJD/10.-RefJulDay)> 0.000001)){
         fprintf(stderr,"Cannot get orbit data\n");
	 fprintf(stderr,"%d %f %f\n",result,ThisJD/10.,ThisTDT);
         }
      }
   /*   for(i=0;i<PolynomNumber;i++){
      for(d=0;d<ActualPolynomOrder+1;d++){
         printf("%10s%d %g %-12.12g\n",PolynomName[i],d,SampleTime[d],Values[i][d]);
         }
	 } */
   /*****************************/
   /*****Polynom coefficients****/
   /*****************************/
   for(i=0;i<PolynomNumber;i++){
      for(d=0;d<ActualPolynomOrder+1;d++)Coeff[i][d]=0;
      for(k=0;k<ActualPolynomOrder+1;k++){
         Step[i]=Values[i][k];
         for(l=0;l<ActualPolynomOrder+1;l++)if(l!=k){
            Step[i]=Step[i]/(SampleTime[k]-SampleTime[l]);
            }
         StepCoeff[i][0]=Step[i];
         for(d=1;d<ActualPolynomOrder+1;d++)StepCoeff[i][d]=0;
         dd=0;
         for(l=0;l<ActualPolynomOrder+1;l++)if(l!=k){
            dd++;
            StepCoeff[i][dd]=StepCoeff[i][dd-1];
            for(d=dd-1;d>0;d--)StepCoeff[i][d]=StepCoeff[i][d-1]+StepCoeff[i][d]*(UTC_Ref_s_of_day-SampleTime[l]);
            StepCoeff[i][0]=StepCoeff[i][0]*(UTC_Ref_s_of_day-SampleTime[l]);
            }
         for(d=0;d<ActualPolynomOrder+1;d++)Coeff[i][d]=Coeff[i][d]+StepCoeff[i][d];
         }
      }
   /*****************************/
   /*****       Output       ****/
   /*****************************/
   printf("STATE_VECTOR_POLYNOM_ORDER %d\n",ActualPolynomOrder);
   for(d=0;d<ActualPolynomOrder+1;d++){
      for(i=0;i<PolynomNumber;i++){
         printf("%10s%d %-12.12g\n",PolynomName[i],d,Coeff[i][d]);
         }
      }
  for(d=0;d<ActualPolynomOrder+1;d++)
     printf("STATE_VECTOR_UTC%d %f\n",d,SampleTime[d]);
     printf("STATE_VECTOR_UTC_REFERENCE %f\n",UTC_Ref_s_of_day);
   /*****************************/
   /*****       Test         ****/
   /*****************************/
     /*   for(i=0;i<PolynomNumber;i++){
      Step[i]=0;
      for(d=ActualPolynomOrder;d>=0;d--){
         Step[i]=Step[i]*(SampleTime[3]*0+1*66000.-UTC_Ref_s_of_day)+Coeff[i][d];
         }
      printf("%10s %-12.12g\n",PolynomName[i],Step[i]);
      }
      printf("%f %f\n",SampleTime[3]*0+1*66000.,UTC_Ref_s_of_day);*/
   /*****************************/
   /*****     The end        ****/
   /*****************************/

     exit(0);
   }
   
   
   
/*********************************************************/
   
  
double date2J2000(double year,double month,double day,double hour,double minute,double second){
   double m[13];
   double j2,a,t;
   
   m[0]=0.;
   m[1]=0.;m[2]=31.;m[3]=59.;m[4]=90.;m[5]=120.;m[6]=151.;
   m[7]=181.;m[8]=212.;m[9]=243.;m[10]=273.;m[11]=304.;m[12]=334.;

   j2=m[(int)month]+day+(hour+minute/60.+second/3600.)/24.-1;
   a=((int)year%4)/4.;
   if(a==0)a=1;
   if((a==1)*(month>=3))j2=j2+1;
   t=(year-2000)*365.25+.5+j2-a;
   return(t);
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
