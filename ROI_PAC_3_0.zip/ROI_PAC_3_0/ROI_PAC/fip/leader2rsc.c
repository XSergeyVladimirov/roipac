/*************************************************************************/
/*   Create parameter file for ERS1 scene                                */
/*								         */
/*Compile cc leader_to_info.c reader.c -o ../bin/leader_to_info -Aa -lm  */
/*Compile acc leader_to_info.c reader.c -o ../bin/leader_to_info -ldl    */
/*************************************************************************/

#include <stdlib.h>
#include <stdio.h>  
#include <string.h>
#include <math.h>


double fReadDouble(int,int,FILE*);
int fReadBinary(int,int,FILE*);

#define MaxPathLength 100         /**/
#define MaxCommandLength 200      /**/
#define MaxNameLength 50          /**/
#define FormatLineLength 1000
#define MaxFieldLength 100
#define MaxNumberOfRecord 20

/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
int FindInteger(FILE *InfoFile,char *Keyword,int *value){
   char DataString[100000],*c;
   long length;
   double Pi=asin(1)*2.;
   
   fseek(InfoFile,0L,SEEK_END);
   length=ftell(InfoFile);
   if(length>99999)length=99999;
   rewind(InfoFile);
   fread(DataString,sizeof(DataString[0]),length-1,InfoFile);
   strcat(DataString,'\0');
   if((c=strstr(DataString,Keyword))!=NULL){
      if(sscanf(c,"%*s %d ",value)==1){
         return(c-DataString);
         }else{
         printf("Value not found for %s\n",Keyword);
         return(-1);
         }
      }else{
      printf("KW %s not found\n",Keyword);
      return(-1);
      }
   }
/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
int FindDouble(FILE *InfoFile,char *Keyword,double *value){
   char DataString[100000],*c;
   long length;
   
   fseek(InfoFile,0L,SEEK_END);
   length=ftell(InfoFile);
   if(length>99999)length=99999;
   rewind(InfoFile);
   fread(DataString,sizeof(DataString[0]),length,InfoFile);
   strcat(DataString,'\0');
   if((c=strstr(DataString,Keyword))!=NULL){
      if(sscanf(c,"%*s %f ",value)==1){
         return(c-DataString);
         }else{
         printf("Value not found for %s\n",Keyword);
         return(-1);
         }
      }else{
      printf("KW %s not found\n",Keyword);
      return(-1);
      }
   }
/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
int FindString(FILE *InfoFile,char *Keyword,char *value){
   char DataString[100000],*c;
   long length;
   
   fseek(InfoFile,0L,SEEK_END);
   length=ftell(InfoFile);
   if(length>99999)length=99999;
   rewind(InfoFile);
   fread(DataString,sizeof(DataString[0]),length,InfoFile);
   strcat(DataString,'\0');
   if((c=strstr(DataString,Keyword))!=NULL){
      if(sscanf(c,"%*s %s ",value)==1){
         return(c-DataString);
         }else{
         printf("Value not found for %s\n",Keyword);
         return(-1);
         }
      }else{
      printf("KW %s not found\n",Keyword);
      return(-1);
      }
   }
/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
main(int argc, char *argv[]){

   char infile1[1000], formatfile[1000], outfile[1000];
   FILE *infp,*ffp,*outfp;
   char FormatString[FormatLineLength],KeyWord[MaxFieldLength];
   char OptionalDescription[MaxFieldLength],Value[MaxFieldLength];
   int RecordOffset,FirstByte,LastByte;
   int i,j,k,l;
   int RECORD_TYPE_CODE[MaxNumberOfRecord],RECORD_OFFSET[MaxNumberOfRecord];
   char DataString[FormatLineLength],location[FormatLineLength];
   int RECORD_TYPE_CODE_FIRST_FIELD,RECORD_TYPE_CODE_LAST_FIELD,
       RECORD_LENGTH_FIRST_FIELD,RECORD_LENGTH_LAST_FIELD;
   int LeaderFileSize,ActualNumberOfRecord,RecordTypeCode;
/*****************************************************************/
/*********************Files oppening******************************/
/*****************************************************************/
   if(argc<4){
      printf("Usage: leader2rsc ldr_file format_file rsc_file\n");
      exit(0);
      }
   sprintf(infile1,"%s",argv[1]);
   sprintf(formatfile,"%s",argv[2]);
   sprintf(outfile,"%s",argv[3]);


   if((infp=fopen(infile1,"r")) == NULL){
       printf("%s file not open\n", infile1);
       exit(1);
       }
   if((ffp=fopen(formatfile,"r")) == NULL){
       printf("%s file not open\n", formatfile);
       exit(1);
       }
/*->ne pas detruire?*/
   if((outfp=fopen(outfile,"w")) == NULL){
       printf("%s file not open\n", outfile);
       exit(1);
       }
/*****************************************************************/
/*********************Structure reading***************************/
/*****************************************************************/
   strcpy(DataString,"\0");
   while(fgets(FormatString,FormatLineLength,ffp)!=NULL)
      strcat(DataString,FormatString);
   strcat(DataString," \0");

   RECORD_TYPE_CODE_FIRST_FIELD=0;
   RECORD_TYPE_CODE_LAST_FIELD=0;
   RECORD_LENGTH_FIRST_FIELD=0;
   RECORD_LENGTH_LAST_FIELD=0;

       if(strstr(DataString,"RECORD_TYPE_CODE_FIRST_FIELD")!=NULL)
   sscanf(strstr(DataString,"RECORD_TYPE_CODE_FIRST_FIELD"),
                  "%*s %d ",&RECORD_TYPE_CODE_FIRST_FIELD);

       if(strstr(DataString,"RECORD_TYPE_CODE_LAST_FIELD")!=NULL)
   sscanf(strstr(DataString,"RECORD_TYPE_CODE_LAST_FIELD"),
                  "%*s %d ",&RECORD_TYPE_CODE_LAST_FIELD);

       if(strstr(DataString,"RECORD_LENGTH_FIRST_FIELD")!=NULL)
   sscanf(strstr(DataString,"RECORD_LENGTH_FIRST_FIELD"),
                  "%*s %d ",&RECORD_LENGTH_FIRST_FIELD);

       if(strstr(DataString,"RECORD_LENGTH_LAST_FIELD")!=NULL)
   sscanf(strstr(DataString,"RECORD_LENGTH_LAST_FIELD"),
                  "%*s %d ",&RECORD_LENGTH_LAST_FIELD);
   
   if((RECORD_TYPE_CODE_FIRST_FIELD*RECORD_TYPE_CODE_LAST_FIELD*
       RECORD_LENGTH_FIRST_FIELD*RECORD_LENGTH_LAST_FIELD)==0){
      printf("Structure not read, check the RECORD_LENGTH parameters in the .format file");
      exit(1);
      }

   for(i=0;i<MaxNumberOfRecord;i++){
      RECORD_TYPE_CODE[i]=0;
      RECORD_OFFSET[i]=0;
      }
   i=0;
   RECORD_OFFSET[0]=0;
   fseek(infp,0L,SEEK_END);
   LeaderFileSize=ftell(infp);
   while(RECORD_LENGTH_LAST_FIELD+RECORD_OFFSET[i]<LeaderFileSize){
      RECORD_TYPE_CODE[i]=fReadBinary(RECORD_TYPE_CODE_FIRST_FIELD+RECORD_OFFSET[i],
                                      RECORD_TYPE_CODE_LAST_FIELD+RECORD_OFFSET[i],infp);
      RECORD_OFFSET[i+1]=RECORD_OFFSET[i]+fReadBinary(RECORD_LENGTH_FIRST_FIELD+RECORD_OFFSET[i],
                                                      RECORD_LENGTH_LAST_FIELD+RECORD_OFFSET[i],infp);
      i++;
      }
   ActualNumberOfRecord=i-1;
   printf("Structure read\n");
/*****************************************************************/
/***********************Files reading*****************************/
/*****************************************************************/
  rewind(ffp);
  while(fgets(FormatString,FormatLineLength,ffp)!=NULL){
      strcat(FormatString," \0");
      strcpy(Value,"\0");
      strcpy(KeyWord,"\0");
      RecordOffset=0;
      FirstByte=0;
      LastByte=0;
      strcpy(OptionalDescription,"\0");
      if((i=sscanf(FormatString," %s %d %d %d %s ",KeyWord,&RecordTypeCode,&FirstByte,&LastByte,OptionalDescription))>=4){
         if(i==5){
            sscanf(FormatString," %s %d %d %d %n ",KeyWord,&RecordTypeCode,&FirstByte,&LastByte,&j);
            k=strlen(FormatString);
            for(l=0;l<k-j-1;l++)OptionalDescription[l]=FormatString[l+j];
            OptionalDescription[k-j-1]='\0';
            }
         RecordOffset=-1;
         for(i=0;i<ActualNumberOfRecord;i++)if(RECORD_TYPE_CODE[i]==RecordTypeCode)RecordOffset=RECORD_OFFSET[i];
         if(RecordOffset>=0){
            fseek(infp,RecordOffset+FirstByte-1,0);
            fgets(Value,LastByte-FirstByte+2,infp);
            i=0;
            while(isspace(Value[i])!=0)i++;
            for(j=0;j<strlen(Value);j++)Value[j]=Value[j+i];
            }else{
            strcpy(Value,"\0");
            }
         fprintf(outfp,"%-30s%-30s%s\n",KeyWord,Value,OptionalDescription);
         }
      }
   fprintf(outfp,"\n");
   fflush(outfp);
   fclose(outfp);
   printf("LeaderFile Read\n");
/*****************************************************************/
/*********************End*****************************************/
/*****************************************************************/
   }
    
    
/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
int fReadBinary(int FirstByte, int LastByte,FILE *infp)
 {
  int k;
  unsigned n;
  n=0;
  fseek(infp,FirstByte-1,0);
  for (k=LastByte-FirstByte;k>=0;k--) n=n*256+fgetc(infp);
  return(n);
 }




double fReadDouble(int FirstByte,int LastByte,FILE *infp)
  {
  int k,d,exposant,e,signe;
  double mantisse,dec;
  char c;
  mantisse=0.;
  exposant=0;
  e=0;
  dec=1.;
  d=0;
  signe=1;
  fseek(infp,FirstByte-1,0);
  for (k=LastByte-FirstByte;k>=0;k--) {
      c=fgetc(infp);
      if ((c=='-')&&((int)mantisse==0)) signe=-1;
      if (isdigit(c)*(e==0)) mantisse=mantisse*10.*(double)(1-d)+mantisse*(double)(d)+(double)(((int)c-48)/dec);
      if (isdigit(c)*(e!=0)) exposant=exposant*10+((int)c-48);
      if ((c=='-')&&(e!=0)) e=-1;
      if (c=='.') d=1;
      if (isalpha(c)) e=1;
      if (d==1) dec=dec*10.;
      }
  for(k=0;k<exposant;k++) if(e==1){
     mantisse=mantisse*10.;
     }else{
     mantisse=mantisse/10.;
     }
  mantisse=mantisse*(double)signe;
  return(mantisse);
  }
  
//$INT_BIN/leader2rsc $leader_file $INT_SCR/format_leaderfile_$facility tmp_IMAGERY.raw.rsc

//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage: leader2rsc ldr_file format_file rsc_file
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "leader2rsc" reads a LEADER file and a LEADER_FORMAT_FILE 
//POD to produce a ROI_PAC RSC file.
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD RSC_FILE listing
//POD =================
//POD RECORD_TYPE_CODE_FIRST_FIELD    6
//POD RECORD_TYPE_CODE_LAST_FIELD     6
//POD RECORD_LENGTH_FIRST_FIELD       9
//POD RECORD_LENGTH_LAST_FIELD        12
//POD
//POD FIRST_FRAME                    10 57   68      
//POD FIRST_FRAME_SCENE_CENTER_TIME  10 69  100
//POD FIRST_FRAME_SCENE_CENTER_LINE  10 325 332
//POD DATE                           10 71   76
//POD
//POD FIRST_LINE_YEAR           10 69 72
//POD FIRST_LINE_MONTH_OF_YEAR  10 73 74
//POD FIRST_LINE_DAY_OF_MONTH   10 75 76
//POD FIRST_CENTER_HOUR_OF_DAY  10 77 78
//POD FIRST_CENTER_MN_OF_HOUR   10 79 80
//POD FIRST_CENTER_S_OF_MN      10 81 82
//POD FIRST_CENTER_MS_OF_S      10 83 85
//POD
//POD PROCESSING_FACILITY     10 1047 1062 
//POD PROCESSING_SYSTEM       10 1063 1070
//POD PROCESSING_VERSION      10 1071 1078 
//POD
//POD=head1 FILES CREATED
//POD
//POD RSC_FILE listing
//POD =================
//POD WIDTH                    12060
//POD FILE_LENGTH              30000
//POD FILE_START               1
//POD XMIN                     412
//POD XMAX                     12060
//POD YMIN                     0
//POD YMAX                     30000
//POD VELOCITY                 7553
//POD HEIGHT                   774824
//POD EARTH_RADIUS             6371495
//POD STARTING_RANGE           829025
//POD WAVELENGTH               0.0565646
//POD PULSE_LENGTH             37.10e-06
//POD CHIRP_SLOPE              0.419137466e12
//POD I_BIAS                   15.5
//POD Q_BIAS                   15.5    
//POD FIRST_LINE_UTC           66000
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD POD comments trm Feb 02nd '04
//POD=cut
