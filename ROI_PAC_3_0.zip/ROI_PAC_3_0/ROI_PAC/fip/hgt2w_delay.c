#include <stdio.h>
#include <math.h>
#include <string.h>

#define MaxWidth  6000
#define MaxLength 9000
 
main(int argc, char *argv[]){

   char   InFile0[1000];
   char   InLine0[10000];
   FILE   *InFP0;
   char   InFile1[1000],       InFile2[1000],      OutFile[1000];
   FILE   *InFP1,              *InFP2,             *OutFP;
   float  InLine1[MaxWidth*2], InLine2[MaxWidth*2],OutLine[MaxWidth*2];
   double HScale;
   double Pi;
   int    Width,Length;
   int    i,j;
   float Elev, Phi2, Amp;
   double DPWV,DPWVx,DPWVy;   

   Pi=4*atan2(1,1);

/********************************************************************************/
/****************************  Reading      Parameters  *************************/
/********************************************************************************/
   sscanf(argv[1],"%s",InFile1);
   sscanf(argv[2],"%s",OutFile);
   sscanf(argv[3],"%d",&Width);
   sscanf(argv[4],"%d",&Length);
   sscanf(argv[5],"%lf",&HScale);
   sscanf(argv[6],"%lf",&DPWV);
   sscanf(argv[7],"%lf",&DPWVx);
   sscanf(argv[8],"%lf",&DPWVy);

/********************************************************************************/
/****************************                           *************************/
/********************************************************************************/
   if((InFP1=fopen(InFile1,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile1);
      exit(0);
   }
   if((OutFP=fopen(OutFile,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile);
      exit(0);
   }

   for(i=0;i<Length;i++){
      if(i%1000==0)printf("\rline %d\n",i);
      fread(InLine1,sizeof(InLine1[0]),Width*2,InFP1);
      for(j=0;j<Width;j++){
        Amp=InLine1[j];
        Elev=InLine1[j+Width];
        OutLine[j]=Amp;
          if(Elev==0){
            OutLine[j+Width]=0;
          }else{
            OutLine[j+Width]=24.*Pi/0.05656*exp(-1*Elev/2500)
                         *(DPWV+(j/(float)Width)*DPWVx+(i/(float)Length)*DPWVy);
          }
        }
        fwrite(OutLine,sizeof(OutLine[0]),Width*2,OutFP);
      }
      close(InFP1);
      close(OutFP);
   }
//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD   usage: hgt2w_delay Infile(str) Outfile(str) Width(int) Length(int) HScale(float/r*4)
//POD          DPWV(float/r*4) DPWVx(float/r*4) DPWVy(float/r*4)
//POD   InFile: RMG Amplitude/Elevation image
//POD   OutFile: RMG Amplitude/Elevation image with scaled Elevation
//POD   Width: number of pixels in record
//POD   Length: number of records to process
//POD   HScale: log scaling factor
//POD   DPWV: linear scaling factor
//POD   DPWVx: Elevation slope along each record (start to end)
//POD   DPWVy: Elevation slope from first to last record
//POD
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "hgt2w_delay" reads records made up of "With" RMG Amp/Elev elements from "Infile"
//POD and writes these RMG records to "Outfile".  Only the Elevation elements is scaled (non-linear) prior to output 
//POD Elev_out[i,j]=24.*Pi/0.05656*exp(-1*Elev_in(i,j)/2500)*(DPWV+(i/(float)Width)*DPWVx+(j/(float)Length)*DPWVy);
//POD 
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD "Infile" Amplitude and elevation stored as r*4/float values "RMG style" ie. alternating Amp and Elev records.
//POD
//POD=head1 FILES CREATED
//POD
//POD "Outfile" Amplitude and elevation stored as r*4/float "RMG" samples ie. alternating Amp and Elev records.
//POD 
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD trm Feb 2nd '04
//POD=cut
