#include <stdio.h>  
#include <string.h>
#include <math.h>

double date2J2000(double,double,double,double,double,double);

main(int argc, char *argv[]){
   /*****************************/
   /*****  Input  variables  ****/
   /*****************************/
  double year,month,day,utc;
  sscanf(argv[1],"%lf",&year);
  sscanf(argv[2],"%lf",&month);
  sscanf(argv[3],"%lf",&day);
  sscanf(argv[4],"%lf",&utc);
  printf("%20.20f\n",date2J2000(year,month,day,0.,0.,utc));
   /*****************************/
   /*****  Output variables  ****/
   /*****************************/
   /*****************************/
   /*****  Local  variables  ****/
   /*****************************/
  }
   
   
   
/*********************************************************/
   
  
double date2J2000(double year,double month,double day,double hour,double minute,double second){
   double m[13];
   double j2,a,t;
   
   m[0]=0.;
   m[1]=0.;m[2]=31.;m[3]=59.;m[4]=90.;m[5]=120.;m[6]=151.;
   m[7]=181.;m[8]=212.;m[9]=243.;m[10]=273.;m[11]=304.;m[12]=334.;

   j2=m[(int)month]+day+(hour+minute/60.+second/3600.)/24.-1;
   a=((int)year%4)/4.;
   if(a==0)a=1;
   if((a==1)*(month>=3))j2=j2+1;
   t=(year-2000)*365.25+.5+j2-a;
   return(t);
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
