#include <stdio.h>
#include <math.h>
#include <string.h>

#define Max(a,b)  ( ( (a) > (b) ) ? (a) : (b) )
#define Min(a,b)  ( ( (a) < (b) ) ? (a) : (b) )
#define Abs(a)    ( ((a) > 0) ? (a) : (-a) )

main(int argc, char *argv[]){

  FILE *InFP, *OutFP;
  char InFile[1000], OutFile[1000];
  int Width, Length;
  int dx0, dxf, dy0, dyf;
  float padr, padi;

  int i,j;
  float *InLine, *OutLine, *PadX0, *PadXf, *PadY;

  strcpy(InFile,argv[1]);
  sscanf(argv[2],"%d",&Width);
  strcpy(OutFile,argv[3]);
  sscanf(argv[4],"%d",&dx0);
  sscanf(argv[5],"%d",&dxf);
  sscanf(argv[6],"%d",&dy0);
  sscanf(argv[7],"%d",&dyf);
  sscanf(argv[8],"%f",&padr);
  sscanf(argv[9],"%f",&padi);


  if((InFP=fopen(InFile,"r")) == NULL){
      printf("%s file not open\n",InFile);
      exit(1);
      }
  if((OutFP=fopen(OutFile,"w")) == NULL){
      printf("%s file not open\n",OutFile);
      exit(1);
      }

   fseek(InFP,0L,SEEK_END);
   Length=ftell(InFP)/(2*sizeof(float)*Width);
   rewind(InFP);

   if(dx0 > 0){
     PadX0=(float *)malloc(2*dx0*sizeof(float));
     for(i=0;i<dx0;i++){
       PadX0[2*i]=padr;
       PadX0[2*i+1]=padi;
     }
   }
   if(dxf > 0){
     PadXf=(float *)malloc(2*dxf*sizeof(float));
     for(i=0;i<dxf;i++){
       PadXf[2*i]=padr;
       PadXf[2*i+1]=padi;
     }
   }
   if((dy0 > 0) || (dyf > 0)){
     PadY=(float *)malloc(2*(dx0+dxf+Width)*sizeof(float));
     for(i=0;i<(dx0+dxf+Width);i++){
       PadY[2*i]=padr;
       PadY[2*i+1]=padi;
     }
   }
   InLine=(float *)malloc(2*Width*sizeof(float));
   OutLine=(float *)malloc(2*(dx0+dxf+Width)*sizeof(float));

  
   for(i=0;i<dy0;i++){
     fwrite(PadY,sizeof(float),(2*(dx0+dxf+Width)),OutFP);
   }
   for(i=Max(0,-1*dy0);i<(Length+Min(0,dyf));i++){
     if(i%100==0) fprintf(stderr,"\rline %d",i);
     fseek(InFP,Width*i*2*sizeof(float),0);
     fread(InLine,sizeof(float),Width*2,InFP);
     if(dx0 > 0){
     fwrite(PadX0,sizeof(float),2*dx0,OutFP);
     if(dxf >0){
       for(j=0;j<2*Width;j++)OutLine[j]=InLine[j];
       fwrite(OutLine,sizeof(float),Width*2,OutFP);
       fwrite(PadXf,sizeof(float),2*dxf,OutFP);
     }else{
       for(j=0;j<2*(Width+dxf);j++)OutLine[j]=InLine[j];
       fwrite(OutLine,sizeof(float),(Width+dxf)*2,OutFP);
     }
     }else{
       if(dxf >0){
         for(j=0;j<2*(Width+dx0);j++)OutLine[j]=InLine[j-2*dx0];
         fwrite(OutLine,sizeof(float),(Width+dx0)*2,OutFP);
         fwrite(PadXf,sizeof(float),2*dxf,OutFP);
       }else{
         for(j=0;j<2*(Width+dxf+dx0);j++)OutLine[j]=InLine[j-2*dx0];
         fwrite(OutLine,sizeof(float),(Width+dxf+dx0)*2,OutFP);
       }
     }      
   }
   for(i=0;i<dyf;i++){
     fwrite(PadY,sizeof(float),(2*(dx0+dxf+Width)),OutFP);
   }
   printf("\n dx0=%d dxf=%d dy0=%d dyf=%d r=%d i=%d\n",dx0,dxf,dy0,dyf,padr,padi);
   close(InFP);
   close(OutFP);
}

//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage: slice_cpx InFile(str) Width(int) OutFile(str) dx0(int) \
//POD                  dxf(int) dy0(int) dyf(int) padr(float) padi(float)
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "slice_cpx" embeds an input c*8 complex binary flat file into 
//POD a larger output c*8 complex binary flat file, pading with complex value padr+i*padi where needed
//POD or extract a rectangular subset of the input records to be written out.  Viewing the input
//POD data a rectangle of extent "Width" in the "X" direction (records) and of extent "Length" in
//POD the "Y" direction (Length==number of input records), the first c*8 value in the input file 
//POD has coordinates (x,y)=(0,0), the end of the first record is (x,y)=(Width-1,0), and the last value
//POD is (x,y)=(Width-1,Length-1).  In that picture the Output data is an overlaping rectangle
//POD with first c*8 value at position (x,y)=(dx0,dy0), and the last value in the Output file is
//POD (x,y)=(Width+dxf-1,Length+dyf-1).  Non overlaping areas as filled in with padr+i*padi [i=sqrt(-1)]
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Input file "InFile" contains an array of complex values c*8, record length "Width"
//POD number of records "Length" (derived from filesize_in_bytes/(8*Width))
//POD
//POD=head1 FILES CREATED
//POD
//POD Output file "OutFile" contains an array of complex values c*8, record length = dx0+dxf+Width
//POD number of records dy0+dyf+Length
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD: trm Jan 29th '04
//POD=cut
