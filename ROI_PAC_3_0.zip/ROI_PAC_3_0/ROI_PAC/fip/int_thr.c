#include <stdio.h>
#include <math.h>
#include <string.h>

#define MaxWidth  8000
#define MaxLength 9000
 
main(int argc, char *argv[]){

   char   InFile[1000],       OutFile[1000];
   FILE   *InFP,              *OutFP;
   float  InLine[MaxWidth*2], OutLine[MaxWidth*2];
   float  DPhaseRange;
   float  DPhaseAzimuth;
   float  PhaseOffset;
   double Pi;
   int    Width,Length;
   int    i,j;
   float amp;
   float Threshold;
   
   sprintf(InFile,"%s",argv[1]);
   sprintf(OutFile,"%s",argv[2]);
   sscanf(argv[3],"%d",&Width);
   sscanf(argv[4],"%f",&Threshold);
/*    Threshold=Threshold*Threshold; */

/********************************************************************************/
/****************************                           *************************/
/********************************************************************************/
   if((InFP=fopen(InFile,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile);
      exit(0);
      }
   if((OutFP=fopen(OutFile,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile);
      exit(0);
      }
      
   fseek(InFP,0L,SEEK_END);
   Length=ftell(InFP)/(2*sizeof(float)*Width);
   rewind(InFP);
   
   for(i=0;i<Length;i++){
      if(i%1000==0)printf("\rline %d\n",i);
      fread(InLine,sizeof(InLine[0]),Width*2,InFP);
      for(j=0;j<Width*2;j=j+2){
         if(sqrt(InLine[j]*InLine[j]+InLine[j+1]*InLine[j+1]) < Threshold){
            OutLine[j+1]=0;
            OutLine[j]=0;
            }else{
            OutLine[j] = InLine[j] ;
            OutLine[j+1]=InLine[j+1];
            }
         }
      fwrite(OutLine,sizeof(OutLine[0]),Width*2,OutFP);
      }
   close(InFP);
   close(OutFP);
   }
//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD   usage:int_thr Infile(str) Outfile(str) Width(int) Threshold(float/r*4)
//POD   Infile: c*8/complex image
//POD   Outfile: c*8/complex image
//POD   Width: number of pixels in record
//POD   Threshold: on the magnitude Sqrt(Re^2+Im^2) of the input data, over which
//POD              the Output data is zeroed instead of simply copied from the input.
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "int_thr" reads records made up of "With" complex/c*8 elements from "Infile"
//POD and wrrites these records to "Outfile".  Only the record elements with magnitude Sqrt(Re^2+Im^2) 
//POD larger than "Treshold" are modified: they are set to 0.0+i*0.0 i= sqrt(-1)
//POD 
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Input file "InFile" contains an array of complex values c*8, record length "Width"
//POD number of records "Length" (derived from filesize_in_bytes/(8*Width))
//POD
//POD=head1 FILES CREATED
//POD
//POD Output file "Outfile" identical to input file except when record elements have agnitude Sqrt(Re^2+Im^2) 
//POD greater than threshold.  In that case they are set to 0.0+i*0.0
//POD 
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD trm Jan 29th '04
//POD=cut
