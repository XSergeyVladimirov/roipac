#include <stdio.h>
#include <math.h>
#include <string.h>

#define MaxWidth  10000
#define MaxLength 9000
 
main(int argc, char *argv[]){

   char   InFile[1000],       OutFile1[1000],       OutFile2[1000];
   FILE   *InFP,              *OutFP1,              *OutFP2;
   float  InLine[MaxWidth*2], OutLine1[MaxWidth],   OutLine2[MaxWidth];
   double Pi;
   int    Width,Length;
   int    i,j;
   
  if(argc < 5){
      printf("   usage:%s Infile Outfile1 Outfile2 width\n",argv[0]);
      printf("  Infile:rmg image\n");
      printf("Outfile1:amplitude image\n");
      printf("Outfile2:phase image\n");
      printf("   width:number of complex pixels\n");
      exit(-1);
    }

   sprintf(InFile,"%s",argv[1]);
   sprintf(OutFile1,"%s",argv[2]);
   sprintf(OutFile2,"%s",argv[3]);
   sscanf(argv[4],"%d",&Width);
/*    Pi=4*atan2(1,1); */

/********************************************************************************/
/****************************                           *************************/
/********************************************************************************/
   if((InFP=fopen(InFile,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile);
      exit(0);
      }
   if((OutFP1=fopen(OutFile1,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile1);
      exit(0);
      }
   if((OutFP2=fopen(OutFile2,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile2);
      exit(0);
      }
      
   fseeko(InFP,0L,SEEK_END);
   Length=ftello(InFP)/(2*sizeof(float)*Width);
   rewind(InFP);
   
   for(i=0;i<Length;i++){
      if(i%100==0)fprintf(stderr,"\rline %d",i);
      fread(InLine,sizeof(InLine[0]),Width*2,InFP);
      for(j=0;j<Width;j++){
         OutLine1[j]  =InLine[j];
         OutLine2[j]  =InLine[j+Width];
         }
      fwrite(OutLine1,sizeof(OutLine1[0]),Width,OutFP1);
      fwrite(OutLine2,sizeof(OutLine2[0]),Width,OutFP2);
      }
   close(InFP);
   close(OutFP1);
   close(OutFP2);
   }
//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD   usage:rmg2mag_phs Infile Outfile1 Outfile2 width
//POD   Infile:rmg image
//POD   Outfile1:amplitude image
//POD   Outfile2:phase image
//POD   width:number of pixels
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "rmg2mag_phs" splits an amplitude/phaseORheight RMG file (Infile, r*4/floats)
//POD into two files: one (Outfile1, r*4/floats) contains the amplitude, the other (Outfile2, r*4/floats)
//POD contains the phase or height.  In all these file the record length is "width"
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Input file "InFile" contains two arrays of r*4/float values stored "RMG style". The record length is "Width"
//POD and the number of records is "Length" (derived from filesize_in_bytes/(8*Width)). The structure
//POD of the binary file is one record of array1 followed by the same record from array2: r*4(1:Width,1:2,1:Length)
//POD (first index fastest)
//POD
//POD=head1 FILES CREATED
//POD
//POD Each of the output files "OutFile1" & "OutFile2" contains one of the two arrays store in the RMG file
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD trm Jan 29th '04
//POD=cut
