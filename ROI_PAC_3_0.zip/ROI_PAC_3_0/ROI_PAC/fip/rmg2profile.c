#include <stdio.h>
#include <math.h>
#include <string.h>

main(int argc, char *argv[]){

  /*****************/
  /*****Input Var***/
  /*****************/
  char InFile[1000], OutFile[1000];
  int Width, x0, y0, x1, y1, Swath;
  /*****************/
  /*****Local Var***/
  /*****************/
  FILE *InFP, *OutFP;
  float *InLine;
  int i,j;
  int Length;
  float n, nx, ny, s, sx, sy;
  float l;

  if(argc < 9){
    printf("  usage:%s InFile OutFile Width x0 y0 x1 y1 Swath",argv[0]);
    exit(-1);
  }
  sprintf(InFile,"%s",argv[1]);
  sprintf(OutFile,"%s",argv[2]);
  sscanf(argv[3],"%d",&Width);
  sscanf(argv[4],"%d",&x0);
  sscanf(argv[5],"%d",&y0);
  sscanf(argv[6],"%d",&x1);
  sscanf(argv[7],"%d",&y1);
  sscanf(argv[8],"%d",&Swath);
  if((InFP=fopen(InFile,"r"))==NULL){
    fprintf(stderr,"file %s not open\n",InFile);
    exit(0);
  }
  if((OutFP=fopen(OutFile,"w"))==NULL){
    fprintf(stderr,"file %s not open\n",OutFile);
    exit(0);
  }
  fseek(InFP,0L,SEEK_END);
  Length=ftell(InFP)/(2*sizeof(float)*Width);
  rewind(InFP);
  InLine=(float *)malloc(Width*2*sizeof(float));

  sx=(float)(x1-x0);
  sy=(float)(y1-y0);
  nx=(float)(y0-y1);
  ny=(float)(x1-x0);
  l=sqrt(sx*sx+sy*sy);
  sx=sx/l;
  sy=sy/l;
  n=sqrt(nx*nx+ny*ny);
  nx=nx/n;
  ny=ny/n;
  for(i=0;i<Length;i++){
    if(i%100==0)fprintf(stderr,"\rline %d",i);
    fread(InLine,sizeof(float),Width*2,InFP);
    for(j=0;j<Width;j++){
      s=sx*(float)(j-x0)+sy*(float)(i-y0);
      n=nx*(float)(j-x0)+ny*(float)(i-y0);
      if((fabs(InLine[Width+j])>.0) && (fabs(n)<(float)Swath) && (s>0.) && (s<l)){
         fprintf(OutFP,"%d %f\n",(int)s,InLine[Width+j]);
      }
    }
  }
  fclose(InFP);
  fclose(OutFP);
}


//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage: rmg2profile InFile(str) OutFile(str) Width(int)  x0(int) y0(int) x1(int) y1(int) Swath(int)
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION: "rmg2profile" extract a height profiles along a straight line
//POD from an input RMG binary file (amplitude=r*4/float  and heights=r*4/float) of record length "Width".  
//POD Viewing the input data as a rectangle of extent "Width" in the "X" direction (records) and of 
//POD extent "Length" in the "Y" direction (Length==number of input records), the first value in the 
//POD input file has coordinates (x,y)=(0,0), the end of the first record is (x,y)=(Width-1,0), 
//POD and the last value is (x,y)=(Width-1,Length-1). In that picture the height profile data is 
//POD extracted on a straitght line joining (x,y)=(x0,y0) to (x1,y1).  All image pixels that are 
//POD less that "Swath" pixels away from that line are reported with the distance in pixels along 
//POD the line from (x0,y0) in the ascii output file.
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Input file "InFile" contains two arrays of r*4/float values stored "RMG style". The record length is "Width"
//POD and the number of records is "Length" (derived from filesize_in_bytes/(8*Width)). The structure
//POD of the binary file is one record of array1 followed by the same record from array2: r*4(1:Width,1:2,1:Length)
//POD (first index is fastest)
//POD
//POD=head1 FILES CREATED
//POD
//POD Output file "OutFile" is an ascii file with (1) distance away from (x0,y0) in pixels (2) the pixel's height 
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD: trm Jan 29th '04
//POD=cut
