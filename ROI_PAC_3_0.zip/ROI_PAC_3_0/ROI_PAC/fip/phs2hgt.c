#include <stdio.h>
#include <math.h>
#include <string.h>

#define MaxWidth  6000
#define MaxLength 9000
 
main(int argc, char *argv[]){

   char   InFile0[1000];
   char   InLine0[10000];
   FILE   *InFP0;
   double Theta[MaxWidth], Range[MaxWidth];
   double StartingRange,Height,RangePixelSize,AzimuthPixelSize,WaveLength;
   double EarthRadius;
   char   InFile1[1000],       InFile2[1000],      OutFile[1000];
   FILE   *InFP1,              *InFP2,             *OutFP;
   float  InLine1[MaxWidth*2], InLine2[MaxWidth*2],OutLine[MaxWidth*2];
   double HBase1,HRate1,HBase2,HRate2;
   double VBase1,VRate1,VBase2,VRate2;
   double Baseline1[MaxWidth], Baseline2[MaxWidth];
   double Alpha1[MaxWidth],    Alpha2[MaxWidth];
   int  RangeOffset,AzimuthOffset;
   double Phase,ThetaTopo,z,PhaseConst;
   double Pi;
   int    Width,Length;
   int    i,j;
   
   sprintf(InFile0,"%s",argv[1]);
   Pi=4*atan2(1,1);

/********************************************************************************/
/****************************  Reading      Parameters  *************************/
/********************************************************************************/
   if((InFP0=fopen(InFile0,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile0);
      exit(0);
      }
   rewind(InFP0);
   fscanf(InFP0,"%s",InFile1);
   fscanf(InFP0,"%lf %lf",&HBase1,&HRate1);
   fscanf(InFP0,"%lf %lf",&VBase1,&VRate1);
   fscanf(InFP0,"%lf",&PhaseConst);
   fscanf(InFP0,"%s",OutFile);
   fscanf(InFP0,"%d %d",&Width,&Length);
   fscanf(InFP0,"%lf %lf %lf",&Height,&EarthRadius,&StartingRange);
   fscanf(InFP0,"%lf %lf %lf",&WaveLength,&RangePixelSize,&AzimuthPixelSize);
   close(InFP0);
/********************************************************************************/
/****************************                           *************************/
/********************************************************************************/
   if((InFP1=fopen(InFile1,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile1);
      exit(0);
      }
   if((OutFP=fopen(OutFile,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile);
      exit(0);
      }
   for(j=0;j<Width;j++){
      Range[j]=StartingRange+j*RangePixelSize;
      Theta[j]=acos((Height*Height+2*EarthRadius*Height+Range[j]*Range[j])/
                    (2*Range[j]*(EarthRadius+Height)));
      }
   for(i=0;i<Length;i++){
      Baseline1[i]=sqrt(pow(HBase1+i*HRate1*AzimuthPixelSize,2)+
                        pow(VBase1+i*VRate1*AzimuthPixelSize,2));
      Alpha1[i]=      atan2(VBase1+i*VRate1*AzimuthPixelSize,
                            HBase1+i*HRate1*AzimuthPixelSize);
      }

   for(i=0;i<Length;i++){
      if(i%1000==0)printf("\rline %d\n",i);
      fread(InLine1,sizeof(InLine1[0]),Width*2,InFP1);
      for(j=0;j<Width;j++){
         if(InLine1[j]*InLine1[j+Width]==0){
            OutLine[j]=0;
            OutLine[j+Width]=0;
            }else{
            OutLine[j]  =InLine1[j];
            Phase=InLine1[j+Width]-PhaseConst;
            ThetaTopo=-1.*(WaveLength*Phase)/(4.*Pi*Baseline1[i]*cos(Theta[j]-Alpha1[i]));
            z=Range[j]*(EarthRadius+Height)/EarthRadius*sin(Theta[j])*ThetaTopo;
            OutLine[j+Width]=z;
            }
         }
      fwrite(OutLine,sizeof(OutLine[0]),Width*2,OutFP);
      }
   close(InFP1);
   close(OutFP);
   }
