#include <stdio.h>
#include <math.h>
#include <string.h>

#define MaxWidth  6000
#define MaxLength 9000
 
main(int argc, char *argv[]){

   char   InFile1[1000],       InFile2[1000],       OutFile[1000];
   FILE   *InFP1,              *InFP2,              *OutFP;
   float  InLine1[MaxWidth],   InLine2[MaxWidth],   OutLine[2*MaxWidth];
   double Pi;
   int    Width,Length,Length1,Length2;
   int    i,j;
   
   if(argc < 4){
      printf("   usage:%s Infile Outfile width\n",argv[0]);
      printf("Infile:amplitude image\n");
      printf("Outfile:complex image\n");
      printf("   width:number of complex pixels\n");
      exit(-1);
    }

   sprintf(InFile1,"%s",argv[1]);
   sprintf(OutFile,"%s",argv[2]);
   sscanf(argv[3],"%d",&Width);
   Pi=4*atan2(1,1);

/********************************************************************************/
/****************************                           *************************/
/********************************************************************************/
   if((InFP1=fopen(InFile1,"r"))==NULL){
      fprintf(stderr,"file %s not open\n",InFile1);
      exit(0);
      }
   if((OutFP=fopen(OutFile,"w"))==NULL){
      fprintf(stderr,"file %s not open\n",OutFile);
      exit(0);
      }
      
   fseek(InFP1,0L,SEEK_END);
   Length=ftell(InFP1)/(sizeof(InLine1[0])*Width);
   rewind(InFP1);
   
   for(i=0;i<Length;i++){
      if(i%100==0)fprintf(stderr,"\rline %d",i);
      fread(InLine1,sizeof(InLine1[0]),Width,InFP1);
      for(j=0;j<Width;j++){
         OutLine[2*j]        = sqrt(InLine1[j]);
         OutLine[2*j+1]      = sqrt(InLine1[j]);
         }
      fwrite(OutLine,sizeof(OutLine[0]),Width*2,OutFP);
      }
   close(InFP1);
   close(OutFP);
   }
//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage:mag2amp Infile Outfile Width
//POD       Infile:amplitude imag
//POD       Outfile:complex image
//POD       Width:number of complex pixels
//POD 
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "mag2amp" get a magnitude (r*4/float, >= 0) image (MAG>=0) from Infile and
//POD writes it to an output c*8 file (Outfile, c*8/complex) as sqrt(MAG)*(1+i) where i = sqrt(-1)
//POD In these input and output files the record length is "Width".
//POD  
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD The input file "Infile" contains a positive r*4/float magnitude array (MAG). Note that it must be all >= 0 !
//POD
//POD=head1 FILES CREATED
//POD
//POD Complex AMP image in which both Real and Imaginary parts are equal to the Square Root of MAG, c*8/complex samples.
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD POD comments trm Jan 29th '04
//POD=cut
