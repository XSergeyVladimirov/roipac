#include <stdio.h>
#include <math.h>
#include <string.h>

main(int argc, char *argv[]){
  int   ArgNum;
  char  *InFile[1000], OutFile[1000];
  FILE  **InFP,        *OutFP;
  float *InLine,      *OutLine;
  float *Coeff;
  int   Width, Length;
  int   i,j,k;
  /***************************************/
  if(argc < 5){
    printf("usage:%s Infile Coeff [Infile Coeff [...]] OutFile width\n",argv[0]);
    exit(1);
  }
  ArgNum=(argc-3)/2;

  Coeff=(float *)malloc(ArgNum*sizeof(float));
  InFP=(FILE **)malloc(ArgNum*sizeof(FILE *));

  for(k=0;k<ArgNum;k++){
      InFile[k]=(char *)malloc(1000);
    sprintf(InFile[k],"%s",argv[2*k+1]);
    sscanf(argv[2*k+2],"%f",&Coeff[k]);
  }
  sprintf(OutFile,"%s",argv[ArgNum*2+1]);
  sscanf(argv[ArgNum*2+2],"%d",&Width);

  InLine=(float *)malloc(sizeof(float)*Width);
  OutLine=(float *)malloc(sizeof(float)*Width);
  /***************************************/
  for(k=0;k<ArgNum;k++){
     printf("%s %f\n",InFile[k],Coeff[k]); 
     if((InFP[k]=fopen(InFile[k],"r"))==NULL){
     fprintf(stderr,"file %s not open\n",InFile[k]);
     exit(1);
     }
  }
  if((OutFP=fopen(OutFile,"w"))==NULL){
    fprintf(stderr,"file %s not open\n",OutFile);
    exit(1);
  }
  fseek(InFP[0],0L,SEEK_END);
  Length=ftell(InFP[0])/(sizeof(float)*Width);
  rewind(InFP[0]);
  printf("%d \n",Length);
  /***************************************/
  for(i=0;i<Length;i++){
    if(i%100==0)fprintf(stderr,"\rline %d",i);
    for(j=0;j<Width;j++)OutLine[j]=0;
    for(k=0;k<ArgNum;k++){
      fread(InLine,sizeof(float),Width,InFP[k]);
      for(j=0;j<Width;j++){
        if(InLine[j]==0 || OutLine[j]==-1){
          OutLine[j]=-1;
        }else{
        OutLine[j]=OutLine[j]+InLine[j]*Coeff[k];
        }
      }
    }
    for(j=0;j<Width;j++)if(OutLine[j]==-1)OutLine[j]=0;
    fwrite(OutLine,sizeof(float),Width,OutFP);
  }
  for(k=0;k<ArgNum;k++)close(InFP[k]);
  close(OutFP);
}
//POD=pod
//POD
//POD=head1 USAGE
//POD
//POD Usage:table_arithm InFile Coeff [Infile Coeff [...]] OutFile Width"
//POD where:        InFile(str) 
//POD               OutFile(str) 
//POD               Width(int) 
//POD               Coeff(float) 
//POD
//POD=head1 FUNCTION
//POD
//POD FUNCTIONAL DESCRIPTION:  "table_arithm" does linear scalling and addition of a sequence
//POD of input files having identical structures: a number (j=0:Length-1) 
//POD of records made up of (i=0:Width-1) float/r*4 
//Pod
//POD    OutFile(i,j) = Sum_{k=1}^{#InFile} InFile(i,j,k) * Coeff(k)
//POD
//POD "table_arithm" reads the j-th record of an each input file "InFile(k)" 
//POD and adds them up after multiplication by "Coeff(k)" before writing the sum as 
//POD the j-th record of "OutFile"
//POD 
//POD Note: if any_of(InFile(i,j,k) == 0) then OutFile(i,j) = 0  
//POD
//POD=head1 ROUTINES CALLED
//POD
//POD none
//POD
//POD=head1 CALLED BY
//POD
//POD
//POD=head1 FILES USED
//POD
//POD Input file "InFile(k)" contain arrays of float/r*4 values R(0:Width-1,0:Length-1,k) (first index fastest)
//POD
//POD=head1 FILES CREATED
//POD
//POD Output file "OutFile" will be an array of float/r*4 values RR(0:Width-1,0:Length-1)  
//POD       where:
//POD             RR(i,j) = Sum_on_k R(i,j,k)*Coeff(k)
//POD
//POD=head1 DIAGNOSTIC FILES
//POD
//POD
//POD=head1 HISTORY
//POD
//POD Routines written by Francois Rogez
//POD
//POD=head1 LAST UPDATE
//POD  Date Changed        Reason Changed 
//POD  ------------       ----------------
//POD
//POD: trm Jan 29th '04
//POD=cut
