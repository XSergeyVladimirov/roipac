#!/bin/sh
#
# automate test runs
#

usage(){
  echo "usage: `basename $0` test_dir_tar installed_script_dir installed_bin_dir..."
  echo "  test_dir_tar         : path to TEST_DIR.tar"
  echo "  installed_script_dir : directory containing ROI_PAC Perl scripts"
  echo "  installed_bin_dir    : directories containing ROI_PAC binary"
  echo "                         executables to be used for test."
  exit 1
}

export run_batch_script

: ${run_batch_script:=sh}

# If the environment variable run_batch_script is set to something
# like the examaple below, it can be used to submit the test jobs
# to run on nodes in a cluster, such as 'cosmos'

# setenv run_batch_script 'bsub -n 1 -W 02:58 -q preemptable -o bsublog-`date "+%y%m%d-%H%M"`'

export dir_in_tar
dir_in_tar=TEST_DIR

export test_dir_tar
test_dir_tar="$1"

shift

# make path absolute if relative
case $test_dir_tar in
  /*) ;;  # leave absolute path alone
   *) test_dir_tar="`pwd`"/"$test_dir_tar"
      ;;
esac



# verify tar file is accessible
if [ ! -r "$test_dir_tar" ]
then
  echo "test_dir_tar >$test_dir_tar< not readable."
  usage
fi


export installed_script_dir
installed_script_dir="$1"
shift

# verify looks like ROI_PAC scripts dir
if [ ! -x "$installed_script_dir"/make_raw.pl ]
then
  echo "installed_script_dir >$installed_script_dir<"
  echo "does not contain executable make_raw.pl"
  usage
fi


# determin endian-ness  (might not work if using ebcdic charset)

export endian
case "`echo "N" | od -x`" in
  *[eE]0* ) endian=big ;;
         *) endian=little ;;
esac

echo "${endian}-endian byte ordering selected"


export installed_bin_dir
for installed_bin_dir in $*
do
  # strip off trailing bin
  t=`dirname $installed_bin_dir`
  export build_name
  build_name=`basename $t`
  if [ ! -x "$installed_bin_dir/roi" ]
  then
    echo "installed_bin_dir >$installed_bin_dir<"
    echo "does not contain executable roi."
    echo "Skipping >$build_name< test."
  else
    echo "Setting up test directory $build_name/$dir_in_tar"
    (
      mkdir "$build_name"
      cd "$build_name"
      tar xf "$test_dir_tar"
      cd "$dir_in_tar"
      testrun_dir="`pwd`"
      echo "DEM=$testrun_dir/DEM/SoCal.dem" >>"$testrun_dir"/int.proc
      rm -f $testrun_dir/DEM/SoCal.dem
      case $endian in
        big)    cp $testrun_dir/DEM/SoCal.dem.nonpc_byte_order $testrun_dir/DEM/SoCal.dem
                ;;
        little) cp $testrun_dir/DEM/SoCal.dem.pc_byte_order $testrun_dir/DEM/SoCal.dem
                ;;
        *)      echo "Unrecognized endian value.  This should never happen. Exiting."
                exit 1
                ;;
      esac


  cat >batch_script.sh <<EOF
#!/bin/sh

   ( 

      set -x

      export SAR_PRC_DIR SAR_ODR_DIR INT_BIN INT_SCR

      SAR_PRC_DIR="$testrun_dir"/PRC
      SAR_ODR_DIR="$testrun_dir"/ERS/Delft

      INT_BIN="$installed_bin_dir"
      INT_SCR="$installed_script_dir"

      export PATH
      PATH="\${INT_BIN}:\${INT_SCR}:\${PATH}"

      env

      which roi make_raw.pl uncompress

      cd $testrun_dir/930110
      date 
      time make_raw.pl PRC SARLEADER1993011018252739T1Of1 930110

      cd $testrun_dir/950523
      date
      time make_raw.pl PRC SARLEADER1995052318253409T1Of1 950523

      cd $testrun_dir/

      # Generate documentation for RSC keywords
      # that are not created by "Use_rsc" operations in the Perl scripts.
      doc_dem.pl DEM/SoCal.dem.rsc
      doc_leader.pl 930110/930110.raw.rsc
      doc_default_raw.pl 930110/930110.raw.rsc

      date
      time process_2pass.pl int.proc

      date

   ) >batchlog-`date '+%y%m%d-%H%M'` 2>&1
EOF

      chmod +x batch_script.sh
      the_command="$run_batch_script ./batch_script.sh"
      echo "  doing: $the_command"
      eval "$the_command"
    )
  fi
done
