#!/bin/sh
#
# download and build FFTW for use by ROI_PAC
#
# Command line options are passed to configure
#
# so, you can say F77={your preferred fortran compiler}
#

# This script was a quick hack.  Has plenty of room
# for improvement and generalization.
# modified EJF 2006/10/30 to use $ver to make it easier to update for new versions of FFTW

# set -x 

export builds_dir
builds_dir=`pwd`

ver=3.1.2

# build_type=default
# Just using the date for the build type since it would be difficult
# to convert the command line configure parameters to a nice short identifier.
build_type=`date '+%y%m%d-%H%M'`

# Download

if [ ! -f "$builds_dir/NetDist/fftw-$ver.tar.gz" ]
then
  mkdir -p "$builds_dir/NetDist"
  cd "$builds_dir/NetDist"
  echo "Doing:  curl -O ftp://ftp.fftw.org/pub/fftw/fftw-$ver.tar.gz"
  curl -O ftp://ftp.fftw.org/pub/fftw/fftw-$ver.tar.gz
else
  echo "Skipping download."
fi


# Unpack

if [ ! -f "$builds_dir/NetSrc/fftw-$ver/configure" ]
then
  mkdir -p "$builds_dir/NetSrc"
  cd "$builds_dir/NetSrc"
  echo "Doing:  tar xzf $builds_dir/NetDist/fftw-$ver.tar.gz"
  tar xzf "$builds_dir/NetDist/fftw-$ver.tar.gz" || 
   ( echo "Failed to unpack with tar.  Trying gtar."
     gtar xzf "$builds_dir/NetDist/fftw-$ver.tar.gz"
   )
else
  echo "Skipping unpack."
fi


# Create installation directory

export install_dir
install_dir="$builds_dir/NetInst/fftw-$ver_${build_type}"
mkdir -p "$install_dir"

# Build

mkdir -p "$builds_dir/NetBuild/fftw-$ver_${build_type}"
cd "$builds_dir/NetBuild/fftw-$ver_${build_type}"

build_log=build-log-${build_type}

echo "Doing:  configure" --enable-float --prefix="$install_dir" $*
echo "        make install"
echo "          (This may take a few minutes.)"
(
  pwd
  # This sets the MACOSX_DEPLOYMENT_TARGET to the current
  # major OS version on a Mac  (eg 10.4)
  # to prevent this link error when building ROI_PAC with g95 and xlf
  #      ld: Undefined symbols:
  #      _fprintf$LDBLStub
  export MACOSX_DEPLOYMENT_TARGET
  MACOSX_DEPLOYMENT_TARGET=`sw_vers -productVersion 2>/dev/null | sed 's/\([0-9]*\.[0-9]*\).*$/\1/'` 2>/dev/null

  env
  "$builds_dir/NetSrc/fftw-$ver/configure" --enable-float --prefix="$install_dir" $*
  date ; time make install ; date
) >$build_log 2>&1




if [ -f "$install_dir"/lib/libfftw3f.a  -a -f "$install_dir"/include/fftw3.f ]
then
  cat <<EOF
  Looks like build was successful.

  To setup your environment for multibuild.sh

    export FFTW_LIB_DIR=$install_dir/lib
    export FFTW_INC_DIR=$install_dir/include

  or

    setenv FFTW_LIB_DIR $install_dir/lib
    setenv FFTW_INC_DIR $install_dir/include
EOF
else
  cat <<EOF
  There was a problem with the build.

  Look for errors in:

    NetBuild/fftw-$ver_${build_type}/$build_log

EOF
fi
