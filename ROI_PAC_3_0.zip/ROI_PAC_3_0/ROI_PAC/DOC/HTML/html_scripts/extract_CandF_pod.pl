#!/bin/perl -w
###extract_CandF_pod.pl

###If there are no arguments, print the usage info

sub Usage{

`pod2man.pl extract_CandF_pod.pl`;
print("world \n");
exit;
}

### Figure out the number of command line arguments
###print("@ARGV\n");
$iargc = @ARGV + 0;
###print("Number of Command Line Arguments is $iargc \n");
if ($iargc == 0) {
###    print("hello \n");
    Usage();
} else { 
###    print ("Command line argument is $ARGV[0] \n");
}
### Grab the file name off of the command line
$file = $ARGV[0];
print ("extract_CandF_pod input file Name is $file\n"); 
open (IN,"$file");

### Loop over the lines looking for ones containing POD
while($line = <IN>) {
  chomp ($line);
  $origline = $line;

### Search for the Fortran POD stuff
  $line =~ s/CPOD//;
  if($line ne $origline){
###    print("line is  $line\n");
    print STDERR "$line\n";
    }

### Search for the C POD stuff
  $line = $origline;
  $line =~ s/\/\/POD//;
  if($line ne $origline){
###    print("line is  $line\n");
    print STDERR "$line\n";
    }
  }

### General Clean Up
close IN;

=pod

=head1 USAGE

extract_CandF filename

input filename can be either C or Fortran

=head1 FUNCTION

Documentation for the ROI_PAC C and Fortran programs is
"inline" and in the perl POD format.  The lines of
the Fortran routines corresponding to the POD lead with
"CPOD".  The lines of the C Routines lead with
"//POD".  

For example:
CPOD This program replaces cull_points.  Fitoff takes a file of offsets,
CPOD iteratively removes points beyond NSIG standard deviations from the mean,
CPOD and quits when a fit is succesfully achieved or warns that a fit can't
CPOD be made with the inputed parameters.  The output is a reduced file
CPOD of offsets and the affine transformation used to relate the offsets.
Or:
//POD FUNCTIONAL DESCRIPTION:  tilt_i reads each record  of an input file "InFile" 
//POD --these input records are made up of a number (Width) of complex values stored
//POD --as Width X r*4(float) amplitude folowed by Width X r*4(float) phases
//POD and writes these records to a file "OutFile" after a scalar multiplication  by
//POD the complex record exp[I*j*DPhaseRange/Width+i*DPhaseAzimuth/Length+PhaseOffset] 
//POD where:

The argument to this routine is either a C or Fortran
program.  This routine extracts the POD lines sending 
them to STDERR

=head1 ROUTINES CALLED

pod2man.pl

=head1 CALLED BY

=head1 FILES USED

input file passed in on command line

=head1 FILES CREATED

None, output is to STDERR

=head1 PAGE LAST UPDATED

Elaine Chapin, Feb 3, 2004

=cut
