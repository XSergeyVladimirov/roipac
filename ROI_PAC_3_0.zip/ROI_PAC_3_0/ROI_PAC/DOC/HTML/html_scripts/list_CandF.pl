#!/usr/bin/perl
###list_CandF.pl

use Env qw(ROI_PAC INT_BIN INT_SCR);

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $ROI_PAC/Doc/HTML/html_scripts/list_CandF.pl`;
exit 1;
}
@ARGV == 0 or Usage();

###Write to C and F list in correct directory
open MAIN, ">$ROI_PAC/Doc/HTML/process_index/C_F_programs.html" or die "Can't write to $ROI_PAC/DOc/HTML/process_index/C_F_programs.html: $!\n"
;
chdir $INT_BIN or die "Can't change directory to $INT_BIN:$!\n";

@files = split /\s+/, `ls`;

###Print header
print MAIN "
   <HTML> 
	<HEAD> 
	    <TITLE>C and Fortran Program List</TITLE> 
	</HEAD>
<BODY BGCOLOR=\"white\" LINK=\"blue\" VLINK=\"purple\">
<H1>C and Fortran Program and Input File List</H1>
    <TABLE BORDER=5 CELLSPACING=3 CELLPADDING=3 COLS=2 WIDTH=\"100%\" BGCOLOR=\"AADDFF\"  >

      <TR><TH>ROUTINE NAME</TH><TH>FUNCTION</TH></TR>
";

###Create link to each file
foreach $file (@files){
  $file =~ /\.html/ and next;
 
    if (-e "$ROI_PAC/Doc/HTML/html_C_Fortran/$file.html") {
    open READ, "$ROI_PAC/Doc/HTML/html_C_Fortran/$file.html" or die "Can't read $file.html\n";
    while ($line = <READ>){
      if ($line =~ /FUNCTION/){last;}
    }
    while ($line = <READ>){
      
      if ($line =~ /TD/){
	$line = <READ>;
	until ($line =~ /\/TD/){
	  $line .= <READ>;
	}
      }
      close READ;
      print MAIN "<TR VALIGN=\"TOP\"><TD><A href = \"../html\_C\_Fortran/$file.html\">$file</A></TD>
 <TD>$line</TD></TR>
";
    }
  }
  else{
    print "$file.html doesn't exist\n";
    print MAIN "<TR><TD>$file</TD></TR>
";
  }
}

###Print logo and master links
print MAIN "
    </TABLE>
	
    <BR>
    <BR>

    <TABLE BORDER=5 CELLSPACING=3 CELLPADDING=3 COLS=2 WIDTH=\"100%\" BGCOLOR=\"#6688DD\" NOSAVE >
      <TR>
	<TD> LAST UPDATE</TD>	
	<TD>May 18, 1998</TD>
      </TR>
      
      <TR>
	<TD>This software is part of the JPL/Caltech ROI\_PAC suite.
	  <BR>Not for general distribution.</TD>
	<TD>For more info:
	  <address><a href=\"mailto:roi\_pac\@jpl.nasa.gov\">roi\_pac\@jpl.nasa.gov</a></address>
	</TD>
      </TR>
    </TABLE>
    
  <BR><BR>

    <TABLE WIDTH=\"100%\">
      <TR>	
	<TD><A href=\"http://www.jpl.nasa.gov\">
	    <img border=0 src=\"../html\_images/jpllogo.gif\"></A></TD>
	<TD><A href=\"http://www.gps.caltech.edu/seismo\">
	    <img border=0 src=\"../html\_images/white\_sm.gif\"></A></TD>
	<TD><UL>
	    <LI><A href=\"../index.html\">Processing Page</A></LI>
	    <LI><A href=\"../process\_index/perl\_scripts.html\">Perl Scripts</A></LI>
	  </UL></TD>
	<TD><A href=\"http://www.caltech.edu\">
	    <img border=0 src=\"../html\_images/tinycitlogo.gif\"></A></TD>
	<TD><A href=\"http://www.nasa.gov\">
	    <img border=0 src=\"../html\_images/nasa.gif\"></A></TD>
      </TR>
    </TABLE>

    
  </BODY>
</HTML>

";


=pod

=head1 USAGE

B<list_CandF.pl> 

=head1 FUNCTION

Creates html list of C and Fortran programs in  $HTML/html_C_Fortran

=head1 ROUTINES CALLED

none

=head1 CALLED BY

none

=head1 FILES USED

all C and Fortran programs in $HTML/html_C_Fortran 

=head1 FILES CREATED

C_F_programs.html

=head1 PAGE LAST UPDATED

Rowena Lohman, Jun 16, 1998

=cut
