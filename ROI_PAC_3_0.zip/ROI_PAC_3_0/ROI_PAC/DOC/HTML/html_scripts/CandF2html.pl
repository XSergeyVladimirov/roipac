#!/usr/bin/perl

use Env qw(INT_BIN ROI_PAC);

chdir $INT_BIN;
@files = split /\s+/, `ls`;
chdir "$ROI_PAC/Doc/HTML/html_C_Fortran/";
@htmlfiles = split /\s+/, `ls *.html`;

foreach $file (@files){
  $done = "no";
  foreach $html (@htmlfiles){
    $html =~ s/\.html//;
    if ($html eq $file){ $done = "yes";}
  }
  if ($done ne "yes"){
    print "Making $file.html\n";
    open HTML, ">$file.html";
    print HTML  " <HTML> 
        <HEAD> 
            <TITLE>$file</TITLE> 
            <BASE href=\"/home/SAR/INT\_PROC/Doc/HTML/\">
        </HEAD>

<BODY BGCOLOR=\"white\" LINK=\"blue\" VLINK=\"purple\">
    <H1>$file</H1>
    <img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<!-- INDEX BEGIN -->

<UL>

        <LI><A HREF=\"html\_C\_Fortran/$file.html/#USAGE\">USAGE</A>
        <LI><A HREF=\"html\_C\_Fortran/$file.html/#FUNCTION\">FUNCTION</A>
        <LI><A HREF=\"html\_C\_Fortran/$file.html/#PROCESS\">PROCESS</A>
        <LI><A HREF=\"html\_C\_Fortran/$file.html/#CALLED\_BY\">CALLED BY</A>
        <LI><A HREF=\"html\_C\_Fortran/$file.html/#FILES\_USED\">FILES USED</A>
        <LI><A HREF=\"html\_C\_Fortran/$file.html/#FILES\_CREATED\">FILES CREATED</A>
        <LI><A HREF=\"html\_C\_Fortran/$file.html/#LAST\_UPDATE\">PAGE LAST UPDATED</A>
</UL>
<!-- INDEX END -->

<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">
<BR>

<H1><A NAME=\"USAGE\">USAGE
</A></H1>

<BR>
<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<H1><A NAME=\"FUNCTION\">FUNCTION
</A></H1>

<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<H1><A NAME=\"PROCESS\">PROCESS
<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<H1><A NAME=\"CALLED\_BY\">CALLED BY
</A></H1>

<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<H1><A NAME=\"FILES\_USED\">FILES USED
</A></H1>

<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<H1><A NAME=\"FILES\_CREATED\">FILES CREATED
</A></H1>
<BR>
<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<H1><A NAME=\"LAST\_UPDATE\">PAGE LAST UPDATED
</A></H1>
<img src = \"html\_images/blue\_line.gif\" height=\"2\" width=\"100%\">


<TABLE WIDTH=\"100%\">
  <TR><TD><img src = \"html\_images/jpllogo.gif\"></TD>
      <TD><UL>
          <LI><A href=\"process\_index/perl\_scripts.html\">Main Perl Scripts list</A></LI>
          <LI><A href=\"process\_index/C\_F\_programs.html\">C and Fortran program list</A></LI>
          <LI><A href=\"process\_index/index.html\">Main Processing Page</A></LI>

          <LI><A href=\"process\_index/setup\_instructions.html\">Processing Setup Instructions</A></LI>
          <LI><A href=\"process\_index/html\_instructions.html\">HTML Setup Instructions</A></LI></UL></TD>

      <TD><img src = \"html\_images/white\_sm.gif\" ALIGN=\"right\"></TD>
</TR>
</TABLE>
</BODY>
</HTML>
";
    close HTML;
  }
}

=pod

LAST UPDATE

Rowena Lohman, Jun 16, 1998

=cut

