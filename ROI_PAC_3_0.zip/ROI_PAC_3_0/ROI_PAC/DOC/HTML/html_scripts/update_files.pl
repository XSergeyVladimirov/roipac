#!/usr/bin/perl

use Env qw(ROI_PAC INT_SCR);

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $ROI_PAC/Doc/HTML/html_scripts/update_files.pl`;
exit 1;
}

@ARGV == 0 or Usage();
@files = split /\s+/, `ls *.html`;
open LOG, ">UPDATE_LOG";
foreach $file (@files){
  if ($file eq "update_files.pl"){next;}
  $dif = "no";
  $last = 0;
  @stuff = split /\s+/, `ls -l $file`;
  $month = $stuff[5];
  $day   = $stuff[6];
  open IN, "$file";
  open TMP, ">tmp" or die "can't write to tmp";
  foreach $line (<IN>){

    if ($last){  ### Get line after LAST UPDATE

      $line =~ s/<.*>(.*)<.*>/$1/;
      ($date, $year) = split /,/, $line;
      ($month1, $day1) = split /\s+/, $date;
      $month1 =~ s/\s+//g;
      $day1 =~ s/\s+//g; 
      $year =~ s/\s+//g;
      unless ($month eq $month1 && $day eq $day1){
	$line = "<TD>$month $day, $year</TD>\n";
	$dif = "yes";
	print "$month eq $month1 && $day eq $day1\n";
      }
      $last = 0;
    }
    
    
    if ($line =~ /LAST/) {$last =1;}

    print TMP $line;
  }
  print LOG "$month $day: $file\n";
  if ($dif eq "yes"){
    `mv tmp $file`;
    print "Updating $file\n";
  }
  else {print "No change to $file\n";}
}
`rm -f tmp`;

=pod

=head1 PAGE LAST UPDATED

Rowena Lohman, Jun 16, 1998

=cut
