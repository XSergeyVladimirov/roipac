#!/usr/bin/perl
###pod2html.pl

use Env qw(ROI_PAC INT_SCR);

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $ROI_PAC/Doc/HTML/html_scripts/pod2html.pl`;
exit 1;
}
@ARGV == 0 or Usage();

###Create list of all files that end in .pl from $INT_SCR directory
@files = split /\s+/, `ls $INT_SCR/*.pl`;

###Go through each file except pod2man.pl, arclist_PRC.pl, dgxit.pl
foreach $file (@files){
  $file =~ /(pod2man|arclist|dgx)/ and next;
  $file1 = $file;
###Remove pathname from file
  $file1 =~s!.*\/!!g;
###html file is in html directory
  $file2 = "$ROI_PAC/Doc/HTML/html_perl/$file1.html";  
  `pod2html $file > $file2`;
###Fix html format
  `$ROI_PAC/Doc/HTML/html_scripts/htmlfixer.pl $file2`;
}
###Create updated listing of all perl scripts
`$ROI_PAC/Doc/HTML/html_scripts/list_perl.pl`; 

=pod

=head1 USAGE

B<pod2html> 

=head1 FUNCTION

Goes through list of perl scripts and creates html pages in new format

=head1 ROUTINES CALLED

pod2man.pl

htmlfixer.pl

list_perl.pl

=head1 CALLED BY

none

=head1 FILES USED

all perlscripts except pod2man.pl arclist_PRC.pl and dgxit.pl

=head1 FILES CREATED

I<perlscripts>.html

=head1 HISTORY

Rowena Lohman, Jun 16, 1998

=head1 PAGE LAST UPDATED

Elaine Chapin, 26/Nov/2003

=cut
