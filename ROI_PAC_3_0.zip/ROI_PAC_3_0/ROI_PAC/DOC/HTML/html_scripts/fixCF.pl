#!/usr/bin/perl

use Env qw(ROI_PAC INT_SCR);

chdir "$ROI_PAC/Doc/HTML/html_C_Fortran";
@files = split /\s+/, `ls *.html`;
foreach $file (@files){
  print "file is $file\n";
  open IN, "$file";
  open OUT, ">tmp";
  while ($line = <IN>){
    if ( $line =~ /<BR><BR>/){
      $line = "
  <BR><BR>

    <TABLE WIDTH=\"100%\">
      <TR>	
	<TD><A href=\"http://www.jpl.nasa.gov\">
	    <img border=0 src=\"../html\_images/jpllogo.gif\"></A></TD>
	<TD><A href=\"http://www.gps.caltech.edu/seismo\">
	    <img border=0 src=\"../html\_images/white\_sm.gif\"></A></TD>
	<TD><UL>
	    <LI><A href=\"../index.html\">Processing Page</A></LI>
            <LI><A href=\"../process\_index/C\_F\_programs.html\">C and Fortran Programs</A></LI>
	    <LI><A href=\"../process\_index/perl\_scripts.html\">Perl Scripts</A></LI>
	  </UL></TD>
	<TD><A href=\"http://www.caltech.edu\">
	    <img border=0 src=\"../html\_images/tinycitlogo.gif\"></A></TD>
	<TD><A href=\"http://www.nasa.gov\">
	    <img border=0 src=\"../html\_images/nasa.gif\"></A></TD>
      </TR>
    </TABLE>
    
  </BODY>
</HTML>
";
      print OUT $line;
      last;
    }
    print OUT $line;
  }

`mv tmp $file`;
}

=pod

=head1 PAGE LAST UPDATED 

Rowena Lohman, Jun 16, 1998

=cut
 

