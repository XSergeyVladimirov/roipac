#!/usr/bin/perl
### htmlfixer.pl

use Env qw(ROI_PAC INT_SCR);

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $ROI_PAC/Doc/HTML/html_scripts/htmlfixer.pl`;
exit 1;
}
@ARGV == 1 or Usage();

$file = shift;
open IN, "$file" or die "Can't read $file\n";
open OUT, ">tmp";

###Remove .html from file name
$file  =~ s/\.html//;
$title = $file;
$title =~ s!.*\/!!g; ##Remove path from title

###Go through lines of html file, first skip all blank lines, printing to tmp
while (chomp($line = <IN>)){
  $line =~ s/<P>/<BR>/;
  if ($line eq ""){
    print OUT "$line\n";
    next;
  }

###If you come upon a <BR> or <HR>, make sure there aren't more than one
###Replace <HR> with blue_line.gif
  if ($line =~ /<BR>/){
    $brcount and next;
    $brcount++;
  }
  elsif ($line =~ /<HR>/) {
    $hrcount and next;
    $hrcount++;
    $brcount = 0;
    $line = "<img src = \"../html\_images/blue\_line.gif\" height=\"2\" width=\"100\%\">";
  }
  else{$hrcount = 0; $brcount = 0;}

###Remove various things in title which aren't needed, pathname etc
  if ($line =~ /<TITLE>/) {
    $line =~ s!>.*\/(.*)<!>$1<!g;
  }
###Change body format to white background, title, etc
  if ($line =~ /<BODY>/){ $line = "<BODY BGCOLOR=\"white\" LINK=\"blue\" VLINK=\"purple\">
    <H1>$title</H1>
    <img src = \"../html\_images/blue\_line.gif\" height=\"2\" width=\"100\%\">
";}

###Make links
  $line =~ s/roi.proc/<A href=\"roi.proc.html\">roi.proc<\/A>/;
  $line =~ s/process\_infile/<A href=\"int\_generic.proc.html\">process\_infile<\/A>/;
  $line =~ s/info on DEM/<A href=\"dem\_info.html\">info on DEM<\/A>/;
###If routine marker was set in last line (see below) make a link to the
###name of file.html, after removing spaces to keep from writing file   .html
###Keep doing this until reach "Called By" which ends the routine section
  if ($rout){
    if ($line =~ /</){}  ### skip html tags like <BR>
    elsif ($line =~ /\.pl/) {
      $line =~ s/\s+//;
      $line = "<A href=\"$line.html\">$line<\/A>";
    }
    elsif ($line =~ /none/){}
    else {
      $line=~ s/\s+//;
      $line = "<A href=\"../html\_C\_Fortran/$line.html\">$line<\/A>";
    }  
  }

###If called by marker was set in last line (see below) make links
### to files calling this routine, until reach FILES USED
  if ($called){
    if ($line =~ /</){}
    elsif ($line =~ /none/){}
    else {
      $line = "<A href=\"$line.html\">$line<\/A>";
    }
    if ($line =~ /FILES/){
      $called = 0;
    }
  }
  $lastline = $line;

### if update marker was set twice, don't print anything until /body
  if ($update == 2){
    if ($line =~ /BODY/){
      $update = 0;
    }
    else {next};
  }
###Add table at the end of the document, with logos and links
  if ($line =~ /\/BODY/){
    print OUT "
<TABLE WIDTH=\"100\%\">
  <TR><TD><img src = \"../html\_images/jpllogo.gif\"><\/TD>
      <TD><UL>
	  <LI><A href=\"../index.html\">Main Processing Page<\/A><\/LI>
          <LI><A href=\"../process\_index/perl\_scripts.html\">Main Perl Scripts list<\/A><\/LI>
          <LI><A href=\"../process\_index/C\_F\_programs.html\">C and Fortran program list<\/A><\/LI>
<\/UL><\/TD>

      <TD><img src = \"../html\_images/white\_sm.gif\" ALIGN=\"right\"><\/TD>
<\/TR>
<\/TABLE>
<img src = \"../html\_images/blue\_line.gif\" height=\"2\" width=\"100\%\">
     For more info:
    <address><a href=\"mailto:roi\_pac\@gps.caltech.edu\">mailto:roi\_pac\@gps.caltech.edu</a></address>
    <address><a href=\"mailto:roi\_pac\@jpl.nasa.gov\">mailto:roi\_pac\@jpl.nasa.gov</a></address>
This software is part of the ROI\_PAC suite. Not for general distribution.
";
  }


###Mark when reach ROUTINES CALLED and CALLED BY and LAST UPDATE
  if ($line =~ /ROUTINES/){
    $rout = 1;
  }
  if ($line =~ /CALLED BY/){
    $called = 1;
    $rout = 0;
  }
  if ($line =~ /LAST UPDATE/){
    $update++;
    next;
  }
  print OUT "$line\n";
}

`mv tmp $file.html`;

=pod

=head1 USAGE

B<htmlfixer> I<file>.html  

=head1 FUNCTION

Changes html files created by pod2html to new format

=head1 ROUTINES CALLED

none

=head1 CALLED BY

pod2html.pl

=head1 FILES USED

I<file>.html

=head1 FILES CREATED

I<file>.html

=head1 PAGE LAST UPDATED

Rowena Lohman, Jun 16, 1998

=cut
