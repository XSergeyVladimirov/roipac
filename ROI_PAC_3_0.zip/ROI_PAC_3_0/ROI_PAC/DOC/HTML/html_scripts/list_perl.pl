#!/usr/bin/perl
###list_perl.pl

use Env qw(ROI_PAC INT_SCR);

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $ROI_PAC/Doc/HTML/html_scripts/list_perl.pl`;
exit 1;
}
@ARGV == 0 or Usage();

open MAIN, ">$ROI_PAC/Doc/HTML//process_index/perl_scripts.html" or die "Can't write to perl_scripts.html";
chdir "$ROI_PAC/Doc/HTML//html_perl";
@files = split /\s+/, `ls *.pl.html`;

###Print header
print MAIN "
   <HTML> 
	<HEAD> 
	    <TITLE>Perl Script List</TITLE> 
	</HEAD>
<BODY BGCOLOR=\"white\" LINK=\"blue\" VLINK=\"purple\">
<H1>Perl Script List</H1>
     <TABLE BORDER=5 CELLSPACING=3 CELLPADDING=3 COLS=2 WIDTH=\"50%\" BGCOLOR=\"AADDFF\"  >

      <TR><TH>SCRIPT NAME</TH></TR>

";
###Print link for each file
foreach $file (@files){
  $filename = $file;
  $filename =~ s/\.html//; ###Remove html suffix
  $filename =~ s!.*\/!!g;  ###Remove pathname
  $filename =~ /(pod2man|arclist|dgx)/ and next;
  print MAIN "<TR><TD><A href = \"../html\_perl/$file\">$filename</A></TD></TR>
";
}
###Print logos and links
print MAIN "
</TABLE>
    <BR>
    <BR>

    <TABLE BORDER=5 CELLSPACING=3 CELLPADDING=3 COLS=2 WIDTH=\"100%\" BGCOLOR=\"#6688DD\" NOSAVE >
      <TR>
	<TD> LAST UPDATE</TD>	
	<TD>May 18, 1998</TD>
      </TR>
      
      <TR>
	<TD>This software is part of the JPL/Caltech ROI\_PAC suite.
	  <BR>Not for general distribution.</TD>
	<TD>For more info:
	  <address><a href=\"mailto:roi\_pac\@jpl.nasa.gov\">roi\_pac\@jpl.nasa.gov</a></address>
	</TD>
      </TR>
    </TABLE>
    
  <BR><BR>

    <TABLE WIDTH=\"100%\">
      <TR>	
	<TD><A href=\"http://www.jpl.nasa.gov\">
	    <img border=0 src=\"../html\_images/jpllogo.gif\"></A></TD>
	<TD><A href=\"http://www.gps.caltech.edu/seismo\">
	    <img border=0 src=\"../html\_images/white\_sm.gif\"></A></TD>
	<TD><UL>
	    <LI><A href=\"../index.html\">Processing Page</A></LI>
	    <LI><A href=\"../process\_index/C\_F\_programs.html\">C and Fortran programs</A></LI>
	  </UL></TD>
	<TD><A href=\"http://www.caltech.edu\">
	    <img border=0 src=\"../html\_images/tinycitlogo.gif\"></A></TD>
	<TD><A href=\"http://www.nasa.gov\">
	    <img border=0 src=\"../html\_images/nasa.gif\"></A></TD>
      </TR>
    </TABLE>
    
  </BODY>
</HTML>
";


=pod

=head1 USAGE

B<list_perl.pl> 

=head1 FUNCTION

Creates html list of perl scripts in $ROI_PAC/Doc/HTML//html_perl

=head1 ROUTINES CALLED

none

=head1 CALLED BY

pod2html.pl

=head1 FILES USED

all perl scripts in $ROI_PAC/Doc/HTML//html_perl 

=head1 FILES CREATED

perl_scripts.html

=head1 PAGE LAST UPDATED 

Rowena Lohman, Jun 16, 1998

=cut
