#!/usr/bin/perl
### htmlfixer.pl

use Env qw(ROI_PAC INT_SCR);

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $ROI_PAC/Doc/HTML/html_scripts/htmlfixer.pl`;
exit 1;
}
@ARGV == 1 or Usage();

$file = shift;
open IN, "$file" or die "Can't read $file\n";
open OUT, ">tmp";


###Remove .html from file name
$file  =~ s/\.html//;
$title = $file;
$title =~ s!.*\/!!g; ##Remove path from title

###Go through lines of html file, first skip all blank lines, printing to tmp
while (chomp($line = <IN>)){
  $line =~ /(<P>|<HR>)/ and next;
  unless ($line =~ /\S/){ 
    next;
  }
  

###Remove various things in title which aren't needed, pathname etc
  if ($line =~ /<TITLE>/) {
    $line =~ s!>.*\/(.*)<!>$1<!g;
  }
###Change body format to white background, title, etc
  if ($line =~ /<BODY>/){ $line = "  <BODY TEXT=\"\#000000\" BGCOLOR=\"\#FFFFFF\" LINK=\"\#0000EE\" VLINK=\"\#551A8B\" ALINK=\"\#FF0000\">
    <H1>$title</H1>
";}

###Remove index, start table
  $line =~ /INDEX/ and next;
  if ($line =~ /<UL>/){$index = 1;}
  if ($index){
    if ($line =~ /<\/UL>/){
      $index = 0;
      $line =   "<TABLE BORDER=5 CELLSPACING=3 CELLPADDING=3 COLS=2 WIDTH=\"100%\" BGCOLOR=\"AADDFF\">
";
      print OUT "$line";
    }
    next;
  }

###Make table rows out of headers
  if ($line =~ /<H1><A NAME=\"(.*)\">/){
    if ($header) {$line = "</TD></TR>
";}
    else {$line = '';}
    $line = "$line
      <TR VALIGN=\"TOP\">
	<TD><H3>$1</H3></TD>
";
    $header = 1;
  }
  
  $line =~ /<\/A><\/H1>/ and $line = "<TD>";


###Make links to info files
  $line =~ s/roi.proc/<A href=\"roi.proc.html\">roi.proc<\/A>/;
  $line =~ s/process\_infile/<A href=\"int\_generic.proc.html\">process\_infile<\/A>/;
  $line =~ s/info on DEM/<A href=\"dem\_info.html\">info on DEM<\/A>/;

###If routine marker was set in last line (see below) make a link to the
###name of file.html, after removing spaces to keep from writing file   .html
###Keep doing this until reach "Called By" which ends the routine section
  if ($rout){
    if ($line =~ /</){}  ### skip html tags like <BR>
    elsif ($line =~ /\.pl/) {
      $line =~ s/\s+//;
      $line = "<A href=\"$line.html\">$line<\/A><BR>";
    }
    elsif ($line =~ /none/){}
    else {
      $line=~ s/\s+//;
      $line = "<A href=\"../html\_C\_Fortran/$line.html\">$line<\/A><BR>";
    }  
  }

###If called by marker was set in last line (see below) make links
### to files calling this routine, until reach FILES USED
  if ($called){
    if ($line =~ /</){}
    elsif ($line =~ /none/){}
    else {
      $line = "<A href=\"$line.html\">$line<\/A><BR>";
    }
    if ($line =~ /FILES/){
      $called = 0;
    }
  }
  $lastline = $line;

### if history marker was set, don't print anything until /body
  if ($history){
    $line =~ /.*,(.*),(.*)/ and $date = "$1,$2";
    if ($line =~ /BODY/){
      $history = 0;
    }
    else {next};
  }


###Add table at the end of the document, with logos and links
  if ($line =~ /\/BODY/){
    print OUT "
           </TD></TR>
	</TABLE>

<BR>
<BR>
    <TABLE BORDER=5 CELLSPACING=3 CELLPADDING=3 COLS=2 WIDTH=\"100%\" BGCOLOR=\"#6688DD\" NOSAVE >
      <TR>
	<TD> LAST UPDATE</TD>	
	<TD> $date</TD>
      </TR>
      
      <TR>
	<TD>This software is part of the JPL/Caltech ROI\_PAC suite.
	  <BR>Not for general distribution.</TD>
	<TD>For more info:
	  <address><a href=\"mailto:roi\_pac\@jpl.nasa.gov\">roi\_pac\@jpl.nasa.gov</a></address>
	</TD>
      </TR>
    </TABLE>
    
  <BR><BR>
    <TABLE WIDTH=\"100%\">
      <TR>	
	<TD><A href=\"http://www.jpl.nasa.gov\">
	    <img border=0 src=\"../html\_images/jpllogo.gif\"></A></TD>
	<TD><A href=\"http://www.gps.caltech.edu/seismo\">
	    <img border=0 src=\"../html\_images/white\_sm.gif\"></A></TD>
	<TD><UL>
	    <LI><A href=\"../index.html\">Processing Page</A></LI>
            <LI><A href=\"../process\_index/perl\_scripts.html\">Perl Scripts</A></LI>
	    <LI><A href=\"../process\_index/C\_F\_programs.html\">C and Fortran programs</A></LI>
	  </UL></TD>
	<TD><A href=\"http://www.caltech.edu\">
	    <img border=0 src=\"../html\_images/tinycitlogo.gif\"></A></TD>
	<TD><A href=\"http://www.nasa.gov\">
	    <img border=0 src=\"../html\_images/nasa.gif\"></A></TD>
      </TR>
    </TABLE>
    
  </BODY>
</HTML>
    ";
  }

###Add carriage returns during lists of files or usage statements

  if ($usage)   {$line =~ /TD/ or $line .= "<BR>";}
  if ($used)    {$line =~ /TD/ or $line .= "<BR>";}
  if ($created) {$line =~ /TD/ or $line .= "<BR>";}

###Mark when reach sections (for future use
  if ($line =~ /USAGE/)    { $usage   = 1;}
  if ($line =~ /ROUTINES/) { $rout    = 1; $usage  = 0; }
  if ($line =~ /BY/)       { $called  = 1; $rout   = 0; }
  if ($line =~ /USED/)     { $used    = 1; $called = 0; }
  if ($line =~ /CREATED/)  { $created = 1; $used   = 0; }
  
  if ($line =~ /HISTORY/){  ### Mark update to skip
    $history ++;
    $created = 0;
    next;
  }
  print OUT "$line\n";
}

`mv tmp $file.html`;

=pod

=head1 USAGE

B<htmlfixer> I<file>.html  

=head1 FUNCTION

Changes html files created by pod2html to new format

=head1 ROUTINES CALLED

none

=head1 CALLED BY

pod2html.pl

=head1 FILES USED

I<file>.html

=head1 FILES CREATED

I<file>.html

=head1 PAGE LAST UPDATED

Rowena Lohman, Jun 16, 1998

=cut
