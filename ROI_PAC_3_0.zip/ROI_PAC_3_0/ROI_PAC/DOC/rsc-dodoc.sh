#!/bin/sh
#
#  Produce HTML from RSC keyword POD files
#    which are produced when ROI_PAC Perl
#    scripts are run.

command_name=`basename $0`

top_index_html_path=index.html


usage(){
# Send documentation to stderr
1>&2 cat <<EOF
usage: $command_name TEST_DIR rsc-introduction.pod

  Concatenates POD files from TEST_DIR with rsc-introduction.pod
  and formats as HTML.

  See see Generic.pm::Doc_rsc documentation for more information.

  All outputs are to current directory.

  Example:

    $command_name TEST_DIR rsc-introduction.pod

  Note: May have problems if pathnames contain spaces.
EOF
exit 1
}



if [ $# -ne 2 ]
then
  usage
  exit 1
fi


test_dir="$1"
introduction="$2"

if [ ! -d "$test_dir" ]
then
  echo "test_dir >$test_dir_tar< not directory." 1>&2
  usage
  exit 1
fi

if [ ! -r "$introduction" ]
then
  echo "$introduction >$introduction< not readable." 1>&2
  usage
  exit 1
fi

cat "$introduction" >rsc_doc.pod

find "$test_dir" -name '*.pod' | xargs ls -l | sort -r +7 | awk '{print $9}' | sed 's,\(^.*/\)\(.*\),\2 \1\2,' | awk '{if(seen[$1]) ; else { print $0 ; seen[$1]=1} }' | sort -t: -k1,1 -k2,2n | awk '{print $2}' | xargs cat >> rsc_doc.pod


pod2html --infile=rsc_doc.pod --outfile=rsc_doc.html --title='Resource Keyword Documentation'

# cleanup
rm -f pod2htmd.tmp pod2htmi.tmp

echo "RSC keyword documentation in rsc_doc.html"

# Unfortunately this isn't integrated with dodoc.sh documentation

