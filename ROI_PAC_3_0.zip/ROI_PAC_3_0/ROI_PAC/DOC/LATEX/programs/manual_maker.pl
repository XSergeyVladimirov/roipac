#!/usr/bin/perl

chdir ("/home/SAR/INT_PROC/INT_SCR/");

@files = split /\s+/, `ls *.pl`;
foreach $file (@files){
  $file =~ /(arclist_PRC|dgxit|inverse3d)/ and next; 
 `pod2latex $file`;
  `mv $file.tex /home/SAR/INT_PROC/Doc/LATEX/texfiles/`;
}

chdir ("/home/SAR/INT_PROC/Doc/LATEX/texfiles/");
`/home/SAR/INT_PROC/Doc/LATEX/programs/texfixer.pl`;
open READ, "/home/SAR/INT_PROC/Doc/LATEX/programs/wrapper.tex" or die "can't read wrapper.tex";
open WRAP, ">/home/SAR/INT_PROC/Doc/LATEX/texfiles/INT_PROC_MAN.tex" or die "can't write INT_PROC_MAN.tex";

until ($line =~ /tableofcontents/){
  $line = <READ>;
  print WRAP $line;
}

foreach $file (@files){
  unless ($file =~ /(pod2man|dgxit|arclist)/){
    print WRAP "\\include{$file}\n";
  }
}

while (<READ>){
  print WRAP $_;
}


close(READ);
close(WRAP);

