#!/usr/bin/perl
@files = split /\s+/, `ls *.pl.tex`;
foreach $file (@files){
  open READ, "$file";
  open WRAP, ">tmp";
  $filename = $file;
  $filename =~ s/\.tex//;
  while ($line = <READ>){
    $line =~ /info on DEM/ and next;
    if ($line =~ /\\section/){
      $line = "\\addcontentsline{toc}{section}{$filename}%\n";
    }
    $line =~ s/\_/\\\_/g;
    $line =~ s/\\underscore{}/\\_/g;
    print WRAP $line;  
  }
  `mv tmp $file`;
}
