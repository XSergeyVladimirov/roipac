#!/bin/sh
#
#  Produce HTML from POD in source_tree

command_name=`basename $0`

top_index_html_path=index.html


usage(){
# Send documentation to stderr
1>&2 cat <<EOF
usage: $command_name source_tree

  Searches source_tree for source files containing
  POD format documentation.

  POD documentation is converted to HTML (when needed)
  and several indices are created.

  All outputs are to current directory.

  Example:

    mkdir new_html
    cd new_html
    $command_name ~/ROI_PAC_DIST
    open $top_index_html_path # If on a Mac

  Note: May have problems if pathnames contain spaces.
EOF
exit 1
}



if [ $# -ne 1 ]
then
  usage
fi

search_root="$1"

############################################################################
#
#  Extract POD from source files
#
#    As each source file containing POD is processed,
#     an entry is added to the $master_index_table
#
############################################################################

# Language filename extensions association
# Fortran .f .F .f90 .inc
# C .c .h
# Perl .pl .pm

master_index_table=master_index_table

echo "Extracting POD from source files under $search_root"
echo "  and building master_index_table >$master_index_table<"

rm -f $master_index_table

find $search_root -type f \
  -name '*.f' \
  -o -name '*.F' \
  -o -name '*.f90' \
  -o -name '*.inc' \
  -o -name '*.c' \
  -o -name '*.h' \
  -o -name '*.pm' \
  -o -name '*.pl' \
| xargs grep -l -e '^CPOD=pod' -e '^=pod' | while read source_path
do
  # $source_path contains some POD
  case $source_path in
      *.f | *.F | *.f90 | *.inc )
      source_language=_Fortran_
      # NOTE: source_language value must match value of grep in below "here" document
      pod_path=`basename $source_path`.pod
      grep '^CPOD' $source_path | sed 's,^CPOD,,' > $pod_path
      pod_lines=`wc -l <$pod_path`
      ;;
      *.c | *.h )
      source_language=_C_
      # NOTE: source_language value must match value of grep in below "here" document
      # don't know how POD is C will look yet
      ;;
      *.pm | *.pl )
      source_language=_Perl_
      # NOTE: source_language value must match value of grep in below "here" document
      ## lamness: see below
      ##pod_path=$source_path
      pod_path=`basename $source_path`.pod
      pod_lines=`sed -n '/^=pod/,/^=cut/p' $source_path | wc -l`
      ## pod2html lameness: seem to need a local reference to
      ##   to perl file for links "L<>" to work
      if [ $source_path -nt $pod_path ]
      then
        # above test doesn't improve performance much
        cp $source_path $pod_path
      fi
      ;;
      * )
      source_language=Unknown
      pod_lines=0
  esac

  if [ 0 -ne $pod_lines ]
  then
    # above test should always be true
    pod_title=`basename $source_path`
    html_path=$pod_title.html
    if [ ! -f $html_path -o $html_path -ot $source_path ]
    then
      # HTML file does not exist or is out of date
      echo Creating $html_path $source_language $source_path $pod_lines $pod_title 
      pod2html --infile=$pod_path --outfile=$html_path --title=$pod_title
    fi
    # Extract description from POD
    #   Description as first sentance FUNCTION block in POD
    description=`sed -n -e '/=head1 FUNCTION/,/^=/{' -e 's,^=.*,,' -e 's,FUNCTIONAL DESCRIPTION:,,' -e '/[^ ]/H' -e '}' -e '${' -e x -e 'y/\n/ /' -e 's,\([^\.]\)  *,\1 ,g' -e 's,\. .*,\.,' -e p -e '}' $pod_path`
    # How above sed works
    #   for text between /=head1 FUNCTION/ and /^=/
    #     remove ^=.* pod tag
    #     remove text "FUNCTIONAL DESCRIPTION:"
    #     append non-blank lines to hold space
    #   After entire file has been read
    #     swap hold and pattern space
    #     translate newlines to single space
    #     replace occurances of multiple spaces (not following a period) with a single space
    #     throw away everything after first '. ' (end of first sentance)
    #     print out the resulting line
   
    # output various usefull info to master_index_table file
    echo "$pod_title $source_language $pod_lines $source_path $description" >> $master_index_table
  else
    echo "NOTE: pod_lines is 0 for $source_path.  Should not happen."
  fi
done

# verify titles are unique
#  not implemented yet

############################################################################
#
# burst, sort and reformat master_index_table into individual pod indicies
#   and convert pod indicies to html  
#
#   master index format is
#    "$pod_title $source_language $pod_lines $source_path $description"
#
############################################################################

top_index_pod_path=index.pod
top_index_pod_title=Index

# POD header for top level index

>$top_index_pod_path cat <<EOF
=pod

=head1 Indices

Description, Index

EOF


# Build individual indicies

while read extract_name extract_command
do
  while read sort_name sort_command
  do
  # the above reads come from below "done <<EOF" "here" documents
  #   They form a product of extractions and sort orderings

    index_description="B<${extract_name}> source sorted by B<${sort_name}>"
    index_name=IDX-${extract_name}-${sort_name}
    index_pod_path=${index_name}.pod
    index_html_path=${index_name}.html
    index_pod_title=$index_name

    echo "Creating Index $index_description"
    # echo "  Using commands  $extract_command '|' $sort_command  producing $index_html_path"

    # Pod header for index
    >$index_pod_path cat <<EOF
=pod

=head1 $index_description

I<Below would be a table if POD supported tables.>

Source Name, POD Lines, Description (I<first sentence of FUNCTION block>)

EOF

    # extract and sort index info from $master_index_table
    #   and reformat into POD entries 
    <$master_index_table eval "$extract_command" | eval "$sort_command" | awk '{t=$0;sub("[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *","",t);printf("L<%s|%s> S<  >  %s S<    >  %s\n\n",$1,$1,$3,t)}' >>$index_pod_path

    #  sub() sets 't' to the text following third field in master index, this is the first sentance of the functional description
    pod2html --infile=$index_pod_path --outfile=$index_html_path --title=$index_pod_title --htmlroot=. --podpath=. --flush

    # Add entry for this index to the top level index
    echo "$index_description  L<$index_pod_title|$index_pod_title>" >>$top_index_pod_path
    echo "" >>$top_index_pod_path

  done <<EOF
  pod_lines sort -rn +2
  source_name sort -f +0
EOF
  # The above "here" document feeds "while read sort_name sort_command"

done <<EOF
Perl grep ' _Perl_ '
Fortran grep ' _Fortran_ '
C grep ' _C_ '
All  grep ' * '
EOF
# The above "here" document feeds "while read extract_name extract_command"
#   The '_' (underscores) are to prevent matching with text in the description

############################################################################
#
# Build the RDF indicies
#
############################################################################

rdf_index_table=rdf_index_table

echo "Extracting RDF rdfval() keywords from source files under $search_root"
echo "  and building rdf_index_table >$rdf_index_table<"

find $search_root -type f \
  -name '*.f' \
  -o -name '*.F' \
  -o -name '*.f90' \
  -o -name '*.inc' \
  -o -name '*.c' \
  -o -name '*.h' \
  -o -name '*.pm' \
  -o -name '*.pl' \
| xargs grep rdf |
   grep 'rdfval(' | grep -v ':c' | sed -e 's,: *.*rdfval(, ,' -e 's,).*,,' | sed -e 's, ,:,' -e 's, ,_,g' -e 's,:, ,' >$rdf_index_table

# produce table of source files and rdf keyword (KW) strings by
#   extracting kw strings from rdfval() calls
#   source_file_name rdfval()_string
#   grep 'rdfval(' | grep -v ':c' | sed -e 's,: *.*rdfval(, ,' -e 's,).*,,' | sed -e 's, ,:,' -e 's, ,_,g' -e 's,:, ,' | sort +1
#   ^ extract rdfval calls
#                    ^ discard comments
#                                           ^ convert text between filename and start of KW to one space
#                                                                             ^ convert spaces in KW to underscores
#    first space becomes ':', remaining spaces become '_', first ':' becomes space

#  can sort keywords by number of occurances in different source files
#    | uniq -c -f 1 | sort -rn 


########################################
#
#  Build first rdfval() index
#

index_description="RDF C<rdfval()> parameters and referencing source files"
index_name=IDX-rdf_by_kw
index_pod_path=${index_name}.pod
index_html_path=${index_name}.html
index_pod_title=$index_name

echo "Creating Index $index_description >$index_pod_path<"

rdf_by_kw_index_pod_path=$index_pod_path


# POD header for rdf index

>$rdf_by_kw_index_pod_path cat <<EOF
=pod

=head1 $index_description

Only keywords accessed via a call to C<rdfval()> are listed.

Links are created for source files that also have POD documentation.

I<Below would be a table if POD supported tables.>

C<rdfval()> paramters, source file(s)

EOF

# Produce POD rdf_by_kw_index from rdf_index_table

#   sort alphabetically by keyword
#     for each keyword, list source files
#     that reference it via rdfval() call
#   Put in single letter '=head2' headings
#     which cause index to produced at top of HTML,
#     and separates blocks of keywords.

sort +1 $rdf_index_table |
while read source_path rdf_keyword
do
  if [ "${rdf_keyword}" != "${previous_rdf_keyword}" ]
  then
    # Produce POD for a new keyword

    rdf_first_char=`expr "${rdf_keyword}" : '.\(.\).*'`
    if [ "$rdf_first_char" != "$previous_rdf_first_char" ]
    then
      # Insert single character heading when first character
      #   of keyword names changes
      echo
      echo
      echo "=head2 $rdf_first_char"

      previous_rdf_first_char=$rdf_first_char
    fi

    echo 
    echo 
    echo "C<$rdf_keyword> S<      >"
    # rdf_keyword name is output a POD C<> typewrite text

    previous_rdf_keyword="$rdf_keyword"
  fi
  short_path_name=`echo $source_path | sed 's,^.*/\([^/][^/]*/[^/][^/]*\),\1,'`
  # short_path_name is last two components of path
  echo -n "L<$short_path_name|`basename $short_path_name`>  S< > "
  # output short_path_name as POD link
done >>$rdf_by_kw_index_pod_path


echo "Converting POD >$index_pod_path< to HTML >$index_html_path<"

pod2html --infile=$index_pod_path --outfile=$index_html_path --title=$index_pod_title --htmlroot=. --podpath=. --flush  2>&1 | grep -v 'cannot resolve L'
# grep discards error messages about not being able to resolve links
#   these are for source files that contain rdfval() keywords, but no POD doc

# Add entry for this index to the top level index
echo "$index_description  L<$index_pod_title|$index_pod_title>" >>$top_index_pod_path
echo "" >>$top_index_pod_path


########################################
#
#  Build second rdfval() index
#

index_description="Source files accessing RDF keywords via C<rdfval()>"
index_name=IDX-rdf_by_source
index_pod_path=${index_name}.pod
index_html_path=${index_name}.html
index_pod_title=$index_name

echo "Creating Index $index_description >$index_pod_path<"

rdf_by_source_index_pod_path=$index_pod_path



# POD header for rdf index

>$rdf_by_source_index_pod_path cat <<EOF
=pod

=head1 Source files accessing RDF keywords via C<rdfval()>

Only keywords accessed via a call to C<rdfval()> are listed.

Links are created for source files that also have POD documentation.

I<Below would be a table if POD supported tables.>

source file, C<rdfval()> paramters

EOF

# Produce POD rdf_by_kw_index from rdf_index_table

#   sort alphabetically by source_path
#     for each source file, list RDF keywords
#     accessed via rdfval() call
#   Source files are output as POD '=head2' headings
#     which causes index to be produced at top of HTML,
#     and separates blocks of keywords.

in_item=false

sort  $rdf_index_table |
while read source_path rdf_keyword
do
  if [ "${source_path}" != "${previous_source_path}" ]
  then
    # Produce POD for a new source file

    if $in_item
    then
      # POD to end previous =item list
      echo
      echo "=back"
      in_item=false
    fi

    short_path_name=`echo $source_path | sed 's,^.*/\([^/][^/]*/[^/][^/]*\),\1,'`
    # short_path_name is last two components of path
    echo
    echo "=head2 L<$short_path_name|`basename $short_path_name`>"
    # output short_path_name as POD =head2 header and link

    # POD to start =item list
    echo
    echo "=over 4"

  fi

  echo 
  echo "=item *"
  in_item=true

  echo 
  echo "C<$rdf_keyword>"
  # rdf_keyword name is output a POD C<> typewrite text

  previous_source_path="$source_path"

done >>$rdf_by_source_index_pod_path


echo "Converting POD >$index_pod_path< to HTML >$index_html_path<"

pod2html --infile=$index_pod_path --outfile=$index_html_path --title=$index_pod_title --htmlroot=. --podpath=. --flush  2>&1 | grep -v 'cannot resolve L'
# grep discards error messages about not being able to resolve links
#   these are for source files that contain rdfval() keywords, but no POD doc

# Add entry for this index to the top level index
echo "$index_description  L<$index_pod_title|$index_pod_title>" >>$top_index_pod_path
echo "" >>$top_index_pod_path

############################################################################
#
# Finally convert top level index POD to html
#
############################################################################

pod2html --infile=$top_index_pod_path --outfile=$top_index_html_path --title=$top_index_pod_title --htmlroot=. --podpath=. --flush
echo "Top level index is $top_index_html_path"
