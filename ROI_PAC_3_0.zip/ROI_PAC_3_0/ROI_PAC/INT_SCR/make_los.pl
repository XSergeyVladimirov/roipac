#!/usr/bin/perl
### make_los.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/make_los.pl `;
exit 1;
}
@ARGV >= 4 or Usage();
@args = @ARGV;

$int_dir   = shift;
$sim_dir   = shift;
$geo_dir   = shift;
$file      = shift; #### file that was geocoded
$im12      = shift;
$Rlooks_sim     = shift or $Rlooks_sim=4;
$Rlooks_unw     = shift or $Rlooks_unw=4;
$Lxmin0               = shift;
$Lxmax0               = shift;
$Lymin0               = shift;
$Lymax0               = shift;


#################
Message "Checking I/O";
#################
@Infiles  = ("$geo_dir/IntSim.in","$int_dir/$file");
@Outfiles = ("$geo_dir/incidence.unw");
&IOcheck(\@Infiles, \@Outfiles);
Log("make_los.pl", @args);

chdir $geo_dir;

$sim2unwlook = $Rlooks_unw / $Rlooks_sim;

$original_sim = "SIM${Rlooks_sim}_${Rlooks_sim}rlks.hgt";
$new_sim      = "SIM${Rlooks_sim}_${Rlooks_unw}rlks.hgt";

`ln -s $sim_dir/${original_sim} .`;
`ln -s $sim_dir/${original_sim}.rsc .`;

`$INT_SCR/look.pl  $original_sim\\
                    $sim2unwlook`;
                    Status "look.pl";


open INT, ">temp.in";
print INT <<END;
Incidence angle in simulated range,doppler coordinates  (-) = incidence.unw
Resampled height in simulated range,doppler coordinates         (-) = ${new_sim}
END
    close(INT);
`cat temp.in IntSim.in > make_los.in`;
`rm temp.in`;
#################
Message "Writing file: make_los.in";
#################



Message "$INT_BIN/make_los make_los.in";
`$INT_BIN/make_los make_los.in`;
Status "make_los";

`cp $int_dir/$file.rsc $geo_dir/incidence.unw.rsc`;

# Because trans file made using affine tranformation from radar coordinates
# must convert look file to radar coordinates
$aff2geolooks = $Rlooks_unw / $Rlooks_sim;
$aff_file         = "$int_dir/${im12}_${Rlooks_sim}rlks_SIM.aff";
open IN, "$aff_file" or die "Can't read $aff_file\n";
chomp($line = <IN>);
@aff_par = split /\s+/, $line;
close(IN);
#change effective looks of old affine transformation parameters if needed
$aff_par[4] = $aff_par[4]/$aff2geolooks;
$aff_par[5] = $aff_par[5]/$aff2geolooks;

###############################################
Message "Registering the look vector to radar coords";
###############################################
`$INT_SCR/rect.pl incidence.unw     \\
                  rect_incidence.unw \\
                  $aff_par[0]     \\
                  $aff_par[1]     \\
                  $aff_par[2]     \\
                  $aff_par[3]     \\
                  $aff_par[4]      \\
                  $aff_par[5]`;
Status "rect.pl";



  ##########################################################################
   Message "Geocoding $tobegeocoded";
   ##########################################################################
  `$INT_SCR/geocode.pl geomap_${Rlooks_unw}rlks.trans \\
                       rect_incidence.unw  \\
                       geo_incidence.unw \\
                       $Lxmin0  \\
                       $Lxmax0 \\
                       $Lymin0 \\
                       $Lymax0`; 
                         Status "geocode.pl";


#`rm incidence.unw* rect_incidence.unw*`;

exit 0;

=pod

=head1 USAGE

B<make_los.pl> I<int_dir sim_dir geo_dir> tobegeocoded_file date1-date2 Rlooks_sim Rlooks_geo

=head1 FUNCTION

builds the simulation files, NOTE use absolute pathnames for directories!

=head1 ROUTINES CALLED

rect.pl

geocode.pl

make_los

find_affine.pl

=head1 CALLED BY


=head1 FILES USED

geomap_${looks}rlks.trans

SIM_${looks}rlks.hgt.rsc

IntSim.in

cull.out

=head1 FILES CREATED

geo_look.unw

=head1 HISTORY

Perl  Script : Matt Pritchard 03/29/00

=head1 LAST UPDATE


=cut
