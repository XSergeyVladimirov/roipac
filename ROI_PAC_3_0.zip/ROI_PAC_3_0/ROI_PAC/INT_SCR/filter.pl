#!/usr/bin/perl
### filter.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/filter.pl`;
exit 1;
}
@ARGV == 4 or Usage();
@args = @ARGV;

$infile   = shift;
$ps       = shift;
$method   = shift;
$filtfile = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ("$infile.int",   "$infile.int.rsc");
@Outfiles = ("$filtfile.int", "$filtfile.int.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("filter.pl", @args);

#################
Message "Filtering";
#################
$width  = Use_rsc "$infile.int read WIDTH";
$length = Use_rsc "$infile.int read FILE_LENGTH";

`$INT_BIN/cpx2mag_phs $infile.int pwr phs $width`;

`cp $infile.int.rsc $filtfile.int.rsc`;

Message "$INT_BIN/psfilt $infile.int $filtfile.int $width $ps";
`$INT_BIN/psfilt $infile.int $filtfile.int $width $ps`;

if($method eq "adapt_filt"){
  `mv $filtfile.int     ${filtfile}_psfilt.int`;
  `mv $filtfile.int.rsc ${filtfile}_psfilt.int.rsc`;
  Message "$INT_SCR/adapt_filt.pl ${filtfile}_psfilt $filtfile";
  `$INT_SCR/adapt_filt.pl ${filtfile}_psfilt $filtfile`;
  `$INT_BIN/cpx2mag_phs ${filtfile}_psfilt.int /dev/null  phs_filt $width`;
  `$INT_BIN/add_phs phs_filt phs phs_filt2 $width $length 0 1`;
  `$INT_BIN/mag_phs2cpx pwr phs_filt2 ${filtfile}_psfilt.int $width`;
}


`$INT_BIN/cpx2mag_phs $filtfile.int /dev/null  phs_filt $width`;
`$INT_BIN/add_phs phs_filt phs phs_filt2 $width $length 0 1`;
`$INT_BIN/mag_phs2cpx pwr phs_filt2 $filtfile.int $width`;

`rm pwr phs phs_filt phs_filt2`;

exit 0;

=pod

=head1 USAGE

B<filter.pl> I<intfile_prefix filter_strength filter_method filtfile_prefix>

=head1 FUNCTION

Filters an interferogram 

=head1 ROUTINES CALLED

rmg2mag_phs

cpx2mag_phs

mag_phs2cpx

mag_phs2rmg

psfilt

adapt_filt.pl

=head1 CALLED BY

process.pl

=head1 FILES USED

I<infile>.int

I<infile>.int.rsc

=head1 FILES CREATED

I<filtfile>.int

I<filtfile>.int.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Frederic CRAMPE, Nov 13, 1998
Mark SIMONS, Nov 15, 1998

=head1 LAST UPDATE

Frederic CRAMPE, Aug 25, 1999

=cut
