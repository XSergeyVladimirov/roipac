#!/usr/bin/perl
### cull_offset.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/cull_offset.pl`;
exit 1;
}
@ARGV == 1 or Usage();
@args = @ARGV;

$date     = shift;
$ampfile  = "${date}_ampcor.off";
$cullfile = "${date}_cull.off";
#################
Message "Checking I/O";
#################
@Infiles  = ($ampfile,  "$ampfile.rsc");
@Outfiles = ($cullfile, "$cullfile.rsc");
### also creates tmp(1-6).off

&IOcheck(\@Infiles, \@Outfiles);
Log("cull_offset.pl", @args);

#################
### Check to make sure offset field isn't null
-s $ampfile == 0 and die "Offset field is null, check gross offsets\n";

#################################################
Message "Copying resource file: $ampfile.rsc";
#################################################
`cp $ampfile.rsc $cullfile.rsc`;

#################
Message "Filtering";
#################
`$INT_BIN/fitoff $ampfile $cullfile 1.5 0.05 50 > fitoff_ampcor.out
`;

### Check to make sure number of culled points is greater than 50
open CULL, "$cullfile";
for ($i=1; $line = <CULL>; $i++){}
$i > 50 or die "Too few points left after culling: $i left\n";

print "$i points left after culling\n";
close(CULL);

exit 0;

=pod

=head1 USAGE

B<cull_offset.p>l I<date1-date2>

the offset field must exist in I<date1-date2>_ampcor.off

=head1 FUNCTION

Filters the offset field I<date1-date2>_ampcor.off

=head1 ROUTINES CALLED

fitoff

=head1 CALLED BY

process.pl

=head1 FILES USED

I<date1-date2>_ampcor.off

I<date1-date2>_ampcor.off.rsc

=head1 FILES CREATED

I<date1-date2>_cull.off

I<date1-date2>_cull.off.rsc

fitoff_ampcor.out

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
