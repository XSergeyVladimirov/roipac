#!/usr/bin/perl
###dgx.pl
##### Usage info/check and assignment of command line arguments

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

sub Usage {
  print STDERR <<END;

Usage: dgxit.pl imagefile 

Function:  runs dgx based on imagefile.rsc

Recognizes: *.slc
            *.int
            *.cor
            *.unw
            *.amp
            *.hgt
            *.hgt_holes
            *.dem
            *.dte
            *.dtm
            *.rect
            *.msk
            *.byt
	    *.flg

Routines called: none

END
  exit 1;
}

sub System {
  print "Running...\n";
  print join(' ', @_), "\n";
  system(@_);
}

@ARGV > 0 or Usage();

my $image = shift;
my $width = `use_rsc.pl $image read WIDTH` or die "Use dgx manually.\n";
 
if ($image =~ /\.slc/) {   
  System("dgx", -c8, $image, $width, @ARGV);
} 
elsif ($image =~ /\.int/) {   
  System("dgx", -c8, $image, $width, @ARGV);
} 
elsif ($image =~ /\.cor/) {
  System("dgx", -rmg, $image, $width, 1, @ARGV);
}
elsif ($image =~ /\.scor/) { 
  System("dgx", -r4, $image, $width, 1, @ARGV);
}
elsif ($image =~ /\.amp/) {   
  System("dgx", -c8, $image, $width, @ARGV);
}   
elsif ($image =~ /\.unw/) {   
  System("dgx", -rmg, $image, $width, 6.28, @ARGV);
}
elsif ($image =~ /\.hgt/) {   
  System("dgx", -rmg, $image, $width, 1000, @ARGV);
}
elsif ($image =~ /\.hgt_holes/) {   
  System("dgx", -rmg, $image, $width, @ARGV);
}
elsif ($image =~ /\.rect/) {   
  System("dgx", -rmg, $image, $width, @ARGV);
}
elsif ($image =~ /\.(dem|dte|dtm)/) {   
  System("dgx", "-S", -si2, $image, $width, 1000, @ARGV);
}
elsif ($image =~ /\.msk/) {
  System("dgx", -rmg, $image, $width, 1.5, @ARGV);
}
elsif ($image =~ /\.byt/) {
  System("dgx", -i1, $image, $width, @ARGV);
}
elsif ($image =~ /\.flg/) {
  System("dgx", -i1, $image, $width, @ARGV);
}
else {print "$image has unrecognizable suffix\n"; Usage();}
exit 0;
=pod

=head1 HISTORY
Perl  Script : Mark Simons 1997

=head1 LAST UPDATE

Rowena Lohman, Oct 13, 1999 

=cut
