#!/usr/bin/perl
### radar2geo.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/radar2geo.pl`;
exit 1;
}
@ARGV == 12 or Usage();

@args = @ARGV;

$mapping              = shift;
$geo_dir              = shift;
$hdrdate              = shift;
$OrbitType            = shift;
$DEM                  = shift;
$aff_name             = shift;
$aff2geolooks         = shift;
$geocoding_lookupfile = shift;
$tobegeocoded         = shift;
$outgeocoded          = shift;
$do_sim               = shift;
$SimDir               = shift;

### Check to see if IntSim has already been done
$do_geomap = 1;
if (-e "$geocoding_lookupfile"){
    $do_geomap = "0";
}

if ($mapping eq "inverse"){
  print STDERR "Use of inverse3d not yet ready!\n";
  exit 1;
#    `$INT_SCR/inverse3d.pl $totalLsim.unw \\
#                           $corLsim.cor \\
#                           $baseline_file   \\
#                           $BaselineType`;
}
else{

   ##########################################################################
   Message "Making mapping file";
   ##########################################################################

if ($do_geomap){
  `$INT_SCR/make_geomap.pl $geo_dir \\
                           $tobegeocoded \\
                           $geocoding_lookupfile \\
                           $OrbitType \\
                           $DEM \\
                           $aff_name  \\
                           $aff2geolooks \\
                           $hdrdate     \\
                           $do_sim \\
			   $SimDir`; 
                         Status "make_geomap.pl";
     
  Link_here "$geo_dir/$geocoding_lookupfile*";
}
else{
  print STDERR "$geocoding_lookupfile file exists and is used to geocode\n";
}

   ##########################################################################
   Message "Geocoding $tobegeocoded";
   ##########################################################################
  `$INT_SCR/geocode.pl $geocoding_lookupfile \\
                       $tobegeocoded  \\
                       $outgeocoded`; 
                         Status "geocode.pl";
}
exit 0;

=pod

=head1 USAGE

B<radar2geo.pl> I<mapping sim_dir orbit_type DEM 
                  aff_name aff2geolooks tobegeocoded outgeocoded do_sim SimDir>  

=head1 FUNCTION

maps the radar scene onto a map  coordinate system

=head1 ROUTINES CALLED

make_geomap.pl

geocode.pl

=head1 CALLED BY

process_changeN.pl

=head1 FILES USED

I<tobegeocoded>

I<tobegeocoded>.rsc

=head1 FILES CREATED

<outgeocoded>

<outgeocoded>.rsc

=head1 HISTORY

Perl  Script : Rowena LOHMAN 04/18/98
Yuri FIALKO, Jul 16, 1999
Frederic Crampe, Aug 26, 1999
Yuri FIALKO, Jan 30, 2001

=head1 LAST UPDATE

Gilles Peltzer, Aug, 2004

=cut
