#!/usr/bin/perl
### select_PRC_date.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN SAR_PRC_DIR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/select_PRC_date.pl`;
exit 1;
}
@ARGV >= 4 or Usage();
Log("select_PRC_date.pl", @ARGV);

$orbit_dir = shift;
$YYYY      = shift;
$MM        = shift;
$DD        = shift;
$UTC       = shift or $UTC = 0;
# Following not Y2K compliant, so it was removed
#$YY        = $YYYY;
#$YY        =~ s/^19//;      ### Shorten date

$this_jd     = `$INT_BIN/YYYYMMDD2Jul $YYYY $MM $DD $UTC`;
$this_jd or  die "YYYYMMDD2Jul failed:$!\n";
$this_jd    *= 10;
$this_jd     = int($this_jd);

open ARC, "$orbit_dir/arclist" or die "$orbit_dir/arclist not readable\n";

### go through each file in arclist and see if the julian day desired falls
### between the start and end dates in each file

foreach $line (<ARC>) {
  @line = split /\s+/, $line;
  if (($line[1] <= $this_jd) && ($line[2] >= $this_jd)){
    print $orbit_dir."/".substr($line[0],rindex($line[0],"/")+1)."\n";
#old line, corrected by C. Miller    print "$line[0]\n";
    exit (0);
  }

}
die "Orbit, $this_jd, not found in $orbit_dir\n";

=pod

=head1 USAGE

B<select_PRC_date.pl> I<orbit_dir year month day time>

 orbit_dir: dir with file "arclist" with names of PRC files
      year: YYYY 
     month: MM
       day: DD
      time: seconds UTC

=head1 FUNCTION

Select the PRC file which covers the desired time and date

=head1 ROUTINES CALLED

YYYYMMDD2Jul 

=head1 CALLED BY

state_vector.pl

=head1 FILES USED

I<orbir_dir>/arclist

=head1 FILES CREATED

none

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
