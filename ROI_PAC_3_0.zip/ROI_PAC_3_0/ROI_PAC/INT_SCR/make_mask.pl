#!/usr/bin/perl
### make_mask.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/make_mask.pl`;
exit 1;
}
@ARGV >= 3 or Usage();
@args = @ARGV;

$infile           = shift;
$maskfile         = shift;
$threshold_mag    = shift;
$threshold_ph_grd = shift or $threshold_ph_grd = 0.;
$smooth_width     = shift or $smooth_width     = 5;
$slope_width      = shift or $slope_width      = 5;
$sigma_thresh     = shift or $sigma_thresh     = 1.0;

#################
Message "Checking I/O";
#################
@Infiles  = ("$infile.int",   "$infile.int.rsc",
	     "$infile.int", "$infile.int.rsc");
@Outfiles = ("$maskfile.msk", "$maskfile.msk.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("make_mask.pl", @args);

############################
Message "Creating the Mask for Unwrapping";
############################

$width  = Use_rsc "$infile.int read WIDTH";
$length = Use_rsc "$infile.int read FILE_LENGTH";

`cp $infile.int.rsc $maskfile.msk.rsc`;

Message "cpx2mag_phs  $infile.int pwr phs $width";
`$INT_BIN/cpx2mag_phs $infile.int pwr phs $width`;

Message "phase_slope  $infile.int phasegrd.cpx $width $slope_width $threshold_ph_grd";
`$INT_BIN/phase_slope $infile.int phasegrd.cpx $width $slope_width $threshold_ph_grd`;

Message "phase_mask  $infile.int phasegrd.cpx sigma $sigma_thresh $width $smooth_width $smooth_width";
`$INT_BIN/phase_mask $infile.int phasegrd.cpx sigma $sigma_thresh $width $smooth_width $smooth_width`;

if ($threshold_mag > 0){
  Message "mag_phs2cpx  pwr sigma $maskfile.int $width";
  `$INT_BIN/mag_phs2cpx pwr sigma $maskfile.int $width`;

  Message "int_thr  $maskfile.int $maskfile\_thresh.int $width $threshold_mag";
  `$INT_BIN/int_thr $maskfile.int $maskfile\_thresh.int $width $threshold_mag`;

  Message "cpx2mag_phs  $maskfile\_thresh.int /dev/null $maskfile\_thresh $width";
  `$INT_BIN/cpx2mag_phs $maskfile\_thresh.int /dev/null $maskfile\_thresh $width`;

  Message "add_phs  $maskfile\_thresh phs final_mask $width $length 0 1";
  `$INT_BIN/add_phs $maskfile\_thresh phs final_mask $width $length 0 1`;

  #clean up
  `rm $maskfile.int $maskfile\_thresh $maskfile\_thresh.int`;

}else{
  Message "add_phs  sigma phs final_mask $width $length 0 1";
  `$INT_BIN/add_phs sigma phs final_mask $width $length 0 1`;
}

Message "mag_phs2rmg  pwr final_mask $maskfile.msk $width";
`$INT_BIN/mag_phs2rmg pwr final_mask $maskfile.msk $width`;

#clean up
`rm pwr phs final_mask phasegrd.cpx sigma`;

exit 0;
 
=pod

=head1 USAGE

B<make_mask.pl> I<infile_prefix maskfile_prefix>

=head1 FUNCTION

Filters an interferogram and computes a mask for unwrapping

=head1 ROUTINES CALLED

add_phs

rmg2mag_phs

cpx2mag_phs

mag_phs2cpx

mag_phs2rmg

psfilt

phase_slope

phase_mask

=head1 CALLED BY

process.pl

=head1 FILES USED

I<infile>.int

I<infile>.int.rsc

=head1 FILES CREATED

phasegradient.cpx

I<infile>.int

I<maskfile>.msk

I<infile>.int.rsc

I<maskfile>.msk.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Frederic CRAMPE, Nov 13, 1998
Mark SIMONS, Nov 15, 1998

=cut
