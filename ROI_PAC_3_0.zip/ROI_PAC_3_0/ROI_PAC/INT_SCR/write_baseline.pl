#!/usr/bin/perl
### write_baseline.pl
$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/write_baseline.pl`;
exit 1;
}
@ARGV == 8 or Usage();

$baseline_file = shift;
$BaseType     = shift;
$bh           = shift;
$bhrate       = shift;
$bhacc       = shift;
$bv           = shift;
$bvrate       = shift;
$bvacc       = shift;
Use_rsc "$baseline_file write H_BASELINE_TOP_${BaseType}  $bh";
Doc_rsc(
 RSC_Doc => q[
    'Initial Cross Track Baseline Component' based on RDF usage in flatten.pl
    'Cross Track Baseline' based on RDF usage in diffnsim.pl
   ],
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from line 1 field 5 of phase2base.out
    which is labeled 
    'Horizontal baseline (m)'
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaseType}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "$baseline_file write H_BASELINE_RATE_${BaseType} $bhrate";
Doc_rsc(
 RSC_Doc => q[
    'Cross Track Baseline Rate' based on RDF usage in flatten.pl and diffnsim.pl
   ],
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from line 4 field 6 of phase2base.out
    which is labeled 
    'Horizontal baseline rate (m/m)'
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaseType}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter/SI:meter'
);


Use_rsc "$baseline_file write H_BASELINE_ACC_${BaseType} $bhacc";
Doc_rsc(
 RSC_Doc => q[
    'Cross Track Baseline Acceleration' based on RDF usage in diffnsim.pl
   ],
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from line 6 field 6 of phase2base.out
    which is labeled 
    'Horizontal baseline acc (m/m^2)'
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaseType}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter/SI:meter**2'
);


Use_rsc "$baseline_file write V_BASELINE_TOP_${BaseType}  $bv";
Doc_rsc(
 RSC_Doc => q[
    'Initial Vertical Baseline Component' based on RDF usage in flatten.pl
    'Vertical Baseline' based on RDF usage in diffnsim.pl
   ],
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from line 2 field 5 of phase2base.out
    which is labeled 
    'Vertical   baseline (m)'
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaseType}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "$baseline_file write V_BASELINE_RATE_${BaseType} $bvrate";
Doc_rsc(
 RSC_Doc => q[
    'Vertical Baseline Rate' based on RDF usage in flatten.pl and diffnsim.pl
   ],
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from line 5 field 6 of phase2base.out
    which is labeled 
    'Vertical   baseline rate (m/m)'
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaseType}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter/SI:meter'
);


Use_rsc "$baseline_file write V_BASELINE_ACC_${BaseType} $bvacc";
Doc_rsc(
 RSC_Doc => q[
    'Vertical Baseline Acceleration' based on RDF usage in diffnsim.pl
   ],
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from line 7 field 6 of phase2base.out
    which is labeled 
    'Vertical   baseline acc (m/m^2)'
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaseType}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter/SI:meter**2'
);




=pod

=head1 USAGE

B<write_baseline.pl> I<baseline_file BaseType H_BASELINE_TOP H_BASELINE_RATE H_BASELINE_ACC V_BASELINE_TOP V_BASELINE_RATE V_BASELINE_ACC>

=head1 FUNCTION

Writes baseline values to baseline_file

=head1 ROUTINES CALLED

none

=head1 CALLED BY

everything

=head1 FILES USED

none

=head1 FILES CREATED

I<baseline_file>.rsc

=head1 HISTORY

Perl  Script : Rowena LOHMAN 11/12/98

=head1 LAST UPDATE

Rowena LOHMAN 11/12/98

=cut

