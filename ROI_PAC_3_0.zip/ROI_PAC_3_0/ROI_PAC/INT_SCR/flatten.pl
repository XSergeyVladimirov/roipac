#!/usr/bin/perl
### flatten.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/flatten.pl`;
exit 1;
}
@ARGV >= 4 or Usage();
@args = @ARGV;

$intfile       = shift;
$baseline_file = shift;
$BaselineType  = shift;
$outfile       = shift;
$looks         = shift or $looks = 1;

#################
Message "Checking I/O";
#################
@Infiles  = ("$intfile.int","$intfile.int.rsc",$baseline_file);
@Outfiles = ("$outfile.int","$outfile.int.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("flatten.pl", @args);

#######################################
Message "Reading resource file: $intfile.int.rsc";
#######################################

$width              = Use_rsc "$intfile.int read WIDTH"; 
$length             = Use_rsc "$intfile.int read FILE_LENGTH";  
$xmin               = Use_rsc "$intfile.int read XMIN"; 
$xmax               = Use_rsc "$intfile.int read XMAX"; 
$ymin               = Use_rsc "$intfile.int read YMIN"; 
$ymax               = Use_rsc "$intfile.int read YMAX"; 
$height_top         = Use_rsc "$intfile.int read HEIGHT"; 
$height_rate        = Use_rsc "$intfile.int read HEIGHT_DS"; 
$height_acc         = Use_rsc "$intfile.int read HEIGHT_DDS"; 
$earth_radius       = Use_rsc "$intfile.int read EARTH_RADIUS"; 
$starting_range     = Use_rsc "$intfile.int read STARTING_RANGE"; 
$range_offset       = Use_rsc "$intfile.int read RANGE_OFFSET"; 
$wavelength         = Use_rsc "$intfile.int read WAVELENGTH"; 
$range_pixel_size   = Use_rsc "$intfile.int read RANGE_PIXEL_SIZE"; 
$azimuth_pixel_size = Use_rsc "$intfile.int read AZIMUTH_PIXEL_SIZE"; 
$first_line_utc     = Use_rsc "$intfile.int read FIRST_LINE_UTC"; 
$center_line_utc    = Use_rsc "$intfile.int read CENTER_LINE_UTC"; 
$delta_line_utc     = Use_rsc "$intfile.int read DELTA_LINE_UTC"; 
$squint             = Use_rsc "$intfile.int read SQUINT"; 
$velocity           = Use_rsc "$intfile.int read VELOCITY"; 
$antenna_side       = Use_rsc "$intfile.int read ANTENNA_SIDE";

$h_baseline_top     = Use_rsc "$baseline_file read H_BASELINE_TOP_${BaselineType}"; 
$h_baseline_rate    = Use_rsc "$baseline_file read H_BASELINE_RATE_${BaselineType}"; 
$v_baseline_top     = Use_rsc "$baseline_file read V_BASELINE_TOP_${BaselineType}"; 
$v_baseline_rate    = Use_rsc "$baseline_file read V_BASELINE_RATE_${BaselineType}"; 

#####################################################
Message "Writing resource file: $outfile.int.rsc";
#####################################################
$new_width   = int($width/$looks);
$new_length  = int($length/$looks);
$new_xmin    = int($xmin/$looks);
$new_xmax    = int($xmax/$looks);
$new_ymin    = int($ymin/$looks);
$new_ymax    = int($ymax/$looks);
$new_rng_pix = $range_pixel_size*$looks;
$new_az_pix  = $azimuth_pixel_size*$looks;
$new_dt      = $delta_line_utc*$looks;

Use_rsc "$outfile.int write WIDTH              $new_width";
Use_rsc "$outfile.int write FILE_LENGTH        $new_length";
Use_rsc "$outfile.int write XMIN               $new_xmin";
Use_rsc "$outfile.int write XMAX               $new_xmax";
Use_rsc "$outfile.int write YMIN               $new_ymin";
Use_rsc "$outfile.int write YMAX               $new_ymax ";
Use_rsc "$outfile.int write RANGE_PIXEL_SIZE   $new_rng_pix";
Use_rsc "$outfile.int write AZIMUTH_PIXEL_SIZE $new_az_pix";
Use_rsc "$outfile.int write DELTA_LINE_UTC     $new_dt";
Use_rsc "$outfile.int write FLATTENED          YES";
Use_rsc "$outfile.int write BASELINE_SRC       $BaselineType";

Use_rsc "$outfile.int merge $intfile.int"; 

#######################################################
Message "Writing cecpxcc input_file: $outfile.int_cecpxcc.in"; 
#######################################################
open OUT, ">$outfile.int_cecpxcc.in";
print OUT <<END;
           CURVED EARTH INTERFEROGRAM FLATTENING RDF FILE
 
FILES
 
Interferogram File Name                 (-)              =  $intfile.int
Flattened Interferogram File Name       (-)              =  $outfile.int
 
FILE DIMENSIONS
 
Number Complex Samples/Lines in Interferogram (-)        =  $width $length
 
RADAR PARAMETERS
 
Earth Radius                            (m)              =  $earth_radius  
Platform Altitude, Rate, & Acceleration (m,-,-)          =  $height_top $height_rate $height_acc
Radar Wavelength                        (m)              =  $wavelength
Left or Right Looking                   (-)              =  Right
Starting Ranges for the SLCs            (m)              =  $starting_range  $starting_range
Range per Pixel                         (m)              =  $range_pixel_size
Azimuth Pixel Size in Orbit             (m)              =  $azimuth_pixel_size
Squint Angle                            (deg)            =  $squint
Additional Range and Azimuth Looks      (-)              =  $looks $looks
 
BASELINE PARAMETERS
 
Initial Cross Track Baseline Component  (m)              =  $h_baseline_top 
Cross Track Baseline Rate               (-)              =  $h_baseline_rate  
Initial Vertical Baseline Component     (m)              =  $v_baseline_top
Vertical Baseline Rate                  (-)              =  $v_baseline_rate
END
    close(OUT);

##########################################################################
Message "$INT_BIN/cecpxcc  $outfile.int_cecpxcc.in > $outfile.int_cecpxcc.out";

`$INT_BIN/cecpxcc  $outfile.int_cecpxcc.in > $outfile.int_cecpxcc.out`; 
exit 0;

=pod

=head1 USAGE

B<flatten.pl> I<intfile_pre baselinefile orbittype outfile_pre [looks]>

I<intfile>: interferogram is I<intfile>.int

I<looks>: default is 4

outfile is I<intfile>_I<looks>looks_flat_notopo

=head1 FUNCTION

Uses the interferogram to flatten the image

=head1 ROUTINES CALLED

cecpxcc

=head1 CALLED BY

process.pl

=head1 FILES USED

I<intfile>.int

I<intfile>.int.rsc

=head1 FILES CREATED

I<outfile>.int

I<outfile>.int.rsc

I<outfile>.int_cecpxcc.in

I<outfile>.int_cecpxcc.out

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
