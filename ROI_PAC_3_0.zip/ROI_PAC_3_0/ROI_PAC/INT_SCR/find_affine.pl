#!/usr/bin/perl
### find_affine.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/find_affine.pl`;
exit 1;
}
@ARGV == 1 or Usage();
$file = shift;

open FILE, "$file" or die  "Can't open $file\n";

while($done ne "yes"){
  $line = <FILE> or die "End of $file reached sooner than expected\n";
     if ($line =~ /Affine/){
    $emptyline          = <FILE>;
    ($junk, $m11, $m12) = split /\s+/, <FILE>;
    ($junk, $m21, $m22) = split /\s+/, <FILE>;
    $found1 = 1;
  }
  if ($line =~ /Translation/){
    $emptyline        = <FILE>;
    ($junk, $t1, $t2) = split /\s+/, <FILE>;
    $found2 = 1;
  }
  if ($found1 and $found2) {$done = "yes";} ### Found both matrix and translat.
}

printf ("%12.12f %12.12f %12.12f %12.12f %12.12f %12.12f",
	 $m11,$m12,$m21,$m22,$t1,$t2);

exit 0;  

=pod

=head1 USAGE

B<find_affine.pl> I<file>

I<file> is data file created in B<synth2radar.pl>

=head1 FUNCTION

looks for values in affine matrix and translation vector

=head1 ROUTINES CALLED

none

=head1 CALLED BY

synth2radar.pl

=head1 FILES USED

I<file>

=head1 FILES CREATED

none

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
