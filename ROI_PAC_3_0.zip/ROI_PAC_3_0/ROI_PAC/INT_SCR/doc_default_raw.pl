#!/usr/bin/perl
### doc_default_raw.pl

# $Id: doc_default_raw.pl,v 1.1.1.1 2007/04/17 22:28:01 ericmg Exp $
#
# $Log: doc_default_raw.pl,v $
# Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1.1.1  2007/04/03 03:40:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1  2005/12/16 18:45:38  bswift
# RSC keyword documentation changes.
#

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;


###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/doc_dem.pl`;
exit 1;
}
@ARGV == 1 or Usage();

$raw_file       = shift;


$toss_it = Use_rsc "$raw_file read WAVELENGTH";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
    'Radar Wavelength' from RDF usage in various scripts.
   ],
 RSC_Derivation => q[
    Value from $INT_SCR/default.raw.rsc is merged into
    tmp_IMAGERY.raw.rsc in make_raw.pl
   ],
 RSC_Comment => q[
    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


$toss_it = Use_rsc "$raw_file read PULSE_LENGTH";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
    'Range pulse duration' based on RDF usage in roi_prep.pl and autofocus.pl
   ],
 RSC_Derivation => q[
    Value from $INT_SCR/default.raw.rsc is merged into
    tmp_IMAGERY.raw.rsc in make_raw.pl
   ],
 RSC_Comment => q[
    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:second',
);


$toss_it = Use_rsc "$raw_file read CHIRP_SLOPE";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
    'Range chirp slope' based on RDF usage in roi_prep.pl and autofocus.pl
   ],
 RSC_Derivation => q[
    Value from $INT_SCR/default.raw.rsc is merged into
    tmp_IMAGERY.raw.rsc in make_raw.pl
   ],
 RSC_Comment => q[
    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:hertz/SI:second',
);




=pod

=head1 USAGE

B<doc_default_raw.pl> I<raw_file>

=head1 FUNCTION

Reads keywords in I<date.raw>.rsc to produce standard documentation,
since these keywords are part of the ROI_PAC_DIST distribution,
and are not created during processing.

=head1 ROUTINES CALLED

=head1 CALLED BY

=head1 FILES USED

=head1 FILES CREATED

=head1 HISTORY

 $Log: doc_default_raw.pl,v $
 Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
 initial import into erda insarcvs

 Revision 1.1.1.1  2007/04/03 03:40:01  ericmg
 initial import into erda insarcvs

 Revision 1.1  2005/12/16 18:45:38  bswift
 RSC keyword documentation changes.


=head1 LAST UPDATE

 $Id: doc_default_raw.pl,v 1.1.1.1 2007/04/17 22:28:01 ericmg Exp $

=cut
