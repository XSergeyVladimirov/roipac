#!/usr/bin/perl
### make_geomap.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/make_geomap.pl`;
exit 1;
}
@ARGV == 10 or Usage();
@args = @ARGV;

$geo_dir              = shift;
$tobegeocoded         = shift;
$geocoding_lookupfile = shift;
$orbit_type           = shift;
$DEM                  = shift;
$aff_file             = shift;
$aff2geolooks         = shift;
$hdrdate              = shift;
$do_sim               = shift;
$SimDir               = shift;

$skip       = 1;

$DEM =~ /\.(dem|dtm|dte)$/ or $DEM = "$DEM.dem";
$SLP = $DEM;
$SLP =~ s/\.(dem|dtm|dte)/\.slp/;
$Sim = $SimDir;
$Sim =~ s!.*\/!!g;

#################
Message "Checking I/O";
#################
@Infiles  = ("$tobegeocoded.rsc");
@Outfiles = ("$geo_dir/$geocoding_lookupfile.rsc",
	     "$geo_dir/$geocoding_lookupfile");
&IOcheck(\@Infiles, \@Outfiles);
Log("make_geomap.pl", @args);

open IN, "$aff_file" or die "Can't read $aff_file\n";
chomp($line = <IN>);
@aff_par = split /\s+/, $line;
close(IN);
#change effective looks of old affine transformation parameters if needed
$aff_par[4] = $aff_par[4]/$aff2geolooks;
$aff_par[5] = $aff_par[5]/$aff2geolooks;

### Check to see if orrm file has already been done
$do_orrm = 1;
if (-e "$geo_dir/geomap.orrm"){
  if (-M "$tobegeocoded.rsc" > -M "$geo_dir/geomap.orrm"){
    $do_orrm = "0";
  }
}
#################
Message "Reading resource file: $tobegeocoded.rsc";
#################
$orbit_number       = Use_rsc "$tobegeocoded read ORBIT_NUMBER";
$width              = Use_rsc "$tobegeocoded read WIDTH";
$length             = Use_rsc "$tobegeocoded read FILE_LENGTH";
$first_line_utc     = Use_rsc "$tobegeocoded read FIRST_LINE_UTC";
$range_pixel_size   = Use_rsc "$tobegeocoded read RANGE_PIXEL_SIZE";
$azimuth_pixel_size = Use_rsc "$tobegeocoded read AZIMUTH_PIXEL_SIZE";
$rlks               = Use_rsc "$tobegeocoded read RLOOKS";
$alks               = Use_rsc "$tobegeocoded read ALOOKS";
$delta_line_utc     = Use_rsc "$tobegeocoded read DELTA_LINE_UTC";
$time_span_year     = Use_rsc "$tobegeocoded read TIME_SPAN_YEAR";
$rt                 = Use_rsc "$tobegeocoded read EARTH_RADIUS";
$r0                 = Use_rsc "$tobegeocoded read STARTING_RANGE";
$h                  = Use_rsc "$tobegeocoded read HEIGHT";
$squint             = Use_rsc "$tobegeocoded read SQUINT";
$year               = Use_rsc "$tobegeocoded read FIRST_LINE_YEAR";
$month              = Use_rsc "$tobegeocoded read FIRST_LINE_MONTH_OF_YEAR";
$day                = Use_rsc "$tobegeocoded read FIRST_LINE_DAY_OF_MONTH";
$date               = Use_rsc "$tobegeocoded read DATE";
$sat                = Use_rsc "$tobegeocoded read PLATFORM";
$direction          = Use_rsc "$tobegeocoded read ORBIT_DIRECTION";
$dop_rng0           = Use_rsc "$tobegeocoded read DOPPLER_RANGE0";
$dop_rng1           = Use_rsc "$tobegeocoded read DOPPLER_RANGE1";
$dop_rng2           = Use_rsc "$tobegeocoded read DOPPLER_RANGE2";
$dop_rng3           = Use_rsc "$tobegeocoded read DOPPLER_RANGE3";
$prf                = Use_rsc "$tobegeocoded read PRF";
$wvl                = Use_rsc "$tobegeocoded read WAVELENGTH";

$range_pixel_size_sl = $range_pixel_size/$rlks;

##########################
Message "Building ORRM file";
##########################

### GP: LINK TO ORRM FILE IN SIMU DIR ###
##########################
chdir $geo_dir;

if ($do_orrm){
   symlink("$SimDir/$Sim.orrm","geomap.orrm");
}


########################################
Message "Reading resource file: $DEM.rsc";
########################################

$DEM_width    = Use_rsc "$DEM read WIDTH";        
$DEM_length   = Use_rsc "$DEM read FILE_LENGTH";        
$DEM_x_first  = Use_rsc "$DEM read X_FIRST";
$DEM_y_first  = Use_rsc "$DEM read Y_FIRST";
$DEM_x_step   = Use_rsc "$DEM read X_STEP";
$DEM_y_step   = Use_rsc "$DEM read Y_STEP";
$DEM_z_scale  = Use_rsc "$DEM read Z_SCALE";
$DEM_z_offset = Use_rsc "$DEM read Z_OFFSET";

####################################
Message "Creating slope file";
####################################
`$INT_SCR/gradient.pl $DEM $SLP`;
Status "gradient.pl";

### GP                                                             ###
### Passing array size of $tobegeocoded to $sim_variables          ###
### OK when using newly made simu but should be read from sim file ###
### for previously made simu                                       ###

$sim_width     = $width;
$sim_length    = $length;
$sim_dr        = $range_pixel_size;
$sim_dz        = $azimuth_pixel_size; 
$sim_dz_ground = $sim_dz*$rt/($rt+$h);
$sim_dt        = $delta_line_utc;

$xmax          = $sim_width-1;
$ymax          = $sim_length-1;

### GP ### Get parameters from Simulation file ######
if ($do_sim eq "no") {
  if ($rlks gt 1){
     $Simrsc = "$SimDir/$Sim"."_"."$rlks"."rlks.hgt.rsc";
  }else{
     $Simrsc = "$SimDir/$Sim".".hgt.rsc";
  }
  
  $sim_width      = Use_rsc "$Simrsc read WIDTH";
  $sim_length     = Use_rsc "$Simrsc read FILE_LENGTH";
  $sim_dr         = Use_rsc "$Simrsc read RANGE_PIXEL_SIZE";
  $sim_dz         = Use_rsc "$Simrsc read AZIMUTH_PIXEL_SIZE"; 
  $sim_dz_ground  = $sim_dz*$rt/($rt+$h);
  $sim_dt         = Use_rsc "$Simrsc read DELTA_LINE_UTC";
  $first_line_utc = Use_rsc "$Simrsc read FIRST_LINE_UTC";
  $r0             = Use_rsc "$Simrsc read STARTING_RANGE";

  $xmax           = $sim_width-1;
  $ymax           = $sim_length-1;

  $squint         = Use_rsc "$Simrsc read SQUINT";
  $dop_rng0       = Use_rsc "$Simrsc read DOPPLER_RANGE0";
  $dop_rng1       = Use_rsc "$Simrsc read DOPPLER_RANGE1";
  $dop_rng2       = Use_rsc "$Simrsc read DOPPLER_RANGE2";
  $dop_rng3       = Use_rsc "$Simrsc read DOPPLER_RANGE3";
##    $prf            = Use_rsc "$Simrsc read PRF";
## keyword does not exist in sim file###
}
### END GP ###

############################################
Message "Writing IntSim input_file: IntSim.in";
############################################
$r0_km      = $r0/1000;
$squint90   = 90 - $squint;
$projection = Use_rsc "$DEM read PROJECTION";

# Set parameters for UTM or LatLon
if ($projection =~ /UTM/){
  $utm_zone = $'; ### stuff after UTM in "PROJECTION"
  $projection = "UTM";
  # datum only needed for UTM, default to USGS standard datum--added EJF 2001/01/11
  $datum = Use_rsc "$DEM read DATUM" or $datum ="NAD27";
}
else {### For lat/lon
  $projection = "LL";
  $utm_zone = 11; ##dummy number, just need something or IntSim crashes
  $datum = "WGS84"  # no need for datum with lat-long projection, set to default
}

# ROI_pac 2.2.2 changed to DOPPLER search and cubic doppler

open INT, ">IntSim.in";
print INT <<END;
Digital Elevation Model Filename                      (-) = $DEM
Slope Filename                                        (-) = $SLP
ORRM formatted filename                               (-) = geomap.orrm
Height in simulated range,doppler coordinates         (-) = /dev/null
Coordinates of simulated range,doppler in map format  (-) = ${geocoding_lookupfile}
GPS vector inputs filename                            (-) = /dev/null
GPS vector mapped to radar LOS output filename        (-) = /dev/null
Rectified height in simulated coordinates             (-) = /dev/null
Rectified height in simulated coordinates with GPS    (-) = /dev/null
Dimensions of rectified height file                 (-,-) = $sim_width $sim_length
DEM projection                                        (-) = $projection
DEM datum                                             (-) = $datum

END
#only need to specify relevant projection info EJF 01/1/11
if ($projection =~ /UTM/){
print INT <<END;
DEM corner easting                                    (m) = $DEM_x_first
DEM easting spacing                                   (m) = $DEM_x_step
DEM total easting pixels                              (-) = $DEM_width 
DEM UTM zone                                          (-) = $utm_zone

DEM corner northing                                   (m) =  $DEM_y_first
DEM northing spacing                                  (m) =  $DEM_y_step
DEM total northing pixels                             (-) =  $DEM_length

END
}
else {### For lat/lon
print INT <<END;
DEM corner latitude                                 (deg) = $DEM_y_first
DEM latitude spacing                                (deg) = $DEM_y_step
DEM total latitude pixels                             (-) = $DEM_length

DEM corner longitude                                (deg) = $DEM_x_first
DEM longitude spacing                               (deg) = $DEM_x_step
DEM total longitude pixels                            (-) = $DEM_width

END
}
print INT <<END;
DEM height bias                                       (-) = $DEM_z_offset
DEM height scale factor                               (-) = $DEM_z_scale
DEM Northing bias                                     (-) = 0.
DEM Easting bias                                      (-) = 0.
Range output reference                               (km) = $r0_km
Time  output reference                              (sec) = $first_line_utc
Range output spacing                                  (m) = $sim_dr
Azimuth output spacing                                (m) = $sim_dz_ground 
Number of range pixels                                (-) = $sim_width
Number of azimuth pixels                              (-) = $sim_length

Nominal squint angle from heading                   (deg) = $squint90
GPS scale factor                                      (-) = 1.
Datum conversion bias vector                          (m) = 0. 0. 0. 
Affine matrix row 1                                   (-) = $aff_par[0] $aff_par[1]
Affine matrix row 2                                   (-) = $aff_par[2] $aff_par[3]
Affine offset vector                                  (-) = $aff_par[4] $aff_par[5]
Do simulation?                                        (-) = no
Do mapping?                                           (-) = yes
Do GPS mapping?                                       (-) = no
Output skip factor                                    (-) = $skip
Search method                                         (-) = DOPPLER
Range reference for Doppler                          (km) = $r0_km
Range spacing for Doppler                             (m) = $range_pixel_size_sl
Doppler coefficients                              (-,-,-) = $dop_rng0 $dop_rng1 $dop_rng2 $dop_rng3
Radar Wavelength                                      (m) = $wvl
Radar PRF                                             (-) = $prf
Desired center latitude                             (deg) = 0.0
Desired center longitude                            (deg) = 0.0
END
    close(INT);


############################################
Message "IntSim IntSim.in > IntSim.out";
############################################

`$INT_BIN/IntSim IntSim.in > IntSim.out`;
Status "IntSim";

open INT, "IntSim.out" or die "Can't read IntSim.out\n";
$i = 0;
while (<INT>){
  if ($_ =~ /First DEM pixel/){
    @array = split /\s+/, $_;
    $trans_x0 = "$array[8]";
    $trans_y0 = "$array[9]";
  }
  if ($_ =~ /Last  DEM pixel/){
    @array = split /\s+/, $_;
    $trans_x1 = "$array[8]";
    $trans_y1 = "$array[9]";
  }
  if ($_ =~ /Spacecraft heading/){
    @array = split /\s+/, $_;
    $heading_deg = "$array[5]";
  }
  if ($_ =~ /Slant range/){
    @array = split /\s+/, $_;
    $range_ref[$i] = "$array[5]";
  }
  if ($_ =~ /Look angle/){
    @array = split /\s+/, $_;
    $look_ref[$i] = "$array[5]";
  }
  if ($_ =~ /Latitude and longitude/){
    @array = split /\s+/, $_;
    $lat_ref[$i] = "$array[6]";
    $lon_ref[$i] = "$array[7]";
    $i++;
  }
}
close (INT);

#################################################
Message "Writing resource file: $geocoding_lookupfile.rsc";
#################################################
Use_rsc "$geocoding_lookupfile write XMIN               $trans_x0";
Use_rsc "$geocoding_lookupfile write XMAX               $trans_x1";
Use_rsc "$geocoding_lookupfile write YMIN               $trans_y0";
Use_rsc "$geocoding_lookupfile write YMAX               $trans_y1";
Use_rsc "$geocoding_lookupfile merge $DEM";

`$INT_SCR/length.pl  $geocoding_lookupfile`;
Status "length.pl";

exit 0;

=pod

=head1 USAGE

B<make_geomap.pl> I<geomap geo_dir pair orbit_type DEM aff_file aff2geolooks hdrdate do_sim SimDir>

=head1 FUNCTION

maps a radar scene onto a "natural"  coordinate system

=head1 ROUTINES CALLED

make_orrm.pl

gradient.pl

IntSim

length.pl

look.pl

=head1 CALLED BY

process.pl

=head1 FILES USED

I<DEM>

I<DEM>.rsc

=head1 FILES CREATED

I<SLP>

I<SLP>.rsc

I<geomap>.trans.rsc

I<geomap>.trans

IntSim.in

IntSim.out

GPS.in

GPS.out

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Yuri FIALKO, Jul 16, 1999
Frederic Crampe, Aug 26, 1999
Eric Fielding, 11 Jan. 2001
Eric Fielding, 24 Mar. 2003
update of usage in POD Eric Fielding, 9 Nov. 2005

=head1 LAST UPDATE

Gilles Peltzer, Aug, 2004

=cut
