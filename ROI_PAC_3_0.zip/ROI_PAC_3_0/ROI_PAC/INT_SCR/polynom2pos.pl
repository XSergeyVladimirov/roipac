#!/usr/bin/perl
### polynom2pos.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Math::Trig;
use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;


###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/polynom2pos.pl`;
exit 1;
}
@ARGV == 2 or Usage();

$file       = shift;
$UTC        = shift;
$j          = 0;
@components = (X, Y, Z, VX, VY, VZ);

# @coefficient only used for dynamically generated documentation
@coefficient= (Constant, Linear, Quadratic, Cubic, Quartic);

foreach $component (@components){
  $keyword = "STATE_VECTOR_$component";


  $UTC_0   = Use_rsc "$file read STATE_VECTOR_UTC_REFERENCE";  
  Doc_rsc(
   RSC_Tip => 'Reference time of State Vector polynomial',
   RSC_Doc => q[
      Used as reference time for polynomial evaluation in polynom2pos.pl
     ],
   RSC_Derivation => q[
      positional parameter 2 of state_vector.pl
      which becomes $utc in state_vector.pl
      which is passed as positional parameter 2 to PRC2polynom
      which becomes UTC_Ref_s_of_day in fip/PRC2polynom.c
     ],
   RSC_Comment => q[
     This keyword read could probably be moved outside loop in polynom2pos.pl
     ],
   RSC_Type => Real,
   RSC_Unit => 'SI:second',
  );




  for($i=0; $i<=4; $i++) {

    $C[$i] = Use_rsc "$file read $keyword$i";

    Doc_rsc(
     RSC_Tip => "$coefficient[$i] term of State Vector $component component",
     RSC_Doc => q[
        Value is used to calculate platform position and velocity 
        at a specific time in polynom2pos.pl
       ],
     RSC_Derivation => q[
        Value extracted from uncompressed precision orbit file tmp_orbit
        by PRC2polynom in state_vector.pl

        See fip/PRC2polynom.c
       ],
     RSC_Comment => q[
        NOTE: Keyword name is created dynamically.
        Portion after last underscore ('_') is $component and polynomial order.

        This keyword is documented where read by perl script,
        because do not yet have support of recording documentation
        when keyword is written from C or Fortran.
       ],
     RSC_Type => Real,
     RSC_Unit => 'needs further investigation',
    );


}
 
  $X[$j] = $C[0] + $C[1]*($UTC-$UTC_0) + $C[2]*($UTC-$UTC_0)**2 + $C[3]*($UTC-$UTC_0)**3 + $C[4]*($UTC-$UTC_0)**4;
  $j++;
}

$x  = $X[0];
$y  = $X[1];
$z  = $X[2];
$vx = $X[3];
$vy = $X[4];
$vz = $X[5];
$ae    = 6378137.0;             #GRS80 reference ellipsoid
$flat  = 1.0/298.257223563;
$r     = sqrt($x**2+$y**2+$z**2);
$r1    = sqrt($x**2+$y**2);

$Lat   = atan2($z,$r1);
$Lon   = atan2($y,$x);
$H     = $r-$ae;
for ($i=1; $i<7; $i++){
  $N      = $ae/(sqrt(1.0-$flat*(2.0-$flat)*sin($Lat)**2));
  $TanLat = $z/$r1/(1.0-(2.0-$flat)*$flat*$N/($N+$H));
  $Lat    = atan2($TanLat,1.0);
  $H      = $r1/cos($Lat)-$N;
}
print "PRC 0 $Lat $Lon $H $x $y $z $vx $vy $vz";


exit (0);
=pod

=head1 USAGE

B<polynom2pos.pl> I<file time>

file: name of resource file to use

time: seconds UTC

=head1 FUNCTION

computes platform position at a given time

=head1 ROUTINES CALLED

none

=head1 CALLED BY

state_vector.pl

=head1 FILES USED

I<file> (Resource file created by PRC2polynom)

=head1 FILES CREATED

none

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
