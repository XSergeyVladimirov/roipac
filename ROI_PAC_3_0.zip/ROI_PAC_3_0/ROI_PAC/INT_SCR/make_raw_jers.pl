#!/usr/bin/perl
### make_raw.pl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/make_raw_jers.pl`;
exit 1;
}
@ARGV >= 3  or Usage();
@args = @ARGV;

$orbit_type        = shift;
$leader_file       = shift;
$date              = shift;
$facility          = shift;

@imagery=split /\s+/, `ls IMAGERY*`;

if ($orbit_type !~ /HDR/){
  print "Sorry, but JERS-1 has no orbit information " ; 
  print "other than those in Leader file.  " ;  
  print "Use them for processing.\n" ;
  $orbit_type = "HDR";
  print "Set orbit type to HDR.\n" ;
}

#################
Message "Checking I/O";
#################
@Infiles  = ($leader_file, @imagery);
@Outfiles = ("$date.raw",  "$date.raw.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log ("make_raw.pl", @args);

###########################
Message "General definitions";
###########################

# light speed (m/s)
$C                        = 299792458;

$RANGE_SAMPLING_FREQUENCY = 17.10e+06;    # from database (same as the value from leaderfile)
$ANTENNA_SIDE             = -1;           # left looking : 1  right looking: -1
$ANTENNA_LENGTH           = 12;           # JERS SAR 11.9x2.4 m

$PLANET_GM       = 3.98600448073E+14;
$PLANET_SPINRATE = 7.29211573052E-05;

$RPVersion = 2.3;  #ROI_PAC version

#############################
Message "Getting facility name";
#############################
$g_facility = ByteRead ($leader_file, 1766, 15);
$facility or $facility = $g_facility;

$version    = ByteRead ($leader_file, 1782, 8);

$orbit_num  = ByteRead ($leader_file, 1164, 8); 

$sat = "JERS-1";
$facility =~ s/\s//g;

if    ($facility eq "EOC-ERS-DPSL") { $facility = "EOC-ERS-DPS";}
elsif ($facility eq "EOC-ERS-DPS") { $facility = "EOC-ERS-DPS";}
else {die "Unknown facility: $facility\n";}
print "Facility is $facility\n";

if ($facility eq "EOC-ERS-DPS"){
# image data file
  $file_header = 720;
  $width = 12700;
  $xmin = 412;
  $xmax = 12700;        # no suffix  
  $SWSToffset=120;      # actually, it is not SWST but STC value
  $swst_num_bytes = 4;
# leader file
  $PRFoffset = 1655;
  $prf_num_bytes = 16; 
#  $LineCounterFirstByte=200;
} 

$size_firstimg = -s $imagery[0];
$lines_firstimg = ($size_firstimg - $file_header)/$width;

##################################
  Message "Finding STC and PRF";
##################################
     

$imagery_file = $imagery[0]; 

$swst = ByteRead ($imagery_file, $file_header+$SWSToffset, $swst_num_bytes);
$swst = unpack("N",$swst);
$swst=$swst."e-09";

print STDERR "STC read: $swst\n";

$prf = ByteRead ($leader_file, $PRFoffset, $prf_num_bytes);


#########################################
Message "Join Scenes and cut file header";
#########################################
$join_args="$file_header $width $xmin";
$call_join="$INT_BIN/JoinJData $join_args @imagery" ;

Message "$call_join";
`$call_join`;

$size         = -s "tmp_IMAGERY.raw" or die "tmp_IMAGERY.raw has zero size\n";

$file_header=0;		# JoinJData removes file header
#$xmax = $xmax - $xmin ; # JoinJData removes record header also
$width = $xmax ;

###############################
Message "Reading the leader file";
###############################
$call_leader="$INT_BIN/leader2rsc $leader_file $INT_SCR/format_leaderfile_$facility tmp_IMAGERY.raw.rsc"; 

Message "$call_leader";
`$call_leader`;

###Create temporary file length
$size         = -s "tmp_IMAGERY.raw" or die "tmp_IMAGERY.raw has zero size\n";
$file_length1 = $size/$width ;  # file header has been removed by JoinJData #

################################
Message "Reading the imagery file";
################################

$pad_top    = 0;
$pad_bottom = 0;

# Read from tmp_IMAGERY.raw.rsc, the output of leader2rsc
$c_line = Use_rsc "tmp_IMAGERY.raw read FIRST_FRAME_SCENE_CENTER_LINE";
$c_hr   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_HOUR_OF_DAY"; 
$c_mn   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_MN_OF_HOUR"; 
$c_s    = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_S_OF_MN"; 
$c_ms   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_MS_OF_S"; 
$c_line           = $c_line+$pad_top;
$first_center_utc = ($c_hr*60+$c_mn)*60+$c_s+$c_ms/1000.;
$first_line_utc   = $first_center_utc-$c_line/$prf;        
$last_line_utc    = $first_line_utc+($file_length1-1)/$prf;   # Interval is (line number)-1
$center_utc       = ($first_line_utc+$last_line_utc)/2;



##################################
Message "Writing the DWP file";
##################################

#$call_dwp="$INT_BIN/MkDwpf_J $file_header $width $xmin  tmp_IMAGERY.raw";
#Message   "$call_dwp";

#`$call_dwp`;

$STCCNG_LN_offset=720+1935;
$STCCNG_LN_num_bytes=16;
$STCCNG_PIX_offset=720+1951;
$STCCNG_PIX_num_bytes=16;


@leaders=split /\s+/, `ls SARLEADER*`;
if(@leaders != @imagery){
	die "The number of leader file is not same as that of imagery file\n";
}

for($i=0;$i<@leaders;$i++){
	$shift_loc[$i]=ByteRead ($leaders[$i], $STCCNG_LN_offset, $STCCNG_LN_num_bytes);
	$shift_bin[$i]=ByteRead ($leaders[$i], $STCCNG_PIX_offset, $STCCNG_PIX_num_bytes);
}

open IN,"merge.out";
$i=1;
while(<IN>){
	if(/BOUNDARY/){
		($dummy,$boundary[$i])=split;
		$i++;
	}
}
close IN;
$boundary[0]=0;

open OUT,">tmp_IMAGERY.raw.dwpf";
$boundary_total_line=0;
$shift_total=0;
for($i=0;$i<@leaders;$i++){
	if($shift_bin[$i] != 0.0 && ($shift_loc[$i] > $boundary[$i]) ){
		$shift_loc_total = $boundary_total_line + $shift_loc[$i] - $boundary[$i];
		$shift_total += $shift_bin[$i];
		$shift_loc_int=int($shift_loc_total);
		$shift_int=int($shift_total);
		print OUT "$shift_loc_int\t$shift_int\n";
	}
	$boundary_total_line += $lines_firstimg - $boundary[$i];
}
close OUT;

$size_dwpf = -s "tmp_IMAGERY.raw.dwpf";
if($size_dwpf==0) {
  print "No STC change in the file: tmp_IMAGERY.raw.dwpf has zero size\n"; 
}

$file_length  = $file_length1 ;

################################
Message "Writing the imagery resource file";
################################

# get the one way delay to the nearest range 
$t0            = ByteRead ($leader_file, 1447, 16);  # in micro second
chop($t0);      # remove NL at the end
$starting_range_delay = $t0."e-06" ;
$starting_range_delay=$starting_range_delay/2;

$starting_range   = $starting_range_delay*$C;
$one_way_delay=$swst/2-$starting_range_delay;

$range_pixel_size = $C / $RANGE_SAMPLING_FREQUENCY /2;

Use_rsc "tmp_IMAGERY.raw write PLATFORM                 $sat";
Use_rsc "tmp_IMAGERY.raw write ORBIT_NUMBER             $orbit_num"; 
Use_rsc "tmp_IMAGERY.raw write ONE_WAY_DELAY            $one_way_delay"; 
Use_rsc "tmp_IMAGERY.raw write STARTING_RANGE           $starting_range"; 
Use_rsc "tmp_IMAGERY.raw write RANGE_PIXEL_SIZE         $range_pixel_size"; 
Use_rsc "tmp_IMAGERY.raw write PRF                      $prf";
Use_rsc "tmp_IMAGERY.raw write ANTENNA_SIDE             $ANTENNA_SIDE";
Use_rsc "tmp_IMAGERY.raw write ANTENNA_LENGTH             $ANTENNA_LENGTH";
Use_rsc "tmp_IMAGERY.raw write FILE_LENGTH              $file_length";
Use_rsc "tmp_IMAGERY.raw write XMIN                     $xmin";
Use_rsc "tmp_IMAGERY.raw write XMAX                     $xmax";
Use_rsc "tmp_IMAGERY.raw write WIDTH                    $xmax";
Use_rsc "tmp_IMAGERY.raw write YMIN                     0";
Use_rsc "tmp_IMAGERY.raw write YMAX                     $file_length";
Use_rsc "tmp_IMAGERY.raw write RANGE_SAMPLING_FREQUENCY $RANGE_SAMPLING_FREQUENCY";
Use_rsc "tmp_IMAGERY.raw write PLANET_GM                $PLANET_GM";
Use_rsc "tmp_IMAGERY.raw write PLANET_SPINRATE          $PLANET_SPINRATE";

Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_UTC  $first_line_utc"; 
Use_rsc "tmp_IMAGERY.raw write CENTER_LINE_UTC $center_utc"; 
Use_rsc "tmp_IMAGERY.raw write LAST_LINE_UTC   $last_line_utc"; 

######################################################################################
Message "Reading state vectors in SARLEADER's header, Building hdr_data_points_$date file"; 
######################################################################################
$day   = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_DAY_OF_MONTH"; 
$month = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_MONTH_OF_YEAR"; 
$year  = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_YEAR";

open HDR, ">hdr_data_points_$date.rsc" or die "Can't write to hdr_data_points_$date.rsc\n";
 
if ($orbit_type eq "HDR"){  
  # Caution: The position of state vector in the leader file is different from the ERS 
  $ld_file = $leader_file;

  $state_vector_num = ByteRead ($ld_file, 4956, 22);

  $time_data1    = ByteRead ($ld_file, 4976, 22);
  $time_data1    =~ s/D/e/g ;   # change exponential 'D' into 'e'
  $time_interval = ByteRead ($ld_file, 4998, 22);
  $time_interval =~ s/D/e/g ;   # change exponential 'D' into 'e'

  $offset_state_vector = 5202;  # offset to the first element of state vector 
                                # of the first point
  $element_length = 22;         # length of the each component of the vector
  $byte=0;
  
  for ($i=0;$i<$state_vector_num;$i++){
   $time_data[$i]=$time_data1+$time_interval*$i;
   if($time_data[$i] gt 86400.) {$time_data[$i] = $time_data[$i]-86400. ;}
   $xx[$i]=ByteRead ($ld_file, $offset_state_vector+$byte, $element_length);
   $byte=$byte+$element_length;
   $yy[$i]=ByteRead ($ld_file, $offset_state_vector+$byte, $element_length);
   $byte=$byte+$element_length;
   $zz[$i]=ByteRead ($ld_file, $offset_state_vector+$byte, $element_length);
   $byte=$byte+$element_length;
   $vvx[$i]=ByteRead ($ld_file, $offset_state_vector+$byte, $element_length);
   $byte=$byte+$element_length;
   $vvy[$i]=ByteRead ($ld_file, $offset_state_vector+$byte, $element_length);
   $byte=$byte+$element_length;
   $vvz[$i]=ByteRead ($ld_file, $offset_state_vector+$byte, $element_length);
   $byte=$byte+$element_length;
   
   $result[$i]=  "$time_data[$i] $xx[$i] $yy[$i] $zz[$i] $vvx[$i] $vvy[$i] $vvz[$i]";
   $result[$i]=~ s/D/e/g ;   # change exponential 'D' into 'e'
   print HDR "$result[$i]\n";
  }
 
}else {
  print "The orbit information other than HDR is not supported for JERS-1\n";
  exit;
}

close(HDR);

# Correct velocity.  Velocity vector of JERS-1 leader file is somehow ECI frame.
# It should be converted into ECR frame.

`mv hdr_data_points_$date.rsc hdr_data_points_$date.eci`;
print  "$INT_SCR/CorrectStateVel_J.pl hdr_data_points_$date.eci > hdr_data_points_$date.rsc\n";
`$INT_SCR/CorrectStateVel_J.pl hdr_data_points_$date.eci > hdr_data_points_$date.rsc`;


###############################
Message "Using Orbit Information"; 
###############################
($q1,$q2,$Lat,$Lon,$height_mid, $x0, $y0, $z0, $vx0, $vy0,$vz0) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $center_utc $sat $orbit_type $date`;
Status "state_vector.pl";

if ($orbit_type eq "HDR"){
 $ae    = 6378137;             #GRS80 reference ellipsoid
 $flat  = 1/298.257223563;
 $r     = sqrt($x0**2+$y0**2+$z0**2);
 $r1    = sqrt($x0**2+$y0**2);
 $Lat   = atan2($z0,$r1);
 $Lon   = atan2($y0,$x0);
 $H     = $r-$ae;
 print "$ae, $flat, $r, $r1, $Lat, $Lon, $H\n" ;
 for ($i=1; $i<7; $i++){
  $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
  $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
  $Lat    = atan2($TanLat,1);
  $H      = $r1/cos($Lat)-$N;
 }
 $Lat = $Lat/3.14159*180;
 $Lon = $Lon/3.14159*180;
 $height_mid=$H; 
}

$pi   = atan2(1,1)*4;
$Lat  = $Lat*$pi/180;
$ae   = 6378137;                        #WGS84 reference ellipsoid
$flat = 1./298.257223563;
$N    = $ae/sqrt(1-$flat*(2-$flat)*sin($Lat)**2);
$re_mid=$N;

$ve=-sin($Lon)*$vx0+cos($Lon)*$vy0;
$vn=-sin($Lat)*cos($Lon)*$vx0-sin($Lat)*sin($Lon)*$vy0+cos($Lat)*$vz0;
$hdg = atan2($ve,$vn);
$e2 = $flat*(2-$flat);
$M = $ae*(1-$e2)/(sqrt(1-$e2*sin($Lat)**2))**3;
$earth_radius_mid = $N*$M/($N*(cos($hdg))**2+$M*(sin($hdg))**2);


($q1,$q2,$q3,$q4,$height_top, $x0, $y0, $z0, $vx, $vy,$vz) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $first_line_utc $sat $orbit_type $date`;
Status "state_vector.pl";

if ($orbit_type eq "HDR"){
 $ae    = 6378137;             #GRS80 reference ellipsoid
 $flat  = 1/298.257223563;
 $r     = sqrt($x0**2+$y0**2+$z0**2);
 $r1    = sqrt($x0**2+$y0**2);
 $Lat   = atan2($z0,$r1);
 $Lon   = atan2($y0,$x0);
 $H     = $r-$ae;
 for ($i=1; $i<7; $i++){
  $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
  $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
  $Lat    = atan2($TanLat,1);
  $H      = $r1/cos($Lat)-$N;
 }
 $height_top=$H; 
}

$height_dt=($height_mid-$height_top)/($center_utc-$first_line_utc);
if ($vz0 > 0) {$orbit_direction =  "ascending";}
else          {$orbit_direction = "descending";}
$velocity_mid=sqrt($vx0**2 + $vy0**2 + $vz0**2);
$Latd=$Lat*180./$pi;
$Lond=$Lon*180./$pi;
$hdgd=$hdg*180./$pi;
Use_rsc "tmp_IMAGERY.raw write HEIGHT       $height_top";

Use_rsc "tmp_IMAGERY.raw write HEIGHT_DT    $height_dt";
Use_rsc "tmp_IMAGERY.raw write VELOCITY     $velocity_mid";
Use_rsc "tmp_IMAGERY.raw write LATITUDE     $Latd";
Use_rsc "tmp_IMAGERY.raw write LONGITUDE    $Lond";
Use_rsc "tmp_IMAGERY.raw write HEADING      $hdgd";
Use_rsc "tmp_IMAGERY.raw write EQUATORIAL_RADIUS   $ae";
Use_rsc "tmp_IMAGERY.raw write ECCENTRICITY_SQUARED $e2";
Use_rsc "tmp_IMAGERY.raw write EARTH_EAST_RADIUS $N";
Use_rsc "tmp_IMAGERY.raw write EARTH_NORTH_RADIUS $M";
Use_rsc "tmp_IMAGERY.raw write EARTH_RADIUS $earth_radius_mid";
Use_rsc "tmp_IMAGERY.raw write ORBIT_DIRECTION $orbit_direction";

#####################################################
$default = "$INT_SCR/default_J.raw.rsc";
Use_rsc    "tmp_IMAGERY.raw.rsc merge $default";
#####################################################

###############################
Message "Doppler Computation"; 
###############################

$line_0 = 100;
$line_1 = $file_length - 200;

$nbits = 3;				# number of bits per each data. JERS-1:3bit/data

# sensor parameters used in doppler estimation
$RANGE_SAMPLING_FREQUENCY = Use_rsc "tmp_IMAGERY.raw read RANGE_SAMPLING_FREQUENCY";
$pulse_length             = Use_rsc "tmp_IMAGERY.raw read PULSE_LENGTH";
$chirp_slope              = Use_rsc "tmp_IMAGERY.raw read CHIRP_SLOPE";
$chirp_bandwidth          =$pulse_length*$chirp_slope;
  if($chirp_bandwidth<0){$chirp_bandwidth *= -1;}		# absolute value
$wavelength               = Use_rsc "tmp_IMAGERY.raw read WAVELENGTH";	# radar wavelength (m)
$cf                       = $C/$wavelength;				# center frequency.  $C:light speed

# parameters for doppler estimation
$xmin  = Use_rsc "tmp_IMAGERY.raw read XMIN" ;
$xmax  = Use_rsc "tmp_IMAGERY.raw read XMAX" ;
$ssamp = $xmin/2+1000 ;		# estimation start sample number
$esamp = $xmax/2-1000 ;		# estimation end sample number
$specwidth = 0.75  ;		# Interval between upper and lower frequency patch (ratio to the chirp bandwidth)
#$specwidth = 0.5  ; 
$bwf   =     0.25  ;		# band width of upper and lower frequency patch (ratio to the chirp bandwidth)
#$bwf   =     0.5  ;
$type  =    'iqb'  ;		# data type(IQ byte data)
  # qf: IQ floating point data
  # iqb: IQ byte data
  # ovf: Offset Video floating point data
  # ovb: Offset Video byte data

$dop_rng0=0;	#constant
$dop_rng1=0;	#linear w.r.t. range pixel
$dop_rng2=0;	#quadratic
$dop_rng3=0;	#quadratic

`$INT_BIN/dopiq <<end
tmp_IMAGERY.raw
$xmax,$line_0,$line_1
3.5,$prf
end
`;
print "$xmax,$line_0,$line_1,$i_bias,$prf\n";
$i_samples = $xmax/2;	# sample number (include record header)
$calc_dop="$INT_BIN/mlcc tmp_IMAGERY.raw  $i_samples  $nbits  \\
                         $RANGE_SAMPLING_FREQUENCY $pulse_length $chirp_bandwidth $prf $cf   \\
                         $ssamp $esamp $specwidth $bwf    \\
                         $type $line_0 $line_1";

Message "$calc_dop";
`$calc_dop`;

# linear fit of doppler w.r.t. range
#  The script for linear fitting is given by Eric Gurroda

print "Fitting doppler polynominal\n";
open(FILE,"dop.out") || die "cannot open dop.out";
$i=0;
while (<FILE>){
	chomp;
	s/^\s+//g;
	($X[$i],$Y[$i])=split /\s+/, $_;
	$i++;
}
$n=$i;	# number of data
close(FILE);

$SumX=0;
$SumY=0;
for( $i=0; $i<$n; $i++){
    $SumX  += $X[$i];
    $SumY  += $Y[$i];
}
$AvgX = $SumX / $n ;
$AvgY = $SumY / $n ;
$SlopeNum = 0;
$SlopeDenom = 0;
for( $i=0; $i<$n; $i++){
    $SlopeNum   += ( $X[$i]-$AvgX )*( $Y[$i]-$AvgY );
    $SlopeDenom += ( $X[$i]-$AvgX )*( $X[$i]-$AvgX );
}
$Slope = $SlopeNum / $SlopeDenom ;
$Intercept = $AvgY - $Slope * $AvgX ;

# output the data about fitting quality
open(RESIDUE,">dopfit.residue");
for( $i=0; $i<$n; $i++){
	$Y_Cal[$i] = $Intercept + $X[$i]*$Slope;
	$Res[$i] = $Y[$i] - $Y_Cal[$i];
	print RESIDUE "$X[$i]\t$Y[$i]\t$Y_Cal[$i]\t$Res[$i]\n";
	$ResSumSq += $Res[$i]*$Res[$i];
}
close (RESIDUE);

open(OUT, ">dopfit.out");
print OUT "Fitting Result:\n";
print OUT "Data count: $n\n";
print OUT "Regression\n";
print OUT "  y = $Intercept + $Slope *X\n";
print OUT "Residual Sum of Sqares: $ResSumSq\n";
close(OUT);

$dop_rng0=$Intercept;
$dop_rng1=$Slope;

print "Doppler Polynominal:  y = $Intercept + $Slope *X\n  (PRF/pix)\n";

Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE0  $dop_rng0";
Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE1  $dop_rng1";
Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE2  $dop_rng2";
Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE3  0.";

# calculate squint
print "Calculate Squint Angle\n";
$rng_center=(($width-$xmin)/2)/2; 
$dop_middle = $dop_rng0+($dop_rng1+$dop_rng2*$rng_center)*$rng_center;

($dummy,$squint)=split(/\s+/,`$INT_SCR/calc_squint.pl $dop_middle tmp_IMAGERY.raw`);
Status "calc_squint.pl" ;

print "Squint angle: $squint (deg)\n";
Use_rsc "tmp_IMAGERY.raw write SQUINT          $squint";
Use_rsc "tmp_IMAGERY.raw write ROI_PAC_VERSION     $RPVersion";


`mv tmp_IMAGERY.raw.dwpf             ${date}.raw.dwpf`;
`mv tmp_IMAGERY.raw.rsc             ${date}.raw.rsc`;
`mv tmp_IMAGERY.raw                 ${date}.raw`;

#########################
Message "Raw data ready for processing";
#########################

exit 0;

=pod

=head1 USAGE

B<make_raw_jers.pl> I<orbit_type leader_file date [facility] >

=head1 FUNCTION

Creates I<date>.raw and I<date>.raw.rsc from imagery files of JERS-1
This script is little endian PC version of make_raw.pl to process JERS-1 data.
Including data concatination, *.dwpf file generation, doppler ambiguity estimation.

=head1 ROUTINES CALLED

JoinJData

leader2rsc

MkDwpf_J

state_vector.pl

dd

mlcc

calc_squint.pl

=head1 CALLED BY

none

=head1 FILES USED

IMAGERY*

SARLEADER*

=head1 FILES CREATED

I<date>.raw

I<date>.raw.rsc

merge.out

shift.out.rsc

spec.dat

dop.out

=head1 HISTORY

This script is little endian pc version of make_raw.pl for dealing with JERS-1 data.

Written by Hiroyuki Nakagawa on Apr. 2001 modifying make_raw.pl

history of make_raw.pl
Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Modifications: Frederic CRAMPE, Oct 21, 1998
update       : Frederic CRAMPE, Oct 06, 1999

=head1 LAST UPDATE

Hiroyuki Nakagawa  4/10/2001


=cut
