#!/usr/bin/perl
### length.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/length.pl`;
exit 1;
}
@ARGV == 1 or Usage();

foreach $infile (@ARGV){
  $width      = Use_rsc "$infile read WIDTH";
  $old_length = Use_rsc "$infile read FILE_LENGTH";
  
  $extension =  $infile;
  $extension =~ s/.*\.//;

  if    ($extension =~ /^(trans|int|amp|unw|hgt|cor|msk|slc)$/)  { $pix = 8;} 
  elsif ($extension eq "phs")   { $pix = 4;}
  else {die "$extension is unknown file extension\n";}
  
  $size = -s $infile;
  $file_length=$size/$pix/$width;
  if ($file_length < $old_length){
    Use_rsc "$infile write FILE_LENGTH $file_length";
  }
}

exit 0;
=pod

=head1 USAGE

B<length.pl> I<file1 [file2] ....>

I<file>: extension must be .trans .int .amp .hgt .cor .slc or .phs

=head1 FUNCTION

Updates rscfile with new length of file

=head1 ROUTINES CALLED

none

=head1 CALLED BY

geocode.pl

make_sim.pl

roi.pl

=head1 FILES USED

I<file1>

I<file1>.rsc

I<file2>

..

=head1 FILES CREATED

I<file1>.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
