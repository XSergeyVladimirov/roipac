#!/usr/bin/perl
### synth2radar.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/synth2radar.pl`;
exit 1;
}
@ARGV == 3  or Usage();
@args = @ARGV;

$hgt         = shift;
$out_aff     = shift;
$out_hgt     = shift;
$DX          = 0;
$DY          = 0;

#################
Message "Checking I/O";
#################
@Infiles  = ("cull.out", $hgt);
@Outfiles = ($out_aff);
&IOcheck(\@Infiles, \@Outfiles);
Log("synth2radar.pl", @args);

($m11, $m12, $m21, $m22, $t1, $t2) = split /\s+/, `$INT_SCR/find_affine.pl cull.out`;
Status "find_affine.pl";

open OUT, ">$out_aff" or die "Can't write to $out_aff\n";
print OUT "$m11 $m12 $m21 $m22 $t1 $t2";
close(OUT);

###############################################
Message "Registering the height map to the radar";
###############################################
`$INT_SCR/rect.pl $hgt     \\
                  $out_hgt \\
                  $m11     \\
                  $m12     \\
                  $m21     \\
                  $m22     \\
                  $t1      \\
                  $t2`;
Status "rect.pl";
exit 0;
 
=pod

=head1 USAGE

B<synth2radar.pl> I<hgt out_aff out_hgt>

=head1 FUNCTION

Transforms the sythesized topography into radar coordinates

=head1 ROUTINES CALLED

rect.pl 

find_affine.pl  

=head1 CALLED BY

process.pl

=head1 FILES USED

I<hgt>

cull.out

=head1 FILES CREATED

I<out_hgt>

I<out_hgt>.rsc

I<out_aff>

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
