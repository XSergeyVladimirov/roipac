#!/usr/bin/perl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

sub Usage {
  print STDERR <<END;
Usage: pod2man.pl filename

    pod format at end must include:

=head1 USAGE

"usage statement"

=head1 FUNCTION

"function statement"

=head1 ROUTINES CALLED
"random stuff of any length"
=head1 LAST UPDATE

name, date, year
"etc"

pod2man.pl will print to STDERR: 
Usage: usage statement
Function: function statment
*** name date year ***
END
    exit 1;

  }
@ARGV ==1 or Usage();
$file = shift;
open IN, "$file";

until ($line =~ /head1 USAGE/){
  $line = <IN>;
}
$line = <IN>;
$line = <IN>;
until ($line =~ /head1 FUNCTION/){
  $usage .= $line;
  $line = <IN>;
}
$line = <IN>;
$line = <IN>;
until ($line =~ /ROUTINES/){
  $function .= $line;
      $line = <IN>;
}
until ($line =~ /LAST UPDATE/){
  $line = <IN>;
}
$line = <IN>;
$date = <IN>;
chomp $date;
chomp $usage;
chomp $function;
$usage =~ s/B<//g;
$usage =~ s/I<//g;
$usage =~ s/>//g;
$date  =~ s/\D+, //;
print STDERR "
Usage: $usage
Function: $function

*** Last Update $date 
*** For more info see http://roipac.org

*** This software is part of the ROI_PAC suite.  
*** Licensed software, not for general distribution. 
";
    close IN;
=pod

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Frederic CRAMPE, May 22, 1998

=head1 LAST UPDATE

Eric Fielding, Aug. 27, 2007

=cut


