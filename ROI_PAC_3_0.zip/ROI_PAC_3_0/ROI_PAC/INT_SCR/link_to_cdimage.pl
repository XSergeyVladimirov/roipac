#!/usr/bin/perl

#####load_cd.pl#####

#links standard ERS data files in a disk image of ERS CD to expected ROI_pac  names
#run this from the directory into which you want the data put

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{`$INT_SCR/pod2man.pl  $INT_SCR/link_to_cdimage.pl`; exit 1;}

@ARGV == 1 or Usage();

$cdimage_name=shift;

$VDF = `ls $cdimage_name/VDF_DAT.00*`;  #gets VDF filename
chop $VDF;                #removes newline character
print "VDF is $VDF\n";

### read_VDF returns "file-length file-length..."

@records = split /\s+/, `$INT_SCR/read_ln_VDF.pl $VDF`; #splits the return into 2 filenames+length.
$index = chop $VDF;       #$index is the last number in VDF filename

foreach $record (@records){  #changes filenames

  ($file,$blocksize) = split /-/, $record;
  print "$file\n";
  if ($file =~ "SAR*") {  #gets SARLEADER
    `ln -s $cdimage_name/LEA_01.00$index $file`;
  }
  else {    #gets IMAGERY
    `ln -s $cdimage_name/DAT_01.00$index $file`;
  }
}

exit 0;

=pod

=head1 USAGE

link_to_cdimage.pl disk_directory_with_files_from_cd

=head1 FUNCTION

links to ERS data copied from CD to disk with proper filenames so that ROI_pac can use them.

=head1 ROUTINES CALLED

none

=head1 CALLED BY

only you

=head1 FILES USED

VDF_DAT

LEA_01

DAT_01

=head1 FILES CREATED

VDF

SARLEADER

IMAGERY

=head1 HISTORY

Perl  Script : Greg Gerbi

=head1 LAST UPDATE

Greg Gerbi, September 21, 1998

=cut
