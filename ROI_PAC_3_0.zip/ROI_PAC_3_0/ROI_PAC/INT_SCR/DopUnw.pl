#!/usr/bin/perl

if( $#ARGV < 0 ){
	die "Usage: DopUnw.pl <Dopiq_output_file>\n";
}

open( DOPOUT, $ARGV[0] );
while( $Line = <DOPOUT> ){
	$Line =~ s/^\s+//;
	( $PixIndex, $Frac, $Hz ) = split( /\s+/, $Line );
	next if $Frac == 0 ;
	push @PixIndex, $PixIndex;
	push @Frac, $Frac;
}
close( DOPOUT );

#################################################################
# Fake wrapping #
#################
$WrapCount = 0*5;
$NoiseLevel = 0*0.7;

foreach $i ( 0..$#Frac ){

	if( $WrapCount != 0 ){
		$Frac[$i] += $WrapCount + $i * $WrapCount / $#Frac;
	}
	 
	if( $NoiseLevel != 0 ){
		$Frac[$i] += 1 + $NoiseLevel/2 - rand($NoiseLevel) ;
	}
	
	$Frac[$i] -= int( $Frac[$i] );
}	

#################################################################
# Unwrapping #
##############

#$Threshold = 0.5;
$AverageLength=10;
$FirstDop = 0;

foreach $i (0..$AverageLength-1){
	$LastValues[$i] = $FirstDop;
}

#$Ambiguity[0] = 0;
#$Predicted = $Frac[0];

#foreach $i ( 1..$#Frac ){
foreach $i ( 0..$#Frac ){

	$Predicted = Average( @LastValues );

	#if( $Frac[$i] - $Frac[$i-1] > $Threshold ){
	#	$Ambiguity[$i] = $Ambiguity[$i-1] - 1;
	#}elsif( $Frac[$i] - $Frac[$i-1] < -1 * $Threshold ){
	#	$Ambiguity[$i] = $Ambiguity[$i-1] + 1;
	#}else{
	#	$Ambiguity[$i] = $Ambiguity[$i-1];
	#}
	
	$Ambiguity[$i] = $Predicted - $Frac[$i];
	$Ambiguity[$i] = sprintf( "%.0f", $Ambiguity[$i] );
	
	$Unw[$i] = $Frac[$i] + $Ambiguity[$i];
	
	shift @LastValues if $#LastValues >= $AverageLength-1;
	push @LastValues, $Unw[$i];
	
}

open( OUT, ">dop.unw" );
foreach $i ( 1..$#Frac ){
	print OUT $PixIndex[$i], " ", $Unw[$i], " ", $Frac[$i], "\n";
}
close( OUT );

#################################################################
# Linear fit #
##############
( $Intercept, $Slope, $StdDev ) = LinearFit( @PixIndex, @Unw );
CullPoints( $Intercept, $Slope, $StdDev, \@PixIndex, \@Unw );
( $Intercept, $Slope, $StdDev ) = LinearFit( @PixIndex, @Unw );
CullPoints( $Intercept, $Slope, $StdDev, \@PixIndex, \@Unw );

printf( "Linear doppler: %7.5g %7.5g\n", $Intercept, $Slope );

( $a, $b, $c ) = QuadraticFit( @PixIndex, @Unw );
printf( "Quadratic doppler: %7.5g %7.5g %7.5g\n", $a, $b, $c );

open( OUT, ">dop.mod" );
foreach $i ( 1..$#Unw ){
	$unw1 = $Intercept + $Slope * $PixIndex[$i];
	$unw2 = $a + $b * $PixIndex[$i] + $c * $PixIndex[$i]* $PixIndex[$i];

	print OUT "$PixIndex[$i] $Unw[$i] $unw1 $unw2\n";
}
close( OUT );

#################################################################
#################################################################

sub CullPoints{
	my $Intercept   = shift;
	my $Slope       = shift;
	my $StdDev      = shift;
	my $PixIndexRef = shift;
	my $UnwRef      = shift;
	
	for( my $i=0; $i< $#{$PixIndexRef}; $i++ ){
		my $Fit      = $Intercept + $Slope * ${$PixIndexRef}[$i];
		my $Residual = ${$UnwRef}[$i] - $Fit;
		next unless abs( $Residual ) > 3 * $StdDev;
		splice @{$PixIndexRef}, $i, 1;
		splice @{$UnwRef},      $i, 1;
	}
}
	
	
	

sub Average{
	my @x;
	my $SumX; 
	my $i;
	
	@x = @_;
	
	for( $i=0; $i<=$#x; $i++ ){
		$SumX += $x[$i];
	}
	
	return( $SumX / ( $#x+1 ) );
}

	

sub LinearFit{

	my @x;
	my @y;
	my ($SumX, $AvgX); 
	my ($SumY, $AvgY); 
	my ($SlopeNum, $SlopeDenom);
	my ($Slope, $Intercept);
	my ($SumErr, $StdDev);
	my $i;

	@x = @_[0..$#_/2];
	@y = @_[$#_/2+1..$#_];
	
	for( $i=0; $i<=$#x; $i++ ){
		$SumX += $x[$i];
		$SumY += $y[$i];
	}
		
	$AvgX = $SumX / ($#x+1);
	$AvgY = $SumY / ($#x+1);

	for( $i=0; $i<=$#x; $i++ ){
	        $SlopeNum   += ($x[$i]-$AvgX)*($y[$i]-$AvgY);
	        $SlopeDenom += ($x[$i]-$AvgX)*($x[$i]-$AvgX);
	}

	$Slope = $SlopeNum / $SlopeDenom ;
	$Intercept = $AvgY - $Slope * $AvgX ;

	for( $i=0; $i<=$#x; $i++ ){
	        $SumErr += ($y[$i]-($Intercept+$Slope*$x[$i]))**2;
	}
	
	$StdDev = sqrt( $SumErr / ($#x+1) );
	
	return( $Intercept, $Slope, $StdDev );
 }

#######################################################################
sub QuadraticFit{

	my @x, @y;
	my @SumX, @SumYX;
	my $i;
	
	@x = @_[0..$#_/2];
	@y = @_[$#_/2+1..$#_];
	
	for( $i=0; $i<=$#x; $i++ ){
		$SumX[0]  += 1;
		$SumX[1]  += $x[$i];
		$SumX[2]  += $x[$i]**2;
		$SumX[3]  += $x[$i]**3;
		$SumX[4]  += $x[$i]**4;
		$SumYX[0] += $y[$i];
		$SumYX[1] += $y[$i] * $x[$i];
		$SumYX[2] += $y[$i] * $x[$i] * $x[$i];
	}
	
#print "@SumX\n";
#print "@SumYX\n";
	
	my @Inversed;
	@Inversed = InverseSquareMatrix( 
				$SumX[0], $SumX[1], $SumX[2],
				$SumX[1], $SumX[2], $SumX[3],
				$SumX[2], $SumX[3], $SumX[4]
			);
			
#print "-------------------------\n";
#print "$Inversed[0] $Inversed[1] $Inversed[2]\n";
#print "$Inversed[3] $Inversed[4] $Inversed[5]\n";
#print "$Inversed[6] $Inversed[7] $Inversed[8]\n";
#print "-------------------------\n";
	
	my $a = $Inversed[0 + 0 * 3] * $SumYX[0]
	      + $Inversed[1 + 0 * 3] * $SumYX[1]	
	      + $Inversed[2 + 0 * 3] * $SumYX[2];
	   
	my $b = $Inversed[0 + 1 * 3] * $SumYX[0]
	      + $Inversed[1 + 1 * 3] * $SumYX[1]	
	      + $Inversed[2 + 1 * 3] * $SumYX[2];
	   	
	my $c = $Inversed[0 + 2 * 3] * $SumYX[0]
	      + $Inversed[1 + 2 * 3] * $SumYX[1]	
	      + $Inversed[2 + 2 * 3] * $SumYX[2];
	
	return( $a, $b, $c );
}

#######################################################################

sub InverseSquareMatrix{
	my @InM;
	my @OutM;
	
	#In and Out have the coefficient of the matrix in a flat list, line by line;
	
	@In = @_;
	my $N = sqrt($#In+1);
	
	for( my $i=0; $i<$N; $i++ ){
	
		$In[ $i + $i * $N ] = 1 / $In[ $i + $i * $N ];
		
		for( my $j=0; $j<$N; $j++ ){
			next if $j == $i;
			$In[ $i + $j * $N ] = $In[ $i + $j * $N ] 
			                       * $In[ $i + $i * $N ];
		}
		
		for( my $j=0; $j<$N; $j++ ){
		for( my $k=0; $k<$N; $k++ ){
			next if $j == $i;	
			next if $k == $i;
			$In[ $k + $j * $N ] = 	$In[ $k + $j * $N ]
			                        - $In[ $i + $j * $N ]
			                        * $In[ $k + $i * $N ];
		}
		}
		
		for( my $k=0; $k<$N; $k++ ){
			next if $k == $i;
			$In[ $k + $i * $N ]  = -1 * $In[ $i + $i * $N ]
			                        * $In[ $k + $i * $N ];
		}
		
	}
		
	return( @In );
	

}

__END__

#######################################################################

sub InverseSquareMatrix{
	my @InM;
	my @OutM;
	
	#In and Out have the coefficient of the matrix in a flat list, line by line;
	
	@In = @_;
	my $N = sqrt($#In+1);
	
	for( my $i=0; $i<$N; $i++ ){
	
		$Out[ $i + $i * $N ] = 1 / $In[ $i + $i * $N ];
		
		for( my $j=0; $j<$N; $j++ ){
			next if $j == $i;
			$Out[ $i + $j * $N ] = $In[ $i + $j * $N ] 
			                       * $Out[ $i + $i * $N ];
		}
		
		for( my $j=0; $j<$N; $j++ ){
		for( my $k=0; $k<$N; $k++ ){
			next if $j == $i;	
			next if $k == $i;
			$Out[ $k + $j * $N ] = 	$In[ $k + $j * $N ]
			                        - $Out[ $i + $j * $N ]
			                        * $In[ $k + $i * $N ];
		}
		}
		
		for( my $k=0; $k<$N; $k++ ){
			next if $k == $i;
			$Out[ $k + $i * $N ]  = -1 * $Out[ $i + $j * $N ]
			                        * $In[ $k + $i * $N ];
		}
		
	}
		
	return( @Out );
	

}















