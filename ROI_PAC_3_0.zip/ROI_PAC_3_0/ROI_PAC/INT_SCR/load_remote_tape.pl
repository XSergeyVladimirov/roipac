#!/usr/bin/perl
### load_remote_tape.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR SAR_TAPE);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl $INT_SCR/load_remote_tape.pl`;
exit 1;
}

$name = `whoami`;
chomp $name;


$host      = shift or $host = "kahn";
$login     = shift or $login =$name;
$device    = shift;
$directory = shift or $directory = ".";

$recordlength=360;
$PID = $$;

if     ($host eq "argus"){ $mt = "mt -f"; }
else   {$mt = "mt -t";}

unless ($device){
  if    ($host eq "lor")    {$device = "/dev/nrst1";}
  elsif ($host eq "kahn")   {$device = "/dev/nrst10";}
  elsif ($host eq "sarhaz") {$device = "/dev/rmt/0n";}
  elsif ($host eq "argus")  {$device = "/dev/rmt/tps0d7nrns";}
  else  {$device = "$SAR_TAPE";}
}
$command ="rsh -l $login $host";


Message "load_remote_tape.pl $host $login $device $directory";
chdir $directory;

### Rewind tape
`$command $mt $device rewind`;  
$VDF = "VDF$PID";
`sleep 5`;

### Send first 360 characters to $VDF, then read the files and lengths
### read_VDF returns "file-length file-length..."
`$command dd if=$device bs=$recordlength > $VDF 2>load.err`;
@records = split /\s+/, `$INT_SCR/read_VDF.pl $VDF`;

foreach $record (@records){
  ($file,$blocksize) = split /-/, $record;
  print STDERR "Loading $file $blocksize\n";
  `sleep 5`;
  `$command dd if=$device bs=$blocksize > $file 2>load.err`;
}

### Eject tape
print STDERR "loaded\n";
`$command $mt $device offline`;
exit 0;
=pod

=head1 USAGE

B<load_remote_tape.pl>  I<[host]> I<[login]> I<[device]> I<[directory]>

  Defaults:
      host: runcorn
     login: login name of user
    device: $SAR_TAPE
 directory: .

=head1 FUNCTION

Loads tapes containing Imagery files

=head1 ROUTINES CALLED

read_VDF.pl

=head1 CALLED BY

none

=head1 FILES USED

none

=head1 FILES CREATED

Depends on tape

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Frederic CRAMPE, Oct 21, 1998

=cut
