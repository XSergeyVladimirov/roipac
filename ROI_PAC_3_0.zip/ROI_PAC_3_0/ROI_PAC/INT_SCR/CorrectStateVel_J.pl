#! /usr/bin/perl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;
use CalcVec;

if(@ARGV<1){ die "usage: CorrectStateVel_J.pl <hdr file>\n";}

$pi=4*atan2(1.0,1.0);

@we=(0,0,2*$pi/24./3600.);	# earth rotation vector

while (<>){
	@para=split;
	
	$time=$para[0];
	@pos=@para[1,2,3];
	@vel_ECI=@para[4,5,6];	# velocity in state vector is somehow Earth Centered Inertia frame (Tobita,1995)
	
	@E_ROT=VecProd3("@we","@pos");
	@vel_ECR=VecSub("@vel_ECI","@E_ROT");
	
	print "$time @pos @vel_ECR\n";
}
	
