#!/usr/bin/perl
###make_cor.pl 

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/make_cor.pl`;
exit 1;
}
@ARGV == 3 or Usage();
@args = @ARGV;

$intpre  = shift;
$amppre  = shift;
$corpre  = shift;
$intfile = "$intpre.int";
$ampfile = "$amppre.amp";
$corfile = "$corpre.cor";

#################
Message "Checking I/O";
#################
@Infiles  = ($intfile, "$intfile.rsc", 
             $ampfile, "$ampfile.rsc");
@Outfiles = ($corfile, "$corfile.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("make_cor.pl", @args);

##########################################
Message "Reading resource file: $intfile.rsc";
##########################################
$width  = Use_rsc "$intfile read WIDTH";

##########################################
Message "Writing resource file: $corfile.rsc";
##########################################
`cp $intfile.rsc $corfile.rsc`;

#######################################
Message "$INT_BIN/cchz_wave $intfile $ampfile $corfile $width 5";
`$INT_BIN/cchz_wave $intfile \\
                    $ampfile \\
                    $corfile \\
                    $width \\
                    5`;
Status "cchz_wave";

exit 0;

=pod

=head1 USAGE

B<make_cor.pl> I<date>

date: interferogram is I<date>.int

=head1 FUNCTION

Creates an rmg file with amplitude and correlation 

=head1 ROUTINES CALLED

cchz_wave

=head1 CALLED BY

process.pl

=head1 FILES USED

I<date>.int

I<date>.amp

I<date>.int.rsc

I<date>.amp.rsc

=head1 FILES CREATED

I<date>.cor

I<date>.cor.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
