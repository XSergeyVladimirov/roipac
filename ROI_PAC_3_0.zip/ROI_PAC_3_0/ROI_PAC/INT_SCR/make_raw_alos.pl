#!/usr/bin/perl
### make_raw_alos.pl

use Env qw(INT_SCR INT_BIN MY_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;
use POSIX qw(ceil floor);

###Usage info/check
#sub Usage{

#`$INT_SCR/pod2man.pl  $INT_SCR/make_raw_envi.pl`;
#exit 1;
#}

sub Usage {
  print STDERR <<END;

Usage: make_raw_alos.pl alos_file_root [outname] 
  alos_file_root   : prefix of Level 0 ALOS data file(s) (e.g., IMG-HH-ALP)
  outname          : output file name; YYMMDD is default

Function: Creates I<outname>.raw and I<outname>.raw.rsc from imagery files

  *** Yuri Fialko, Aug.7, 2007 *** 
software inputs from Dave Sandwell, Rob Mellors, and Matt Wei
revised by Eric Fielding

END
  exit 1;
}

@ARGV >= 1  or Usage();
@args = @ARGV;

$alos_file_prefix       = shift;
$outname           = shift ;
$new_ws_code       = shift or $new_ws_code = 0;  # optional window start code word

# get name of image file

@imagery=split /\s+/, `ls $alos_file_prefix*1.0__A $alos_file_prefix*1.0__D` or die "No Imagery files\n";;
print STDERR "@imagery \n";

#################
Message "Checking I/O";
#################
@Infiles  = ($alos_file_prefix, @imagery);
@Outfiles = ("$outname.raw",  "$outname.raw.rsc");
#&IOcheck(\@Infiles, \@Outfiles);
Log ("make_raw_alos.pl", @args);

###########################
Message "General definitions";
###########################

$C                        = 299792458;
$ANTENNA_SIDE             = -1;
$ANTENNA_LENGTH           = 8.9;

$PLANET_GM       = 3.98600448073E+14;
$PLANET_SPINRATE = 7.29211573052E-05;
$sat = "ALOS";

$ii=0;
foreach $imagery (@imagery){
 $fname=substr($imagery,-23); # get last 23 characters
 $leader_file="LED-"."$fname";
 $frame=substr($fname,11,4); 
 $orbit_num=substr($fname,6,5); 
 $polar=substr($imagery,4,2);
# determining track still needs some tinkering
 $ref_tr=291;
 $ref_orb=1434;
 $track=$ref_tr+($orbit_num-$ref_orb) % 671;

$time = ByteRead ($leader_file, 780, 30);
$proc_sys = ByteRead ($leader_file, 1782, 8);
$proc_ver = ByteRead ($leader_file, 1791, 4);
$swath = ByteRead ($leader_file, 2564, 4);

$yr=substr($time,0,4); 
$yr2=substr($time,2,2); 
$mo=substr($time,4,2); 
$da=substr($time,6,2); 
# these correspond to the middle of the strip:
$hr=substr($time,8,2); 
$mn=substr($time,10,2); 
$sc=substr($time,12,2); 
$ms=substr($time,14,4); 
$dt=$yr2.$mo.$da;
if ($#imagery == 0){ $outname=$dt;}  # only one frame
else { $outname = "$dt-$ii" }   # save as separate names if multiple frames

print STDERR " date: $outname \n";

# This part uses Dave's decoder (ALOS_pre_process)
$ii++;
print STDERR " Decoding $ii frame \n";
Message "ALOS_pre_process $imagery $leader_file ";
`$MY_BIN/ALOS_pre_process $imagery $leader_file`; # removed -nolh EJF 2007/8/22

 open(PARAM,"$imagery.PRM") or die "Can't open $imagery.PRM\n";
 while (<PARAM>) {
   ($name,$value) = split /\=/,$_;
   $name=trim($name);
   chomp($value);
   if ($name eq "bytes_per_line") {$width=$value+0;}
   if ($name eq "first_sample") {$first_samp=$value+0;}
   if ($name eq "good_bytes_per_line") {$good=$value+0;}
   if ($name eq "num_lines") {$length=$value+0;}
   if ($name eq "PRF") {$prf=$value+0;}
   if ($name eq "rng_samp_rate") {$range_sampling_frequency=$value+0;}
   if ($name eq "pulse_dur") {$pulse_dur=$value+0;}
   if ($name eq "near_range") {$starting_range=$value+0;}
   if ($name eq "chirp_slope") {$chirp=$value+0;}
   if ($name eq "radar_wavelength") {$wavelength=$value+0;}
   if ($name eq "I_mean") {$i_bias=$value+0;}
   if ($name eq "Q_mean") {$q_bias=$value+0;}
   if ($name eq "SC_clock_start") {$start_time=$value+0;}
   if ($name eq "orbdir") {$orbdir=$value+0;}
   if ($name eq "earth_radius") {$earth_radius=$value+0;}
   if ($name eq "equatorial_radius") {$equatorial_radius=$value+0;}
   if ($name eq "polar_radius") {$polar_radius=$value+0;}
   if ($name eq "SC_height") {$height=$value+0;}
   if ($name eq "SC_vel") {$vel=$value+0;}
   if ($name eq "fd1") {$fd1=$value+0;}
  }
 close(PARAM);
$range_bias=0;
# alternatively, start time can be read from the leader file
$tday=$start_time-floor($start_time);
$hr=floor($tday*24);
$tday=$tday-$hr/24;
$mn=floor($tday*60*24);
$tday=$tday-$mn/60/24;
$sc=floor($tday*60*60*24);
$tday=$tday-$sc/60/60/24;
$ms=floor($tday*1000*60*60*24);

# in case range_bias is non-zero : get true starting range
if ($range_bias != 0.) {
  print STDERR "subtracting range bias \n";
  $starting_range = $starting_range - $range_bias;
}

$xmin=($first_samp*2)+1;  # now leaving line headers on; in bytes
$xmax=$good;     # also padding at end in bytes
`mv $imagery.raw tmp_IMAGERY.raw`; 

##################################
  Message "Finding reference counter, pri and prf";
##################################

$pri = 1/$prf;

###Calculate file length
$size         = -s "tmp_IMAGERY.raw" or die "tmp_IMAGERY.raw has zero size\n";
$file_length = $size/$width;
print STDERR "width=$width, length=$file_length \n";
$clength=0;  
$rms=floor($ms);

Use_rsc "tmp_IMAGERY.raw write FIRST_FRAME                 $frame";
Use_rsc "tmp_IMAGERY.raw write FIRST_FRAME_SCENE_CENTER_TIME            $yr$mo$da$hr$mn$sc$rms";
Use_rsc "tmp_IMAGERY.raw write FIRST_FRAME_SCENE_CENTER_LINE            $clength";
Use_rsc "tmp_IMAGERY.raw write DATE                                     $dt";
Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_YEAR                          $yr";
Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_MONTH_OF_YEAR                 $mo";
Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_DAY_OF_MONTH                  $da";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_HOUR_OF_DAY                 $hr";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_MN_OF_HOUR                  $mn";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_S_OF_MN                     $sc";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_MS_OF_S                     $ms";
#Use_rsc "tmp_IMAGERY.raw write PROCESSING_FACILITY                      $facility";
Use_rsc "tmp_IMAGERY.raw write PROCESSING_SYSTEM                        $proc_sys";
Use_rsc "tmp_IMAGERY.raw write PROCESSING_VERSION                       $proc_ver";
Use_rsc "tmp_IMAGERY.raw write WAVELENGTH                               $wavelength";
Use_rsc "tmp_IMAGERY.raw write PULSE_LENGTH                             $pulse_dur";
Use_rsc "tmp_IMAGERY.raw write CHIRP_SLOPE                              $chirp";
Use_rsc "tmp_IMAGERY.raw write I_BIAS                                   $i_bias";
Use_rsc "tmp_IMAGERY.raw write Q_BIAS                                   $q_bias";

################################
Message "Reading the imagery file";
################################


$first_line_utc   = ($hr*60+$mn)*60+$sc+$ms/1000.;
$last_line_utc    = $first_line_utc+$pri*$file_length;
$center_utc       = ($first_line_utc+$last_line_utc)/2;

################################
Message "Writing the imagery resource file";
################################
$range_pixel_size = $C / $range_sampling_frequency /2;

Use_rsc "tmp_IMAGERY.raw write PLATFORM                 $sat";
Use_rsc "tmp_IMAGERY.raw write BEAM                     $swath";
Use_rsc "tmp_IMAGERY.raw write POLARIZATION             $polar";
Use_rsc "tmp_IMAGERY.raw write ORBIT_NUMBER             $orbit_num"; 
#Use_rsc "tmp_IMAGERY.raw write TRACK                    $track";
Use_rsc "tmp_IMAGERY.raw write RANGE_BIAS               $range_bias"; 
Use_rsc "tmp_IMAGERY.raw write STARTING_RANGE           $starting_range"; 
Use_rsc "tmp_IMAGERY.raw write RANGE_PIXEL_SIZE         $range_pixel_size"; 
Use_rsc "tmp_IMAGERY.raw write PRF                      $prf";
Use_rsc "tmp_IMAGERY.raw write ANTENNA_SIDE             $ANTENNA_SIDE";
Use_rsc "tmp_IMAGERY.raw write ANTENNA_LENGTH           $ANTENNA_LENGTH";
Use_rsc "tmp_IMAGERY.raw write FILE_LENGTH              $file_length";
Use_rsc "tmp_IMAGERY.raw write XMIN                     $xmin";
Use_rsc "tmp_IMAGERY.raw write XMAX                     $xmax";
Use_rsc "tmp_IMAGERY.raw write WIDTH                    $width";
Use_rsc "tmp_IMAGERY.raw write YMIN                     0";
Use_rsc "tmp_IMAGERY.raw write YMAX                     $file_length";
Use_rsc "tmp_IMAGERY.raw write RANGE_SAMPLING_FREQUENCY $range_sampling_frequency";
Use_rsc "tmp_IMAGERY.raw write PLANET_GM                $PLANET_GM";
Use_rsc "tmp_IMAGERY.raw write PLANET_SPINRATE          $PLANET_SPINRATE";

Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_UTC  $first_line_utc"; 
Use_rsc "tmp_IMAGERY.raw write CENTER_LINE_UTC $center_utc"; 
Use_rsc "tmp_IMAGERY.raw write LAST_LINE_UTC   $last_line_utc"; 

######################################################################################
Message "Reading state vectors, Building hdr_data_points_$outname file"; 
######################################################################################
$day   = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_DAY_OF_MONTH"; 
$month = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_MONTH_OF_YEAR"; 
$year  = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_YEAR";

$orbit_type=HDR;

open HDR, ">hdr_data_points_$outname.rsc" or die "Can't write to hdr_data_points_$outname.rsc\n";
if ($orbit_type eq "HDR"){  
 $countsarl=0;
  $countsarl=$countsarl+1;
  $time_data1    = ByteRead ($leader_file, 4977, 21);
  $time_interval    = ByteRead ($leader_file, 4999, 21);
  $byte=0;
  for ($i=0;$i<28;$i++){
   $time_data[$i]=$time_data1+$time_interval*$i;
   $xx[$i]=ByteRead ($leader_file, 5202+$byte, 22);
   $byte=$byte+22;
   $yy[$i]=ByteRead ($leader_file, 5202+$byte, 22);
   $byte=$byte+22;
   $zz[$i]=ByteRead ($leader_file, 5202+$byte, 22);
   $byte=$byte+22;
   $vvx[$i]=ByteRead ($leader_file, 5202+$byte, 22);
   $byte=$byte+22;
   $vvy[$i]=ByteRead ($leader_file, 5202+$byte, 22);
   $byte=$byte+22;
   $vvz[$i]=ByteRead ($leader_file, 5202+$byte, 22);
   $byte=$byte+22;
#   if ( ($numofsarl==1) || (($countsarl==1)&&($i==0)) || (($countsarl==$numofsarl)&&($i==4)) ||
#      (($numofsarl==2)&&($countsarl==1)&&($i==2)) || (($numofsarl==2)&&($countsarl==1)&&($i==4)) ||
#      (($numofsarl==2)&&($countsarl==2)&&($i==2)) || (($numofsarl==3)&&($countsarl==1)&&($i==3)) ||
#      (($numofsarl==3)&&($countsarl==2)&&($i==2)) || (($numofsarl==3)&&($countsarl==3)&&($i==1)) ||
#      (($numofsarl==4)&&($countsarl==1)&&($i==4)) || (($numofsarl==4)&&($countsarl==2)&&($i==4)) ||
#      (($numofsarl==4)&&($countsarl==3)&&($i==4)) ){
      print HDR "$time_data[$i] $xx[$i] $yy[$i] $zz[$i] $vvx[$i] $vvy[$i] $vvz[$i]\n";
#   }
 }
}
else {
 for ($i=0;$i<5;$i++){
  $time=($last_line_utc-$first_line_utc)*$i/4+$first_line_utc;
  ($q1,$q2,$q3,$q4,$q5, $x, $y, $z, $vx, $vy,$vz) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $time $sat $orbit_type $date`;
  Status "state_vector.pl";
  print HDR "$time $x $y $z $vx $vy $vz\n";
 }
}

close(HDR);

###############################
Message "Using Orbit Information"; 
###############################
($q1,$q2,$Lat,$Lon,$height_mid, $x0, $y0, $z0, $vx0, $vy0,$vz0) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $center_utc $sat $orbit_type $outname`;
Status "state_vector.pl";

$pi   = atan2(1,1)*4;
if ($orbit_type eq "HDR"){
 $ae    = 6378137;             #GRS80 reference ellipsoid
 $flat  = 1/298.257223563;
 $r     = sqrt($x0**2+$y0**2+$z0**2);
 $r1    = sqrt($x0**2+$y0**2);
 $Lat   = atan2($z0,$r1);
 $Lon   = atan2($y0,$x0);
 $H     = $r-$ae;
 for ($i=1; $i<7; $i++){
  $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
  $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
  $Lat    = atan2($TanLat,1);
  $H      = $r1/cos($Lat)-$N;
 }
 $height_mid=$H; 
}

$ae   = 6378137;                        #WGS84 reference ellipsoid
$flat = 1./298.257223563;
$N    = $ae/sqrt(1-$flat*(2-$flat)*sin($Lat)**2);
$re_mid=$N;

$ve=-sin($Lon)*$vx0+cos($Lon)*$vy0;
$vn=-sin($Lat)*cos($Lon)*$vx0-sin($Lat)*sin($Lon)*$vy0+cos($Lat)*$vz0;
$hdg = atan2($ve,$vn);
$e2 = $flat*(2-$flat);
$M = $ae*(1-$e2)/(sqrt(1-$e2*sin($Lat)**2))**3;
$earth_radius_mid = $N*$M/($N*(cos($hdg))**2+$M*(sin($hdg))**2);

($q1,$q2,$q3,$q4,$height_top, $x0, $y0, $z0, $vx, $vy,$vz) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $first_line_utc $sat $orbit_type $outname`;
Status "state_vector.pl";

if ($orbit_type eq "HDR"){
  $ae    = 6378137;             #GRS80 reference ellipsoid
  $flat  = 1/298.257223563;
  $r     = sqrt($x0**2+$y0**2+$z0**2);
  $r1    = sqrt($x0**2+$y0**2);
  $Lat   = atan2($z0,$r1);
  $Lon   = atan2($y0,$x0);
  $H     = $r-$ae;
  for ($i=1; $i<7; $i++){
    $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
    $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
    $Lat    = atan2($TanLat,1);
    $H      = $r1/cos($Lat)-$N;
  }
  $height_top=$H; 
}

$height_dt=($height_mid-$height_top)/($center_utc-$first_line_utc);
if ($vz0 > 0) {$orbit_direction =  "ascending";}
else          {$orbit_direction = "descending";}
$velocity_mid=sqrt($vx0**2 + $vy0**2 + $vz0**2);

$Latd=$Lat*180./$pi;
$Lond=$Lon*180./$pi;
$hdgd=$hdg*180./$pi;

  print STDERR "vel : $vel $velocity_mid \n";

$Latd=$Lat*180./$pi;
$Lond=$Lon*180./$pi;
$hdgd=$hdg*180./$pi;
Use_rsc "tmp_IMAGERY.raw write HEIGHT_TOP   $height_top";
Use_rsc "tmp_IMAGERY.raw write HEIGHT       $height_mid";
Use_rsc "tmp_IMAGERY.raw write HEIGHT_DT    $height_dt";
Use_rsc "tmp_IMAGERY.raw write VELOCITY     $velocity_mid";
Use_rsc "tmp_IMAGERY.raw write LATITUDE     $Latd";
Use_rsc "tmp_IMAGERY.raw write LONGITUDE    $Lond";
Use_rsc "tmp_IMAGERY.raw write HEADING      $hdgd";
Use_rsc "tmp_IMAGERY.raw write EQUATORIAL_RADIUS   $equatorial_radius";
Use_rsc "tmp_IMAGERY.raw write ECCENTRICITY_SQUARED $e2";
Use_rsc "tmp_IMAGERY.raw write EARTH_EAST_RADIUS $N";
Use_rsc "tmp_IMAGERY.raw write EARTH_NORTH_RADIUS $M";
Use_rsc "tmp_IMAGERY.raw write EARTH_RADIUS $earth_radius_mid";
#Use_rsc "tmp_IMAGERY.raw write EARTH_NORTH_RADIUS $polar_radius";
#Use_rsc "tmp_IMAGERY.raw write EARTH_RADIUS $earth_radius";
Use_rsc "tmp_IMAGERY.raw write ORBIT_DIRECTION $orbit_direction";

###############################
Message "Doppler Computation"; 
###############################

# use external routine
system "$INT_SCR/scan_doppler.pl tmp_IMAGERY $file_length";

#$nambiguity=0;
#$dop_rng0=$fd1/$prf;
#if ($vz0 > 0) {$dop_rng0=-abs($dop_rng0)}

#Use_rsc "tmp_IMAGERY.raw write DOPPLER_AMBGTY  $nambiguity";
#Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE0  $dop_rng0";
#Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE1  0.";
#Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE2  0.";
#Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE3  0.";

#$r2d             = 180/$pi;
#$sin_theta       = sqrt( 1 - ($height / $starting_range)**2 );
#$fd              = $dop_rng0 * $prf;
#$sin_squint = $fd / ( 2 * $velocity_mid * $sin_theta ) * $wavelength;
#$squint_rad = atan2( $sin_squint, sqrt( 1 - $sin_squint ** 2 ) );
#$squint_deg = $squint_rad * $r2d;
#Use_rsc "tmp_IMAGERY.raw write SQUINT          $squint_deg";

# move to final file name
#`mv tmp_IMAGERY.raw_parse_line.out  ${outname}_parse_line.out`;
`mv tmp_IMAGERY.raw.rsc             ${outname}.raw.rsc`;
`mv tmp_IMAGERY.raw                 ${outname}.raw`;
`rm -f *tmp* IMA*`;

#########################
Message "Raw data ready for processing";
#########################
}
exit 0;

# Perl trim function to remove whitespace from the start and end of the string
sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}

=pod

=head1 USAGE

B<make_raw_alos.pl> I< alos_file_prefix_root [outname] >

=head1 FUNCTION

Creates I<date>.raw and I<date>.raw.rsc from imagery files

=head1 ROUTINES CALLED

ALOS_pre_process

state_vector.pl

=head1 CALLED BY

none

=head1 FILES USED

IMG*

LED*

=head1 FILES CREATED

I<date>.raw

I<date>.raw.rsc

I<date>_parse_line.out

shift.out

shift.out.rsc

=head1 HISTORY

Perl  Script : Yuri Fialko 07/11/2007
updated 2007/08/07 Yuri Fialko

=head1 LAST UPDATE

2007/9/5 Eric Fielding

=cut
