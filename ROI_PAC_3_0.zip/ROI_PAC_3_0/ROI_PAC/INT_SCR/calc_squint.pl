#! /usr/bin/perl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;
use CalcVec;

if(@ARGV<1){ die "usage: calc_squint <fd> <rawfile>\n";}

# CONSTANTS
$C=299792458.;
$pi=4*atan2(1.0,1.0);

# READ ARGMENTS
$fd=shift;
$rawfile=shift;

# Open log file

open OUT, ">calc_squint.out";

print OUT "Doppler frequency at the center: $fd (PRF)";
$prf=Use_rsc "$rawfile read PRF";
$fd=$fd*$prf;
print OUT "\t$fd (Hz)\n";


$velocity_mid=Use_rsc "$rawfile read VELOCITY";
$wavelength=Use_rsc "$rawfile read WAVELENGTH";
print OUT "Satellite velocity at the center: $velocity_mid (m/s)\n";
print OUT "Radar wavelength: $wavelength (m)\n";
print OUT "PRF: $prf (Hz)\n";

$Re=Use_rsc "$rawfile read EARTH_RADIUS";
$h=Use_rsc "$rawfile read HEIGHT";
print OUT "Earth radius under satellite (Re): $Re (m)\n";
print OUT "Satellite height (h): $h (m)\n";
$Rs= $h + $Re;
print OUT "Satellite radius (Rs=Re+h): $Rs (m)\n";

# calculate center slant range
$R0=Use_rsc "$rawfile read STARTING_RANGE";
print OUT "Starting range (R0): $R0 (m)\n";
$width=Use_rsc "$rawfile read WIDTH";
$xmin=Use_rsc "$rawfile read XMIN";
$rg_pix_sz=Use_rsc "$rawfile read RANGE_PIXEL_SIZE";
$Rc=$R0+(($width-$xmin)/2)/2*$rg_pix_sz;
print OUT "Slant range to the center of the scene (Rc): $Rc (m)\n";

#######
#$velocity_mid *= sqrt($Re/$Rs);
#######

# calculate look angle gamma
$cos_gamma=($Rs*$Rs+$Rc*$Rc-$Re*$Re)/2./$Rc/$Rs;
$sin_gamma=sqrt(1-$cos_gamma*$cos_gamma);
print OUT "Look angle: ",atan2($sin_gamma,$cos_gamma)/$pi*180," (deg.)\n";

# complementary angle of the squint angle
$cos_cmpsq=($wavelength*$fd/2.0)/$velocity_mid/$sin_gamma;
$sin_cmpsq=sqrt(1-$cos_cmpsq*$cos_cmpsq);
$cmpsq=atan2($sin_cmpsq,$cos_cmpsq);
print OUT "pi/2-squint $cmpsq (rad)\n\n";

# squint angle
$squint=$pi/2.0-$cmpsq;
print OUT "Squint angle  $squint (rad)\n";
print OUT "Squint angle  ",$squint/2/$pi*360,"  (deg)\n";

# output standard output
print "SQUINT(deg) ",$squint/$pi*180,"\n";

