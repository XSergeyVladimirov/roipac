#!/usr/bin/perl 
### ratio.pl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{
  `$INT_SCR/pod2man.pl  $INT_SCR/ratio.pl`;
  exit 1;
}

@ARGV >= 7  or Usage();
@args = @ARGV;

$prefix1 = shift;
$prefix2 = shift;
$basefile1 = shift;
$basetype1 = shift;
$basefile2 = shift;
$basetype2 = shift;
$outprefix = shift;
$scaleprefix = shift;

$fudge = 1.0;

###  By copying prefix1.int.rsc to ratio.int.rsc we are assuming
###  morphing has been done into the prefix1 coordinate system.  This
###  may have to change in the future!

$sat_dir = -1;  #because of different sign convention, fake left looking.

#######################################
Message "reading resource_file: $prefix1.int.rsc";
#######################################

$width              = Use_rsc "$prefix1.int read WIDTH";
$length             = Use_rsc "$prefix1.int read FILE_LENGTH";
$start              = Use_rsc "$prefix1.int read FILE_START";
$height_top         = Use_rsc "$prefix1.int read HEIGHT";
$earth_radius       = Use_rsc "$prefix1.int read EARTH_RADIUS";
$starting_range     = Use_rsc "$prefix1.int read STARTING_RANGE"; 
$wavelength         = Use_rsc "$prefix1.int read WAVELENGTH";
$range_pixel_size   = Use_rsc "$prefix1.int read RANGE_PIXEL_SIZE";
$azimuth_pixel_size = Use_rsc "$prefix1.int read AZIMUTH_PIXEL_SIZE";
$orbit_number       = Use_rsc "$prefix1.int read ORBIT_NUMBER";

($h_baseline_top, $h_baseline_rate, $v_baseline_top, $v_baseline_rate) =
    split /\n/, `select_baseline.pl $basefile1 $basetype1`;

$height=$height_top;

#######################################
Message "reading resource_file: $prefix2.unw.rsc";
#######################################

$orbit_number_2    = Use_rsc "$prefix2.unw read ORBIT_NUMBER";
($h_baseline_top_2, $h_baseline_rate_2, $v_baseline_top_2, $v_baseline_rate_2) =
    split /\n/, `select_baseline.pl $basefile2 $basetype2`;

##########################################
Message "writing resource_file: ratio.int.rsc";
##########################################

`cp $prefix1.int.rsc $outprefix.int.rsc`;

Use_rsc "$outprefix.int write ORBIT_NUMBER               $orbit_number         $orbit_number_2";
Use_rsc "$outprefix.int write H_BASELINE_TOP             $h_baseline_top       $h_baseline_top_2";
Use_rsc "$outprefix.int write H_BASELINE_RATE            $h_baseline_rate      $h_baseline_rate_2";
Use_rsc "$outprefix.int write V_BASELINE_TOP             $v_baseline_top       $v_baseline_top_2";
Use_rsc "$outprefix.int write V_BASELINE_RATE            $v_baseline_rate      $v_baseline_rate_2";

$RangeOffset   = 0;
$AzimuthOffset = 0;

`cp $outprefix.int.rsc $scaleprefix.unw.rsc`;

###############################################
Message "writing ratio_i_u input_file: ratio_i_u.in";
###############################################

open (OUT, "> ratio_i_u.in") or die "Can't write to ratio_i_u.in\n";
print OUT <<END;
$prefix1.int    
$h_baseline_top      $h_baseline_rate 
$v_baseline_top      $v_baseline_rate 
$prefix2.unw
$h_baseline_top_2    $h_baseline_rate_2
$v_baseline_top_2    $v_baseline_rate_2
$outprefix.int
$scaleprefix.unw
$width               $length
$height              $earth_radius         $starting_range 
$wavelength          $range_pixel_size     $azimuth_pixel_size 
$sat_dir
$fudge
END

close(OUT);

###############################################
Message "ratio_i_u   ratio_i_u.in > ratio.out";
###############################################

`$INT_BIN/ratio_i_u  ratio_i_u.in > ratio.out`;
Status "ratio_i_u";

exit 0;

=pod

=head1 USAGE

B<ratio.pl> I<date>
Usage: ratio.pl prefix prefix2

Will look locally for:  prefix1.int(.rsc)
                        prefix2.unw(.rsc)

=head1 FUNCTION

Morphs an unwrapped file to a different coordinate system.

=head1 ROUTINES CALLED

=head1 CALLED BY

=head1 FILES USED

=head1 FILES CREATED

=head1 HISTORY

Perl  Script : Mark Simons, September 15, 1998

=head1 LAST UPDATE

Mark Simons, September 15, 1998

=cut


