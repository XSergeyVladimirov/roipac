#!/usr/bin/perl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

### rect_cut.pl

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/rect_cut.pl`;
exit 1;
}


@ARGV >= 3 or Usage();
@args = @ARGV;

$infile  = shift;
$outfile = shift;
$im12 = shift;


       open IN, "${im12}_SIM.aff" or die "Can't read $infile\n";
	$line    = <IN>;
	($m11, $m12, $m21, $m22, $t1, $t2) = split /\s+/, $line;



#################
Message "Checking I/O";
#################
@Infiles  = ($infile, "$infile.rsc");
@Outfiles = ($outfile);
&IOcheck(\@Infiles, \@Outfiles);
Log("rect_cut.pl", @args);

#####################################
Message "Registering to the simulation";
#####################################
$width  = Use_rsc "$infile read WIDTH";
$length = Use_rsc "$infile read FILE_LENGTH";

open RECTB, ">rectB.in" or die "Can't write to rectB.in\n";

print RECTB <<END;
Input Image File Name  (-) = $infile        ! dimension of file to be rectified
Output Image File Name (-) = $outfile       ! dimension of output
Input Dimensions       (-) = $width $length ! across, down
Output Dimensions      (-) = $width $length ! across, down
Affine Matrix Row 1    (-) = $m11 $m12      ! a b
Affine Matrix Row 2    (-) = $m21 $m22      ! c d
Affine Offset Vector   (-) = $t1 $t2        ! e f
File Type              (-) = BYTE           ! [BYTE]
Interpolation Method   (-) = NN             ! [NN, Bilinear, Sinc]
END

close(RECTB);


############################
`cp $infile.rsc $outfile.rsc`;

Message "$INT_BIN/rect rectB.in";
`$INT_BIN/rect rectB.in`;
Status "rect";

exit 0;

=pod

=head1 USAGE

B<rect_cut.pl> I<infile outfile >

Method NN(nearest neighbor)|Bilinear|Sinc

Recognizes infiles with a suffix of in

=head1 FUNCTION

morphs an BYTE file given a set of affine transformation parameters

=head1 ROUTINES CALLED

rectB

=head1 CALLED BY

process_2passRS.pl

process.pl

=head1 FILES USED

I<infile>

I<infile>.rsc

=head1 FILES CREATED

I<outfile>

I<outfile>.rsc

rectB.in

