#!/usr/bin/perl
### phase2base.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/phase2base.pl`;
exit 1;
}
@ARGV >=  11 or Usage();
@args = @ARGV;

$offset           = shift;
$phase            = shift;
$correlation      = shift;
$cor_thresh       = shift;
$height           = shift;
$rlooks           = shift;  #from full_res to unw
$alooks           = shift;  #from full_res to unw
$baseline_file    = shift;
$BaselineType1    = shift;
$BaselineType2    = shift;
$BaselineOrder    = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ($offset, $phase, $correlation, $height);
@Outfiles = ("phase2base.out");  # added per Matt P. 2007/8/21
&IOcheck(\@Infiles,\@Outfiles);
Log("phase2base.pl", @args);

#######################################
Message "Reading resource file: $offset.rsc";
#######################################
$range_pixel_size   = Use_rsc "$offset read RANGE_PIXEL_SIZE";
$azimuth_pixel_size = Use_rsc "$offset read AZIMUTH_PIXEL_SIZE";

#######################################
Message "Reading resource file: $height.rsc";
#######################################

$simwidth           = Use_rsc "$height read WIDTH";

#######################################
Message "Reading resource file: $phase.rsc";
#######################################

$width           = Use_rsc "$phase read WIDTH";
$length          = Use_rsc "$phase read FILE_LENGTH";
$wavelength      = Use_rsc "$phase read WAVELENGTH";
$earth_radius    = Use_rsc "$phase read EARTH_RADIUS";
$height_top      = Use_rsc "$phase read HEIGHT";
$height_rate     = Use_rsc "$phase read HEIGHT_DS";
$height_acc      = Use_rsc "$phase read HEIGHT_DDS";
$slc_offset      = Use_rsc "$phase read SLC_RELATIVE_YMIN";
$starting_range1 = Use_rsc "$phase read STARTING_RANGE1";
$starting_range2 = Use_rsc "$phase read STARTING_RANGE2";
$squint          = Use_rsc "$phase read SQUINT";
$first_line_utc  = Use_rsc "$phase read FIRST_LINE_UTC";
$center_line_utc = Use_rsc "$phase read CENTER_LINE_UTC";
$velocity        = Use_rsc "$phase read VELOCITY";
$antenna_side    = Use_rsc "$phase read ANTENNA_SIDE";
$prf             = Use_rsc "$phase read PRF";
$dop0            = Use_rsc "$phase read DOPPLER_RANGE0";
$dop1            = Use_rsc "$phase read DOPPLER_RANGE1";
$dop2            = Use_rsc "$phase read DOPPLER_RANGE2";
$dop3            = Use_rsc "$phase read DOPPLER_RANGE3";


($h_baseline_top, $h_baseline_rate, $h_baseline_acc, $v_baseline_top, $v_baseline_rate, $v_baseline_acc) =
    split /\n/, `select_baseline.pl $baseline_file $BaselineType1`;
$range_offset = Use_rsc "$baseline_file read RANGE_OFFSET_$BaselineType1";

# check length of height file also EJF 2005/10/10
$length_height = Use_rsc "$height read FILE_LENGTH";

# use shorter length to avoid overrun
if ($length_height < $length){ $length = $length_height } ;

##############################################
Message "Writing baseest input_file: phase2base.in with $BaselineOrder fit";
##############################################
$num1 = int ($length/10);

# added to avoid too many points with high correlation 1rlks images
# EJF 2004/2/21
# changed again per Matt Pritchard 2007/8/20
if($length > 5000)
  {
    $num1 = int($length/(35000/$simwidth));
  }

$LeftorRight = "Right" ;
if($antenna_side == 1) 
  {
    $LeftorRight = "Left" ;
  }

if($BaselineOrder eq "QUAD"){ $fit_acc = "yes";}
else {
$fit_acc = "no";
# added to set acceleration to zero when using LIN baseline fit EJF 2007/8/20
$h_baseline_acc = 0.;
$V_baseline_acc = 0.;
}

open PHASE, ">phase2base.in" or die "Can't write to phase2base.in\n";
print PHASE <<END;
           BASELINE ESTIMATION RDF INPUT FILE

INPUT FILES

Interferogram File Name                      (-)         =        $phase
Simulated Height File Name                   (-)         =        $height
SLC Offset File Name                         (-)         =        qOffsetFile
Correlation File Name                        (-)         =        $correlation
Tie Point File Name                          (-)         =        qTie_points_file

FILE DIMENSIONS

Number Complex Samples in Interferogram      (-)         =        $width 
Number Complex Samples in Simulation         (-)         =        $simwidth
Start, End and Skip Lines in Interferogram   (-)         =        100  $length   $num1
Line Offset Between Reference SLC Start and Interferogram Start (-) = $slc_offset
Range Direction - Across or Down             (-)         =        Across                     ![Across , Down]

RADAR PARAMETERS

Earth Radius                                 (m)          =       $earth_radius 
Terrain Height and Range/Azimuth Slopes    (m,-,-)        =       0 0 0
Platform Altitude, Rate, & Acceleration    (m,-,-)        =       $height_top $height_rate $height_acc
Radar Wavelength                             (m)          =       $wavelength
Left or Right Looking                        (-)          =       $LeftorRight                       ![Left , Right]
Starting Ranges for the SLCs                 (m,m)        =       $starting_range1 $starting_range2
Azimuth Offset Between Images                (m)          =       0.
Range per Pixel Single Look                  (m)          =       $range_pixel_size  
Azimuth Pixel Size in Orbit Single Look      (m)          =       $azimuth_pixel_size
Specify Squint or Doppler Polynomial         (-)          =       Doppler Polynomial
Doppler Cubic Polynomial               (-,-,-,-)          =       $dop0 $dop1 $dop2 $dop3  ! fit versus range bin
Platform Velocity                          (m/s)          =       $velocity    !
Radar PRF                                   (Hz)          =       $prf         ! Hz
Range and Azimuth Looks in Interferogram     (-)          =       $rlooks $alooks
Range and Azimuth Looks in Offset Estimates  (-)          =       1 1	
Range and Azimuth Looks in Simulation        (-)          =       $rlooks $alooks
 
ESTIMATION PARAMETERS

Correlation Threshold for use in Estimation   (-)         =        $cor_thresh
Estimate Cross Track Baseline Component	      (-)         =        yes       ![yes , no]
Estimate Cross Track Baseline Rate	      (-)         =        yes       ![yes , no]
Estimate Cross Track Baseline Acceleration    (-)         =        $fit_acc       ![yes , no]
Estimate Vertical Baseline Component	      (-)         =        yes        ![yes , no]
Estimate Vertical Baseline Rate		      (-)         =        yes       ![yes , no]
Estimate Vertical Baseline Acceleration       (-)         =        $fit_acc       ![yes , no]
Estimate Range Offset                         (-)         =        yes       ![yes , no]
Estimate Azimuth Offset			      (-)         =        yes       ![yes , no]
Estimate Azimuth Scale Factor		      (-)         =        no        ![yes , no]

INITIAL ESTIMATES			      

Initial Estimate Cross Track Baseline Component  (m)         =    $h_baseline_top    !horizontal???
Initial Estimate Cross Track Baseline Rate	 (-)         =    $h_baseline_rate
Initial Estimate Cross Track Baseline Acceleration (-)       =    $h_baseline_acc
Initial Estimate Vertical Baseline Component	 (m)         =    $v_baseline_top   
Initial Estimate Vertical Baseline Rate		 (-)         =    $v_baseline_rate
Initial Estimate Vertical Baseline Acceleration	 (-)         =    $v_baseline_acc
Initial Estimate Range Offset			 (m)         =    0.
Initial Estimate Azimuth Offset			 (m)         =    0.
Initial Estimate Azimuth Scale Factor		 (-)         =    1.0       !better be nonzero

DATA USE PARAMETERS
         
Use Range Data in Baseline Estimate           (-)         =       yes      ![yes , no]
Use Azimuth Data in Baseline Estimate	      (-)         =       no       ![yes , no]
END
    close(PHASE);


`$INT_BIN/baseest phase2base.in phase2base.out > /dev/null `;
Status "baseest";

open PHASE, "phase2base.out" or die "Can't read phase2base.out\n";
@array = ("htop","vtop","delta","hrate","vrate","hacc","vacc");
foreach (@array){
  $line = <PHASE>;
#convert D to e in scientific notation
  $line =~ s/D-/e-/;
  @$_ = split /\s+/, $line;
}

$hb          = $htop[5];
$vb          = $vtop[5];
$phase_const = $delta[6];
$hbr         = $hrate[6];
$vbr         = $vrate[6];
$hba         = $hacc[6];
$vba         = $vacc[6];
close(PHASE);

$test_phase_cst=($phase_const*100);
if ($test_phase_cst == 0 ){$phase_const=-99999;}

##############################################
Message "write_baseline.pl $baseline_file $BaselineType2 $hb $hbr $hba $vb $vbr $vba";
##############################################
`write_baseline.pl $baseline_file $BaselineType2 $hb $hbr $hba $vb $vbr $vba`;


Use_rsc "$baseline_file write PHASE_CONST_$BaselineType2 $phase_const";
Doc_rsc(
 RSC_Tip => 'delta phase',
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from line 3 field 6 of phase2base.out
    which is labeled 
    'Delta range/phase (m/rad)'
    output by baseest
    becomes $phase_const in phase2base.pl
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaselineType2}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:radian',
);


Use_rsc "$baseline_file write RANGE_OFFSET_$BaselineType2 $range_offset";
Doc_rsc(
 RSC_Tip => 'difference in starting range values',
 RSC_Derivation => q[
    See phase2base.pl
    Value comes from
      $range_offset = Use_rsc "$baseline_file read RANGE_OFFSET_$BaselineType1";
   ],
 RSC_Comment => q[
    NOTE: Keyword name is created dynamically.
    Portion after last underscore ('_') is ${BaselineType2}.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);



`rm cecpxcc.rdf`;

exit 0;

=pod

=head1 USAGE

B<phase2base.pl> I<offset phase correlation cor_thresh height rlooks alooks baselineFile BaselineTypeInitial BaselineTypeOutput> [BaselineOrder]

optional BaselineOrder can be LIN or QUAD for linear or quadratic baseline fit default is LIN

=head1 FUNCTION

Estimate baseline

=head1 ROUTINES CALLED

baseest

=head1 CALLED BY

process.pl

=head1 FILES USED

I<offset>

I<phase>

I<correlation>

I<height>

=head1 FILES CREATED

I<baseline.rsc>

I<phase2base.in>

I<phase2base.out>

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

Frederic Crampe, Aug 23, 1999

changed to quadratic baseline fit Rosen&Pritchard? 2002-2003

modified to make quadratic baseline fit optional, default linear fit EJF 2004/01/17

minor mod. to check length of height file EJF 2005/10/10

=head1 LAST UPDATE

Eric Fielding Jan. 17, 2004

=cut
