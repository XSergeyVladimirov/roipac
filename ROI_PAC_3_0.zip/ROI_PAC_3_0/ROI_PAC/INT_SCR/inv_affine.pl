#!/usr/bin/perl
### inv_affine.pl 

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/inv_affine.pl`;
exit 1;
}
@ARGV    == 2 or Usage();

$infile  = shift;
$outfile = shift;

open IN, "$infile" or die "Can't read $infile\n";
$line    = <IN>;

($m11, $m12, $m21, $m22, $t1, $t2) = split /\s+/, $line;

### Manipulation of values
$d   = ($m11*$m22) - ($m12*$m21);
$a11 = $m22/$d;
$a12 = -1 * $m12/$d;
$a21 = -1 * $m21/$d;
$a22 = $m11/$d;
$b1  = (($m12*$t2)-($m22*$t1))/$d;
$b2  = (($m21*$t1)-($m11*$t2))/$d;

open  OUT, ">$outfile" or die "Can't write to $outfile\n";
print OUT "$a11 $a12 $a21 $a22 $b1 $b2";
close(OUT);

exit 0;
=pod

=head1 USAGE

B<inv_affine> I<infile outfile>

infile format: m11 m12 m21 m22 t1 t2

=head1 FUNCTION

Manipulates matrix and translation values in infile

=head1 ROUTINES CALLED

none

=head1 CALLED BY

process.pl

=head1 FILES USED

I<infile>

=head1 FILES CREATED

I<outfile>

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
