#!/bin/perl -w

#Renames the files comming from thw winsar web site.
#Expects to find 1 datafile, 1 sarleader, and 1 vdf
 
@DataFileList  = glob("DAT*");
@SarleaderList = glob("LEA*");
@VdfFileList   = glob("VDF*");

if( $#DataFileList != 0 || $#SarleaderList != 0 || $#VdfFileList != 0 ){
	die "Expects to find 1 datafile, 1 sarleader, and 1 vdf";
}

$DataFile  = $DataFileList[0];
$Sarleader = $SarleaderList[0];
$VdfFile   = $VdfFileList[0];

$VdfStr = `$ENV{'INT_SCR'}/read_VDF.pl $VdfFile`;

%VdfOut   = split( /[\s-]/, $VdfStr );
@NameList = keys %VdfOut;

foreach $Name ( @NameList ){
	if( $Name =~ /IMAGERY/ ){
		rename $DataFile, $Name;
	}elsif( $Name =~ /SARLEADER/ ){
		rename $Sarleader, $Name;
	}
}




