#!/usr/bin/perl
### make_raw.pl

# $Id: make_raw.pl,v 1.3 2007/10/03 20:42:27 ericf Exp $
#
# $Log: make_raw.pl,v $
# Revision 1.3  2007/10/03 20:42:27  ericf
# added calculation of lat and long in radians from center_utc state vector when not HDR orbits
# per Matt P.
#
# Revision 1.2  2007/08/20 23:43:37  ericf
# added AKCEOS format per Matt P. from Evelyn Price
#
# Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1.1.1  2007/04/03 03:40:05  ericmg
# initial import into erda insarcvs
#
# Revision 1.3  2005/12/16 18:45:39  bswift
# RSC keyword documentation changes.
#


use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/make_raw.pl`;
exit 1;
}
@ARGV >= 3  or Usage();
@args = @ARGV;

$orbit_type        = shift;
$leader_file       = shift;
$date              = shift;
$facility          = shift;
$reference_counter = shift;

@imagery=split /\s+/, `ls IMAGERY*`;

#################
Message "Checking I/O";
#################
@Infiles  = ($leader_file, @imagery);
@Outfiles = ("$date.raw",  "$date.raw.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log ("make_raw.pl", @args);

###########################
Message "General definitions";
###########################

$C                        = 299792458;
# new value
 $ONE_WAY_DELAY            = 3.4449923715353358e-06;
# old value
#$ONE_WAY_DELAY            = -2.0168e-06;
$RANGE_SAMPLING_FREQUENCY = 18.950420e6;
$ANTENNA_SIDE             = -1;
$ANTENNA_LENGTH           = 12;
$SEC_PER_PRI_COUNT        = 210.94e-09;

###############
# FR 20020903
$ANTENNA_LENGTH           = 10;

###############
#Soren's paper
$RANGE_SAMPLING_FREQUENCY = 18.962468e6;
$SEC_PER_PRI_COUNT        = 210.943006e-9;
$ONE_WAY_DELAY            = 6.622e-6 / 2;
#chirp_length 37.12e-6
#chirp bandwidth 15.50829e6;

$PLANET_GM       = 3.98600448073E+14;
$PLANET_SPINRATE = 7.29211573052E-05;

$RPVersion = 3.0;  #ROI_PAC version

#############################
Message "Getting facility name";
#############################
$g_facility = ByteRead ($leader_file, 1766, 15);
$facility or $facility = $g_facility;

$version    = ByteRead ($leader_file, 1782, 8);
$sat_num    = ByteRead ($leader_file, 1119, 2);
$orbit_num  = ByteRead ($leader_file, 1164, 8); 

$sat = sqrt($sat_num**2);
$sat = "ERS$sat";
$facility =~ s/\s//g;

if    ($facility eq "CRDC_SARDPF"
            or $facility eq "GTS")              { $facility = "CRDC-SARDPF";}
elsif ($facility eq "UK-PAF")                   { $facility = "UK-PAF";}
elsif ($facility eq "D-PAF"){
  if ($version =~ /VMP/)                        { $facility = "D-PAF";}
  elsif ($version =~ /MSAR/)                    { $facility = "NEW-D-PAF";}
}
elsif ($facility eq "AKCEOS")                   {$facility = "AKCEOS";}
elsif ($facility eq "ASF")                   {$facility = "AKCEOS";}
elsif ($facility =~ /^(NEW-D-PAF|ESRIN|ES|IP|IPAF|I-PAF)$/){ $facility = "D-PAF";}
else {die "Unknown facility: $facility\n";}

if ($facility eq "CRDC-SARDPF"){
  $width = 12060;
  $xmin = 412;
  $xmax = 11636;
  $LineCounterFirstByte=200;
  $SWSToffset=204;
  $PRIoffset=206;
}
elsif ($facility eq "D-PAF"){
  $width=11644;
  $xmin=412;
  $xmax=11636;
  $LineCounterFirstByte=210;
  $SWSToffset=214;
  $PRIoffset=216;
}
elsif ($facility eq "NEW-D-PAF"){
  $width=11644;
  $xmin=412;
  $xmax=11636;
  $LineCounterFirstByte=206;
  $SWSToffset=210;
  $PRIoffset=212;
}

elsif ($facility eq "UK-PAF"){ 
  $width=11644;
  $xmin=412;
  $xmax=11636;
  $LineCounterFirstByte=210;
  $SWSToffset=214;
  $PRIoffset=216;
} 
elsif ($facility eq "AKCEOS"){
  $width=11644;
  $xmin=412;
  $xmax=11636;
  $LineCounterFirstByte=210;
  $SWSToffset=214;
  $PRIoffset=216;
}



##################################
  Message "Finding reference counter, pri and prf";
##################################
$num_bytes    = 2;     #both SWST and PRI are 2-byte integers.

$imagery_file = $imagery[0]; 

$pri_count    = ByteRead ($imagery_file, $width+$PRIoffset,  $num_bytes);
$swst_counter = ByteRead ($imagery_file, $width+$SWSToffset, $num_bytes);

$swst_counter = unpack("n",$swst_counter);
$pri_count    = unpack("n",$pri_count);

print STDERR "counter read: $swst_counter\n";
print STDERR "swst offset read: $SWSToffset\n";

$pri = ($pri_count + 2.0) * $SEC_PER_PRI_COUNT;
$prf = 1/$pri;

unless ($reference_counter){
  $reference_counter = $swst_counter;
}
Message "Reference counter = $reference_counter";

############################
Message "Checking line number";
############################
$LineCounterLength = 4;
$RemoveInputFiles  = 1;

$parse_args="$width $LineCounterFirstByte $LineCounterLength $RemoveInputFiles";
$call_parse="$INT_BIN/new_parse $parse_args @imagery tmp_IMAGERY.raw" ;

Message "$call_parse";
`$call_parse`;

###############################
Message "Reading the leader file";
###############################
$call_leader="$INT_BIN/leader2rsc $leader_file $INT_SCR/format_leaderfile_$facility tmp_IMAGERY.raw.rsc"; 

Message "$call_leader";
`$call_leader`;

###Create temporary file length
$size         = -s "tmp_IMAGERY.raw" or die "tmp_IMAGERY.raw has zero size\n";
$file_length1 = $size/$width;

################################
Message "Reading the imagery file";
################################

$pad_top    = 0;
$pad_bottom = 0;
#if($facility eq "AKCEOS"){
#  $icu_time_start = read_icu($imagery_file,$width,$first_line,204);
#  $icu_time_center = read_icu($imagery_file,$width,$center_line,204);
#  $icu_time_end     = read_icu($imagery_file,$width,$file_length1-1,204);
#}

if ($facility eq "CRDC-SARDPF"){

  $timems = ByteRead ("tmp_IMAGERY.raw" , 44 , 4);
  $first_line_ms_of_day = unpack("N",$timems);

  $first_line_ms_of_day = $first_line_ms_of_day -      $pad_top/$prf*1000.;
  $last_line_ms_of_day  = $first_line_ms_of_day + $file_length1/$prf*1000.;

  $first_line_utc = $first_line_ms_of_day /1000.;
  $last_line_utc  = $last_line_ms_of_day  /1000.;
  $center_utc     = ($first_line_utc+$last_line_utc)/2;
}

else{
  $c_line = Use_rsc "tmp_IMAGERY.raw read FIRST_FRAME_SCENE_CENTER_LINE";
  $c_hr   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_HOUR_OF_DAY"; 
  $c_mn   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_MN_OF_HOUR"; 
  $c_s    = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_S_OF_MN"; 
  $c_ms   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_MS_OF_S"; 
  $c_line           = $c_line+$pad_top;
  $first_center_utc = ($c_hr*60+$c_mn)*60+$c_s+$c_ms/1000.;
  $first_line_utc   = $first_center_utc-$pri*$c_line;        
  $last_line_utc    = $first_line_utc+$pri*$file_length1;
  $center_utc       = ($first_line_utc+$last_line_utc)/2;
}


##################################
Message "Setting the starting range";
##################################

$call_shift="$INT_BIN/delay_shift tmp_IMAGERY.raw tmp_IMAGERY.new shift.out $SWSToffset $reference_counter $width $xmin $xmax $pad_top $pad_bottom";

Message   "$call_shift";
$status = `$call_shift`;
if ($status =~ /No good range counter found/){
  die "No good range counter found using reference counter = $reference_counter\n";
}


`mv tmp_IMAGERY.new tmp_IMAGERY.raw`;
`cp shift.out shift.out.rsc`;
### Changed shift.out to shift.out.rsc so that Use_rsc can read it

$swst_counter = Use_rsc "shift.out read SWST_COUNTER";
Doc_rsc(
 RSC_Tip => 'Sampling Window Start Time Counter Minimum',
 RSC_Doc => q[
   The Sampling Window Start Time is a two byte field in
   the Signal Data Record line header.
   The keyword value is the minimum value of this field detected
   by the delay_shift application.

   According to Soren's paper, a counter value is 4 samples.
   In the header, counter changes in steps of +/-22 (+/-88 samples).
   ],
 RSC_Derivation => q[
   Keyword and value written to shift.out.rsc by delay_shift in make_raw.pl
   swst_counter_min in fip/delay_shift.c
   ],
 RSC_Comment => q[
   ],
 RSC_Type => Int,
 RSC_Unit => '4 * samples / count',
);


$width        = Use_rsc "shift.out read WIDTH";
$xmax         = $width;
###Find true length using new width
$size         = -s "tmp_IMAGERY.raw" or die "tmp_IMAGERY.raw has zero size\n";
$file_length  = $size/$width;

################################
Message "Writing the imagery resource file";
################################
$swst             = 9*$pri+$swst_counter*$SEC_PER_PRI_COUNT;
$starting_range   = ($swst/2-($ONE_WAY_DELAY))*$C;
$range_pixel_size = $C / $RANGE_SAMPLING_FREQUENCY /2;



Use_rsc "tmp_IMAGERY.raw write PLATFORM                 $sat";
Doc_rsc(
 RSC_Derivation => q[
   Literal string ERS with absolute value of $sat_num appended.
   $sat_num    = ByteRead ($leader_file, 1119, 2);
   $sat = sqrt($sat_num**2);
   $sat = "ERS$sat";
   ],
 RSC_Comment => q[
   In the TEST_DIR $leader_file(s) the two characters extracted
   by ByteRead() are the last two characters of the string 'ERS-1'.
   So, $sat_num starts out as '-1' which is why absolute value
   is taken.  Do not know why entire field is not extracted, nor
   why fields is not extracted with leader2rsc.
   ],
 RSC_Type => String,
);


Use_rsc "tmp_IMAGERY.raw write ORBIT_NUMBER             $orbit_num"; 
Doc_rsc(
 RSC_Derivation => q[
   Eight byte string extracted from $leader_file via
   $orbit_num  = ByteRead ($leader_file, 1164, 8); 
   ],
 RSC_Comment => q[
   In TEST_DIR $leader_file(s) these bytes are all spaces.
   So, ByteRead() returns '0'.
   ],
 RSC_Type => Int,
);


Use_rsc "tmp_IMAGERY.raw write ONE_WAY_DELAY            $ONE_WAY_DELAY"; 
Doc_rsc(
 RSC_Derivation => q[
   Initialized to constant value in make_raw.pl
   #Soren's paper
   $ONE_WAY_DELAY            = 6.622e-6 / 2;
   ],
 RSC_Comment => q[
   Keyword does not appear to be read by any scripts.
   Is only used in calculation of $starting_range in make_raw.pl.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:second',
);


Use_rsc "tmp_IMAGERY.raw write STARTING_RANGE           $starting_range"; 
Doc_rsc(
 RSC_Doc => q[
   Range of first sample in data file.
   Based on RDF keyword usage in roi_prep.pl and autofocus.pl
   ],
 RSC_Derivation => q[
   Constants initialized in make_raw.pl
     $C                        = 299792458;      # speed of light.
     $SEC_PER_PRI_COUNT        = 210.943006e-9;  #Soren's paper
     $width is a per $facility constant. (eg. 12060)
     $PRIoffset is a per $facility constant. (eg. 206)
     $num_bytes    = 2;

   $pri_count    = ByteRead ($imagery_file, $width+$PRIoffset,  $num_bytes);
   $pri_count    = unpack("n",$pri_count);

   # Above produces a 16-bit integer from two big-endian ordered bytes

   $pri = ($pri_count + 2.0) * $SEC_PER_PRI_COUNT;
   $swst_counter = Use_rsc "shift.out read SWST_COUNTER";
   #  (eg. 878)
   # above swst_counter is "sampling window start time" based on comment in fip/delay_shift.c

   $swst             = 9*$pri+$swst_counter*$SEC_PER_PRI_COUNT;

   $starting_range   = ($swst/2-($ONE_WAY_DELAY))*$C;
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "tmp_IMAGERY.raw write RANGE_PIXEL_SIZE         $range_pixel_size"; 
Doc_rsc(
 RSC_Derivation => q[
   Constants initialized in make_raw.pl
     $C                        = 299792458;      # speed of light.
     $RANGE_SAMPLING_FREQUENCY = 18.962468e6;    #Soren's paper

   $range_pixel_size = $C / $RANGE_SAMPLING_FREQUENCY /2;
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "tmp_IMAGERY.raw write PRF                      $prf";
Doc_rsc(
 RSC_Tip => 'Pulse Repetition Frequency',
 RSC_Derivation => q[
   See STARTING_RANGE for Derivation of $pri.
   $prf = 1/$pri;
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:hertz',
);


Use_rsc "tmp_IMAGERY.raw write ANTENNA_SIDE             $ANTENNA_SIDE";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   Indication of Left or Right pointing.
     -1 implies Right
      1 implies Left
   Based on usage in roi_prep.pl and autofocus.pl
   ],
 RSC_Derivation => q[
   Constants initialized in make_raw.pl
     $ANTENNA_SIDE             = -1;
   ],
 RSC_Comment => q[
   It appears that wherever this value is read, it is translated
   to the string 'Right' or 'Left' before being used.
   The value should probably just be initialized as a string.
   ],
 RSC_Type => 'One of {-1,1}',
);



Use_rsc "tmp_IMAGERY.raw write ANTENNA_LENGTH           $ANTENNA_LENGTH";
Doc_rsc(
 RSC_Derivation => q[
   Constants initialized in make_raw.pl
   $ANTENNA_LENGTH           = 10;
   ],
 RSC_Comment => q[
   Appears to only be used in dopav.pl in calculation of SL_AZIMUT_RESOL.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "tmp_IMAGERY.raw write FILE_LENGTH              $file_length";
Doc_rsc(
 RSC_Tip => 'Length of file in lines (records).',
 RSC_Derivation => q[
   $width        = Use_rsc "shift.out read WIDTH";
   # $width is line (record) length in bytes.  Based on fip/delay_shift.c
   $size         = -s "tmp_IMAGERY.raw" or die "tmp_IMAGERY.raw has zero size\n";
   # $size is length of file in bytes.
   $file_length  = $size/$width;
   ],
 RSC_Comment => q[
   If value appears to be real, probably indicates creation of file
   aborted, causing it to not have an integral number of records.
   ],
 RSC_Type => Int,
 RSC_Unit => 'record'
);


Use_rsc "tmp_IMAGERY.raw write XMIN                     $xmin";
Doc_rsc(
 RSC_Tip => 'Line header length',
 RSC_Doc => q[
   Appears to be the the length of the line (record) header in bytes.
   ],
 RSC_Derivation => q[
     $xmin is a per $facility constant. (eg. 412)
   ],
 RSC_Comment => q[
   Even though xmin is set in per $facility code blocks,
   each $facility has the same value.
   $xmin = 412;
   These bytes are maintained unshifted in the .raw file.
   Based on fip/delay_shift.c, 
   ],
 RSC_Type => Int,
 RSC_Unit => 'byte',
);


Use_rsc "tmp_IMAGERY.raw write XMAX                     $xmax";
Doc_rsc(
 RSC_Tip => 'End of useful data in line (record)',
 RSC_Doc => q[
   "Good bytes per input line" based on RDF usage in roi_prep.pl and autofocus.pl.
   ],
 RSC_Derivation => q[
   $width        = Use_rsc "shift.out read WIDTH";
   $xmax         = $width;  
   ],
 RSC_Comment => q[
   $xmax is initialized to constant in per $facility code blocks.
   $xmax = 11636;
   But value is updated to new line (record) length by delay_shift.

   Various C codes expect/set "xmax=width-1", implying it should
   be zero based index of last sample.
   Further investigation needed to determine if value is used
   consistently everywhere.  Could be off by one in some usages.
   ],
 RSC_Type => Int,
 RSC_Unit => 'byte',
);


Use_rsc "tmp_IMAGERY.raw write WIDTH                    $xmax";
Doc_rsc(
 RSC_Tip => 'Line (record) length in bytes',
 RSC_Doc => q[
   ],
 RSC_Derivation => q[
   Initial value of $width is a per $facility constant (eg. 12060).
   But value is updated to new line (record) length by delay_shift.
   $width        = Use_rsc "shift.out read WIDTH";
   $xmax         = $width;  
   Use_rsc "tmp_IMAGERY.raw write WIDTH                    $xmax";
   ],
 RSC_Comment => q[
   Might make slightly more sense if value was set to $width.
   ],
 RSC_Type => Int,
 RSC_Unit => 'byte / record',
);


Use_rsc "tmp_IMAGERY.raw write YMIN                     0";
Doc_rsc(
 RSC_Tip => 'Lines (records) to skip',
 RSC_Doc => q[
   Number of lines (records) to skip in a file to reach data
   intended to be processed.
   "starting azimuth row offset, relative to start"
   based on comments in several applications.
   ],
 RSC_Derivation => q[
   Constant. 
   Use_rsc "tmp_IMAGERY.raw write YMIN                     0";
   ],
 RSC_Comment => q[
   Value is zero everywhere, except for make_geomap.pl,
   where a value of 1 is written out for geomap_4rlks.trans.rsc

   Note - for trees, corr_flag, and grass applications the
   YMIN values is relative to the FILE_START record.
   ],
 RSC_Type => Int,
 RSC_Unit => 'record'
);


Use_rsc "tmp_IMAGERY.raw write YMAX                     $file_length";
Doc_rsc(
 RSC_Tip => 'Last line (record) to process',
 RSC_Doc => q[
   "last azimuth row offset, relative to start"
   based on comments in several applications.
   ],
 RSC_Derivation => q[
   Set to same value as FILE_LENGTH
   Use_rsc "tmp_IMAGERY.raw write YMAX                     $file_length";
   ],
 RSC_Type => Int,
 RSC_Unit => 'record'
);


Use_rsc "tmp_IMAGERY.raw write RANGE_SAMPLING_FREQUENCY $RANGE_SAMPLING_FREQUENCY";
Doc_rsc(
 RSC_Derivation => q[
   Constants initialized in make_raw.pl
   $RANGE_SAMPLING_FREQUENCY = 18.962468e6; #Soren's paper
   ],
 RSC_Comment => q[
   Usage in roi_prep.pl and autofocus.pl
     $rng_pixel_size          = $speed_of_light/$sampling_freq/2;
   Value also passed as RDF to diffnsim in diffnsim.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:hertz',
);


Use_rsc "tmp_IMAGERY.raw write PLANET_GM                $PLANET_GM";
Doc_rsc(
 RSC_Tip => 'Gravitational constant times planet mass',
 RSC_Doc => q[

   ],
 RSC_Derivation => q[
    Constants initialized in make_raw.pl
    $PLANET_GM       = 3.98600448073E+14;
   ],
 RSC_Comment => q[
   Value passed as RDF to roi via roi_prep.pl
   Value passed as RDF to roi and afocus in autofocus.pl
   Usage in roi/acpatch.F roi/rmpatch.F
      acc = gm/(re+ht)**2
   Usage in roi/get_frate.f
      r_inertialacc(k) = -(pln.r_gm*r_xyz(k))/r_xyznorm**3
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter**3/SI:second**2',
);


Use_rsc "tmp_IMAGERY.raw write PLANET_SPINRATE          $PLANET_SPINRATE";
Doc_rsc(
 RSC_Derivation => q[
    Constants initialized in make_raw.pl
    $PLANET_SPINRATE = 7.29211573052E-05;
   ],
 RSC_Comment => q[
   Only usage
   value passed as RDF to get_peg_info in GetPeg.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:radian/SI:second',
);



Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_UTC  $first_line_utc"; 
Doc_rsc(
 RSC_Tip => 'Time of first line (record)',
 RSC_Doc => q[
   Is seconds portion of UTC time, to millisecond precision.
   Unknown accuracy.
   ],
 RSC_Derivation => q[
    if ($facility eq "CRDC-SARDPF"){
      $timems = ByteRead ("tmp_IMAGERY.raw" , 44 , 4);

      # The above four bytes are the "Acquisition msecs of day" (ACQ_MSEC)
      # field of the first "Processed Data Record"
      # based on ASF documentation.

      $first_line_ms_of_day = unpack("N",$timems);

      # Above produces a 32-bit integer from four big-endian ordered bytes

      $first_line_ms_of_day = $first_line_ms_of_day -      $pad_top/$prf*1000.;

      $first_line_utc = $first_line_ms_of_day /1000.;

      $last_line_utc  = $last_line_ms_of_day  /1000.;
      $center_utc     = ($first_line_utc+$last_line_utc)/2;

    } else {

      $c_line = Use_rsc "tmp_IMAGERY.raw read FIRST_FRAME_SCENE_CENTER_LINE";
      $c_hr   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_HOUR_OF_DAY"; 
      $c_mn   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_MN_OF_HOUR"; 
      $c_s    = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_S_OF_MN"; 
      $c_ms   = Use_rsc "tmp_IMAGERY.raw read FIRST_CENTER_MS_OF_S"; 

      # The above values are initially extracted from CEOS $leader_file
      # by leader2rsc based on field descriptions in
      # found in $INT_SCR/format_leaderfile_$facility
      # They are a portion of the "INPUT SCENE CENTER TIME" field,
      # in the "Data Set Summary Record".

      $c_line           = $c_line+$pad_top;
      $first_center_utc = ($c_hr*60+$c_mn)*60+$c_s+$c_ms/1000.;
      $first_line_utc   = $first_center_utc-$pri*$c_line;        

      $last_line_utc    = $first_line_utc+$pri*$file_length1;
      $center_utc       = ($first_line_utc+$last_line_utc)/2;
    }
 ],
 RSC_Comment => q[
   Note: $first_line_utc could be negative if first half of frame
   spans a day boundary.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:second',
);


Use_rsc "tmp_IMAGERY.raw write CENTER_LINE_UTC $center_utc"; 
Doc_rsc(
 RSC_Tip => 'Time of scene center',
 RSC_Doc => q[
   Is seconds portion of UTC time, to millisecond precision.
   Unknown accuracy.
   ],
 RSC_Derivation => q[
   See FIRST_LINE_UTC keyword for derivation of $center_utc.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:second',
);


Use_rsc "tmp_IMAGERY.raw write LAST_LINE_UTC   $last_line_utc"; 
Doc_rsc(
 RSC_Tip => 'Time of last line (record)',
 RSC_Doc => q[
   Is seconds portion of UTC time, to millisecond precision.
   Unknown accuracy.
   ],
 RSC_Derivation => q[
   See FIRST_LINE_UTC keyword for derivation of $last_line_utc.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:second',
);



######################################################################################
Message "Reading state vectors in SARLEADER's header, Building hdr_data_points_$date file"; 
######################################################################################
$day   = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_DAY_OF_MONTH"; 
$month = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_MONTH_OF_YEAR"; 
$year  = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_YEAR";

open HDR, ">hdr_data_points_$date.rsc" or die "Can't write to hdr_data_points_$date.rsc\n";
 
if ($orbit_type eq "HDR"){  
 @ld_file=split /\s+/, `ls SARLEADER*`;
 $numofsarl=$#ld_file+1;
 $countsarl=0;
 foreach $ld_file (@ld_file){
  $countsarl=$countsarl+1;
  $time_data1    = ByteRead ($ld_file, 2766, 22);
  $time_interval = ByteRead ($ld_file, 2788, 22);
  $byte=0;
  for ($i=0;$i<5;$i++){
   $time_data[$i]=$time_data1+$time_interval*$i;
   $xx[$i]=ByteRead ($ld_file, 2992+$byte, 22);
   $byte=$byte+22;
   $yy[$i]=ByteRead ($ld_file, 2992+$byte, 22);
   $byte=$byte+22;
   $zz[$i]=ByteRead ($ld_file, 2992+$byte, 22);
   $byte=$byte+22;
   $vvx[$i]=ByteRead ($ld_file, 2992+$byte, 22);
   $byte=$byte+22;
   $vvy[$i]=ByteRead ($ld_file, 2992+$byte, 22);
   $byte=$byte+22;
   $vvz[$i]=ByteRead ($ld_file, 2992+$byte, 22);
   $byte=$byte+22;
   if ( ($numofsarl==1) || (($countsarl==1)&&($i==0)) || (($countsarl==$numofsarl)&&($i==4)) ||
      (($numofsarl==2)&&($countsarl==1)&&($i==2)) || (($numofsarl==2)&&($countsarl==1)&&($i==4)) ||
      (($numofsarl==2)&&($countsarl==2)&&($i==2)) || (($numofsarl==3)&&($countsarl==1)&&($i==3)) ||
      (($numofsarl==3)&&($countsarl==2)&&($i==2)) || (($numofsarl==3)&&($countsarl==3)&&($i==1)) ||
      (($numofsarl==4)&&($countsarl==1)&&($i==4)) || (($numofsarl==4)&&($countsarl==2)&&($i==4)) ||
      (($numofsarl==4)&&($countsarl==3)&&($i==4)) ){
      print HDR "$time_data[$i] $xx[$i] $yy[$i] $zz[$i] $vvx[$i] $vvy[$i] $vvz[$i]\n";
   }
  }
 }
}else {
 for ($i=0;$i<5;$i++){
  $time=($last_line_utc-$first_line_utc)*$i/4+$first_line_utc;
  ($q1,$q2,$q3,$q4,$q5, $x, $y, $z, $vx, $vy,$vz) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $time $sat $orbit_type $date`;
  Status "state_vector.pl";
  print HDR "$time $x $y $z $vx $vy $vz\n";
 }
}

close(HDR);


###############################
Message "Using Orbit Information"; 
###############################
($q1,$q2,$Latd,$Lond,$height_mid, $x0, $y0, $z0, $vx0, $vy0,$vz0) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $center_utc $sat $orbit_type $date`;
Status "state_vector.pl";

$pi   = atan2(1,1)*4;
$Lat=$Latd*$pi/180.; # convert to radians
$Lon=$Lond*$pi/180.;

if ($orbit_type eq "HDR"){
 $ae    = 6378137;             #GRS80 reference ellipsoid
 $flat  = 1/298.257223563;
 $r     = sqrt($x0**2+$y0**2+$z0**2);
 $r1    = sqrt($x0**2+$y0**2);
 $Lat   = atan2($z0,$r1);
 $Lon   = atan2($y0,$x0);
 $H     = $r-$ae;
 for ($i=1; $i<7; $i++){
  $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
  $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
  $Lat    = atan2($TanLat,1);
  $H      = $r1/cos($Lat)-$N;
 }
 $height_mid=$H; 
}

$ae   = 6378137;                        #WGS84 reference ellipsoid
$flat = 1./298.257223563;
$N    = $ae/sqrt(1-$flat*(2-$flat)*sin($Lat)**2);
$re_mid=$N;

$ve=-sin($Lon)*$vx0+cos($Lon)*$vy0;
$vn=-sin($Lat)*cos($Lon)*$vx0-sin($Lat)*sin($Lon)*$vy0+cos($Lat)*$vz0;
$hdg = atan2($ve,$vn);
$e2 = $flat*(2-$flat);
$M = $ae*(1-$e2)/(sqrt(1-$e2*sin($Lat)**2))**3;
$earth_radius_mid = $N*$M/($N*(cos($hdg))**2+$M*(sin($hdg))**2);

($q1,$q2,$q3,$q4,$height_top, $x0, $y0, $z0, $vx, $vy,$vz) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $first_line_utc $sat $orbit_type $date`;
Status "state_vector.pl";

if ($orbit_type eq "HDR"){
 $ae    = 6378137;             #GRS80 reference ellipsoid
 $flat  = 1/298.257223563;
 $r     = sqrt($x0**2+$y0**2+$z0**2);
 $r1    = sqrt($x0**2+$y0**2);
 $Lat   = atan2($z0,$r1);
 $Lon   = atan2($y0,$x0);
 $H     = $r-$ae;
 for ($i=1; $i<7; $i++){
  $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
  $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
  $Lat    = atan2($TanLat,1);
  $H      = $r1/cos($Lat)-$N;
 }
 $height_top=$H; 
}

$height_dt=($height_mid-$height_top)/($center_utc-$first_line_utc);
if ($vz0 > 0) {$orbit_direction =  "ascending";}
else          {$orbit_direction = "descending";}
$velocity_mid=sqrt($vx0**2 + $vy0**2 + $vz0**2);

$Latd=$Lat*180./$pi;
$Lond=$Lon*180./$pi;
$hdgd=$hdg*180./$pi;

Use_rsc "tmp_IMAGERY.raw write HEIGHT       $height_top";
Doc_rsc(
 RSC_Tip => 'state_vector based Platform Altitude',
 RSC_Doc => q[
   Value from second instance of keyword is what is propogated
   through ROI_PAC.
   This instance is not used outside make_raw.pl
   ],
 RSC_Derivation => q[
   See make_raw.pl for derivation of $height_top.
   This instance of keyword is overwritten with value from GetPeg.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "tmp_IMAGERY.raw write HEIGHT_DT    $height_dt";
Doc_rsc(
 RSC_Tip => 'state_vector based Platform Altitude change w.r.t. time',
 RSC_Doc => q[
   Value from second instance of keyword is what is propogated
   through ROI_PAC.
   This instance is not used outside make_raw.pl
   ],
 RSC_Derivation => q[
   See make_raw.pl for derivation of $height_dt.
   This instance of keyword is overwritten with value based on GetPeg.pl
   ],
 RSC_Comment => q[
   Does not appear to ever be used.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter/SI:second',
);


Use_rsc "tmp_IMAGERY.raw write VELOCITY     $velocity_mid";
Doc_rsc(
 RSC_Tip => 'state_vector based velocity',
 RSC_Doc => q[
   Value from second instance of keyword is what is propogated
   through ROI_PAC.
   This instance is not used outside make_raw.pl
   ],
 RSC_Derivation => q[
   # $vx0, $vy0,$vz0 are outputs of state_vector.pl
   $velocity_mid=sqrt($vx0**2 + $vy0**2 + $vz0**2);

   This instance of keyword is overwritten with value from GetPeg.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter/SI:second',
);


Use_rsc "tmp_IMAGERY.raw write LATITUDE     $Latd";
Doc_rsc(
 RSC_Tip => 'state_vector based latitude',
 RSC_Doc => q[
   Value from second instance of keyword is what is propogated
   through ROI_PAC.
   This instance is not used outside make_raw.pl
   ],
 RSC_Derivation => q[
   See make_raw.pl for derivation of $Latd.
   This instance of keyword is overwritten with value from GetPeg.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


Use_rsc "tmp_IMAGERY.raw write LONGITUDE    $Lond";
Doc_rsc(
 RSC_Tip => 'state_vector based longitude',
 RSC_Doc => q[
   Value from second instance of keyword is what is propogated
   through ROI_PAC.
   This instance is not used outside make_raw.pl
   ],
 RSC_Derivation => q[
   # $y0,$x0 are outputs of state_vector.pl
   $Lon   = atan2($y0,$x0);
   $Lond=$Lon*180./$pi;

   This instance of keyword is overwritten with value from GetPeg.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


Use_rsc "tmp_IMAGERY.raw write HEADING      $hdgd";
Doc_rsc(
 RSC_Tip => 'state_vector based Heading',
 RSC_Doc => q[
   Value from second instance of keyword is what is propogated
   through ROI_PAC.
   This instance is not used outside make_raw.pl
   ],
 RSC_Derivation => q[
   See make_raw.pl for derivation of $hdgd.
   This instance of keyword is overwritten with value from GetPeg.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


Use_rsc "tmp_IMAGERY.raw write EQUATORIAL_RADIUS   $ae";
Doc_rsc(
 RSC_Derivation => q[
    Constants initialized in make_raw.pl
    $ae    = 6378137;
   ],
 RSC_Comment => q[
   Note: same value used with GRS80 and WGS84 reference ellipsoid comment
   Resource keyword value does not appear to be used outside make_raw.pl.
   However, "r_am" constant repeated in application source codes.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "tmp_IMAGERY.raw write ECCENTRICITY_SQUARED $e2";
Doc_rsc(
 RSC_Derivation => q[
   $flat = 1./298.257223563;
   $e2 = $flat*(2-$flat);
   ],
 RSC_Comment => q[
   Resource keyword value does not appear to be used outside make_raw.pl.
   However, "r_e2" constant repeated in application source codes.
   ],
 RSC_Type => Real,
 RSC_Unit => 'needs further investigation',
);


#Use_rsc "tmp_IMAGERY.raw write EARTH_EAST_RADIUS $N";
#Use_rsc "tmp_IMAGERY.raw write EARTH_NORTH_RADIUS $M";

Use_rsc "tmp_IMAGERY.raw write EARTH_RADIUS $earth_radius_mid";
Doc_rsc(
 RSC_Tip => 'Planet Radius of curvature at scene center',
 RSC_Derivation => q[
   See make_raw.pl.
   ],
 RSC_Comment => q[
   Note: based on scene LATITUDE and LONGITUDE, not SCH Peg location.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "tmp_IMAGERY.raw write ORBIT_DIRECTION $orbit_direction";
Doc_rsc(
 RSC_Derivation => q[
   # $vz0 is a return value from state_vector.pl
   if ($vz0 > 0) {$orbit_direction =  "ascending";}
   else          {$orbit_direction = "descending";}
   ],
 RSC_Comment => q[
   Value does not appear to be used anywhere.
   ],
 RSC_Type => String,
 RSC_Type => 'One of {"ascending","descending"}',
);

#####################################################
$default = "$INT_SCR/default.raw.rsc";
Use_rsc    "tmp_IMAGERY.raw.rsc merge $default";
#####################################################

###############################
Message "Doppler Computation"; 
###############################

$line_0=100;
$line_1=$file_length - 200;
$i_bias = Use_rsc "tmp_IMAGERY.raw read I_BIAS";

$dop_rng1=0;
$dop_rng2=0;
$dop_rng3=0;

`$INT_BIN/dopiq <<end
tmp_IMAGERY.raw
$xmax,$line_0,$line_1
$i_bias,$prf
end
`;

$DopUnwStr = `$INT_SCR/DopUnw.pl dop.out`;
$DopUnwStr =~ /Quadratic doppler:\s+(\S+)\s+(\S+)\s+(\S+)/;
@QuadDopCoeff = ( $1, $2, $3 );

$wavelength  = Use_rsc "tmp_IMAGERY.raw read WAVELENGTH";
$sin_theta = sqrt( 1 - ($height_top / $starting_range)**2 );
$fd = $QuadDopCoeff[0] * $prf;
$sin_squint = $fd / ( 2 * $velocity_mid * $sin_theta ) * $wavelength; # neglect vertical velocity

$squint_rad = atan2( $sin_squint, sqrt( 1 - $sin_squint ** 2 ) );
$squint_deg = 180 * $squint_rad / $pi;

Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE0  $QuadDopCoeff[0]";
Doc_rsc(
 RSC_Tip => 'Doppler polynomial constant term',
 RSC_Doc => q[
   Doppler values are expressed as fraction of PRF.
   "Doppler centroid coefs", "(Hz/prf) quadratic polynomial" from roi_prep.pl.
   "Doppler Cubic Polynomial", "fit versus range bin" from phase2base.pl, diffnsim.pl.
   ],
 RSC_Derivation => q[
   Quadratic fit DopUnw.pl processed output of dopiq program.
   Values updated by dopav.pl and roi.pl during processing.
   ],
 RSC_Comment => q[
   Various bits of related info used in above conclusion.
     c     convert to frequencies in cycles
     do k=1, (len-412)/2
       write(22,*)k,acc(k),acc(k)*prf
     First column in output file is in units of prf.  Second column is in hz.
     ( $PixIndex, $Frac, $Hz ) = split( /\s+/, $Line );
     $Unw[$i] = $Frac[$i] + $Ambiguity[$i];
     ( $a, $b, $c ) = QuadraticFit( @PixIndex, @Unw );
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:hertz/SI:hertz',
);


Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE1  $QuadDopCoeff[1]";
Doc_rsc(
 RSC_Tip => 'Doppler polynomial linear term',
 RSC_Doc => q[
   See DOPPLER_RANGE0 keyword documentation.
   ],
 RSC_Derivation => q[
   See DOPPLER_RANGE0 keyword documentation.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:hertz/SI:hertz/(range_sample)',
);


Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE2  $QuadDopCoeff[2]";
Doc_rsc(
 RSC_Tip => 'Doppler polynomial quadratic term',
 RSC_Doc => q[
   See DOPPLER_RANGE0 keyword documentation.
   ],
 RSC_Derivation => q[
   See DOPPLER_RANGE0 keyword documentation.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:hertz/SI:hertz/(range_sample**2)',
);


Use_rsc "tmp_IMAGERY.raw write DOPPLER_RANGE3  0.";
Doc_rsc(
 RSC_Tip => 'Doppler polynomial cubic term',
 RSC_Doc => q[
   See DOPPLER_RANGE0 keyword documentation.
   ],
 RSC_Derivation => q[
   Set to 0 in make_raw.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:hertz/SI:hertz/(range_sample**3)',
);


Use_rsc "tmp_IMAGERY.raw write SQUINT          $squint_deg";
Doc_rsc(
 RSC_Tip => 'Squint angle from heading',
 RSC_Derivation => q[
   From make_raw.pl.
     $height_top is 'Platform Altitude', see HEIGHT
     $QuadDopCoeff[0] is 'Doppler polynomial constant term', see DOPPLER_RANGE0
     $sin_theta = sqrt( 1 - ($height_top / $starting_range)**2 );
     $fd = $QuadDopCoeff[0] * $prf;
     $sin_squint = $fd / ( 2 * $velocity_mid * $sin_theta ) * $wavelength; # neglect vertical velocity
     $squint_rad = atan2( $sin_squint, sqrt( 1 - $sin_squint ** 2 ) );
     $squint_deg = 180 * $squint_rad / $pi;
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


Use_rsc "tmp_IMAGERY.raw write ROI_PAC_VERSION     $RPVersion";
Doc_rsc(
 RSC_Comment => q[
   Value of $RPVersion which is set in make_raw.pl.
   ],
 RSC_Type => String,
);


`mv tmp_IMAGERY.raw_parse_line.out  ${date}_parse_line.out`;
`mv tmp_IMAGERY.raw.rsc             ${date}.raw.rsc`;
`mv tmp_IMAGERY.raw                 ${date}.raw`;


#########################
Message "Raw data ready for processing";
#########################
### START AKCEOS MODIFICATION
sub read_icu {
    $b1     = ByteRead ($_[0] ,$_[2]*$_[1]+$_[3], 1);
    $b2     = ByteRead ($_[0] ,$_[2]*$_[1]+$_[3]+1, 1);
    $b3     = ByteRead ($_[0] ,$_[2]*$_[1]+$_[3]+2, 1);
    $b4     = ByteRead ($_[0] ,$_[2]*$_[1]+$_[3]+3, 1);
    $b1     = unpack("C",$b1);
    $b2     = unpack("C",$b2);
    $b3     = unpack("C",$b3);
    $b4     = unpack("C",$b4);
    $icu_time = $b1*16777216+$b2*65536+$b3*256+$b4;
    return $icu_time;
  }

### END AKCEOS MODIFICATION

exit 0;

=pod

=head1 USAGE

B<make_raw.pl> I<orbit_type leader_file date [facility] [reference_counter] >

reference_counter: default is read from imagery file

=head1 FUNCTION

Creates I<date>.raw and I<date>.raw.rsc from imagery files

=head1 ROUTINES CALLED

delay_shift

leader2rsc

new_parse

state_vector.pl

dd

dopiq

=head1 CALLED BY

none

=head1 FILES USED

IMAGERY*

SARLEADER*

=head1 FILES CREATED

I<date>.raw

I<date>.raw.rsc

I<date>_parse_line.out

shift.out

shift.out.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Modifications: Frederic CRAMPE, Oct 21, 1998

=head1 LAST UPDATE

Frederic CRAMPE, Oct 06, 1999

=cut
