#!/usr/bin/perl
### new_cut.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/new_cut.pl`;
exit 1;
}
@ARGV == 1 or Usage();
@args = @ARGV;
$date = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ("$date.int",       "$date.int.rsc");
@Outfiles = ("${date}_cut.flg", "${date}_cut.flg.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("new_cut.pl", @args);

##########################################
Message "Reading resource file: $date.int.rsc";
##########################################
$width  = Use_rsc "$date.int read WIDTH";
$start  = Use_rsc "$date.int read FILE_START";
$xmin   = Use_rsc "$date.int read XMIN";
$xmax   = Use_rsc "$date.int read XMAX";
$ymin   = Use_rsc "$date.int read YMIN";
$ymax   = Use_rsc "$date.int read YMAX";

if (-r "manual_cut.in") {`cp manual_cut.in ${date}_cut.flg`;}
else {
`touch ${date}_cut.flg`;
`rm    ${date}_cut.flg`;}

##############################################
Message "Writing resource file: ${date}_cut.flg.rsc";
##############################################
`cp $date.int.rsc ${date}_cut.flg.rsc`;

#######################################################
$call_residue = "$INT_BIN/residue $date.int ${date}_cut.flg $width $xmin $xmax $ymin $ymax";

Message "$call_residue";  
`$call_residue`;
Status "residue";
#######################################################
$call_trees = "$INT_BIN/trees ${date}_cut.flg $width 64 $start $xmin $xmax $ymin $ymax";

Message "$call_trees";
`$call_trees`; 
Status "trees";

exit 0;

=pod

=head1 USAGE

B<new_cut.pl> I<date>

date: interferogram is I<date>.int

=head1 FUNCTION

Computes the residues and builds trees to connect them 

=head1 ROUTINES CALLED

trees

residue

=head1 CALLED BY

process.pl

=head1 FILES USED

I<date>.int

I<date>.int.rsc

=head1 FILES CREATED

I<date>_cut.flg

I<date>_cut.flg.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Frederic CRAMPE, Nov 10, 1998

=cut
