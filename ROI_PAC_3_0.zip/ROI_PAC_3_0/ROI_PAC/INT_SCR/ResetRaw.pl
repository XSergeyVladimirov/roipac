#!/usr/bin/perl -w

system "mkdir tmp_raw" and die;

system "mv IM* SAR* VDF* tmp_raw" and die;

system "rm *";

system "mv tmp_raw/* ." and die;

system "rm -r tmp_raw";
