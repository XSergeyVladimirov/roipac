#!/usr/bin/perl
### make_raw_envi.pl

use Env qw(INT_SCR INT_BIN INS_DIR VOR_DIR POR_DIR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;
use POSIX qw(ceil floor);

###Usage info/check
#sub Usage{

#`$INT_SCR/pod2man.pl  $INT_SCR/make_raw_envi.pl`;
#exit 1;
#}

sub Usage {
  print STDERR <<END;

Usage: make_raw_envi.pl asa_file_root [orbit_type] [outname] 
  asa_file   : prefix of Level 0 ASAR data file(s) (e.g., asa_)
  orbit_type : ODR is default, can be DOR for DORIS orbits
  out        : output file name; YYMMDD is default

Function: Creates I<outname>.raw and I<outname>.raw.rsc from imagery files

  *** Yuri Fialko, Mar 24, 2004 *** 
updated by Ingrid Johanson and Eric Fielding Nov. 2004-Jan. 2005

END
  exit 1;
}

@ARGV >= 1  or Usage();
@args = @ARGV;

$asa_file_prefix       = shift;
$orbit_type        = shift or $orbit_type = "ODR"; 
$outname           = shift ;
$new_ws_code       = shift or $new_ws_code = 0;  # optional window start code word

# get list of image file inputs
@imagery=split /\s+/, `ls $asa_file_prefix*` or die "No Imagery files\n";;
print STDERR "@imagery \n";

#################
Message "Checking I/O";
#################
@Infiles  = ($asa_file_prefix, @imagery);
@Outfiles = ("$outname.raw",  "$outname.raw.rsc");
#&IOcheck(\@Infiles, \@Outfiles);
Log ("make_raw_envi.pl", @args);

###########################
Message "General definitions";
###########################

$C                        = 299792458;
$ANTENNA_SIDE             = -1;
$ANTENNA_LENGTH           = 10;

$PLANET_GM       = 3.98600448073E+14;
$PLANET_SPINRATE = 7.29211573052E-05;
$sat = "Envisat";


$inputnum       = @imagery;
for ($j = 0; $j < $inputnum; ++$j){
 open(RAW,$imagery[$j]) or die "Can't open Imagery file\n";
 for ($i=1; $i<79; $i++) {
   ($name,$value) = split /\=/,<RAW>;
   chomp($value);
   #Message "Name: $name";
   #Message "Value: $value";
   if ($j==0 && $name eq "PRODUCT") {($foo,$time) = split /\"/,$value;}
   if ($name eq "SOFTWARE_VER") {($foo,$proc_ver) = split /\"/,$value;}
   if ($name eq "SWATH") {($foo,$swath)=split /\"/,$value;}   
   if ($name eq "TX_RX_POLAR") {($foo,$polar)=split /\"/,$value;}   
   if ($j==0 && $name eq "SENSING_START") {($foo,$stime)=split /\"/,$value;}
   if ($j==($inputnum-1) && $name eq "SENSING_STOP") {($foo,$sense_sp)=split /\"/,$value;}
   if ($name eq "PROC_CENTER") {($foo,$facility)=split /\"/,$value;}
   if ($name eq "REL_ORBIT") {($foo,$track)=split /\+/,$value;}
   if ($name eq "ABS_ORBIT") {($foo,$orbit_num)=split /\+/,$value;}
 }
 close(RAW);
}
 

print "orbit number $orbit_num, track $track\n";
# Envisat header does not contain frame number
$frame=0;

$dt=substr($time,16,6); 
$yr=substr($time,14,4); 
$mo=substr($time,18,2); 
$da=substr($time,20,2); 
$hr=substr($time,23,2); 
$mn=substr($time,25,2); 
$sc=substr($time,27,2); 
$ms=substr($stime,-6)/1000; 
$outname or $outname=$dt;  # use date if not set in call
#print STDERR " $yr $mo $da $hr $mn $sc $ms\n";
#print STDERR " $proc_ver \n";
print STDERR "Facility: $facility \n";
print STDERR "Acqsn date: $dt \n";


#######
Message "Retrieving Instrument file from $INS_DIR";
#######
@files = `ls -1 $INS_DIR/ASA_INS*`;
chomp($ins_file_tmp = Get_Filename($stime, $sense_sp, @files));
if (!$ins_file_tmp) {Message "Instrument file was not found in $INS_DIR; using default";}
else {$ins_file = $ins_file_tmp;}
Message "Using Instrument file: $ins_file";


# This part uses Sean's decoder (asa_im_decode)
$i=$#imagery+1;
print STDERR " Decoding $i frame(s) \n";
Message "asa_im_decode @imagery $ins_file tmp_IMAGERY.raw 1 $new_ws_code";
`$INT_BIN/asa_im_decode @imagery $ins_file tmp_IMAGERY.raw 1 $new_ws_code > SAR.param`; # Sean's decoder

 open(PARAM,"SAR.param") or die "Can't open SAR.param\n";
 while (<PARAM>) {
   ($name,$value) = split /\:/,$_;
   chomp($value);
   #Message "Name: $name";
   #Message "Value: $value";
   if ($name eq "number of output samples") {$width=$value+0;}
   if ($name eq "number of output lines") {$length=$value+0;}
   if ($name eq "prf (Hz)") {$prf=$value+0;}
   if ($name eq "range sampling frequency (Hz)") {$range_sampling_frequency=$value+0;}
   if ($name eq "starting range (m)") {$starting_range=$value+0;}
   if ($name eq "chirp slope (Hz/s)") {$chirp=$value+0;}
   if ($name eq "wavelength (m)") {$wavelength=$value+0;}
   if ($name eq "pulse length (s)") {$pulse_length=$value+0;}
   if ($name eq "rangeGateBias*c/2 (m)") {$range_bias=$value+0;}
 }
 close(PARAM);
print STDERR "width=$width, length=$length \n";

# need to subtract range bias to get true starting range
if ($range_bias != 0.) {
  print STDERR "subtracting range bias \n";
  $starting_range = $starting_range - $range_bias;
}

$xmin=0;
$width=$width*2; # each sample is 2 bytes
$xmax=$width;

##################################
  Message "Finding reference counter, pri and prf";
##################################

$pri = 1/$prf;

###Calculate file length
$size         = -s "tmp_IMAGERY.raw" or die "tmp_IMAGERY.raw has zero size\n";
$file_length = $size/$width;
$clength=0;  # Envisat provides first sample line time, not scene center, so we fib here
$rms=floor($ms);

Use_rsc "tmp_IMAGERY.raw write FIRST_FRAME                 $frame";
Use_rsc "tmp_IMAGERY.raw write FIRST_FRAME_SCENE_CENTER_TIME            $yr$mo$da$hr$mn$sc$rms";
Use_rsc "tmp_IMAGERY.raw write FIRST_FRAME_SCENE_CENTER_LINE            $clength";
Use_rsc "tmp_IMAGERY.raw write DATE                                     $dt";
Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_YEAR                          $yr";
Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_MONTH_OF_YEAR                 $mo";
Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_DAY_OF_MONTH                  $da";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_HOUR_OF_DAY                 $hr";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_MN_OF_HOUR                  $mn";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_S_OF_MN                     $sc";
Use_rsc "tmp_IMAGERY.raw write FIRST_CENTER_MS_OF_S                     $ms";
Use_rsc "tmp_IMAGERY.raw write PROCESSING_FACILITY                      $facility";
Use_rsc "tmp_IMAGERY.raw write PROCESSING_SYSTEM                        $proc_ver";
#Use_rsc "tmp_IMAGERY.raw write PROCESSING_VERSION                      $sat";
Use_rsc "tmp_IMAGERY.raw write WAVELENGTH                        $wavelength";
Use_rsc "tmp_IMAGERY.raw write PULSE_LENGTH                      $pulse_length";
Use_rsc "tmp_IMAGERY.raw write CHIRP_SLOPE                        $chirp";
Use_rsc "tmp_IMAGERY.raw write I_BIAS                        128";
Use_rsc "tmp_IMAGERY.raw write Q_BIAS                        128";

################################
Message "Reading the imagery file";
################################


$first_line_utc   = ($hr*60+$mn)*60+$sc+$ms/1000.;
$last_line_utc    = $first_line_utc+$pri*$file_length;
$center_utc       = ($first_line_utc+$last_line_utc)/2;

################################
Message "Writing the imagery resource file";
################################
$range_pixel_size = $C / $range_sampling_frequency /2;

Use_rsc "tmp_IMAGERY.raw write PLATFORM                 $sat";
Use_rsc "tmp_IMAGERY.raw write BEAM                     $swath";
Use_rsc "tmp_IMAGERY.raw write POLARIZATION             $polar";
Use_rsc "tmp_IMAGERY.raw write ORBIT_NUMBER             $orbit_num"; 
Use_rsc "tmp_IMAGERY.raw write RANGE_BIAS               $range_bias"; 
Use_rsc "tmp_IMAGERY.raw write STARTING_RANGE           $starting_range"; 
Use_rsc "tmp_IMAGERY.raw write RANGE_PIXEL_SIZE         $range_pixel_size"; 
Use_rsc "tmp_IMAGERY.raw write PRF                      $prf";
Use_rsc "tmp_IMAGERY.raw write ANTENNA_SIDE             $ANTENNA_SIDE";
Use_rsc "tmp_IMAGERY.raw write ANTENNA_LENGTH           $ANTENNA_LENGTH";
Use_rsc "tmp_IMAGERY.raw write FILE_LENGTH              $file_length";
Use_rsc "tmp_IMAGERY.raw write XMIN                     $xmin";
Use_rsc "tmp_IMAGERY.raw write XMAX                     $xmax";
Use_rsc "tmp_IMAGERY.raw write WIDTH                    $width";
Use_rsc "tmp_IMAGERY.raw write YMIN                     0";
Use_rsc "tmp_IMAGERY.raw write YMAX                     $file_length";
Use_rsc "tmp_IMAGERY.raw write RANGE_SAMPLING_FREQUENCY $range_sampling_frequency";
Use_rsc "tmp_IMAGERY.raw write PLANET_GM                $PLANET_GM";
Use_rsc "tmp_IMAGERY.raw write PLANET_SPINRATE          $PLANET_SPINRATE";

Use_rsc "tmp_IMAGERY.raw write FIRST_LINE_UTC  $first_line_utc"; 
Use_rsc "tmp_IMAGERY.raw write CENTER_LINE_UTC $center_utc"; 
Use_rsc "tmp_IMAGERY.raw write LAST_LINE_UTC   $last_line_utc"; 

######################################################################################
Message "Reading state vectors, Building hdr_data_points_$outname file"; 
######################################################################################
$day   = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_DAY_OF_MONTH"; 
$month = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_MONTH_OF_YEAR"; 
$year  = Use_rsc "tmp_IMAGERY.raw read FIRST_LINE_YEAR";

 
if ($orbit_type eq "DOR"){ # use this until state_vector.pl is changed to access DORIS orbits directly
#######
Message "Retrieving Orbit file from $VOR_DIR";
#######
# ls changed to work on SGI EJF 2004/11/29
@files = `ls -1 $VOR_DIR`;
chomp($orbdata = Get_Filename($stime, $sense_sp, @files));
$orb_dir = $VOR_DIR;
if (!$orbdata) {
  Message "Final orbits not found, using PRELIMINARY orbit file";
  @files = `ls -1 $POR_DIR`;
  chomp($orbdata = Get_Filename($stime, $sense_sp, @files));
  $orb_dir = $POR_DIR;
}
if (!$orbdata) {Message "Orbit file was not found in $VOR_DIR or $POR_DIR";exit 1;}
else {
$orbdata = "$orb_dir/$orbdata";  # add directory back EJF 2004/11/30
Message "Using orbit file: $orbdata";
}

Message "Reformating DORIS orbit information into HDR style";
Get_Orbit_Data($orbdata);
$orbit_type=HDR;

}else { # this is for ODR versions of Envisat orbits
 open HDR, ">hdr_data_points_$outname.rsc" or die "Can't write to hdr_data_points_$outname.rsc\n";
 for ($i=0;$i<5;$i++){
  $time=($last_line_utc-$first_line_utc)*$i/4+$first_line_utc;
  ($q1,$q2,$q3,$q4,$q5, $x, $y, $z, $vx, $vy,$vz) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $time $sat $orbit_type $outname`;
  Status "state_vector.pl";
#print STDERR "state_vector.pl $year$month$day $time $sat $orbit_type $outname \n";
  print HDR "$time $x $y $z $vx $vy $vz\n";
 }
 close(HDR);
}


###############################
Message "Using Orbit Information"; 
###############################
($q1,$q2,$Lat,$Lon,$height_mid, $x0, $y0, $z0, $vx0, $vy0,$vz0) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $center_utc $sat $orbit_type $outname`;
Status "state_vector.pl";

$pi   = atan2(1,1)*4;
if ($orbit_type eq "HDR"){
 $ae    = 6378137;             #GRS80 reference ellipsoid
 $flat  = 1/298.257223563;
 $r     = sqrt($x0**2+$y0**2+$z0**2);
 $r1    = sqrt($x0**2+$y0**2);
 $Lat   = atan2($z0,$r1);
 $Lon   = atan2($y0,$x0);
 $H     = $r-$ae;
 for ($i=1; $i<7; $i++){
  $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
  $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
  $Lat    = atan2($TanLat,1);
  $H      = $r1/cos($Lat)-$N;
 }
 $height_mid=$H; 
}

$ae   = 6378137;                        #WGS84 reference ellipsoid
$flat = 1./298.257223563;
$N    = $ae/sqrt(1-$flat*(2-$flat)*sin($Lat)**2);
$re_mid=$N;

$ve=-sin($Lon)*$vx0+cos($Lon)*$vy0;
$vn=-sin($Lat)*cos($Lon)*$vx0-sin($Lat)*sin($Lon)*$vy0+cos($Lat)*$vz0;
$hdg = atan2($ve,$vn);
$e2 = $flat*(2-$flat);
$M = $ae*(1-$e2)/(sqrt(1-$e2*sin($Lat)**2))**3;
$earth_radius_mid = $N*$M/($N*(cos($hdg))**2+$M*(sin($hdg))**2);

($q1,$q2,$q3,$q4,$height_top, $x0, $y0, $z0, $vx, $vy,$vz) = split /\s+/,
    `$INT_SCR/state_vector.pl $year$month$day $first_line_utc $sat $orbit_type $outname`;
Status "state_vector.pl";

if ($orbit_type eq "HDR"){
  $ae    = 6378137;             #GRS80 reference ellipsoid
  $flat  = 1/298.257223563;
  $r     = sqrt($x0**2+$y0**2+$z0**2);
  $r1    = sqrt($x0**2+$y0**2);
  $Lat   = atan2($z0,$r1);
  $Lon   = atan2($y0,$x0);
  $H     = $r-$ae;
  for ($i=1; $i<7; $i++){
    $N      = $ae/(sqrt(1-$flat*(2-$flat)*sin($Lat)**2));
    $TanLat = $z0/$r1/(1-(2-$flat)*$flat*$N/($N+$H));
    $Lat    = atan2($TanLat,1);
    $H      = $r1/cos($Lat)-$N;
  }
  $height_top=$H; 
}

$height_dt=($height_mid-$height_top)/($center_utc-$first_line_utc);
if ($vz0 > 0) {$orbit_direction =  "ascending";}
else          {$orbit_direction = "descending";}
$velocity_mid=sqrt($vx0**2 + $vy0**2 + $vz0**2);

$Latd=$Lat*180./$pi;
$Lond=$Lon*180./$pi;
$hdgd=$hdg*180./$pi;
Use_rsc "tmp_IMAGERY.raw write HEIGHT_TOP   $height_top";
Use_rsc "tmp_IMAGERY.raw write HEIGHT       $height_mid";
Use_rsc "tmp_IMAGERY.raw write HEIGHT_DT    $height_dt";
Use_rsc "tmp_IMAGERY.raw write VELOCITY     $velocity_mid";
Use_rsc "tmp_IMAGERY.raw write LATITUDE     $Latd";
Use_rsc "tmp_IMAGERY.raw write LONGITUDE    $Lond";
Use_rsc "tmp_IMAGERY.raw write HEADING      $hdgd";
Use_rsc "tmp_IMAGERY.raw write EQUATORIAL_RADIUS   $ae";
Use_rsc "tmp_IMAGERY.raw write ECCENTRICITY_SQUARED $e2";
Use_rsc "tmp_IMAGERY.raw write EARTH_EAST_RADIUS $N";
Use_rsc "tmp_IMAGERY.raw write EARTH_NORTH_RADIUS $M";
Use_rsc "tmp_IMAGERY.raw write EARTH_RADIUS $earth_radius_mid";
Use_rsc "tmp_IMAGERY.raw write ORBIT_DIRECTION $orbit_direction";

#####################################################
#$default = "$INT_SCR/Env_default.raw.rsc";
#Use_rsc    "tmp_IMAGERY.raw.rsc merge $default";
#####################################################

###############################
Message "Doppler Computation"; 
###############################

# use external routine
system "$INT_SCR/scan_doppler.pl tmp_IMAGERY $file_length";

# move to final file name
#`mv tmp_IMAGERY.raw_parse_line.out  ${outname}_parse_line.out`;
# changed to save time by using mv EJF 2005/3/8
`mv tmp_IMAGERY.raw.rsc             ${outname}.raw.rsc`;
`mv tmp_IMAGERY.raw                 ${outname}.raw`;
`rm -f *tmp* IM*`;

#########################
Message "Raw data ready for processing";
#########################

exit 0;

sub Get_Orbit_Data($orbdata) {
  local($input);
  local($i);
  local($j);
  local($sense_st);
  local($sense_sp);
  local($st_utc);
  local($sp_utc);
  local($orbnum);
  
  open(ORBIT,$orbdata);
  
  for ($i=1; $i<44; $i++) {
   ($name,$value) = split /\=/,<ORBIT>;
    chomp($value);
    if ($name eq "SENSING_START") {($foo,$sense_st)=split /\"/,$value;
				   #print "Orbit file start $value\n";
				 }
    if ($name eq "SENSING_STOP") {($foo,$sense_sp)=split /\"/,$value; 
				  #print "Orbit file stop $value\n";
				}
    if ($name eq "NUM_DSD") {$j = $value*8;}
  }
  
  ($st_yr,$st_mon,$st_day,$st_utc) = split /\:/, Date_to_UTC($sense_st);
  ($sp_yr,$sp_mon,$sp_day,$sp_utc) = split /\:/, Date_to_UTC($sense_sp);

  CHECK_ORB_DATE: {
    if (($sp_yr < $year ) || ($st_yr > $year )) {Message "Orbit file is for wrong year"; 
       print "year $year, st_yr $st_yr, sp_yr $sp_yr\n"; print "sense_st $sens_st\n";
						 exit 1;} 
    if ($sp_yr > $year ) {$sp_mon += 12};
    if ($st_yr < $year ) {$st_mon -= 12};
    if (($sp_mon < $month) || ($st_mon > $month)) {Message "Orbit file is for wrong month"; exit 1;} 
    if ($sp_mon > $month) {$sp_day += 31;}
    if ($st_mon < $month) {$st_day -= 31;}
    if (($sp_day < $day) || ($st_day > $day)) {Message "Orbit file is for wrong day"; exit 1;}
    if ($sp_day > $day) {$sp_utc += 86400;}
    if ($st_day < $day) {$st_utc -= 86400;}
    if (($sp_utc < $first_line_utc) || ($st_utc > $last_line_utc)) {Message "Orbit file is for wrong time"; exit 1;}
  }
  
  for ($i; $i<44+$j; $i++) {
   ($name,$value) = split /\=/,<ORBIT>;
    chomp($value);
  }
  $i=0;
  while (<ORBIT>) {
    ($caldate, $time, $foo, $orbnum, $x, $y, $z, $vx, $vy, $vz, $foo) = split /\s+/;
    $input = $caldate." ".$time;
    ($orb_yr, $orb_mon, $orb_day,$utc_time) = split /\:/, Date_to_UTC($input);
    if ($orb_day == $day) {
# not enough for long strips EJF 07/9/11     if (abs($utc_time - $center_utc) <= 175) {
      if ( abs($utc_time - $center_utc) <= 600 ) {
        $buff[$i]=$utc_time." ".$x." ".$y." ".$z." ".$vx." ".$vy." ".$vz;  
        $i++; 
      }
    }
  }
  open(HDR,">hdr_data_points_$outname.rsc");
  foreach $line (@buff) {print HDR "${line}\n";}
  close(HDR);
  close(ORBIT);
}

sub Get_Filename()
{
  local($datastart, $datastop, @files) = @_;
  local($orbpath, $orbname, $startdate, $stopdate);
  local($st_year, $st_mon, $st_day);

  ($dst_year,$dst_mon,$dst_day,$dst_utc)= split /\:/, Date_to_UTC($datastart);
  $dst_caldate = "$dst_year"."$dst_mon"."$dst_day";
  $dst_ddate = Date_to_DecDate($dst_caldate);
  ($dsp_year,$dsp_mon,$dsp_day,$dsp_utc)= split /\:/, Date_to_UTC($datastop);
  $dsp_caldate = "$dsp_year"."$dsp_mon"."$dsp_day";
  $dsp_ddate = Date_to_DecDate($dsp_caldate);

  foreach $file (@files) {
    #m0s
    #bad logic, assumed no underscores in directory path name
    #($foo,$foo,$foo,$foo,$orbstart, $orb_sttime, $orbstop, $orb_sptime)=split /\_/, $file;
    (@fileparts) = split /\//, $file;
    $actual_name = @fileparts[@fileparts-1];
    ($foo, $foo, $foo, $foo,$orbstart, $orb_sttime, $orbstop, $orb_sptime)=split /\_/, $actual_name;
    #m0s

    $sp_ddate = Date_to_DecDate($orbstop);
    if ($sp_ddate >= $dst_ddate) {
      $st_ddate = Date_to_DecDate($orbstart);
      if ($st_ddate <= $dsp_ddate) {
        if ($orbstop != $dsp_caldate && $orbstart != $dst_caldate) {$orbname=$file; last;}
        if ($orbstop == $dsp_caldate && $orb_sptime > $dsp_utc) {
          if  ($orbstart != $dst_caldate) {$orbname=$file; last;}
          if  ($orbstart == $dst_caldate && $orb_sttime < $dst_utc) {$orbname=$file; last;}
        }  
      }
    }
  }
return $orbname;
}

  
sub Date_to_UTC()
{
  local($full_date) = @_;
  local($caldate);
  local($time);
  local($date);
  local($mon);
  local($year);
  local($day);
  local($hr);
  local($mn);
  local($s);
  local($ms);
  local($time_utc);
  
  ($caldate,$time)=split /\ /,$full_date;
  ($day,$mon,$year)=split /\-/,$caldate;
  ($hr, $mn, $s)=split /\:/,$time;
  ($s, $ms)=split /\./,$s;
  $ms =~ s/^(\d{3})(\d*)$/\1/;

  MONTH: {
    if ($mon eq "JAN") {$mon="01";last MONTH;}
    if ($mon eq "FEB") {$mon="02";last MONTH;}
    if ($mon eq "MAR") {$mon="03";last MONTH;}
    if ($mon eq "APR") {$mon="04";last MONTH;}
    if ($mon eq "MAY") {$mon="05";last MONTH;}
    if ($mon eq "JUN") {$mon="06";last MONTH;}
    if ($mon eq "JUL") {$mon="07";last MONTH;}
    if ($mon eq "AUG") {$mon="08";last MONTH;}
    if ($mon eq "SEP") {$mon="09";last MONTH;}
    if ($mon eq "OCT") {$mon="10";last MONTH;}
    if ($mon eq "NOV") {$mon="11";last MONTH;}
    if ($mon eq "DEC") {$mon="12";last MONTH;}
  }
  $time_utc = ($hr * 3600) + ($mn * 60) + $s + $ms/1000;
  $output = $year.":".$mon.":".$day.":".$time_utc;
  return $output;	
}

sub Date_to_DecDate() 
{
  local($caldate) = @_;
  local($mon);
  local($year);
  local($day, $days);
  
  $_ = $caldate;
  s/^(.{4})(..)(..)$/\1\2\3/;
  ($year, $mon, $day) = ($1, $2, $3);
  DAYS_OF_MONTH: {
    if ($mon eq "01") {$days=0;last DAYS_OF_MONTH;}
    if ($mon eq "02") {$days=31;last DAYS_OF_MONTH;}
    if ($mon eq "03") {$days=59;last DAYS_OF_MONTH;}
    if ($mon eq "04") {$days=90;last DAYS_OF_MONTH;}
    if ($mon eq "05") {$days=120;last DAYS_OF_MONTH;}
    if ($mon eq "06") {$days=151;last DAYS_OF_MONTH;}
    if ($mon eq "07") {$days=181;last DAYS_OF_MONTH;}
    if ($mon eq "08") {$days=212;last DAYS_OF_MONTH;}
    if ($mon eq "09") {$days=243;last DAYS_OF_MONTH;}
    if ($mon eq "10") {$days=273;last DAYS_OF_MONTH;}
    if ($mon eq "11") {$days=304;last DAYS_OF_MONTH;}
    if ($mon eq "12") {$days=334;last DAYS_OF_MONTH;}
  }
  $julday = $days + $day;
  $div = 365;
  if ($year % 4 == 0 && $mon > 2) {$julday++;$div++}
  $decdate = $year+($julday/$div);
  return $decdate;
}



=pod

=head1 USAGE

B<make_raw_envi.pl> I< asa_file_prefix_root [orbit type] >

orbit type: ODR, HDR, DOR

=head1 FUNCTION

Creates I<date>.raw and I<date>.raw.rsc from imagery files

=head1 ROUTINES CALLED

delay_shift

leader2rsc

new_parse

state_vector.pl

dd

dopiq

=head1 CALLED BY

none

=head1 FILES USED

IMAGERY*

SARLEADER*

=head1 FILES CREATED

I<date>.raw

I<date>.raw.rsc

I<date>_parse_line.out

shift.out

shift.out.rsc

=head1 HISTORY

Perl  Script : Yuri Fialko 03/24/2004
modified by Ingrid Johanson 10/2004 to include DOR as orbit option
modified to add range bias adjustment Eric Fielding 1/2005
Other cleanup Eric Fielding 2/2005
added HEIGHT_TOP keyword to .raw.rsc to keep both top and middle (peg) heights EJF 2005/3/21
modified code to find orbit file with Mark Simon's fix to avoid problems with underscores in directory path EJF 2005/8/19
added optional choice of starting window code EJF 2005/9/28

=head1 LAST UPDATE

2005/9/28 Eric Fielding

=cut
