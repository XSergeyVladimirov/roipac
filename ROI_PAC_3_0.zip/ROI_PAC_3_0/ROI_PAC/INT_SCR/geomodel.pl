#!/usr/bin/perl
# *** JPL/Caltech Repeat Orbit Interferometry (ROI) Package ***

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

### geomodel.pl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/geomodel.pl`;
exit 1;
}
@ARGV == 6 or Usage();
@args = @ARGV;

$Model  = shift;  
$Quake  = shift;  
$Flat   = shift;   
$Mask   = shift;
$Trans  = shift;
$Geo    = shift;

$geo_model = "${Geo}-${Model}";

#################
Message "Checking I/O";
#################
@Infiles  = ($Model,$Flat,$Trans,$Mask); # $Quake is optional
@Outfiles = ($geo_model);
&IOcheck(\@Infiles, \@Outfiles);
Log("geomodel.pl", @args); 

#############################################
Message "Create geo-model and geo-quake";
#############################################
if (-r "$Quake"){
   @file = ($Quake,$Model);}
else{
   @file = ($Model);}
  
foreach $file (@file)
        {
        `$INT_SCR/add_rmg.pl  $Flat    \\
                              $file    \\
                              tmp1.unw \\
                              -1 0`;
                              Status "add_rmg.pl";
                              
        `$INT_SCR/add_rmg.pl  tmp1.unw \\
                              $Mask    \\
                              tmp2.unw \\
                              0 1`;
                              Status "add_rmg.pl";
        
        `$INT_SCR/geocode.pl  $Trans   \\
                              tmp2.unw \\
                              ${Geo}-${file}`; 
                              Status "geocode.pl";
                              
        `rm tmp1* tmp2*`;
        }                              
 
exit 0;

=pod

=head1 USAGE

B<geomodel.pl> I<Model Quake Flat Mask Trans Geo>

=head1 FUNCTION

builds the geocoded interferogram minus seismic deformation models

=head1 ROUTINES CALLED

add_rmg.pl

rect.pl

geocode.pl

=head1 CALLED BY

process.pl

=head1 FILES USED

I<Model>

I<Quake>

I<Trans>

I<Flat>

I<Mask>

=head1 FILES CREATED

=head1 HISTORY

Perl  Script : Frederic CRAMPE 10/14/98
Frederic CRAMPE, Aug 24, 1999

=head1 LAST UPDATE

minor cleanup Eric Fielding 2005/8/24

=cut
