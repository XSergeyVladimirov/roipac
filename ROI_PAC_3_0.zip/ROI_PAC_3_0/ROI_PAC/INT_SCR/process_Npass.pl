#!/usr/bin/perl
### process_Npass.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/process_Npass.pl`;
exit 1;
}
@ARGV >= 1 or Usage();
$processfile = shift;
$DoItFrom    = shift or $DoItFrom = "raw";
$EndItAt     = shift or $EndItAt  = "done";

$DoItFrom =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb|full_res|hgt_off|morph|mask|ratio|filtered|make_mask|simulation|unwrapped|done_sim_removal|redo_base|morph_sim|use_sim_base)$/ or Usage();
$EndItAt  =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb|full_res|hgt_off|morph|mask|ratio|filtered|make_mask|simulation|unwrapped|done_sim_removal|redo_base|morph_sim|use_sim_base|done)$/ or Usage();
##########################################################################
Message "Read the inputfile";
##########################################################################
open IN, "$processfile" or die "Can't read $processfile\n";
while (chomp($line = <IN>)){
  $line =~ /=/ or next;
  $line =~ s/\s//g; ###Remove all whitespace
  ($keyname, $value) = split /=/, $line;

  if ($value =~ /,/){ ### more than one value, i.e. models
    @values = split /,/, $value;
    $i=0;
    foreach $val (@values){
      $$keyname[$i] = $val;
      $i++;
    }
  }
  else{
    $$keyname = $value;
  }
}

##########################################################################
Message "Define Variables";
##########################################################################
chomp($dir0=`pwd`);
#### Variables that can be set in int_date1_date2.proc

$SimDir             or $SimDir             = "SIM";
$GeoDir             or $GeoDir             = "GEO";
$FilterStrength     or $FilterStrength     = 0.75;
$UnwrappedThreshold or $UnwrappedThreshold = 0.73;
$OrbitType          or $OrbitType          = "ODR";
$BaselineType       or $BaselineType       = $OrbitType;
$Rlooks_int         or $Rlooks_int         = 1;
$Rlooks_sim         or $Rlooks_sim         = 4;
$Rlooks_unw         or $Rlooks_unw         = 4;
$Rlooks_sml         or $Rlooks_sml         = 16;
$pixel_ratio        or $pixel_ratio        = 5;
$Alooks_sml         or $Alooks_sml         = $Rlooks_sml*$pixel_ratio;
$before_z_ext       or $before_z_ext       = 1500;
$after_z_ext        or $after_z_ext        = 1500;
$near_rng_ext       or $near_rng_ext       = 700;
$far_rng_ext        or $far_rng_ext        = 0;
$usergivendop1      or $usergivendop1      = 0;
$usergivendop2      or $usergivendop2      = 0;
$unw_seedx          or $unw_seedx          = -9999;
$unw_seedy          or $unw_seedy          = -9999;
$x_start            or $x_start            = 0.01;
$y_start            or $y_start            = 0.01;
$flattening         or $flattening         = "orbit";
$Threshold_mag      or $Threshold_mag      = 5.0e-5;
$Threshold_ph_grd   or $Threshold_ph_grd   = 0;
$sigma_thresh       or $sigma_thresh       = 1.0;
$smooth_width       or $smooth_width       = 5;
$slope_width        or $slope_width        = 5;
$concurrent_roi     or $concurrent_roi     = "no";
$mapping            or $mapping            = "dem_based";
$cleanup            or $cleanup            = "no";
$Filt_method        or $Filt_method        = "psfilt";
$unw_method         or $unw_method         = "old";

$im1 or $im1 = $SarDir1;
$im2 or $im2 = $SarDir2;

$im1 =~ s!.*\/!!g;
$im2 =~ s!.*\/!!g;

$im12 or $im12 = "$im1-$im2";

$slc1 = "$im1.slc";
$slc2 = "$im2.slc";

$Sim = $SimDir;
$Sim =~ s!.*\/!!g;

if ($Rlooks_int > 1){$Lint = "_${Rlooks_int}rlks";}
else{$Lint = "";}
if ($Rlooks_unw > 1){$Lunw = "_${Rlooks_unw}rlks";}
else{$Lunw = "";}
if ($Rlooks_sim > 1){$Lsim = "_${Rlooks_sim}rlks";}
else{$Lsim = "";}
if ($Rlooks_sml > 1){$Lsml = "_${Rlooks_sml}rlks";}
else{$Lsml = "";}

$int2unwlook = $Rlooks_unw / $Rlooks_int;
$unw2simlook = $Rlooks_sim / $Rlooks_unw;
$cor_tag     = int($UnwrappedThreshold*100);

$slc1Lsml        = "${im1}${Lsml}.slc";
$slc2Lsml        = "${im2}${Lsml}.slc";
$corLint         = "${im12}${Lint}";
$corLunw         = "${im12}${Lunw}";
$corLsim         = "${im12}${Lsim}";
$corLsml         = "${im12}${Lsml}";
$ampLint         = "${im12}${Lint}";
$ampLsim         = "${im12}${Lsim}";
$ampLunw         = "${im12}${Lunw}";
$flatBorb        = "flat_${OrbitType}_$im12";
$flatBorbLint    = "${flatBorb}${Lint}";
$baseline_file   = "${im1}_${im2}_baseline.rsc";
$RampBorb        = "ramp_$OrbitType";
$RampBorbLint    = "${RampBorb}${Lint}";
$RampBorbLunw    = "${RampBorb}${Lunw}";
$zeroLunw        = "zero${Lunw}";

# information on the height file
$HgtDir             or die "need to define HgtDir\n";
$HgtPre             or die "need to define HgtPre\n";
$HgtBaseFile        or die "need to define HgtBaseFile\n";
$HgtBaseType        or $HgtBaseType = "ODR";
$offset_file_pref   = "ampmag_morph";
$offset_file        = "ampmag_morph.off"; 
$prefix_slave_morph = "${HgtPre}_rect";

$scaleLint = "scaled${Lint}";
$scaleLunw = "scaled${Lunw}";

# information on the ratio'ed file
$ratioBorb           = "${im12}_ratio_${OrbitType}";
$ratioBorbLint       = "${ratioBorb}${Lint}";
$ratioBorbLunw       = "${ratioBorb}${Lunw}";
$ratioBorbLsim       = "${ratioBorb}${Lsim}";
$filteredLunw        = "filt_${ratioBorbLunw}";
$filteredLsim        = "filt_${ratioBorbLsim}";
$filteredLunw_masked = "${filteredLunw}_masked";
$filteredLsim_masked = "${filteredLsim}_masked";
$unwBorbLunw         = "${filteredLunw_masked}_c${cor_tag}";
$unwBorbLsim         = "${filteredLsim_masked}_c${cor_tag}";

$maskBorbLunw        = "phase_var_${OrbitType}${Lunw}";
$maskBorbLsim        = "phase_var_${OrbitType}${Lsim}";
$lowcorBorbLsim      = "low_cor${Lsim}";

# files related to simulation
$SynthIntBorbLsim = "radar_${OrbitType}${Lsim}";
$HgtRadarGeomLsim = "radar${Lsim}";
$simLsim          = "${Sim}${Lsim}";
$simLsml          = "${Sim}${Lsml}";
$baseestmsk       = "baseest${Lsim}.msk";
$aff_name         = "${im12}${Lsim}_SIM.aff";
$twopassBorbLsim  = "$im12-sim_${OrbitType}${Lsim}";
$twopassBsimLsim  = "$im12-sim_SIM${Lsim}";
$totalLunw        = "total_${im12}${Lunw}";
$totalLsim        = "total_${im12}${Lsim}";
$flatBsimLsim     = "flat_SIM_$im12${Lsim}";

# files for geocoding
$geocoding_lookupfile = "geomap${Lunw}.trans";
$tobegeocoded         = "$unwBorbLunw.unw";
$outgeocoded          = "geo_${im12}.unw";

chdir $dir0;
chdir $SarDir1;
chomp($SarDir1=`pwd`);
chdir $dir0; 
chdir $SarDir2;
chomp($SarDir2=`pwd`);
chdir $dir0;
unless(-d $IntDir) {`mkdir $IntDir`;}
chdir $IntDir;
chomp($IntDir=`pwd`);
chdir $dir0;
if ($DEM eq ""){
  $DEM = "NULL";
}
print STDERR "GEODIR $GeoDir \n";
if ($DEM ne "NULL"){
  unless(-d $SimDir) {`mkdir $SimDir`;}
  chdir $SimDir;
  chomp($SimDir=`pwd`);
  chdir $dir0;
  unless(-d $GeoDir) {`mkdir $GeoDir`;}
  chdir $GeoDir;
  chomp($GeoDir=`pwd`);
}  

if (-r "$SarDir1/hdr_data_points_$im1.rsc"){
  `cp $SarDir1/hdr_data_points_$im1.rsc $IntDir/`;
  `cp $SarDir1/hdr_data_points_$im1.rsc $SimDir/`;
  `cp $SarDir1/hdr_data_points_$im1.rsc $GeoDir/`;
}
elsif (-r "$IntDir/hdr_data_points_$im1.rsc"){
  `cp $IntDir/hdr_data_points_$im1.rsc $SimDir/`;
  `cp $IntDir/hdr_data_points_$im1.rsc $GeoDir/`;
}
if (-r "$SarDir2/hdr_data_points_$im2.rsc"){
  `cp $SarDir2/hdr_data_points_$im2.rsc $IntDir/`;
}  


##########################################################################
Message "Go from raw to slc to int and cor";
##########################################################################
if ($DoItFrom =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb)$/){

`$INT_SCR/raw2ampintcor.pl $DoItFrom         \\
                           $EndItAt          \\
                           $dir0             \\
                           $SarDir1          \\
                           $SarDir2          \\
                           $IntDir           \\
                           $im1              \\
                           $im2              \\
                           $im12             \\
                           $slc1             \\
                           $slc2             \\
                           $baseline_file    \\
                           $usergivendop1    \\
                           $usergivendop2    \\
                           $OrbitType        \\
                           $BaselineType     \\
                           $Rlooks_int       \\
                           $Rlooks_sml       \\
                           $Alooks_sml       \\
                           $slc1Lsml         \\
                           $slc2Lsml         \\
                           $pixel_ratio      \\
                           $x_start          \\
                           $y_start          \\
                           $concurrent_roi   \\
                           $flatBorb         \\
                           $flatBorbLint     \\
                           $RampBorb         \\
                           $corLint          \\
                           $cleanup`;
                           Status "raw2ampintcor.pl";
  $DoItFrom="full_res";
  $EndItAt =~/^($DoItFrom|roi_prep|orbbase|slcs|offsets|resamp|flatorb)$/ and die "Ended at $EndItAt\n";
}

#######################################
Message "generating offset field (int=master unw=slave)";
#######################################
if ($DoItFrom eq "full_res"){

  chdir $IntDir;

  Link_here "$HgtDir/$HgtPre.unw*";
  Link_here "$HgtDir/$HgtBaseFile";

  # get offsets, assuming that the unwrapped (topo) pair will be
  # put into the coordinate system of the wrapped (change) pair.

  `$INT_SCR/offset.pl $corLint.cor $HgtPre.unw $offset_file_pref 1 rmg`;

  $DoItFrom="hgt_off";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";
}
#######################################
Message "rectifying the unwrapped pair into the master coordinate system";
#######################################
if ($DoItFrom eq "hgt_off"){

  chdir $IntDir;

  `$INT_SCR/morph.pl $HgtPre.unw $prefix_slave_morph.unw $offset_file `;

  $DoItFrom="morph";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";
}

##########################################################################
Message "Remove topo pair to get wrapped change map";
##########################################################################
if ($DoItFrom eq "morph"){

  chdir $IntDir;

  `$INT_SCR/ratio.pl $flatBorbLint      \\
                     $prefix_slave_morph \\
                     $baseline_file      \\
                     $BaselineType       \\
                     $HgtBaseFile        \\
                     $HgtBaseType        \\
                     $ratioBorbLint          \\
                     $scaleLint`;
                     Status "ratio.pl"; 
  
  $DoItFrom="ratio";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";
}


##########################################################################
Message "Filtering, making the mask, unwrapping";
##########################################################################
if ($DoItFrom =~ /^(ratio|filtered|make_mask)$/){

  chdir $IntDir;
      
  `$INT_SCR/look.pl $RampBorbLint.unw \\
                    $int2unwlook`; 
                    Status "look.pl";

  `$INT_SCR/look.pl $scaleLint.unw \\
                    $int2unwlook`; 
                    Status "look.pl";

  `$INT_SCR/look.pl $ratioBorbLint.int \\
                    $int2unwlook`; 
                    Status "look.pl";

  `$INT_SCR/look.pl $im12.cor \\
                    $Rlooks_unw`; 
                    Status "look.pl";

  `$INT_SCR/look.pl $im12.cor \\
                    $Rlooks_sim`; 
                    Status "look.pl";

  $DoItFrom2 = "begin_filt";
  $EndItAt2  = "done";

  if ($DoItFrom eq "ratio"){$DoItFrom2 = "begin_filt";} 
  if ($DoItFrom eq "filtered"   ){$DoItFrom2 = "done_filt";} 
  if ($DoItFrom eq "make_mask"  ){$DoItFrom2 = "make_mask";} 
  if ($EndItAt  eq "filtered"   ){$EndItAt2  = "done_filt";} 
  if ($EndItAt  eq "make_mask"  ){$EndItAt2  = "make_mask";} 
  if ($EndItAt  eq "unwrapped"  ){$EndItAt2  = "unwrapped";} 
  
  `$INT_SCR/int2filtmaskunwrap.pl $DoItFrom2          \\
                                  $EndItAt2           \\
                                  $IntDir             \\
                                  $ratioBorbLunw      \\
                                  $corLunw            \\
                                  $ampLunw            \\
                                  $filteredLunw       \\
                                  $unwBorbLunw        \\
                                  $maskBorbLunw       \\
                                  $Filt_method        \\
                                  $FilterStrength     \\
                                  $Threshold_mag      \\
                                  $Threshold_ph_grd   \\
                                  $smooth_width       \\
                                  $slope_width        \\
                                  $sigma_thresh       \\
                                  $UnwrappedThreshold \\
                                  $unw_seedx          \\
                                  $unw_seedy          \\
                                  $unw_method         `; 
    
                                Status "int2filtmaskunwrap.pl";
  $DoItFrom="unwrapped";
  $EndItAt =~/^($DoItFrom|filtered|make_mask)$/ and die "Ended at $EndItAt\n";
}       
            
##########################################################################
Message "Making the Simulation for baseline reestimation and 2 pass approach";
##########################################################################
if ($DoItFrom =~ /^(unwrapped|done_sim_off)$/){
  
  chdir $IntDir;

  $EndItAt2  = "done";

  if ($DoItFrom eq "unwrapped"       ){$DoItFrom2 = "begin_sim";} 
  if ($DoItFrom eq "done_sim_off"    ){$DoItFrom2 = "done_sim_off";} 
  if ($EndItAt  eq "done_sim_off"    ){$EndItAt2  = "done_sim_off";} 
  if ($EndItAt  eq "done_sim_removal"){$EndItAt2  = "done_sim_removal";} 

  `$INT_SCR/dem2diff.pl $DoItFrom2        \\
                        $EndItAt2         \\
                        $DEM              \\
                        $Sim              \\
                        $SimDir           \\
                        $IntDir           \\
                        $im12             \\
                        $Rlooks_sim       \\
                        $Rlooks_sml       \\
                        $twopassBorbLsim  \\
                        $SynthIntBorbLsim \\
                        $HgtRadarGeomLsim \\
                        $simLsim          \\
                        $simLsml          \\
                        $corLsim          \\
                        $corLsml          \\
                        $aff_name         \\
                        $baseline_file    \\
                        $OrbitType        `;  

                      Status "dem2diff.pl";

  $DoItFrom="done_sim_removal";
  $EndItAt =~/^($DoItFrom|done_sim_off|done_sim_removal)$/ and die "Ended at $EndItAt\n";
}

##########################################################################
Message "Baseline Re-estimation (done at simulation resolution)";
##########################################################################
if ($DoItFrom eq "done_sim_removal"){

  chdir $IntDir;
                     

  #add the orbit-based flattened unwrapped change image and the ramp
  `$INT_SCR/add_rmg.pl $unwBorbLunw.unw     \\
                       $RampBorbLunw.unw \\
                       ${unwBorbLunw}_ramp.unw \\
                       1 1`; 
                       Status "add_rmg.pl";
 
  #add the topography too
  `$INT_SCR/add_rmg.pl ${unwBorbLunw}_ramp.unw \\
                       $scaleLunw.unw      \\
                       $totalLunw.unw      \\
                       1 1`; 
                       Status "add_rmg.pl";
 
  #look down to simulation resolution
  `$INT_SCR/look.pl $totalLunw.unw \\
                    $unw2simlook`;
                    Status "look.pl";

  `$INT_SCR/look.pl $maskBorbLunw.msk \\
                    $unw2simlook`;
                    Status "look.pl";

  `$INT_SCR/look.pl $unwBorbLunw.unw \\
                    $unw2simlook`;
                    Status "look.pl";

if($unw_method eq "old"){
  #Put low correlation area at 0 in low_cor.msk
  `$INT_SCR/add_rmg.pl $maskBorbLsim.msk   \\
                       $unwBorbLsim.unw    \\
                       $lowcorBorbLsim.msk \\
                       0 1`; 
                       Status "add_rmg.pl";

  #modify mask to have zero value where there is no simulation info
  `$INT_SCR/add_rmg.pl $lowcorBorbLsim.msk \\
                       $HgtRadarGeomLsim.hgt \\
                       $baseestmsk         \\
                       0 1`; 
                       Status "add_rmg.pl";
}else{
  #modify mask to have zero value where there is no simulation info
  `$INT_SCR/add_rmg.pl $maskBorbLsim.msk   \\
                       $SynthIntBorbLsim.unw \\
                       $baseestmsk           \\
                       0 1`; 
                       Status "add_rmg.pl";
}
 

  #get new baselines based on total unwrapped and simulation
  #offest file not used (would need to make one at Lsim)
  $cullLsim = "${im12}_cull.off";
  $num      = $Rlooks_sim * $pixel_ratio;

  `$INT_SCR/phase2base.pl $cullLsim            \\
                          $totalLsim.unw       \\
                          $baseestmsk          \\
                          $UnwrappedThreshold  \\
                          $HgtRadarGeomLsim.hgt  \\
                          $Rlooks_sim          \\
                          $num                 \\
                          $baseline_file       \\
                          $OrbitType           \\
                          SIM`; 
                          Status "phase2base.pl";  
   
  $DoItFrom="redo_base";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";   
}

##########################################################################
#Message "Use simulation baselines to re-calculate everything should";
#"should re-ratio";
##########################################################################
#if ($DoItFrom eq "redo_base"){
#
#  chdir $IntDir;
#                    
#  $DoItFrom="use_sim_base";
#  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n"
#}

##########################################################################
Message "Geocoding";
##########################################################################
if ($DoItFrom eq "redo_base"){
#uncomment this line if reratioing section is implimented
#if ($DoItFrom eq "use_sim_base"){

  $aff2geolooks = $Rlooks_unw / $Rlooks_sim;

  chdir $IntDir;
  `$INT_SCR/radar2geo.pl $mapping \\
                         $GeoDir \\
                         $im1    \\
                         $OrbitType \\
                         $DEM \\
                         $aff_name \\
                         $aff2geolooks \\
                         $geocoding_lookupfile \\
                         $tobegeocoded \\
                         $outgeocoded `; 
                         Status "radar2geo.pl";
  
  $DoItFrom="done";
}

##########################################################################
Message "That\'s all folks";
##########################################################################
exit 0;

=pod

=head1 USAGE

B<process_Npass.pl> I<process_infile> [DoItFrom EndItAt]

 DoItFrom = point in process.pl to start
 EndItAt = point in process.pl to end
 Can be: raw, roi_prep, orbbase, slcs, offsets, resamp, flat_orb, full_res, hgt_off, morph, mask, ratio, filtered, make_mask, simulation, unwrapped, redo_base, morph_sim, or  use_sim_base

process_infile

 ###Required
 SarDir1     = name of image directory 1
 SarDir2     = name of image directory 2
 IntDir      = name of interferogram directory
 HgtDir      = name of directory with .hgt files
 HgtPre      = prefix of height files
 HgtBaseFile = baseline file for topo pair

 ###Optional (with default values)
 HgtBaseType        = ODR
 SimDir             = SIM
 DEM                = NULL
 FilterStrength     = 0.75
 UnwrappedThreshold = 0.73
 OrbitType          = ODR
 BaselineType       = OrbitType
 Rlooks_int         = 1
 Rlooks_sim         = 4
 Rlooks_sml         = 16
 pixel_ratio        = 5
 Alooks_sml         = Rlooks_sml*pixel_ratio
 before_z_ext       = 1500
 after_z_ext        = 1500
 near_rng_ext       = 700
 far_rng_ext        = 0
 usergivendop1      = 0
 usergivendop2      = 0
 unw_seedx          = 0
 unw_seedy          = 0
 x_start            = 0.01
 y_start            = 0.01
 flattening         = orbit
 Threshold_mag      = 5.0e-5
 sigma_thresh       = 1.0
 smooth_width       = 5
 slope_width        = 5
 concurrent_roi     = no
 mapping            = geocode
 Filt_method        = psfilt
 
=head1 FUNCTION

This script does end to end control of the multiple
pass interferometric processing.  The inputs are the
raw data for the change detection pair and the interferogram
for the topographic pair.

Specifically, read the input file and use default values
for keywords which are not included.  Create output and
intermediate file names.  Do the processing to convert the
raw pulse data for two passes into SLCs and the SLCs into 
an inteferometric phase and correlation for the interferometric
pair that is going to be used for change detection.
Then generate an offset field between the interferogram you
just made and one you made earlier for the topography pair.
Then transform the topographic pair into the coordinate
system of the change detection pair using the offset field.
Remove the topo pair to get wrapped change map.
Of course you want the unwrapped change detection map, so
filter, mask, and unwrap the interferogram with the topo
effects removed.  Make the Simulation for baseline 
reestimation and re-estimate the baseline.
Use simulation baselines to re-calculate everything and
geocoding the final output product.


=head1 ROUTINES CALLED

pod2man.pl

offset.pl 

morph.pl 

ratio.pl 

look.pl 

int2filtmaskunwrap.pl 

dem2diff.pl 

add_rmg.pl 

phase2base.pl 

radar2geo.pl 

raw2ampintcor.pl

=head1 CALLED BY

none

=head1 FILES USED

I<process_infile>

I<date1>.raw

I<date1>.raw.rsc

I<date2>.raw

I<date2>.raw.rsc

=head1 FILES CREATED

im12
slc1
slc2
Sim
slc1Lsml
slc2Lsml
corLint
corLunw
corLsim
corLsml
ampLint
ampLsim
ampLunw
flatBorb
flatBorbLint    
baseline_file   
RampBorb        
RampBorbLint    
RampBorbLunw    
zeroLunw        
offset_file_pref
offset_file
scaleLint 
scaleLunw 
ratioBorbLint       
ratioBorbLunw       
ratioBorbLsim       
filteredLunw        
filteredLsim        
filteredLunw_masked 
filteredLsim_masked 
unwBorbLunw         
unwBorbLsim         
maskBorbLunw        
maskBorbLsim        
lowcorBorbLsim      
SynthIntBorbLsim 
HgtRadarGeomLsim 
simLsim          
simLsml          
baseestmsk       
aff_name         
twopassBorbLsim  
twopassBsimLsim  
totalLunw        
totalLsim        
flatBsimLsim     
geocoding_lookupfile
tobegeocoded
outgeocoded
hdr_data_points_im1.rsc
hdr_data_points_im2.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Rewrite Perl Script: Mark SIMONS 07/30/99
Mark Simons, 05/01/01 

=head1 LAST UPDATE

Updated POD - Elaine Chapin 26/Nov/2003

=cut
