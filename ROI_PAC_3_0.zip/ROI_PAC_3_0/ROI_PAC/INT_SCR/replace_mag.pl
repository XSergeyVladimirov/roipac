#!/usr/bin/perl
### filtNcor.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/replace_mag.pl`;
exit 1;
}
@ARGV == 4 or Usage();
@args = @ARGV;

$infile1 = shift;
$type1   = shift;
$infile2 = shift;
$type2   = shift;

$outfile = $infile1;

#################
#Message "Checking I/O";
#################
# no IO check since this is a replacement operation

Log("replace_mag.pl", @args);

$width  = Use_rsc "$infile1 read WIDTH";
$void   = "/dev/null";

if ($type1 eq "cpx"){
   Message "cpx2mag_phs $infile1 $void phs  $width";
  `$INT_BIN/cpx2mag_phs $infile1 $void phs  $width`;
}elsif ($type1 eq "rmg"){
   Message "rmg2mag_phs $infile1 $void phs  $width";
  `$INT_BIN/rmg2mag_phs $infile1 $void phs  $width`;
}else {
  print STDERR "type1 must be cpx or rmg \n";
  Usage ();
}

if ($type2 eq "cpx"){
   Message "cpx2mag_phs $infile2 pwr $void $width";
  `$INT_BIN/cpx2mag_phs $infile2 pwr $void $width`;
}elsif ($type2 eq "rmg"){
   Message "rmg2mag_phs $infile2 pwr $void $width";
  `$INT_BIN/rmg2mag_phs $infile2 pwr $void $width`;
}else{
  print STDERR "type2 must be cpx or rmg \n";
  Usage ();
}

if ($type1 eq "cpx"){
   Message "mag_phs2cpx pwr phs $outfile $width";
  `$INT_BIN/mag_phs2cpx pwr phs $outfile $width`;
}elsif ($type1 eq "rmg"){
   Message "mag_phs2rmg pwr phs $outfile $width";
  `$INT_BIN/mag_phs2rmg pwr phs $outfile $width`;
}
else {
  print STDERR "type1 must be cpx or rmg \n";
  Usage ();
}

`rm pwr phs`;

exit 0;

=pod

=head1 USAGE

B<replace_mag.pl> I<infile1 type1 infile2 type2>

=head1 FUNCTION

Replace magnitude from infile1 with the magnitude from infile2 

   -Each file must include the int/cor/... suffix
   -types = rmg or cpx

=head1 ROUTINES CALLED

rmg2mag_phs

cpx2mag_phs

mag_phs2cpx

mag_phs2rmg

=head1 CALLED BY


=head1 FILES USED

I<infile1>

I<infile2>

I<infile>.rsc

I<incorfile>.rsc

=head1 FILES CREATED

I<outfile>

I<outfile>.rsc

=head1 HISTORY

mark Simons, Nov 13, 1998

=head1 LAST UPDATE

mark Simons, Nov 13, 1998

=cut
