#!/usr/bin/perl
### add_rmg.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/add_rmg.pl`;
exit 1;
}
@ARGV >= 3 or Usage();
@args = @ARGV;

$unwfile = shift;
$simfile = shift;
$outfile = shift;
if (@ARGV==1) {
  $sign     = shift;
  $conserve = 1;
}
elsif (@ARGV==2){
  $sign     = shift;
  $conserve = shift;
}
else{
  $sign     = 1;
  $conserve = 1;
}

#################
Message "Checking I/O";
#################
@Infiles  = ($unwfile, "$unwfile.rsc", 
             $simfile, "$simfile.rsc");
@Outfiles = ($outfile, "$outfile.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("add_rmg.pl", @args);

###################
Message "Adding back";
###################
$width  = Use_rsc "$unwfile read WIDTH";
$length = Use_rsc "$unwfile read FILE_LENGTH";

`cp $unwfile.rsc $outfile.rsc`;

$call_add = "$INT_BIN/add_rmg $unwfile \\
                              $simfile \\
                              $outfile \\
                              $width   \\
                              $length  \\
                              $sign   \\
                              $conserve"; 

Message $call_add;
`$call_add`;
#Status "add_rmg";
       
exit 0;

=pod

=head1 USAGE

B<add_rmg.pl> I<unwfile simfile outfile>
                  I<unwfile simfile outfile [sign]>
                  I<unwfile simfile outfile [sign conserve]>

=head1 FUNCTION

Adds two rmg files together

I<sign>: 1 (add) or -1 (subtract), default=1

I<conserve>: 1 => phase zero if phase from either file is zero, default=1

=head1 ROUTINES CALLED

add_rmg

=head1 CALLED BY

process.pl

=head1 FILES USED

I<unwfile>

I<unwfile>.rsc

I<simfile>

I<simfile>.rsc

=head1 FILES CREATED

I<outfile>

I<outfile>.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
