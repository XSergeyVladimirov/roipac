#!/usr/bin/perl
### raw2ampintcor.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/raw2ampintcor.pl`;
exit 1;
}
@ARGV == 34 or Usage();
@args = @ARGV;

$DoItFrom         = shift;
$EndItAt          = shift;
$dir0             = shift;
$SarDir1          = shift;
$SarDir2          = shift;
$IntDir           = shift;
$im1              = shift;
$im2              = shift;
$im12             = shift;
$slc1             = shift;
$slc2             = shift;
$baseline_file    = shift;
$usergivendop1    = shift;
$usergivendop2    = shift;
$OrbitType        = shift;
$BaselineType     = shift;
$Rlooks_int       = shift;
$Rlooks_sml       = shift;
$Alooks_sml       = shift;
$slc1Lsml         = shift;
$slc2Lsml         = shift;
$pixel_ratio      = shift;
$x_start          = shift;
$y_start          = shift;
$concurrent_roi   = shift;
$flatorbit        = shift; 
$flatorbitLint    = shift; 
$RampOrb          = shift; 
$corLint          = shift; 
$cleanup          = shift;
$MPI_PARA         = shift;
$NUM_PROC         = shift;
$ROMIO            = shift;
$ref_height       = shift;

########################### 
  Message "Check Doppler values";
###########################

if ($DoItFrom =~ /^(raw|roi_prep|orbbase|slcs)$/){

  chdir $dir0;

  `$INT_SCR/dopav.pl $SarDir1       \\
                     $SarDir2       \\
                     $im1           \\
                     $im2           \\
    	             $DoItFrom      \\
                     $usergivendop1 \\
                     $usergivendop2`;
#### $usergivendop? Variables that can be set in int_date1_date2.proc
#### to process with a determined doppler value
                     Status "dopav.pl";
}

###################
Message "Make ROI Input Files"; 
###################

if ($DoItFrom eq "raw"){

  $plat  = Use_rsc "$SarDir1/$im1.raw read PLATFORM";

### Autofocus if orbit type is HDR
    if (($OrbitType eq "HDR") and ($plat eq "JERS-1")){

	print STDERR "Orbit Type is HDR\n";
	print STDERR "Platform is is JERS-1\n";
	print STDERR "Autofocus starts\n";

	chdir $SarDir1;
	print STDERR "Autofocus 1\n";
	`$INT_SCR/autofocus.pl $im1`;
	Status "autofocus.pl";

	chdir $SarDir2;
	print STDERR "Autofocus 2\n";
	`$INT_SCR/autofocus.pl $im2`;
	Status "autofocus.pl";

    }

  chdir $SarDir1;
  `$INT_SCR/roi_prep.pl $im1 $OrbitType`;
         Status "roi_prep.pl";

  chdir $SarDir2;
  `$INT_SCR/roi_prep.pl $im2 $OrbitType`;
         Status "roi_prep.pl";

  $DoItFrom="roi_prep";
  $EndItAt eq $DoItFrom and exit 0;
}

###################
Message "Make Baseline files"; 
###################

if ($DoItFrom eq "roi_prep"){
  chdir $IntDir;
  Link_here "$SarDir1/$slc1*";
  Link_here "$SarDir2/$slc2*";
  `$INT_SCR/baseline.pl    $slc1      \\
                           $slc2      \\
                           $OrbitType \\
                           $baseline_file`; 
                           Status "baseline.pl";
  $DoItFrom="orbbase";
  $EndItAt eq $DoItFrom and exit 0;
}

###################
Message "Running ROI"; 
###################

if ($DoItFrom eq "orbbase"){
 if ($concurrent_roi eq "no"){
  chdir $SarDir1;
  print STDERR "Starting ROI 1\n";
  `$INT_SCR/roi.pl $im1 $MPI_PARA $NUM_PROC $ROMIO`;
  Status "roi.pl";
  `$INT_SCR/look.pl $im1.slc $Rlooks_sml $Alooks_sml`; 
  chdir $SarDir2;
  print STDERR "Starting ROI 2\n";
  `$INT_SCR/roi.pl $im2 $MPI_PARA $NUM_PROC $ROMIO`;
  `$INT_SCR/look.pl $im2.slc $Rlooks_sml $Alooks_sml`;
  Status "roi.pl";
 }
 else{
  chdir $SarDir1;
  print STDERR "Starting ROI 1\n";
  if (($pid1 = fork) == 0) {
    system "$INT_SCR/roi.pl $im1 $MPI_PARA $NUM_PROC $ROMIO";
    `$INT_SCR/look.pl $im1.slc $Rlooks_sml $Alooks_sml`;
    Status "roi.pl";
    exit 0;
  }
  #delay start of 2nd one in concurrent mode to avoid
  #both roi's doing IO in phase.
  sleep 20;        
  chdir $SarDir2;
  print STDERR "Starting ROI 2\n";
  if (($pid2 = fork) == 0) {
    system "$INT_SCR/roi.pl $im2 $MPI_PARA $NUM_PROC $ROMIO";
    `$INT_SCR/look.pl $im2.slc $Rlooks_sml $Alooks_sml`;
    Status "roi.pl";
    exit 0;
  }
    waitpid $pid1, 0;
  if ($? > 0){
    die "roi failed(2), returned $?\n"; 
  }
  waitpid $pid2, 0;
  if ($? > 0){
    die "roi failed(3), returned $?\n";
  }
 }
  
    
  if ($cleanup eq "yes"){
    chdir $dir0;
    `rm */*raw`;
  }


  $DoItFrom="slcs";
  $EndItAt eq $DoItFrom and exit 0;
}


###################################
Message "Get offsets";
###################################
if ($DoItFrom eq "slcs"){

  chdir $IntDir;
  Link_here "$SarDir1/$slc1*";
  Link_here "$SarDir2/$slc2*";
  Link_here "$SarDir1/$slc1Lsml*";
  Link_here "$SarDir2/$slc2Lsml*";  

  `$INT_SCR/make_offset.pl $im1                    \\
                           $im2                    \\
                           $baseline_file          \\
                           $BaselineType           \\
                           $x_start                \\
                           $y_start                \\
                           $MPI_PARA               \\
                           $NUM_PROC               \\
                           $ROMIO     `;
                           Status "make_offset.pl";

  $DoItFrom="offsets";
  $EndItAt eq $DoItFrom and exit 0;
}
############################
Message "Do the interferogram";
############################
if ($DoItFrom eq "offsets"){
  chdir $IntDir;

  `$INT_SCR/resamp.pl      $im1          \\
                           $im2          \\
                           1             \\
                           $pixel_ratio  \\
                           $MPI_PARA     \\
                           $NUM_PROC     \\
                           $ROMIO     `;
                           Status "resamp.pl";
  
  if ($cleanup eq "yes"){
    `rm -f $SarDir1/$slc1`;
    `rm -f $SarDir2/$slc2`;
    `rm -f $IntDir/*gross*`;
  }

  $DoItFrom="resamp";
  $EndItAt eq $DoItFrom and exit 0;
}

##########################################################################
Message "Flattening with orbits";
##########################################################################

if ($DoItFrom eq "resamp"){

  chdir $IntDir;
      
  #make dummy rmg file at the size of the intfile

  $width  = Use_rsc "$im12.int read WIDTH";
  $length = Use_rsc "$im12.int read FILE_LENGTH";

  `$INT_BIN/cpx2rmg $im12.int junk.unw $width $length`;
  `cp $im12.int.rsc junk.unw.rsc`;

  #Make reference height-valued dummy height file at inteferogram resolution
  #Could use cecpxcc, but we want unwrapped ramp as well, so use diffnsim.

  `$INT_SCR/add_rmg.pl junk.unw \\
                       junk.unw \\
                       reference.hgt  \\
                       -1 $ref_height`; 
                       Status "add_rmg.pl";

  `rm junk.unw junk.unw.rsc`;

  #Flatten with orbit baseline and simultaneously get flat-earth ramp
  #all at full resolution, need to look down do Lint eventually.
  `$INT_SCR/diffnsim.pl $im12.int          \\
                        reference.hgt           \\
                        $flatorbit.int     \\
                        $RampOrb.unw       \\
                        1                  \\
                        $baseline_file     \\
                        $OrbitType         \\
                        n                  `; 
                        Status "diffnsim.pl"; 

  `$INT_SCR/look.pl        $flatorbit.int \\
                           $Rlooks_int`; 
                           Status "look.pl";

  `$INT_SCR/look.pl        $RampOrb.unw \\
                           $Rlooks_int`; 
                           Status "look.pl";

  `$INT_SCR/look.pl        reference.hgt \\
                           $Rlooks_int`; 
                           Status "look.pl";
  $DoItFrom="flatorb";
  $EndItAt eq $DoItFrom and exit 0;
}

############################
Message "Calculate Correlation File";
############################
if ($DoItFrom eq "flatorb"){

  chdir $IntDir;
      
  `$INT_SCR/make_cor.pl    $flatorbit \\
                           $im12 \\
                           $im12 `; 
                           Status "make_cor.pl";

  `$INT_SCR/look.pl        $im12.cor \\
                           $Rlooks_int`; 
                           Status "look.pl";

  `$INT_SCR/look.pl        $im12.cor \\
                           $Rlooks_sml`; 
                           Status "look.pl";

  `$INT_SCR/replace_mag.pl $flatorbitLint.int \\
                           cpx                \\
                           $corLint.cor       \\
                           rmg`;
                           Status "replace_mag.pl";

  if ($cleanup eq "yes"){
    `rm $IntDir/*.amp`;
  }
  $DoItFrom="full_res";
  $EndItAt eq $DoItFrom and exit 0;
}

exit 0;

=pod

=head1 USAGE

B<raw2ampintcor.pl> 

=head1 FUNCTION

Goes from the raw ERS data to interferogram and correlation images

=head1 ROUTINES CALLED

dopav.pl

roi.pl

look.pl

baseline.pl

make_offset.pl

resamp.pl

flatten.pl

make_cor.pl

make_sim.pl

=head1 CALLED BY

process.pl

=head1 FILES USED

I<process_infile>

I<date1>.raw

I<date1>.raw.rsc

I<date2>.raw

I<date2>.raw.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Split from process.pl : Mark Simons, July 10, 1998

=head1 LAST UPDATE

Frederic CRAMPE, Aug 18, 1999

=cut
