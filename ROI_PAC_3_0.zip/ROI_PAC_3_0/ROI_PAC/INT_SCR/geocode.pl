#!/usr/bin/perl
### geocode.pl 

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/geocode.pl`;
exit 1;
}
@ARGV >= 3 or Usage();
@args = @ARGV;

$geocoding_lookupfile = shift;
$tobegeocoded         = shift;
$outgeocoded          = shift;
$Lxmin0               = shift;
$Lxmax0               = shift;
$Lymin0               = shift;
$Lymax0               = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ($geocoding_lookupfile,
	     "$geocoding_lookupfile.rsc", 
              $tobegeocoded,
	     "$tobegeocoded.rsc");  
@Outfiles = ($outgeocoded, "$outgeocoded.rsc");

&IOcheck(\@Infiles, \@Outfiles);
Log("geocode.pl", @args);

###############################################
Message "Reading resource file: $geocoding_lookupfile.rsc";
###############################################


$Lwidth  = Use_rsc "$geocoding_lookupfile read WIDTH";
$Llength = Use_rsc "$geocoding_lookupfile read FILE_LENGTH";
$Lxmax   = Use_rsc "$geocoding_lookupfile read XMAX";
$Lymax   = Use_rsc "$geocoding_lookupfile read YMAX";
$Lxfirst = Use_rsc "$geocoding_lookupfile read X_FIRST";
$Lxstep  = Use_rsc "$geocoding_lookupfile read X_STEP";
$Lxunit  = Use_rsc "$geocoding_lookupfile read X_UNIT";
$Lyfirst = Use_rsc "$geocoding_lookupfile read Y_FIRST";
$Lystep  = Use_rsc "$geocoding_lookupfile read Y_STEP";
$Lyunit  = Use_rsc "$geocoding_lookupfile read Y_UNIT";

if ($Lxmin0){
  $Lxmin = $Lxmin0;
  $Lxmax = $Lxmax0;
  $Lymin = $Lymin0;
  $Lymax = $Lymax0;
}else{
  $Lxmin = Use_rsc "$geocoding_lookupfile read XMIN";
  $Lxmax = Use_rsc "$geocoding_lookupfile read XMAX";
  $Lymin = Use_rsc "$geocoding_lookupfile read YMIN";
  $Lymax = Use_rsc "$geocoding_lookupfile read YMAX";
}

############################################
Message "Reading resource file: $tobegeocoded.rsc";
############################################

$Rwidth       = Use_rsc "$tobegeocoded read WIDTH";
$Rlength      = Use_rsc "$tobegeocoded read FILE_LENGTH";
$year         = Use_rsc "$tobegeocoded read TIME_SPAN_YEAR";
$cor_thresh   = Use_rsc "$tobegeocoded read MSK_THRESHOLD";
$orbit        = Use_rsc "$tobegeocoded read ORBIT_NUMBER";
$vel          = Use_rsc "$tobegeocoded read VELOCITY";
$hgt          = Use_rsc "$tobegeocoded read HEIGHT";
$rt           = Use_rsc "$tobegeocoded read EARTH_RADIUS";
$wavelength   = Use_rsc "$tobegeocoded read WAVELENGTH";
$date         = Use_rsc "$tobegeocoded read DATE";
$date12       = Use_rsc "$tobegeocoded read DATE12";
$heading_deg  = Use_rsc "$tobegeocoded read HEADING_DEG";
$range_ref[0] = Use_rsc "$tobegeocoded read RGE_REF1";
$look_ref[0]  = Use_rsc "$tobegeocoded read LOOK_REF1";
$lat_ref[0]   = Use_rsc "$tobegeocoded read LAT_REF1";
$lon_ref[0]   = Use_rsc "$tobegeocoded read LON_REF1";
$range_ref[1] = Use_rsc "$tobegeocoded read RGE_REF2";
$look_ref[1]  = Use_rsc "$tobegeocoded read LOOK_REF2";
$lat_ref[1]   = Use_rsc "$tobegeocoded read LAT_REF2";
$lon_ref[1]   = Use_rsc "$tobegeocoded read LON_REF2";
$range_ref[2] = Use_rsc "$tobegeocoded read RGE_REF3";
$look_ref[2]  = Use_rsc "$tobegeocoded read LOOK_REF3";
$lat_ref[2]   = Use_rsc "$tobegeocoded read LAT_REF3";
$lon_ref[2]   = Use_rsc "$tobegeocoded read LON_REF3";
$range_ref[3] = Use_rsc "$tobegeocoded read RGE_REF4";
$look_ref[3]  = Use_rsc "$tobegeocoded read LOOK_REF4";
$lat_ref[3]   = Use_rsc "$tobegeocoded read LAT_REF4";
$lon_ref[3]   = Use_rsc "$tobegeocoded read LON_REF4";

$Gxfirst = $Lxfirst + $Lxstep*$Lxmin;
$Gyfirst = $Lyfirst + $Lystep*$Lymin;
$Gwidth  = $Lxmax   - $Lxmin + 1;
$Glength = $Lymax   - $Lymin + 1;
$xmax    = $Gwidth-1;
$ymax    = $Glength-1;

############################################
Message "Writing resource file: $outgeocoded.rsc";
############################################

Use_rsc "$outgeocoded write WIDTH             $Gwidth";
Use_rsc "$outgeocoded write FILE_LENGTH       $Glength";
Use_rsc "$outgeocoded write XMIN              0 ";
Use_rsc "$outgeocoded write XMAX              $xmax";
Use_rsc "$outgeocoded write YMIN              0";
Use_rsc "$outgeocoded write YMAX              $ymax";
Use_rsc "$outgeocoded write RLOOKS            1";
Use_rsc "$outgeocoded write ALOOKS            1";
Use_rsc "$outgeocoded write X_FIRST           $Gxfirst";
Use_rsc "$outgeocoded write X_STEP            $Lxstep";
Use_rsc "$outgeocoded write X_UNIT            $Lxunit";
Use_rsc "$outgeocoded write Y_FIRST           $Gyfirst";
Use_rsc "$outgeocoded write Y_STEP            $Lystep";
Use_rsc "$outgeocoded write Y_UNIT            $Lyunit";
Use_rsc "$outgeocoded write TIME_SPAN_YEAR    $year";

Use_rsc "$outgeocoded write COR_THRESHOLD     $cor_thresh";
Doc_rsc(
 RSC_Tip => 'Correlation Threshold',
 RSC_Doc => q[
   See MSK_THRESHOLD
   ],
 RSC_Derivation => q[
   Is set to value of MSK_THRESHOLD in geocode.pl
   ],
 RSC_Comment => q[
   Value does not appear to be used anywhere.
   ],
 RSC_Type => Real,
 RSC_Unit => 'needs further investigation',
);


Use_rsc "$outgeocoded write ORBIT_NUMBER      $orbit";
Use_rsc "$outgeocoded write VELOCITY          $vel";
Use_rsc "$outgeocoded write HEIGHT            $hgt";
Use_rsc "$outgeocoded write EARTH_RADIUS      $rt";
Use_rsc "$outgeocoded write WAVELENGTH        $wavelength";
Use_rsc "$outgeocoded write DATE              $date";
Use_rsc "$outgeocoded write DATE12            $date12"; 
Use_rsc "$outgeocoded write HEADING_DEG       $heading_deg";
Use_rsc "$outgeocoded write RGE_REF1          $range_ref[0]";
Use_rsc "$outgeocoded write LOOK_REF1         $look_ref[0]";
Use_rsc "$outgeocoded write LAT_REF1          $lat_ref[0]";
Use_rsc "$outgeocoded write LON_REF1          $lon_ref[0]";
Use_rsc "$outgeocoded write RGE_REF2          $range_ref[1]";
Use_rsc "$outgeocoded write LOOK_REF2         $look_ref[1]";
Use_rsc "$outgeocoded write LAT_REF2          $lat_ref[1]";
Use_rsc "$outgeocoded write LON_REF2          $lon_ref[1]";
Use_rsc "$outgeocoded write RGE_REF3          $range_ref[2]";
Use_rsc "$outgeocoded write LOOK_REF3         $look_ref[2]";
Use_rsc "$outgeocoded write LAT_REF3          $lat_ref[2]";
Use_rsc "$outgeocoded write LON_REF3          $lon_ref[2]";
Use_rsc "$outgeocoded write RGE_REF4          $range_ref[3]";
Use_rsc "$outgeocoded write LOOK_REF4         $look_ref[3]";
Use_rsc "$outgeocoded write LAT_REF4          $lat_ref[3]";
Use_rsc "$outgeocoded write LON_REF4          $lon_ref[3]";

open RECTIN, ">rect_lookup.in" or die "Can't write to rect_lookup.in\n";
print RECTIN <<END;
Longitude-Latitude Lookup File Name    (-)   = $geocoding_lookupfile    ! Lookup file
Lookup File Dimensions                 (-)   = $Lwidth $Llength     ! across ,  down
Input Image File Name                  (-)   = $tobegeocoded     ! file to be resampled
Input File Dimensions                  (-)   = $Rwidth $Rlength       ! across , down
Output Image File Name                 (-)   = $outgeocoded     ! output filename
Lookup File Start Sample for Output    (-)   = $Lxmin           ! pixel across
Number of Samples for Output           (-)   = $Gwidth         ! number of pixels
Lookup File Start Line for Output      (-)   = $Lymin           ! start line 
Number of Lines for Output             (-)   = $Glength         ! number of lines
Skip Every N Lookup points Across-Down (-)   = 1 1        ! across , down
File Type                              (-)   = RMG         ! [RMG,CPX]
Interpolation Method                   (-)   = Bilinear    ! [Bilinear,Sinc,NN]
END
close(RECTIN);

`$INT_BIN/rect_lookup rect_lookup.in`;
Status "rect_lookup";
`$INT_SCR/length.pl $outgeocoded`;
Status "length.pl";

exit 0;

=pod

=head1 USAGE

B<geocode.pl> I<geocoding_lookupfile tobegeocoded outgeocoded>

  geocoding_lookupfile: mapping lookup file
  tobegeocoded: input rmg file
  outgeocoded: output rmg file

=head1 FUNCTION

Does the geocoding of a rmg file registered to a simulation

=head1 ROUTINES CALLED

rect_lookup
length.pl

=head1 CALLED BY

radar2geo.pl

=head1 FILES USED

I<geocoding_lookupfile> 

I<geocoding_lookupfile>.rsc

I<tobegeoded> 

I<tobegeoded>.rsc 

=head1 FILES CREATED

I<outgeocoded>

I<outgeocoded>.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Frederic CRAMPE, May 22, 1998
Yuri FIALKO, July 22, 1999

=head1 LAST UPDATE

Frederic Crampe, Aug 18,1999

=cut
