#!/usr/bin/perl
### adapt_filt.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/adapt_filt.pl`;
exit 1;
}
@ARGV == 2 or Usage();
@args = @ARGV;

$psfilt_file    = shift;
$adaptfilt_file = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ("$psfilt_file.int","$psfilt_file.int.rsc");
@Outfiles = ("$adaptfilt_file.int","$adaptfilt_file.int.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("adapt_filt.pl", @args);

##########################################
Message "Reading resource file: $psfilt_file.int.rsc";
##########################################

$width  = Use_rsc "$psfilt_file.int read WIDTH";
$xmin   = Use_rsc "$psfilt_file.int read XMIN"; 
$xmax   = Use_rsc "$psfilt_file.int read XMAX";
$ymin   = Use_rsc "$psfilt_file.int read YMIN"; 
$ymax   = Use_rsc "$psfilt_file.int read YMAX"; 

#################################################
Message "Writing resource file: $adaptfilt_file.int.rsc";
#################################################
$new_xmin= $xmin + 16;
$new_xmax= $xmax - 16;
$new_ymin= $ymin + 16;
$new_ymax= $ymax - 16;

Use_rsc "$adaptfilt_file.int write XMIN               $new_xmin";
Use_rsc "$adaptfilt_file.int write XMAX               $new_xmax";
Use_rsc "$adaptfilt_file.int write YMIN               $new_ymin";
Use_rsc "$adaptfilt_file.int write YMAX               $new_ymax";
Use_rsc "$adaptfilt_file.int merge $psfilt_file.int";

#######################################################
$call_adapt = "$INT_BIN/adapt_filt $psfilt_file.int \\
                                   $adaptfilt_file.int \\
                                   $width \\
                                   .10 \\
                                   2.  \\
                                   $xmin \\
                                   $xmax \\
                                   $ymin \\
                                   $ymax";

Message $call_adapt;
`$call_adapt >! /dev/null`;
Status "adapt_filt";
`rm adapt_filt.dat !`;


exit 0;

=pod

=head1 USAGE

B<adapt_filt.pl> I<psfilt_file> I<adaptfilt_file>

interferogram is I<psfilt_file>.int

=head1 FUNCTION

runs adapt_filt on I<psfilt_file>

=head1 ROUTINES CALLED

adapt_filt

=head1 CALLED BY

filter.pl

=head1 FILES USED

I<psfilt_file>.int

I<psfilt_file>.int.rsc

=head1 FILES CREATED

I<adaptfilt_file>.int

I<adaptfilt_file>.int.rsc

=head1 HISTORY

Perl  Script : Frederic Crampe, Aug 25, 1999

=head1 LAST UPDATE



=cut
