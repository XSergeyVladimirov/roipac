#!/usr/bin/perl
### mask_int.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/make_mask.pl`;
exit 1;
}
@ARGV >= 3 or Usage();
@args = @ARGV;

$intfile = shift;
$maskfile = shift;
$outfile  = shift;
$amp0     = shift or $amp0 = 0;   # optionally 1 to set amplitude to zero


#################
Message "Checking I/O";
#################
@Infiles  = ("$intfile",   "$intfile.rsc",
	     "$maskfile", "$maskfile.rsc");
@Outfiles = ("$outfile", "$outfile.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("mask_int.pl", @args);

############################
Message "Creating the Mask for Unwrapping";
############################

$width  = Use_rsc "$intfile read WIDTH";
$length = Use_rsc "$intfile read FILE_LENGTH";

`cp $intfile.rsc $outfile.rsc`;

Message "cpx2mag_phs  $intfile pwr phs1 $width";
`$INT_BIN/cpx2mag_phs $intfile pwr phs1 $width`;

Message "rmg2mag_phs  $maskfile /dev/null phs2 $width";
`$INT_BIN/rmg2mag_phs $maskfile /dev/null phs2 $width`;

Message "add_phs  phs1 phs2 phs3 $width $length 0 1";
`$INT_BIN/add_phs phs1 phs2 phs3 $width $length 0 1`;

if (amp0) {
Message "add_phs  pwr phs2 pwrm $width $length 0 1";
`$INT_BIN/add_phs pwr phs2 pwrm $width $length 0 1`;

`mv pwrm pwr`;
}


Message "mag_phs2cpx  pwr phs3 $outfile $width";
`$INT_BIN/mag_phs2cpx pwr phs3 $outfile $width`;

#clean up
`rm phs1 phs2 phs3 pwr`;

exit 0;
 
=pod

=head1 USAGE

B<mask_int.pl> I<intfile maskfile outfile> I<[amp0]>

=head1 FUNCTION

Will mask the intfile(c8) using zeroed areas in the maskfile(rmg),
generating outfile(c8).

amp0 optionally 1 to set amplitude to zero, otherwise amplitude unchanged

=head1 ROUTINES CALLED

add_phs

rmg2mag_phs

cpx2mag_phs

mag_phs2cpx

=head1 CALLED BY

process*.pl

=head1 FILES USED

I<intfile>

I<intfile>.rsc

I<maskfile>

I<maskfile>.rsc

=head1 FILES CREATED

I<outfile>

I<outfile>.rsc

=head1 HISTORY

Perl  Script : Mark Simons, Nov 29, 1998
Mark SIMONS, Nov 29, 1998

=head1 LAST UPDATE

Eric Fielding, July 3, 2006

=cut
