#!/usr/bin/perl 
### rescale_topo.pl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{
  `$INT_SCR/pod2man.pl  $INT_SCR/rescale_topo.pl`;
  exit 1;
}

@ARGV == 10  or Usage();
@args = @ARGV;

$prefix1 = shift;
$prefix2 = shift;
$prefix3 = shift;
$basefile1 = shift;
$basetype1 = shift;
$basefile2 = shift;
$basetype2 = shift;
$basefile3 = shift;
$basetype3 = shift;
$outprefix = shift;

###  By copying prefix1.int.rsc to ratio.int.rsc we are assuming
###  morphing has been done into the prefix1 coordinate system.  This
###  may have to change in the future!

$sat_dir = -1;  #because of different sign convention, fake left looking.

#######################################
Message "reading resource_file: $prefix1.unw.rsc";
#######################################

$width              = Use_rsc "$prefix1.unw read WIDTH";
$length             = Use_rsc "$prefix1.unw read FILE_LENGTH";
$start              = Use_rsc "$prefix1.unw read FILE_START";
$height_top         = Use_rsc "$prefix1.unw read HEIGHT";
$earth_radius       = Use_rsc "$prefix1.unw read EARTH_RADIUS";
$starting_range     = Use_rsc "$prefix1.unw read STARTING_RANGE"; 
$wavelength         = Use_rsc "$prefix1.unw read WAVELENGTH";
$range_pixel_size   = Use_rsc "$prefix1.unw read RANGE_PIXEL_SIZE";
$azimuth_pixel_size = Use_rsc "$prefix1.unw read AZIMUTH_PIXEL_SIZE";
$orbit_number       = Use_rsc "$prefix1.unw read ORBIT_NUMBER";

($h_baseline_top, $h_baseline_rate, $h_baseline_acc, $v_baseline_top, $v_baseline_rate, $v_baseline_acc) =
    split /\n/, `select_baseline.pl $basefile1 $basetype1`;

$height=$height_top;

#######################################
Message "reading resource_file: $prefix2.unw.rsc";
#######################################

$orbit_number_2    = Use_rsc "$prefix2.unw read ORBIT_NUMBER";
($h_baseline_top_2, $h_baseline_rate_2, $hbaseline_acc_2, $v_baseline_top_2, $v_baseline_rate_2, $v_baseline_acc_2) =
    split /\n/, `select_baseline.pl $basefile2 $basetype2`;

#######################################
Message "reading resource_file: $prefix3.unw.rsc";
#######################################

$orbit_number_3    = Use_rsc "$prefix3.unw read ORBIT_NUMBER";
($h_baseline_top_3, $h_baseline_rate_3, $h_baseline_acc_3, $v_baseline_top_3, $v_baseline_rate_3, $v_baseline_acc_3) =
    split /\n/, `select_baseline.pl $basefile3 $basetype3`;

##########################################
Message "writing resource_file: ratio.unw.rsc";
##########################################

`cp $prefix1.unw.rsc $outprefix.unw.rsc`;

Use_rsc "$outprefix.unw write ORBIT_NUMBER               $orbit_number         $orbit_number_2";
Use_rsc "$outprefix.unw write H_BASELINE_TOP             $h_baseline_top       $h_baseline_top_2";
Use_rsc "$outprefix.unw write H_BASELINE_RATE            $h_baseline_rate      $h_baseline_rate_2";
Use_rsc "$outprefix.unw write H_BASELINE_ACC            $h_baseline_acc      $h_baseline_acc_2";
Use_rsc "$outprefix.unw write V_BASELINE_TOP             $v_baseline_top       $v_baseline_top_2";
Use_rsc "$outprefix.unw write V_BASELINE_RATE            $v_baseline_rate      $v_baseline_rate_2";
Use_rsc "$outprefix.unw write V_BASELINE_ACC            $v_baseline_acc      $v_baseline_acc_2";

###############################################
Message "writing rescale_topo input_file: rescale_topo.in";
###############################################

open (OUT, "> rescale_topo.in") or die "Can't write to rescale_topo.in\n";
print OUT <<END;
$prefix1.unw    
$h_baseline_top      $h_baseline_rate  $h_baseline_acc
$v_baseline_top      $v_baseline_rate  $v_baseline_acc
$prefix2.unw
$h_baseline_top_2    $h_baseline_rate_2 $h_baseline_acc_2
$v_baseline_top_2    $v_baseline_rate_2 $v_baseline_acc_2
$prefix3.unw
$h_baseline_top_3    $h_baseline_rate_3 $h_baseline_acc_3
$v_baseline_top_3    $v_baseline_rate_3 $v_baseline_acc_3
$outprefix.unw
$width               $length
$height              $earth_radius         $starting_range 
$wavelength          $range_pixel_size     $azimuth_pixel_size 
$sat_dir
END

close(OUT);

###############################################
Message "rescale_topo   rescale_topo.in > rescale_topo.out";
###############################################

`$INT_BIN/rescale_topo  rescale_topo.in > rescale_topo.out`;
Status "rescale_topo";

exit 0;

=pod

=head1 USAGE

B<rescale_topo.pl> I<date>
Usage: rescale_topo.pl prefix prefix2

Will look locally for:  prefix1.unw(.rsc)
                        prefix2.unw(.rsc)

=head1 FUNCTION

Morphs an unwrapped file to a different coordinate system.

=head1 ROUTINES CALLED

=head1 CALLED BY

=head1 FILES USED

=head1 FILES CREATED

=head1 HISTORY

Perl  Script : Mark Simons, September 15, 1998

=head1 LAST UPDATE

Mark Simons, September 15, 1998

=cut


