#!/usr/bin/perl
### rect.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/rect.pl`;
exit 1;
}
@ARGV >= 2 or Usage();
@args = @ARGV;

$infile  = shift;
$outfile = shift;
$m11     = shift or $m11 = 1;
$m12     = shift or $m12 = 0;
$m21     = shift or $m21 = 0;
$m22     = shift or $m22 = 1;
$t1      = shift or $t1  = 0;
$t2      = shift or $t2  = 0;
$method  = shift or $method = Bilinear;

$method =~ /(NN|Bilinear|Sinc)/ or Usage();

if    ($infile =~ /(cor|hgt|unw|msk)/){$format = "RMG";}
elsif ($infile =~ /(slc|int)/)        {$format = "COMPLEX";}
else  {Usage();}

#################
Message "Believes input file is $format format";
Message "Using  $method to interpolate";
#################

#################
Message "Checking I/O";
#################
@Infiles  = ($infile, "$infile.rsc");
@Outfiles = ($outfile);
&IOcheck(\@Infiles, \@Outfiles);
Log("rect.pl", @args);

#####################################
Message "Registering to the simulation";
#####################################
$width  = Use_rsc "$infile read WIDTH";
$length = Use_rsc "$infile read FILE_LENGTH";

open RECT, ">rect.in" or die "Can't write to rect.in\n";

print RECT <<END;
Input Image File Name  (-) = $infile        ! dimension of file to be rectified
Output Image File Name (-) = $outfile       ! dimension of output
Input Dimensions       (-) = $width $length ! across, down
Output Dimensions      (-) = $width $length ! across, down
Affine Matrix Row 1    (-) = $m11 $m12      ! a b
Affine Matrix Row 2    (-) = $m21 $m22      ! c d
Affine Offset Vector   (-) = $t1 $t2        ! e f
File Type              (-) = $format        ! [RMG, COMPLEX]
Interpolation Method   (-) = $method        ! [NN, Bilinear, Sinc]
END

close(RECT);


############################
`cp $infile.rsc $outfile.rsc`;

Message "$INT_BIN/rect rect.in";
`$INT_BIN/rect rect.in`;
Status "rect";

exit 0;

=pod

=head1 USAGE

B<rect.pl> I<infile outfile [m11 m12 m21 m22 t1 t2 method]>
    default values: [1 0 0 1 0 0 NN]

Method NN(nearest neighbor)|Bilinear|Sinc

Recognizes infiles with a suffix of cor|hgt|unw|msk|slc|int

=head1 FUNCTION

morphs an rmg or cpx file given a set of affine transformation parameters

=head1 ROUTINES CALLED

rect

=head1 CALLED BY

synth2radar.pl

process.pl

=head1 FILES USED

I<infile>

I<infile>.rsc

=head1 FILES CREATED

I<outfile>

I<outfile>.rsc

rect.in

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
