#!/usr/bin/perl
### bridge.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/bridge.pl`;
exit 1;
}
@ARGV == 2 or Usage();
@args = @ARGV;

$filtered = shift;  
$unw      = shift; 
#it needs bridge.in file : x0 y0 x1 y1 number of cycles 

#########################################
Message "Reading resource_file: $unw.unw.rsc";
#########################################

$width  = Use_rsc "$unw.unw read WIDTH";
$length = Use_rsc "$unw.unw read FILE_LENGTH";
$xmin   = Use_rsc "$unw.unw read XMIN";
$xmax   = Use_rsc "$unw.unw read XMAX";
$ymin   = Use_rsc "$unw.unw read YMIN";
$ymax   = Use_rsc "$unw.unw read YMAX";

##############################
Message "Create the bridge";
################################

`$INT_BIN/rmg2mag_phs $unw.unw $unw.mag $unw.phs $width`;

`$INT_BIN/bridge $filtered.int \\
                 $unw.flg      \\
                 $unw.phs      \\
    		 bridge.in     \\
		 $width        \\
		 $xmin         \\
		 $xmax         \\
		 $ymin         \\
		 $ymax`;
                 Status "bridge";

`$INT_BIN/cpx2mag_phs $filtered.int mag junk $width`;
`$INT_BIN/add_phs mag $unw.phs mag2 $width $length 0 1`;
`$INT_BIN/mag_phs2rmg mag2 $unw.phs $unw.unw $width`;

`rm mag`;
`rm mag2`;
`rm junk`;
`rm $unw.mag`;
`rm $unw.phs`;


exit 0;

=pod

=head1 USAGE

B<bridge.pl> I<filtered unw>

=head1 FUNCTION

Allows to unwrap an image

=head1 ROUTINES CALLED

bridge

rmg2mag_phs

mag_phs2rmg

=head1 CALLED BY

=head1 FILES USED

I<filtered>.int

I<filtered>.int.rsc

I<unw>.unw

I<unw>.unw.rsc

bridge.in

=head1 FILES CREATED

I<unw>.unw

=head1 HISTORY

Perl  Script : Frederic CRAMPE 06/15/98

=head1 LAST UPDATE

Frederic CRAMPE, Oct 30, 1998

=cut
