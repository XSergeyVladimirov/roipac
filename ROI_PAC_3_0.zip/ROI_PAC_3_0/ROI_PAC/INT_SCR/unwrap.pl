#!/usr/bin/perl
### unwrap.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/unwrap.pl`;
exit 1;
}
@ARGV >= 4 or Usage();
@args = @ARGV;

$intfile    = shift;
$maskfile   = shift;
$unwfile    = shift;
$msk_thresh = shift;
$x_root     = shift;
$y_root     = shift;
$cor_index  = int($msk_thresh * 100);

#################
Message "Checking I/O";
#################
@Infiles  = ("$intfile.int",       "$intfile.int.rsc",
	     "${intfile}_cut.flg", "${intfile}_cut.flg.rsc",
	     "$maskfile.msk",       "$maskfile.msk.rsc");

@Outfiles = ("$unwfile.flg", 
	     "$unwfile.flg.rsc",
	     "$unwfile.unw", 
	     "$unwfile.unw.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("unwrap.pl", @args);

##########################################
Message "reading resource file: $intfile.int.rsc";
##########################################
$width  = Use_rsc "$intfile.int read WIDTH";
$length = Use_rsc "$intfile.int read FILE_LENGTH";
$start  = Use_rsc "$intfile.int read FILE_START";
$xmin   = Use_rsc "$intfile.int read XMIN";
$xmax   = Use_rsc "$intfile.int read XMAX";
$ymin   = Use_rsc "$intfile.int read YMIN";
$ymax   = Use_rsc "$intfile.int read YMAX";

if ($x_root == -9999){$x_root = $width/2;}
if ($y_root == -9999){$y_root = int($length/2);}

#################################
Message "doing the correlation mask"; 
#################################

Use_rsc "$unwfile.flg write MSK_THRESHOLD $msk_thresh";
Doc_rsc(
 RSC_Tip => 'Correlation Threshold',
 RSC_Doc => q[
   Based on unwrap/corr_flag.c
   'corr_thr       corrrelation threshold (0 --> 1.0)'
   this value was used for positional parameter 4 to corr_flag
   called by unwrap.pl

   In unwrap/corr_flag.c
   if value in 'interferometric correlation file'
   is larger than 'correlation threshold'
   the low SNR flag (LSNR) bit is cleared
   in the 'phase unwrapping flag file'.
   ],
 RSC_Derivation => q[
   Initial value (could be) specified in TEST_DIR/int.proc via
     UnwrappedThreshold=0.1
   otherwise $UnwrappedThreshold in process_2pass.pl
   gets default value of 0.1
   which is passed as positional parameter 17 to int2filtmaskunwrap.pl
   which becomes $unw_thresh in int2filtmaskunwrap.pl
   which is passed as positional parameter 4 to unwrap.pl
   which becomes $msk_thresh in unwrap.pl
   ],
 RSC_Comment => q[
   Keyword appears to only be used to set COR_THRESHOLD value in geocode.pl
   ],
 RSC_Type => Real,
 RSC_Unit => 'needs further investigation',
);


Use_rsc "$unwfile.flg merge ${intfile}_cut.flg";
`cp ${intfile}_cut.flg $unwfile.flg`;

$call_corrflag = "$INT_BIN/corr_flag $maskfile.msk $unwfile.flg $width $msk_thresh $start $xmin $xmax $ymin $ymax"; 

Message "$call_corrflag";
`$call_corrflag`;
Status "corr_flag";

##################
Message "unwrapping";
##################

Use_rsc "$unwfile.unw write MSK_THRESHOLD $msk_thresh";
Use_rsc "$unwfile.unw merge $intfile.int";

$call_grass="$INT_BIN/grass $intfile.int $unwfile.flg $unwfile.unw $width $start $xmin $xmax $ymin $ymax $x_root $y_root";

Message "$call_grass";
`echo "10000" |  $call_grass`;
Status "grass";

#####################################
###Message "getting amp from the cor file";
#####################################

###Can't check exit status of rmg2mag_phs

###`$INT_BIN/rmg2mag_phs $unwfile.unw /dev/null $unwfile.unw.phs $width`;

###`$INT_BIN/rmg2mag_phs $maskfile.msk $maskfile.msk.pwr /dev/null $width`;

###`$INT_BIN/mag_phs2rmg $maskfile.msk.pwr $unwfile.unw.phs $unwfile.unw $width `;

###`rm $maskfile.msk.pwr $unwfile.unw.phs`;

exit 0;

=pod

=head1 USAGE

B<unwrap.pl> I<intfile maskfile threshold>

intfile: interferogram is I<intfile>.int

maskfile: correlation is I<maskfile>.cor

threshold: minimum correlation to unwrap

cor_index: threshold*100

=head1 FUNCTION

Unwraps an interferogram using a flag file

=head1 ROUTINES CALLED

rmg2mag_phs

mag_phs2rmg

corr_flag

grass

=head1 CALLED BY

process.pl

=head1 FILES USED

I<intfile>.int

I<intfile>.int.rsc

I<intfile>_cut.flg

I<intfile>_cut.flg.rsc

I<maskfile>.cor

I<maskfile>.cor.rsc

=head1 FILES CREATED

I<intfile>_cI<cor_index>.flg 

I<intfile>_cI<cor_index>.flg.rsc

I<intfile>_cI<cor_index>.unw

I<intfile>_cI<cor_index>.unw.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
