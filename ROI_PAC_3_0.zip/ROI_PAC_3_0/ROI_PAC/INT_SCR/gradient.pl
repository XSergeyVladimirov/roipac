#!/usr/bin/perl
### gradient.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/gradient.pl`;
exit 1;
}
@ARGV >= 1 or Usage();
@args = @ARGV;

$demfile = shift;
$slpfile = shift or $slpfile = "$demfile.slp";

#################
Message "Checking I/O";
#################
@Infiles  = ("$demfile", "$demfile.rsc");
@Outfiles = ("$slpfile", "$slpfile.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("gradient.pl", @args);

#################
Message "Reading resource file: $demfile.rsc";
#################
$width  = Use_rsc "$demfile read WIDTH";
$length = Use_rsc "$demfile read FILE_LENGTH";
$xstep  = Use_rsc "$demfile read X_STEP";
$ystep  = Use_rsc "$demfile read Y_STEP";
$projection = Use_rsc "$demfile read PROJECTION";
$pi     = atan2(1,1)*4;

$radius = 6371000;
if ($projection =~ /UTM/){
  $dx = $xstep;
  $dy = -1*$ystep;
}
else {### For lat/lon
  $lat  = Use_rsc "$demfile read Y_FIRST";
  $dy = -1.*$ystep * $pi * $radius / 180.0;
  $dx = $xstep * $pi * cos($pi*$lat/180.) * $radius / 180.0;
}

#################
Message "Writing resource file: $slpfile.rsc";
#################
`cp $demfile.rsc $slpfile.rsc`;

#################
Message "Writing Gradient.in";
#################
open GRAD, ">Gradient.in" or die "Can't write to Gradient.in: $!\n";
print GRAD <<END;
DEM input file                           (-)  =  $demfile  ! i*2 dem file
Slope output file                        (-)  =  $slpfile  ! c*8 slope file
Number of pixels down                    (-)  =  $length   ! number of pixels down
Number of pixels across                  (-)  =  $width    ! number of pixels across
Pixel spacing across in DEM units        (-)  =  $dx       ! sample spacing across
Pixel spacing down in DEM units          (-)  =  $dy       ! sample spacing down
END
    close (GRAD);

#################
Message "Gradient Gradient.in";
`Gradient Gradient.in`;
Status "Gradient";
exit 0;

=pod

=head1 USAGE

B<gradient.pl> I<demfile [slpfile]>

info on DEM

slpfile: default = I<demfile>.slp    

=head1 FUNCTION

Creates the slope file from the demfile

=head1 ROUTINES CALLED

Gradient

=head1 CALLED BY

make_sim.pl

=head1 FILES USED

I<demfile>

I<demfile>.rsc

=head1 FILES CREATED

I<slpfile> 

I<slpfile>.rsc

Gradient.in

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
