#!/usr/bin/perl
###resamp.pl 

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

$i=Min(1.,2.);
print "$i\n";
