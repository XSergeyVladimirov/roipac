#!/usr/bin/perl -w
use strict;
use IO::Socket;
my ($host, $port, $kidpid, $handle, $line);
my( $YYYYMMDD, $UTCs, $Sat, $OrbType, $Hdrdate);
$host="altyn";
$port=39000;

unless (@ARGV == 5) { die "usage: $0 YYYYMMDD UTCs ERS[1,2] PRC/ODR hdrdate"}
($YYYYMMDD, $UTCs, $Sat, $OrbType, $Hdrdate) = @ARGV;

# create a tcp connection to the specified host and port
$handle = IO::Socket::INET->new(Proto	  => "tcp",
				PeerAddr  => $host,
				PeerPort  => $port)
       or die "can't connect to port $port on $host: $!";

$handle->autoflush(1);  	    # so output gets there right away
# print STDERR "[Connected to $host:$port]\n";

print $handle "$YYYYMMDD $UTCs $Sat $OrbType $Hdrdate\n";

while (defined ($line = <$handle>)) {
  print "$line\n";
  last
}
=pod

=head1 USAGE

usage: orbit_client.pl YYYYMMDD UTCs ERS[1,2] PRC/ODR hdrdate

=head1 FUNCTION

The script generates command line to connect with altyn.jpl.nasa.gov
in order to get the orbit information off of the server.

=head1 ROUTINES CALLED

=head1 CALLED BY

state_vector.pl

=head1 FILES USED

None

=head1 FILES CREATED

None

=head1 HISTORY

=head1 LAST UPDATE

Elaine Chapin, 26 Nov 2003 - added POD

=cut
