#!/usr/bin/perl
### doc_dem.pl

# $Id: doc_dem.pl,v 1.1.1.1 2007/04/17 22:28:01 ericmg Exp $
#
# $Log: doc_dem.pl,v $
# Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1.1.1  2007/04/03 03:40:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1  2005/12/16 18:45:38  bswift
# RSC keyword documentation changes.
#

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;


###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/doc_dem.pl`;
exit 1;
}
@ARGV == 1 or Usage();

$dem_file       = shift;

$toss_it = Use_rsc "$dem_file read FILE_DIR";
Doc_rsc(
 RSC_Tip => 'Pathname to DEM',
 RSC_Doc => q[

   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    Value does not appear to be used anywhere.

    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Filename,
);


$toss_it = Use_rsc "$dem_file read WIDTH";
# Above documented elsewhere
$toss_it = Use_rsc "$dem_file read FILE_LENGTH";
# Above documented elsewhere
$toss_it = Use_rsc "$dem_file read XMIN";
# Above documented elsewhere
$toss_it = Use_rsc "$dem_file read XMAX";
# Above documented elsewhere
$toss_it = Use_rsc "$dem_file read YMIN";
# Above documented elsewhere
$toss_it = Use_rsc "$dem_file read YMAX";
# Above documented elsewhere

$toss_it = Use_rsc "$dem_file read X_FIRST";
Doc_rsc(
 RSC_Tip => 'Longitude of upper left corner',
 RSC_Doc => q[
    'DEM corner longitude' based on RDF usage in make_sim.pl and make_geomap.pl
   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    Note: Value is also used to set RDF keyword 'DEM corner easting' 
    with units (m) in IntSim.in in make_sim.pl and make_geomap.pl

    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


$toss_it = Use_rsc "$dem_file read Y_FIRST";
Doc_rsc(
 RSC_Tip => 'Latitude of upper left corner',
 RSC_Doc => q[
    'DEM corner latitude' based on RDF usage in make_sim.pl and make_geomap.pl
   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    Note: Value is also used to set RDF keyword 'DEM corner northing' 
    with units (m) in IntSim.in in make_sim.pl and make_geomap.pl

    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


$toss_it = Use_rsc "$dem_file read X_STEP";
Doc_rsc(
 RSC_Tip => 'Pixel Size',
 RSC_Doc => q[
    Pixel size in degrees for latlon, meters for UTM,
    from DOC/HTML/html_perl/dem_info.html

    'DEM longitude spacing' based on RDF usage in make_sim.pl and make_geomap.pl

   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    Note: Value is also used to set RDF keyword 'DEM easting spacing' 
    with units (m) in IntSim.in in make_sim.pl and make_geomap.pl

    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


$toss_it = Use_rsc "$dem_file read Y_STEP";
Doc_rsc(
 RSC_Tip => 'Pixel Size',
 RSC_Doc => q[
    Pixel size in degrees for latlon, meters for UTM,
    from DOC/HTML/html_perl/dem_info.html

    'DEM latitude spacing' based on RDF usage in make_sim.pl and make_geomap.pl

   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    Note: Value is also used to set RDF keyword 'DEM northing spacing' 
    with units (m) in IntSim.in in make_sim.pl and make_geomap.pl

    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:degree',
);


$toss_it = Use_rsc "$dem_file read X_UNIT";
Doc_rsc(
 RSC_Tip => 'degrees or meters',
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    Value does not appear to be used anywhere.

    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => 'One of {"degrees","meters"}',
);


$toss_it = Use_rsc "$dem_file read Y_UNIT";
Doc_rsc(
 RSC_Tip => 'degrees or meters',
 RSC_Doc => q[
   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    Value does not appear to be used anywhere.

    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => 'One of {"degrees","meters"}',
);


$toss_it = Use_rsc "$dem_file read Z_OFFSET";
Doc_rsc(
 RSC_Tip => 'DEM height bias',
 RSC_Doc => q[
    'DEM height bias' based on RDF usage in make_sim.pl and make_geomap.pl

    Value is subtracted from DEM posting values before the
    result is multiplied Z_SCALE value in IntSim.f

    height = ( dem_post_value - Z_OFFSET ) * Z_SCALE
   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'DEM posting units, (SI:meter / Z_SCALE)',
);


$toss_it = Use_rsc "$dem_file read Z_SCALE";
Doc_rsc(
 RSC_Tip => 'DEM height scale factor',
 RSC_Doc => q[
    'DEM height bias' based on RDF usage in make_sim.pl and make_geomap.pl

    DEM elevation value is multiplied by this value after
    it has had Z_OFFSET subtracted in IntSim.f

    height = ( dem_post_value - Z_OFFSET ) * Z_SCALE
   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => Real,
 RSC_Unit => 'DEM un-biased posting units / SI:meter',
);


$toss_it = Use_rsc "$dem_file read PROJECTION";
Doc_rsc(
 RSC_Tip => 'DEM projection',
 RSC_Doc => q[
    Indicates projection is UTM or LATLON.

    If value does not start with 'UTM', LATLON is assumed in make_sim.pl, make_geomap.pl, gradient.pl.
   ],
 RSC_Derivation => q[
    Initial value in DEM/SoCal.dem.rsc distributed in TEST_DIR
   ],
 RSC_Comment => q[
    This keyword is documented where read by perl script,
    because resource file is included in distribution, and
    not created by processing.
   ],
 RSC_Type => String,
 RSC_Format => 'UTM{zone} or LATLON ',
);






=pod

=head1 USAGE

B<doc_dem.pl> I<dem_file>

=head1 FUNCTION

Reads keywords in I<dem_file>.rsc to produce standard documentation,
since these keywords are part of the TEST_DIR distribution,
and are not created during processing.

=head1 ROUTINES CALLED

=head1 CALLED BY

=head1 FILES USED

=head1 FILES CREATED

=head1 HISTORY

 $Log: doc_dem.pl,v $
 Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
 initial import into erda insarcvs

 Revision 1.1.1.1  2007/04/03 03:40:01  ericmg
 initial import into erda insarcvs

 Revision 1.1  2005/12/16 18:45:38  bswift
 RSC keyword documentation changes.


=head1 LAST UPDATE

 $Id: doc_dem.pl,v 1.1.1.1 2007/04/17 22:28:01 ericmg Exp $

=cut
