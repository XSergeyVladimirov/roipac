#!/usr/bin/perl 
### dopav.pl

# $Id: dopav.pl,v 1.1.1.1 2007/04/17 22:28:01 ericmg Exp $
#
# $Log: dopav.pl,v $
# Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1.1.1  2007/04/03 03:40:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.2  2005/12/16 18:45:39  bswift
# RSC keyword documentation changes.
#

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/dopav.pl`;
exit 1;
}
@ARGV >= 5  or Usage();
@args = @ARGV;

$SarDir1           = shift;
$SarDir2           = shift;
$Im1               = shift;
$Im2               = shift;
$DoItFrom          = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ("$SarDir1/$Im1.raw.rsc", "$SarDir2/$Im2.raw.rsc");
@Outfiles = ("$SarDir1/roi.dop.rsc",  "$SarDir2/roi.dop.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("dopav.pl", @args);

################################
Message "Reading the imagery files.raw.rsc";
################################

chdir $SarDir1;
$dop1_rng0    = Use_rsc "$Im1.raw read DOPPLER_RANGE0";
$dop1_rng1    = Use_rsc "$Im1.raw read DOPPLER_RANGE1";
$dop1_rng2    = Use_rsc "$Im1.raw read DOPPLER_RANGE2";
$dop1_rng3    = Use_rsc "$Im1.raw read DOPPLER_RANGE3";
$prf1         = Use_rsc "$Im1.raw read PRF";
$squint1      = Use_rsc "$Im1.raw read SQUINT";
$velocity1    = Use_rsc "$Im1.raw read VELOCITY";
$antenna_l    = Use_rsc "$Im1.raw read ANTENNA_LENGTH";

chdir $SarDir2;
$dop2_rng0    = Use_rsc "$Im2.raw read DOPPLER_RANGE0";
$dop2_rng1    = Use_rsc "$Im2.raw read DOPPLER_RANGE1";
$dop2_rng2    = Use_rsc "$Im2.raw read DOPPLER_RANGE2";
$dop2_rng3    = Use_rsc "$Im2.raw read DOPPLER_RANGE3";
$prf2         = Use_rsc "$Im2.raw read PRF";
$squint2      = Use_rsc "$Im2.raw read SQUINT";

$prf_ave      = ($prf1+$prf2)/2;

#note that dopX_rngY (from dopiq) is non-dimensional and from scenes
#with potentially different prfs.  Need to average dimension dopplers.
$dop_rng0_d   = ($dop1_rng0*$prf1+$dop2_rng0*$prf2)/2;
$dop_rng1_d   = ($dop1_rng1*$prf1+$dop2_rng1*$prf2)/2;
$dop_rng2_d   = ($dop1_rng2*$prf1+$dop2_rng2*$prf2)/2;
$dop_rng3_d   = ($dop1_rng3*$prf1+$dop2_rng3*$prf2)/2;
#assuming velocities are the same for both satellites:
$res = $antenna_l / 2;
$sl_azim_res  = $res/ (1 - ($res/$velocity1)*abs($dop1_rng0*$prf1-$dop2_rng0*$prf2));  

$squint       = ($squint1+$squint2)/2;

################################
Message "Creating the files roi.dop.rsc";
################################
@Dir = ( $SarDir1, $SarDir2 );
@Prf = ( $prf1, $prf2 );

for( my $i=0; $i<=$#Dir; $i++ ){
	chdir $Dir[$i];
	@Dop = ( $dop_rng0_d /  $Prf[$i], $dop_rng1_d /  $Prf[$i], $dop_rng2_d /  $Prf[$i], $dop_rng3_d /  $Prf[$i] );
	Use_rsc "roi.dop write DOPPLER_RANGE0  $Dop[0]";
	Use_rsc "roi.dop write DOPPLER_RANGE1  $Dop[1]";
	Use_rsc "roi.dop write DOPPLER_RANGE2  $Dop[2]";
	Use_rsc "roi.dop write DOPPLER_RANGE3  $Dop[3]";
Message "just before SL_AZIMUT_RESOL";
	Use_rsc "roi.dop write SL_AZIMUT_RESOL $sl_azim_res";
	Doc_rsc(
	 RSC_Tip => 'Azimuth resolution',
	 RSC_Doc => q[
	   ],
	 RSC_Derivation => q[
	   $sl_azim_res  = $res/ (1 - ($res/$velocity1)*abs($dop1_rng0*$prf1-$dop2_rng0*$prf2));  
	   See dopav.pl
	   ],
	 RSC_Comment => q[
	   Used in roi_prep.pl and autofocus.pl.
	   ],
	 RSC_Type => Real,
	 RSC_Unit => 'SI:meter',
	);
Message "just after SL_AZIMUT_RESOL";


	Use_rsc "roi.dop write SQUINT          $squint";

	if ($DoItFrom eq "slcs"){
#		$dop1_rng0    = Use_rsc "$Im1.slc read DOPPLER_RANGE0";
#		$lowlimit     = $usergivendop1*(1-1/100);
#		$uplimit      = $usergivendop1*(1+1/100);
#		if ($dop1_rng0 < $lowlimit || $dop1_rng0 > $uplimit){
 			`rm *.slc`;
			`rm *.slc.rsc`;
#		}
	}
}


exit 0;

=pod

=head1 USAGE

B<dopav.pl> I<SarDir1 SarDir2 slc1 slc2 DoItFrom usergivendop1 usergivendop2>

If I<DoItFrom> = "slcs", checks to make sure the bandwidth of the two slcs are within reasonable limits.  If not, it removes the slc files, which kills process.pl

if I<usergivendop#> is zero, DOPPLER_RANGE0 is used from the .raw.rsc file

=head1 FUNCTION

Figures out the mean centroid and the common bandwidth

=head1 ROUTINES CALLED

none

=head1 CALLED BY

process.pl

=head1 FILES USED

I<slc1>.rsc

I<slc2>.rsc

=head1 FILES CREATED

I<SarDir1>/roi.dop.rsc

I<SarDir2>/roi.dop.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Jun 10, 1998

=cut
