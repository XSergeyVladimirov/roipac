#!/usr/bin/perl
### int2filtmaskunwrap.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/int2filtmaskunwrap.pl`;
exit 1;
}

@ARGV == 20 or Usage();

@args = @ARGV;

$DoItFrom           = shift;
$EndItAt            = shift;
$IntDir             = shift;
$Int0               = shift; # a file
$Cor                = shift; # a file
$Amp                = shift; # a file
$Intfilt            = shift; # a file
$Unw                = shift; # a file
$Mask               = shift; # a file
$Filt_method        = shift; # a name
$FilterStrength     = shift; # a real parameter
$Threshold_mag      = shift; # a real parameter
$Threshold_ph_grd   = shift; # a real parameter
$smooth_width       = shift; # an integer parameter
$slope_width        = shift; # a real parameter
$sigma_thresh       = shift; # a real parameter
$unw_thresh         = shift; # a real parameter
$unw_seedx          = shift; # an integer parameter
$unw_seedy          = shift; # an integer parameter
$unw_method         = shift; # old or icu

Log ("int2filtmaskunwrap.pl", @args);

if ($unw_method eq "old"){

##########################################################################
  Message "Filtering";
##########################################################################
  if ($DoItFrom eq "begin_filt"){

    chdir $IntDir;
      
    `$INT_SCR/filter.pl $Int0            \\
                        $FilterStrength  \\
                        $Filt_method     \\
                        $Intfilt`; 
    Status "filter.pl";
    
    $DoItFrom="done_filt";
    $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";
  }
  
##########################################################################
  Message "Form unwrapping mask using phase covariance";
##########################################################################
  if ($DoItFrom eq "done_filt"){
    
    chdir $IntDir;
    `$INT_SCR/replace_mag.pl $Intfilt.int cpx $Cor.cor rmg`;    
    `$INT_SCR/make_mask.pl   $Intfilt          \\
                             $Mask             \\
                             $Threshold_mag    \\
                             $Threshold_ph_grd \\
                             $smooth_width     \\
                             $slope_width      \\
                             $sigma_thresh     `; 
    Status "make_mask.pl";
    
    $DoItFrom="make_mask";
    $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";
  }
  
##########################################################################
  Message "Unwrapping";
##########################################################################
  if ($DoItFrom eq "make_mask"){
    
    chdir $IntDir;
    `$INT_SCR/new_cut.pl $Intfilt`; 
    Status "new_cut.pl";
    
#!!!! should pass name of unwrapped file $Unw, not build it in unwrap.pl
    
    `$INT_SCR/unwrap.pl  $Intfilt    \\
                         $Mask       \\
                         $Unw        \\
                         $unw_thresh \\
                         $unw_seedx  \\
                         $unw_seedy  `; 
    Status "unwrap.pl";
    
    #make a bridge if necessary
    if (-r "bridge.in"){`$INT_SCR/bridge.pl $Intfilt $Unw`;}
    
    $DoItFrom="unwrapped";
    $EndItAt eq $DoItFrom and exit 0;
  }
########  USE ICU to do everything instead #####
  
}elsif ($unw_method eq "icu"){
  if ($DoItFrom =~ /^(begin_filt|done_filt|filtered|make_mask)$/){
    `$INT_SCR/icu.pl $Int0           \\
                     $Unw            \\
                     $Amp            \\
                     $Mask           \\
                     $Intfilt        \\
                     $Filt_method    \\
                     $FilterStrength \\
                     Phase_Sigma     \\
                     $smooth_width   \\
                     $unw_thresh`; 
    
    Status "icu.pl";
    
    $DoItFrom="unwrapped";
    $EndItAt eq $DoItFrom and exit 0;
  }
}else{
  die "ERROR: unknown unwrapping method\n";
}
  
    exit 0; 

=pod

=head1 USAGE

B<int2filtmaskunwrap.pl> 

=head1 FUNCTION

filters, makes the mask, then unwraps.

=head1 ROUTINES CALLED

filter.pl

make_mask.pl

unwrap.pl

=head1 CALLED BY

process_XXX.pl

=head1 FILES USED

I<process_infile>


=head1 HISTORY

Perl  Script : Mark Simons, May 10, 1999

=head1 LAST UPDATE

Frederic Crampe, Aug 25, 1999

=cut
