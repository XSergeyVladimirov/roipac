#!/usr/bin/perl
# *** JPL/Caltech Repeat Orbit Interferometry (ROI) Package ***

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

### removeModel.pl

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/removeModel.pl`;
exit 1;
}
@ARGV == 3 or Usage();
@args = @ARGV;

$InFileint  = shift;  
$InFileunw  = shift; 
$OutFileint = shift; 

#################
Message "Checking I/O";
#################
@Infiles  = ($InFileint, "$InFileint.rsc", 
             $InFileunw, "$InFileunw.rsc");
@Outfiles = ($OutFileint,"$OutFileint.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("removeModel.pl", @args);

##########################################
Message "Reading ressource file: $InFileint.rsc";
##########################################
$width        = Use_rsc "$InFileint read WIDTH";
$length       = Use_rsc "$InFileint read FILE_LENGTH";

########################################################
Message "Remove models : $OutFileint = $InFileint - $InFileunw";
########################################################
`$INT_BIN/rmg2mag_phs $InFileunw amp phs $width`;
`$INT_BIN/mag_phs2cpx amp phs model.int $width`;
`$INT_BIN/add_cpx $InFileint model.int $OutFileint $width $length -1`;
`cp $InFileint.rsc $OutFileint.rsc`;
`rm phs amp`;
`rm model.int`;

exit 0;

=pod

=head1 USAGE

B<removeModel.pl> I<InFileint InFileunw>

intfiles: interferogram is I<InFileint> 
          and the model is I<InFileunw> -> model.int (CPX format)

outfile is I<InFileint> (previous one minus the model)

=head1 FUNCTION

Removes the model to the interferogram

=head1 ROUTINES CALLED

rmg2mag_phs

mag_phs2cpx

add_cpx

=head1 CALLED BY

process.pl

=head1 FILES USED

I<InFileint>

I<InFileint>.rsc

I<InFileunw>

I<InFileunw>.rsc

=head1 FILES CREATED

I<OutFileint>

I<OutFileint>.rsc

=head1 HISTORY

Perl  Script : Frederic Crampe 07/01/98

=head1 LAST UPDATE

Frederic CRAMPE, Jul 28, 1998

=cut
