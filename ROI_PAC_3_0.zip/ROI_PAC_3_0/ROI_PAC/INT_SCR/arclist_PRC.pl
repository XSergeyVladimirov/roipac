#!/usr/bin/perl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

$orbit_dir = shift or $orbit_dir = ".";

chdir $orbit_dir;
$dir = `pwd`;
chomp $dir;

$PRC90s=`ls PRC_9*`;
$PRC00s=`ls PRC_0*`;
$PRL90s=`ls PRL_9*`;
$PRL00s=`ls PRL_0*`;
$RPD90s=`ls RPD_9*.Z`;
$RPD00s=`ls RPD_0*.Z`;
$list=join ' ',$PRC90s,$PRC00s,$PRL90s,$PRL00s,$RPD90s,$RPD00s;
@files = split /\s+/, $list;

open ARC, ">arclist" or die "Can't write to arclist\n";

foreach $file (@files) {
  if ($file =~ /\.Z$/){
    `uncompress -c $file | dd of=tmp bs=130 skip=1 count=1 2>/dev/null`;
  }
  elsif ($file =~ /\.gz$/){
    `gunzip -c $file | dd of=tmp bs=130 skip=1 count=1 2>/dev/null`;
  }
  elsif ( ! ($file =~ /\..*$/)){
    `dd if=$file of=tmp bs=130 skip=1 count=1 2>/dev/null`;
  }
  $start_jd = `dd if=tmp bs=1 skip=6  count=6 2>/dev/null`;
  $end_jd   = `dd if=tmp bs=1 skip=12 count=6 2>/dev/null`;
  print ARC "$dir/$file $start_jd $end_jd\n";
}
`rm tmp 2>/dev/null`;
exit 0;
