#!/usr/bin/perl
# *** JPL/Caltech Repeat Orbit Interferometry (ROI) Package ***

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

### geo2radar.pl

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/geo2radar.pl`;
exit 1;
}
@ARGV >= 2 or Usage();
@args = @ARGV;

$InTable   = shift;  #Lookup table 
$InData    = shift;  #Float array in geo coordinate
$InSimEx   = shift;  #Radar image for example of file size 
$OutData   = shift;  #Float array in radar coordinate


#################
Message "Checking I/O";
#################
@Infiles  = ($InTable,$InData,$InSimEx);
@Outfiles = ($OutData);
&IOcheck(\@Infiles, \@Outfiles);
Log("geo2radar.pl", @args);

#################
Message "Reading ressource file: $InTable.rsc";
#################
$LookupWidth        = Use_rsc "$InTable read WIDTH";
$LookupLength       = Use_rsc "$InTable read FILE_LENGTH";
$LookupLon0         = Use_rsc "$InTable read X_FIRST";
$LookupLat0         = Use_rsc "$InTable read Y_FIRST";
$LookupLonStep      = Use_rsc "$InTable read X_STEP";
$LookupLatStep      = Use_rsc "$InTable read Y_STEP";

#################
Message "Reading ressource file: $InData.rsc";
#################
$GeoWidth           = Use_rsc "$InData read WIDTH";
$GeoLength          = Use_rsc "$InData read FILE_LENGTH";
$GeoLon0            = Use_rsc "$InData read X_FIRST";
$GeoLat0            = Use_rsc "$InData read Y_FIRST";
$GeoLonStep         = Use_rsc "$InData read X_STEP";
$GeoLatStep         = Use_rsc "$InData read Y_STEP";

#################
Message "Reading ressource file: $InSimEx.rsc";
#################
$OutWidth           = Use_rsc "$InSimEx read WIDTH";
$OutLength          = Use_rsc "$InSimEx read FILE_LENGTH";

############################################
Message "Writing input_file: geo2radar.in";
############################################
open INT, ">geo2radar.in";
print INT <<END;
$InData
$GeoLon0 $GeoLonStep $GeoWidth
$GeoLat0 $GeoLatStep $GeoLength
$InTable
$LookupLon0 $LookupLonStep $LookupWidth
$LookupLat0 $LookupLatStep $LookupLength
$OutData
$OutWidth $OutLength
END
close(INT);


`$INT_BIN/geo2radar geo2radar.in`;
#Status "geo2radar";

exit 0;

=pod

=head1 USAGE

B<geo2radar.pl.pl> I<InTable InData InSimEx OutData>

=head1 FUNCTION

builds the simulation files

=head1 ROUTINES CALLED

geo2radar

=head1 FILES USED

I<InTable>

I<InTable>.rsc

I<InData>

I<InData>.rsc

I<InSimEx>

I<InSimEx>.rsc

=head1 FILES CREATED

geo2radar.in

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Frederic CRAMPE 05/22/98
Frederic CRAMPE, Oct 23, 1998
Commented status check, Zhenhong Li, 16 Aug 2005

=head1 LAST UPDATE

Zhenhong Li, 16 Aug 2005

=cut
