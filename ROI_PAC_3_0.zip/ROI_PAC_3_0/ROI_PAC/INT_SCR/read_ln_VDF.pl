#!/usr/bin/perl
### read_VDF.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/read_VDF.pl`;
    exit 1;
}

@ARGV == 1 or Usage();

$recordlength=360;
$VDF=shift;

### Read in values from $VDF
$ThisVol     = ByteRead ($VDF, 98, 2);
$NumOfFiles  = ByteRead ($VDF, 160, 4);
$SceneID     = `dd if=$VDF bs=1 skip=76 count=16 2>/dev/null`;
$SceneID     =~ s/ /0/g;

$NumOfFiles or die;

### Create new name for VDF, instead of just VDF(PID number)
$NVDF     = "VDF${SceneID}T${ThisVol}";

if ($VDF ne $NVDF) {
  `ln -s $VDF $NVDF`; 
  $VDF=$NVDF;
}

### Go through list of files, creating name and finding size of each
for ($i=1; $i <= $NumOfFiles; $i++){
  $Offset     = 116+$i*$recordlength;
  $BlockSize  = ByteRead ($VDF, $Offset, 8);
  $Offset     = 36+$i*$recordlength;
  $FileType   = ByteRead ($VDF, $Offset, 20);
  $Offset     = 140+$i*$recordlength;
  $FirstVol   = ByteRead ($VDF, $Offset, 2);
  $Offset     = 142+$i*$recordlength;
  $LastVol    = ByteRead ($VDF, $Offset, 2);
  $Part       = $ThisVol-$FirstVol+1;
  $Total      = $LastVol-$FirstVol+1;
  $FileName   = "$FileType${SceneID}T${Part}Of${Total}";
  $list      .= "$FileName-$BlockSize ";
}

### Return format: name-size name-size etc.
print "$list\n";
exit 0;

=pod


=head1 USAGE

B<read_VDF.pl> I<VDF_file>

I<VDF_file> = first 360 characters on tape

=head1 FUNCTION

Returns name-size name-size etc for each file on tape

=head1 ROUTINES CALLED

none

=head1 CALLED BY

load_remote_tape.pl

=head1 FILES USED

I<VDF_file>

=head1 FILES CREATED

none

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Frederic CRAMPE, Oct 12, 1998

=cut
