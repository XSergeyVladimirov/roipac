#!/usr/bin/perl
### disp2phase.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/disp2phase.pl`;
exit 1;
}
@ARGV >= 3 or Usage();
@args = @ARGV;

$PhsArray   = shift;  #Output
$look       = shift;
$EastArray  = shift;
$NorthArray = shift;
$UpArray    = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ($look,$EastArray,$NorthArray);
@Outfiles = ($PhsArray);
&IOcheck(\@Infiles, \@Outfiles);
Log("disp2phase.pl", @args);

#####################################################
Message "Reading ressource file: $EastArray.rsc and $look.rsc";
#####################################################
$width            = Use_rsc "$EastArray read WIDTH";
$range_pixel_size = Use_rsc "$look      read RANGE_PIXEL_SIZE";
$wavelength       = Use_rsc "$look      read WAVELENGTH";
$earth_radius     = Use_rsc "$look      read EARTH_RADIUS";
$height           = Use_rsc "$look      read HEIGHT";
$starting_range   = Use_rsc "$look      read STARTING_RANGE";
$heading_deg      = Use_rsc "$look      read HEADING_DEG";

$heading = $heading_deg/180*3.14159;

`$INT_BIN/disp2phase $starting_range   \\
                     $range_pixel_size \\
                     $earth_radius     \\
                     $height           \\
                     $heading          \\
                     $wavelength       \\
                     $width            \\
                     $PhsArray         \\
                     $EastArray        \\
                     $NorthArray       \\
                     $UpArray`;
                     Status "disp2phase";

exit 0;

=pod

=head1 USAGE

B<disp2phase.pl> I<PhsArray EastArray NorthArray UpArray>

=head1 FUNCTION

Buils a phase array combining East North and Up data

=head1 ROUTINES CALLED

disp2phase

=head1 FILES USED

I<EastArray>

I<EastArray>.rsc

I<NorthArray>

I<NorthArray>.rsc

I<UpArray>

I<UpArray>.rsc

=head1 FILES CREATED

I<PhsArray>

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Frederic CRAMPE 05/22/98

=head1 LAST UPDATE

Frederic CRAMPE, May 22, 1998

=cut
