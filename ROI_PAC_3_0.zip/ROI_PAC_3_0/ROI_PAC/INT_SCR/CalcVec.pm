#!/usr/bin/perl
#---#!/usr/bin/perl

package   CalcVec;
require   Exporter;
@ISA    = qw(Exporter);
@EXPORT = qw(VecAdd VecSub VecMulS VecProd3 InnerProd);
use Env qw(INT_SCR INT_BIN);

sub VecAdd {
	@x=split(/\s+/,shift);
	@y=split(/\s+/,shift);

	(@x==@y) or die "Error - VecAdd: Input vectors must have same dimension.\n";
	
	for($i=0; $i<@x; $i++){
		$z[$i]=$x[$i]+$y[$i];
	}
	
	return (@z);
}

sub VecSub {
	@x=split(/\s+/,shift);
	@y=split(/\s+/,shift);

	(@x==@y) or die "Error - VecSub: Input vectors must have same dimension.\n";

	for($i=0; $i<@x; $i++){
		$z[$i]=$x[$i]-$y[$i];
	}
	
	return (@z);
}

sub VecMulS {
	@x=split(/\s+/,shift);
	$y=shift;

	for($i=0; $i<@x; $i++){
		$z[$i]=$x[$i]*$y;
	}
	
	return (@z);
}

sub VecProd3 {
	@x=split(/\s+/,shift);
	@y=split(/\s+/,shift);
	
	(@x==3 && @y==3) or die "Error - VecProd3: Input must be 3 dimensional vector.\n";
	
	$z[0]=$x[1]*$y[2]-$x[2]*$y[1];
	$z[1]=$x[2]*$y[0]-$x[0]*$y[2];
	$z[2]=$x[0]*$y[1]-$x[1]*$y[0];
	
	return(@z);
}

sub InnerProd{
	@x=split(/\s+/,shift);
	@y=split(/\s+/,shift);

	(@x==@y) or die "Error - InnerProd: Input vectors must have same dimension.\n";
	
	$xy=0;
	for($i=0;$i<@x;$i++){
		$xy+=$x[$i]*$y[$i];
	}
	
	return($xy);
}
