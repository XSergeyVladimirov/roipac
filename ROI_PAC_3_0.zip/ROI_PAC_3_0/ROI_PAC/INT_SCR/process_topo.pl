#!/usr/bin/perl
### process_topo.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/process_topo.pl`;
exit 1;
}
@ARGV >= 1 or Usage();
$processfile = shift;
$DoItFrom    = shift or $DoItFrom = "raw";
$EndItAt     = shift or $EndItAt  = "done";

$DoItFrom =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb|full_res|filtered|done_filt|make_mask|unwrapped|simulation|morph_sim|seismic|redo_base|use_sim_base)$/ or Usage();
$EndItAt  =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb|full_res|filtered|done_filt|make_mask|unwrapped|simulation|morph_sim|seismic|redo_base|use_sim_base|done)$/ or Usage();

##########################################################################
Message "Read the inputfile";
##########################################################################
open IN, "$processfile" or die "Can't read $processfile\n";
while (chomp($line = <IN>)){
  $line =~ /=/ or next;
  $line =~ s/\s//g; ###Remove all whitespace
  ($keyname, $value) = split /=/, $line;

  if ($value =~ /,/){ ### more than one value, i.e. models
    @values = split /,/, $value;
    $i=0;
    foreach $val (@values){
      $$keyname[$i] = $val;
      $i++;
    }
  }
  else{
    $$keyname = $value;
  }
}

##########################################################################
Message "Define Variables";
##########################################################################
chomp($dir0=`pwd`);
#### Variables that can be set in int_date1_date2.proc
$SimDir             or $SimDir             = "SIM";
$DEM                or $DEM                = "NULL";
$GeoDir             or $GeoDir             = "GEO";
$FilterStrength     or $FilterStrength     = 0.75;
$UnwrappedThreshold or $UnwrappedThreshold = 0.73;
$OrbitType          or $OrbitType          = "ODR";
$BaselineType       or $BaselineType       = $OrbitType;
$Rlooks_int         or $Rlooks_int         = 1;
$Rlooks_sim         or $Rlooks_sim         = 4;
$Rlooks_sml         or $Rlooks_sml         = 16;
$pixel_ratio        or $pixel_ratio        = 5;
$Alooks_sml         or $Alooks_sml         = $Rlooks_sml*$pixel_ratio;
$before_z_ext       or $before_z_ext       = 1500;
$after_z_ext        or $after_z_ext        = 1500;
$near_rng_ext       or $near_rng_ext       = 700;
$far_rng_ext        or $far_rng_ext        = 0;
$usergivendop1      or $usergivendop1      = 0;
$usergivendop2      or $usergivendop2      = 0;
$unw_seedx          or $unw_seedx          = -9999;
$unw_seedy          or $unw_seedy          = -9999;
$x_start            or $x_start            = 0.01;
$y_start            or $y_start            = 0.01;
$Threshold_mag      or $Threshold_mag      = 5.0e-5;
$Threshold_ph_grd   or $Threshold_ph_grd   = 0;
$sigma_thresh       or $sigma_thresh       = 1.0;
$smooth_width       or $smooth_width       = 5;
$slope_width        or $slope_width        = 5;
$concurrent_roi     or $concurrent_roi     = "no";
$mapping            or $mapping            = "dem_based";
$cleanup            or $cleanup            = "no";
$CO_MODEL           or $CO_MODEL           = "NULL";
$INTER_MODEL        or $INTER_MODEL        = "NULL";
$Filt_method        or $Filt_method        = "psfilt";
$unw_method         or $unw_method         = "old";

$im1 or $im1 = $SarDir1;
$im2 or $im2 = $SarDir2;

$im1 =~ s!.*\/!!g;
$im2 =~ s!.*\/!!g;

$im12 or $im12 = "$im1-$im2";

$slc1 = "$im1.slc";
$slc2 = "$im2.slc";

$Sim = $SimDir;
$Sim =~ s!.*\/!!g;

if ($Rlooks_int > 1){$Lint = "_${Rlooks_int}rlks";}
else{$Lint = "";}
if ($Rlooks_sim > 1){$Lsim = "_${Rlooks_sim}rlks";}
else{$Lsim = "";}
if ($Rlooks_sml > 1){$Lsml = "_${Rlooks_sml}rlks";}
else{$Lsml = "";}

if ( ($CO_MODEL ne "NULL") || ($INTER_MODEL ne "NULL") ){$MODEL = "TRUE";}
else{$MODEL = "NULL";}

$int2simlook = $Rlooks_sim / $Rlooks_int;
$cor_tag     = int($UnwrappedThreshold*100);

$slc1Lsml        = "${im1}${Lsml}.slc";
$slc2Lsml        = "${im2}${Lsml}.slc";
$baseline_file   = "${im1}_${im2}_baseline.rsc";
$flatBorb        = "flat_${OrbitType}_$im12";
$flatBorbLint    = "${flatBorb}${Lint}";
$RampBorb        = "ramp_$OrbitType";
$RampBorbLint    = "${RampBorb}${Lint}";
$corLint         = "${im12}${Lint}";
$corLsim         = "${im12}${Lsim}";
$ampLint         = "${im12}${Lint}";
$ampLsim         = "${im12}${Lsim}";
$ampLunw         = "${im12}${Lunw}";
$filtBorb        = "filt_${OrbitType}_$im12";
$filtBorbLint    = "$filtBorb${Lint}";
$unwBorbLint     = "${filtBorb}_c${cor_tag}${Lint}";
$maskBorbLint    = "phase_var_${OrbitType}${Lint}";
$twopassBorbLsim = "$im12-sim_${OrbitType}${Lsim}";
$twopassBsimLsim = "$im12-sim_SIM${Lsim}";
$totalLint       = "total_${im12}${Lint}";
$msklowcorLint   = "low_cor${Lint}.msk";
$msklowcorLsim   = "low_cor${Lsim}.msk";
$baseestmsk      = "baseest${Lsim}.msk";
$cullLsim        = "${im12}_cull.off";
$totalLsim       = "total_${im12}${Lsim}";
$zeroLint        = "zero${Lint}";
$RampBsimLint    = "ramp_SIM${Lint}";
$flatBsimLint    = "flat_SIM_$im12${Lint}";

# files related to simulation
$SynthIntBorbLsim = "radar_${OrbitType}${Lsim}";
$SynthIntBsimLsim = "radar_SIM${Lsim}";
$HgtRadarGeomLsim   = "radar${Lsim}";
$simLsim          = "${Sim}${Lsim}";
$simLsml          = "${Sim}${Lsml}";
$corLsml          = "${im12}${Lsml}";
$aff_name         = "${im12}${Lsim}_SIM.aff";

# files related to coseismic&interseismic models
$SynthQuakeLsim   = "quakes${Lsim}";
$SynthModelLsim   = "models${Lsim}";
$totalModelLsim   = "total_${im12}-models${Lsim}";

# file for baseline recomputation
if ($MODEL eq "NULL"){$totalbaseest=$totalLsim;}
else{$totalbaseest=$totalModelLsim;}

# files for geocoding
$outgeocoded = "geo_$im12.unw";

###geocode CHANGE interferogram Lsim without topo (put Rlooks_int=4 in .proc)
#$tobegeocoded = "$twopassBsimLsim.unw";     #eq. of change2 with filt. before remov. simu.
#$geocoding_lookupfile = "SIM${Lsim}.trans"; #eq. of change2 with filt. before remov. simu.

###geocode flat interferogram Lint with TOPO
$tobegeocoded = "$flatBsimLint.unw";
$geocoding_lookupfile = "SIM${Lint}.trans";

chdir $dir0;
chdir $SarDir1;
chomp($SarDir1=`pwd`);
chdir $dir0; 
chdir $SarDir2;
chomp($SarDir2=`pwd`);
chdir $dir0;
unless(-d $IntDir) {`mkdir $IntDir`;}
chdir $IntDir;
chomp($IntDir=`pwd`);
chdir $dir0;
unless(-d $GeoDir) {`mkdir $GeoDir`;}
chdir $GeoDir;
chomp($GeoDir=`pwd`);
chdir $dir0;

if ($DEM ne "NULL"){
  unless(-d $SimDir) {`mkdir $SimDir`;}
  chdir $SimDir;
  chomp($SimDir=`pwd`);
}

if (-r "$SarDir1/hdr_data_points_$im1.rsc"){
  `cp $SarDir1/hdr_data_points_$im1.rsc $IntDir/`;
  `cp $SarDir1/hdr_data_points_$im1.rsc $SimDir/`;
  `cp $SarDir1/hdr_data_points_$im1.rsc $GeoDir/`;
}
elsif (-r "$IntDir/hdr_data_points_$im1.rsc"){
  `cp $IntDir/hdr_data_points_$im1.rsc $SimDir/`;
  `cp $IntDir/hdr_data_points_$im1.rsc $GeoDir/`;
}
if (-r "$SarDir2/hdr_data_points_$im2.rsc"){
  `cp $SarDir2/hdr_data_points_$im2.rsc $IntDir/`;
}  

##########################################################################
Message "Go from raw to slc to int and cor (also flattens with orbits)";
##########################################################################
if ($DoItFrom =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb)$/){

`$INT_SCR/raw2ampintcor.pl $DoItFrom          \\
                           $EndItAt           \\
                           $dir0              \\
                           $SarDir1           \\
                           $SarDir2           \\
                           $IntDir            \\
                           $im1               \\
                           $im2               \\
                           $im12              \\
                           $slc1              \\
                           $slc2              \\
                           $baseline_file     \\
                           $usergivendop1     \\
                           $usergivendop2     \\
                           $OrbitType         \\
                           $BaselineType      \\
                           $Rlooks_int        \\
                           $Rlooks_sml        \\
                           $Alooks_sml        \\
                           $slc1Lsml          \\
                           $slc2Lsml          \\
                           $pixel_ratio       \\
                           $x_start           \\
                           $y_start           \\
                           $concurrent_roi    \\
                           $flatBorb          \\
                           $flatBorbLint      \\
                           $RampBorb          \\
                           $corLint           \\
                           $cleanup`; 

                           Status "raw2ampintcor.pl";
  $DoItFrom="full_res";
  $EndItAt =~/^($DoItFrom|roi_prep|orbbase|slcs|offsets|resamp|flatorb)$/ and die "Ended at $EndItAt\n";
}
 
##########################################################################
Message "Filtering";
##########################################################################
if ($DoItFrom =~ /^(full_res|filtered|make_mask)$/){
 
  $DoItFrom2 = "begin_filt";
  $EndItAt2  = "done";

  if ($DoItFrom eq "full_res"   ){$DoItFrom2 = "begin_filt";} 
  if ($DoItFrom eq "filtered"   ){$DoItFrom2 = "done_filt";} 
  if ($DoItFrom eq "make_mask"  ){$DoItFrom2 = "make_mask";} 
  if ($EndItAt  eq "filtered"   ){$EndItAt2  = "done_filt";} 
  if ($EndItAt  eq "make_mask"  ){$EndItAt2  = "make_mask";} 
  if ($EndItAt  eq "unwrapped"  ){$EndItAt2  = "unwrapped";} 

  chdir $IntDir;
  `$INT_SCR/int2filtmaskunwrap.pl $DoItFrom2        \\
                                $EndItAt2           \\
                                $IntDir             \\
                                $flatBorbLint       \\
                                $corLint            \\
                                $ampLint            \\
                                $filtBorbLint       \\
                                $unwBorbLint        \\
                                $maskBorbLint       \\
                                $Filt_method        \\
                                $FilterStrength     \\
                                $Threshold_mag      \\
                                $Threshold_ph_grd   \\
                                $smooth_width       \\
                                $slope_width        \\
                                $sigma_thresh       \\
                                $UnwrappedThreshold \\
                                $unw_seedx          \\
                                $unw_seedy          \\
                                $unw_method         `; 
    
                                Status "int2filtmaskunwrap.pl";
  
  chdir $IntDir;
  #Put low corelation area at 0 in low_cor.msk
  `$INT_SCR/add_rmg.pl $maskBorbLint.msk \\
                       $unwBorbLint.unw  \\
                       $msklowcorLint    \\
                       0 1`; 
                       Status "add_rmg.pl";
  
  $DoItFrom="unwrapped";
  $EndItAt =~/^($DoItFrom|filtered|make_mask)$/ and die "Ended at $EndItAt\n";
}

##########################################################################
Message "Making the Simulation for baseline reestimation and 2 pass approach";
##########################################################################
if ($DoItFrom =~ /^(unwrapped|done_sim_off)$/){

    
  chdir $IntDir;

  `$INT_SCR/look.pl $im12.cor \\
                    $Rlooks_sim`; 
                    Status "look.pl";

  $EndItAt2  = "done";

  if ($DoItFrom eq "unwrapped"       ){$DoItFrom2 = "begin_sim";} 
  if ($DoItFrom eq "done_sim_off"    ){$DoItFrom2 = "done_sim_off";} 
  if ($EndItAt  eq "done_sim_off"    ){$EndItAt2  = "done_sim_off";} 
  if ($EndItAt  eq "done_sim_removal"){$EndItAt2  = "done_sim_removal";} 

  `$INT_SCR/dem2diff.pl $DoItFrom2        \\
                        $EndItAt2         \\
                        $DEM              \\
                        $Sim              \\
                        $SimDir           \\
                        $IntDir           \\
                        $im12             \\
                        $Rlooks_sim       \\
                        $Rlooks_sml       \\
                        $twopassBorbLsim  \\
                        $SynthIntBorbLsim \\
                        $HgtRadarGeomLsim \\
                        $simLsim          \\
                        $simLsml          \\
                        $corLsim          \\
                        $corLsml          \\
                        $aff_name         \\
                        $baseline_file    \\
                        $OrbitType        `;  

                      Status "dem2diff.pl";

  $DoItFrom="done_sim_removal";
  $EndItAt =~/^($DoItFrom|done_sim_off|done_sim_removal)$/ and die "Ended at $EndItAt\n";

  #add the orbit-based flattened unwrapped image and the orbit-based ramp back 
  #together at interferogram resolution
  `$INT_SCR/add_rmg.pl $unwBorbLint.unw  \\
                       $RampBorbLint.unw \\
                       $totalLint.unw    \\
                       1 1`; 
                       Status "add_rmg.pl";
                       
  #Print Simulation information (like heading, lat/lon corner) in rsc
  Use_rsc "$totalLint.unw merge $twopassBorbLsim.int";                     
 
  #Rlook down the total interferogram to simulation resolution
  `$INT_SCR/look.pl $totalLint.unw \\
                    $int2simlook`; 
                    Status "add_rmg.pl";

  #Get unwrapped 2-pass method with orbit derived baselines
  `$INT_SCR/add_rmg.pl $totalLsim.unw           \\
                       $SynthIntBorbLsim.unw    \\
                       $twopassBorbLsim.unw     \\
                       -1 1              `; 
                       Status "add_rmg.pl";

  $DoItFrom="seismic";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";   
}

##########################################################################
Message "Making the deformation models for baseline reestimation";
##########################################################################
if ($DoItFrom eq "seismic"){
  if ($MODEL ne "NULL"){
    chdir $IntDir;
    $aff2geolooks = 1.0;
    `$INT_SCR/radarseismodel.pl $CO_MODEL             \\
                                $INTER_MODEL          \\
                                $geocoding_lookupfile \\
                                $twopassBorbLsim.unw  \\
                                $aff_name             \\
                                $GeoDir               \\
                                $OrbitType            \\
                                $DEM                  \\
                                $aff2geolooks         \\
                                $SynthQuakeLsim.unw   \\
                                $SynthModelLsim.unw   \\
                                $im1`; 
                                Status "radarseismodel.pl";
                                
    `$INT_SCR/add_rmg.pl $totalLsim.unw      \\
                         $SynthModelLsim.unw \\
                         $totalModelLsim.unw \\
                         -1 1`;
  }

  $DoItFrom="morph_sim";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";   
}

##########################################################################
Message "Baseline Re-estimation";
##########################################################################
if ($DoItFrom eq "morph_sim"){

  chdir $IntDir;
                     
if($unw_method eq "old"){
  #Look down the mask file to simulation resolution
  `$INT_SCR/look.pl $msklowcorLint  \\
                    $int2simlook`; 
                    Status "add_rmg.pl";

  #modify mask to have zero value where there is no simulation info
  `$INT_SCR/add_rmg.pl $msklowcorLsim         \\
                       $SynthIntBorbLsim.unw  \\
                       $baseestmsk            \\
                       0 1`; 
                       Status "add_rmg.pl";
}else{
  #Look down the mask file to simulation resolution
  `$INT_SCR/look.pl $maskBorbLint.msk  \\
                    $int2simlook`; 
                    Status "add_rmg.pl";

  #modify mask to have zero value where there is no simulation info
  `$INT_SCR/add_rmg.pl $maskBorbLsim.msk   \\
                       $SynthIntBorbLsim.unw \\
                       $baseestmsk           \\
                       0 1`; 
                       Status "add_rmg.pl";
}


  #get new baselines based on total unwrapped and simulation
  $num      = $Rlooks_sim * $pixel_ratio;

  `$INT_SCR/phase2base.pl $cullLsim            \\
                          $totalbaseest.unw    \\
                          $baseestmsk          \\
                          $UnwrappedThreshold  \\
                          $HgtRadarGeomLsim.hgt\\
                          $Rlooks_sim          \\
                          $num                 \\
                          $baseline_file       \\
                          $OrbitType           \\
                          SIM`; 
                          Status "phase2base.pl";  
   
  $DoItFrom="redo_base";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";   
}

##########################################################################
Message "Use simulation baselines to re-calculate everything";
##########################################################################
if ($DoItFrom eq "redo_base"){

  chdir $IntDir;
                    
  #Get the simulation based flat-earth ramp at the interferogram resolution
  #and reflatten original interferogram with new baseline.
  `$INT_SCR/diffnsim.pl $im12.int         \\
                        $zeroLint.hgt     \\
                        $flatBsimLint.int \\
                        $RampBsimLint.unw \\
                        $Rlooks_int       \\
                        $baseline_file    \\
                        SIM               \\
                        n                 `; 
                        Status "diffnsim.pl"; 

  #reflatten the total unwrapped image by removing the new simulation-derived ramp
  #at the interferogram resolution
  `$INT_SCR/add_rmg.pl $totalLint.unw    \\
                       $RampBsimLint.unw \\
                       $flatBsimLint.unw \\
                       -1 1`; 
                       Status "add_rmg.pl";

  #Repeat 2-pass method with simulation derived baselines (at simulation res)
  `$INT_SCR/diffnsim.pl  $im12.int            \\
                         $HgtRadarGeomLsim.hgt\\
                         $twopassBsimLsim.int \\
                         $SynthIntBsimLsim.unw\\
                         $Rlooks_sim          \\
                         $baseline_file       \\
                         SIM                  \\
                         y                    `; 
                         Status "diffnsim.pl";

  #Get unwrapped 2-pass method with simulation derived baselines (at simulation res)
  `$INT_SCR/add_rmg.pl $totalLsim.unw           \\
                       $SynthIntBsimLsim.unw    \\
                       $twopassBsimLsim.unw     \\
                       -1 1                 `; 
                       Status "add_rmg.pl";

  $DoItFrom="use_sim_base";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n"
}

##########################################################################
Message "Geocoding";
##########################################################################
if ($DoItFrom eq "use_sim_base"){

  chdir $IntDir;
  $aff2geolooks = 1.0;

  `$INT_SCR/radar2geo.pl $mapping              \\
                         $GeoDir               \\
                         $im1                  \\
                         $OrbitType            \\
                         $DEM                  \\
                         $aff_name             \\
                         $aff2geolooks         \\
                         $geocoding_lookupfile \\
                         $tobegeocoded         \\
                         $outgeocoded`; 
                         Status "radar2geo.pl";
                         
  if ($MODEL ne "NULL"){
   `$INT_SCR/geomodel.pl $SynthModelLsim.unw   \\
                         $SynthQuakeLsim.unw   \\
                         $twopassBsimLsim.unw  \\
                         $baseestmsk           \\
                         $geocoding_lookupfile \\
                         geo_$im12`;
                         Status "geomodel.pl";
  }
                          
  $DoItFrom="done";
}

##########################################################################
Message "That\'s all folks";
##########################################################################
exit 0;

=pod

=head1 USAGE

B<process_topo.pl> I<process_infile> [DoItFrom EndItAt]

 DoItFrom = point in process.pl to start
 EndItAt = point in process.pl to end
 Can be: raw, roi_prep, orbbase, slcs, offsets, resamp, flatorb, full_res, filtered, make_mask, unwrapped, simulation, morph_sim, redo_base or use_sim_base

process_infile

 ###Required
 SarDir1     = name of image directory 1
 SarDir2     = name of image directory 2
 IntDir      = name of interferogram directory
 ###Optional (with default values)
 SimDir             = SIM
 DEM                = NULL
 GeoDir             = GEO
 FilterStrength     = 0.75
 UnwrappedThreshold = 0.73
 OrbitType          = ODR
 BaselineType       = OrbitType
 Rlooks_int         = 1
 Rlooks_sim         = 4
 Rlooks_sml         = 16
 pixel_ratio        = 5
 Alooks_sml         = Rlooks_sml*pixel_ratio
 before_z_ext       = 1500
 after_z_ext        = 1500
 near_rng_ext       = 700
 far_rng_ext        = 0
 usergivendop1      = 0
 usergivendop2      = 0
 unw_seedx          = -9999
 unw_seedy          = -9999
 x_start            = 0.01
 y_start            = 0.01
 Threshold_mag      = 5.0e-5
 Threshold_ph_grd   = 0
 sigma_thresh       = 1.0
 smooth_width       = 5
 slope_width        = 5
 concurrent_roi     = no
 mapping            = dem_based
 cleanup            = no
 CO_MODEL           = NULL
 INTER_MODEL        = NULL
 Filt_method        = psfilt

=head1 FUNCTION

Goes from the raw ERS data to geocoded interferogram without topo

=head1 ROUTINES CALLED

raw2ampintcor.pl

int2filtmaskunwrap.pl

look.pl

dem2diff.pl

add_rmg.pl

phase2base.pl

diffnsim.pl

radar2geo.pl

=head1 CALLED BY

none

=head1 FILES USED

I<process_infile>

I<date1>.raw

I<date1>.raw.rsc

I<date2>.raw

I<date2>.raw.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Mark Simons : 05/01/01
=cut
