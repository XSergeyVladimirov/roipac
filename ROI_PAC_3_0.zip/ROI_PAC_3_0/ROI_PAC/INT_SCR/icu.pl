#!/usr/bin/perl
# *** JPL/Caltech Repeat Orbit Interferometry (ROI) Package ***

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

### icu.pl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{`$INT_SCR/pod2man.pl  $INT_SCR/icu.pl`; exit 1;}

@ARGV == 10 or Usage();
@args = @ARGV;

$Int            = shift;
$Unw            = shift;
$Amp            = shift;
$Mask           = shift;
$Intfilt        = shift;
$Filt_method    = shift; #[LP , PS , None]
$FilterStrength = shift;
$cormethod      = shift; #[Slope, NoSlope, Phase Sigma, All]
$filt_width     = shift;
$initial_cor    = shift; #initial correlation threshold to use

#################
Message "Checking I/O";
#################
@Infiles  = ("$Int.int", "$Int.int.rsc", "$Amp.amp", "$Amp.amp.rsc");
@Outfiles = ("$Unw.unw", "$Unw.unw.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("icu.pl", @args);

$width  = Use_rsc "$Int.int read WIDTH";
$length = Use_rsc "$Int.int read FILE_LENGTH";
$rpx0 = 1;
$rpx1 = $width;
$apx0 = 1;
$apx1 = $length;
$napx = $apx1-$apx0+1;

$overlap = 100;
$az_buf  = 3700;
if ($az_buf > $napx) {
  $az_buf = $napx;
}
if ($cormethod eq "Phase_Sigma" ) {
  $cormethod = "Phase Sigma";
}
if ($Filt_method eq "psfilt"){
  $Filt_method = "PS";
}

#################
Message "Making byte mask file";
#################

#make byte mask, with zero everywhere there is no simulation 
#(using amp from intfile)

`cp $Int.int.rsc MaskLunw.byt.rsc`;
`$INT_BIN/cpx2mag_phs $Int.int mag phs $width `;
`$INT_BIN/add_phs      mag phs mag_msk $width $length 0 1`;
`$INT_BIN/mag_phs2rmg  mag_msk phs temp.unw $width`;
`$INT_BIN/rmg2byt      temp.unw MaskLunw.byt $width $length mag 1e-20`;

`rm mag phs mag_msk temp.unw`;

#################
Message "Making necessary RSC files";
#################

`cp $Int.int.rsc $Intfilt.int.rsc`;
`cp $Int.int.rsc $Unw.unw.rsc`;
`cp $Int.int.rsc $Unw.flg.rsc`;
`cp $Unw.unw.rsc $Mask.msk.rsc`;

#################
Message "Create RDF input file";
#################

open RDF, ">icu_unw.in" or die "Can't write to icu_unw.in\n";
print RDF <<END;
                                          icu COMMAND FILE
INPUT FILES

Interferogram File                   (-) = $Int.int
Use Amplitude File                   (-) = Use Amp        ![Use Amp , No Amp]
Amplitude File                       (-) = $Amp.amp      
Use Mask File                        (-) = Use Mask        ![Use Mask, No Mask]
Mask File                            (-) = MaskLunw.byt   !read only if Use Mask
Number of Samples                    (-) = $width
Start and End Sample                 (-) = $rpx0 $rpx1    !less than 3000
Starting Line                        (-) = $apx0         
Number of Lines                      (-) = $napx          !number of lines to process
Azimuth Buffer Size                  (-) = $az_buf        !less than or equal length of file     
Number of Lines in Overlap           (-) = $overlap       !less than half buffer size           
Filtering or Unwrapping              (-) = Both           ![Filtering, Unwrapping, Both]     

INTERFEROGRAM FORMATION AND PHASE UNWRAPPING PARAMETERS

Filtering Method                     (-) = $Filt_method             ![LP , PS , None]
Correlation Estimation Method        (-) = $cormethod               ![Slope, NoSlope, Phase Sigma, All]
Correlation Estimation Box Size      (-) = $filt_width              !MAX size of 11
Phase Sigma Estimation Box Size      (-) = $filt_width              !MAX size of 11
Low Pass Filter Window Size Rng,Az   (-) = $filt_width $filt_width  !fractions of pixel are allowed
Filter Exponent                      (-) = $FilterStrength          !PS Filter strength
Primary Seed Location Adjustment     (-) = 0
Number of Connected Component Seeds  (-) = 31           !should be 2^k - 1, k=1,2,3...
Phase Variance Threshold           (rad) = 8.0 
Initial Correlation Threshold        (-) = $initial_cor !initial corr. threshold to unwrap
Maximum Correlation Threshold        (-) = 0.90         !max corr. threshold, to attempt unwrap
Correlation Threshold Increment      (-) = 0.10         !increment for corr. threshold to unwrap
Phase Gradient Neutron Flag          (-) = 0            ![0,1] 0=no phase gradient neutrons
Phase Gradient Neutron Threshold     (-) = 3.0          !radians/pixels
Intensity Neutron Flag               (-) = 0            ![0,1] 0=no intensity neutrons
Intensity Neutron Threshold          (-) = 8.0		!set to average+value*std. deviation     
Correlation Neutron Threshold        (-) = 0.8		!intensity neutrons must have a correlation
Minimum Phase Bootstrap Points       (-) = 16     	!min. number points overlap for bootstrap
Minimum Phase Bootstrap Lines        (-) = 16     	!min. #points overlap for bootstrap
Number of Tree Sets                  (-) = 7            !number of sets of trees
Tree Type                            (-) = GZW 

OUTPUT FILES
  
Filtered Interferogram File          (-) = ${Intfilt}.int
Unwrapped Phase File                 (-) = ${Unw}.phase
Unwrapped Amplitude File             (-) = ${Unw}.amp
Flag File                            (-) = ${Unw}.flg
Connected Components File            (-) = /dev/null
Phase Gradient File                  (-) = /dev/null
Gradient Corrected Correlation File  (-) = /dev/null
Standard Correlation File            (-) = /dev/null
Phase Sigma File                     (-) = /dev/null
Phase Sigma Correlation File         (-) = ${Unw}.phsig

DEBUG OPTIONS

Patch Output for Debug?              (-) =  No         ! [Yes/No] if yes, need more files
All Unwrapped File                   (-) =  /dev/null
All Flag File                        (-) =  /dev/null
All Connected Components File        (-) =  /dev/null

END
close(RDF);

#################
Message "Unwrapping with icu";
#################

`$INT_BIN/icu icu_unw.in > icu_unw.out`;

#################
Message "Making mask file as combination of correlation and unwrapped area";
#################

`$INT_BIN/mag_phs2rmg ${Unw}.amp ${Unw}.phase ${Unw}.unw $width`;
`$INT_BIN/mag_phs2rmg ${Unw}.amp ${Unw}.phsig  temp1.msk $width`;
`$INT_BIN/mag_phs2rmg ${Unw}.amp ${Unw}.amp    temp2.msk $width`;
`cp ${Unw}.unw.rsc temp1.msk.rsc`;
`cp ${Unw}.unw.rsc temp2.msk.rsc`;

`$INT_SCR/add_rmg.pl temp1.msk   \\
                     temp2.msk   \\
                     ${Mask}.msk \\
                     0 1`; 
                     Status "add_rmg.pl";

#clean up
`rm ${Unw}.amp ${Unw}.phsig ${Unw}.phase temp1.msk temp1.msk.rsc temp2.msk temp2.msk.rsc`;

exit 0;

=pod

=head1 USAGE

B<icu.pl> I< Int Unw Amp Mask IntFilt filter_method filter_strength correlation_method filter_width initial_cor>

Choices:

Filenames are all preficies.

Filt_method     = LP (low pass), PS/psfilt (power spectra), None
filter_strength = >0, typically 0.5 to 1
cormethod       = Slope, NoSlope, Phase_Sigma, All
initial_cor     = 0 to 1

=head1 FUNCTION

Filt_Method and unwrap an interferogram using icu.

=head1 ROUTINES CALLED

icu

add_rmg.pl

=head1 CALLED BY

process.pl

=head1 FILES USED

I<Int>.int

I<Int>.int.rsc

I<Amp>.amp

I<Amp>.amp.rsc

=head1 FILES CREATED

I<unw>.unw

I<unw>.unw.rsc

I<icu.cor>

I<icu.cor.rsc>

I<mask.cor>

I<mask.cor.rsc>

=head1 HISTORY

Perl  Script : Frederic CRAMPE 05/29/98

=head1 LAST UPDATE

Frederic CRAMPE, October 20, 1998

=cut
