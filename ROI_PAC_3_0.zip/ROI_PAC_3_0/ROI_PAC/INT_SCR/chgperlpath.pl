#!/usr/bin/perl
print "ChgPerlPath - Change the path to perl in all *.pl scripts.\n";

#written by Herb Siegel
#for Jet Propulsion Lab
#last update 08/16/98

#find out where perl is installed, try default of /usr/bin/perl first
$deflt = "/usr/bin/perl";
@perls = split(' ',$deflt." ".`whereis perl`);
$perlpath = shift;
if ($perlpath eq "default") {
    print "Using default path of $deflt\n";
    $perlpath = $deflt;
}
if ($perlpath eq "") {
PERL:
    foreach $item (@perls) {
	if ($item =~ /.*perl$/) {
	    if (-f $item && -x $item && ! -d $item){
		@lines = split('\n',`$item -v`);
		foreach $line (@lines){
		    if ($line =~ /.*version\b(.*)/) {
			if ($1 >= 5.004) {
			    print "$item is $1\n" if ($1 >= 5.004);
			    $perlpath = $item if ($1 >= 5.004);
			    last PERL;
			}
		    }
		}
	    }
	}
    }
}

if ($perlpath eq ""){
    print STDERR
	"Could not locate an appropriate version of perl on this system\n";
    print STDERR "What is the path for perl 5.004 (or greater)?\n";
    $perlpath = <STDIN>;
    chop ($perlpath);
}
print "Setting perl5 path to $perlpath\n";

opendir(THISDIR,".");
while ($_ = readdir(THISDIR)) {
	if (/\.pl$/) {
	    $orig = $_;
	    $count++;
	    print $orig "\n";
	    open(FILE, $orig) || die "Can't open $file: $!\n";
	    $line = <FILE>;
	    chop ($line);
	    if ($line =~ /^#!\S*\s*(.*)/) {
		$options = $1;
		open (OUT, ">outscript") || die "Can't create outscript\m";
		if ($options eq "") {
		    print $count," ",$orig,"\n";
		    print OUT "#!$perlpath\n";
		}
		else {
		    print $count," ",$orig," options: ",$options,"\n";
		    print OUT "#!$perlpath $options\n";
		}
		while ($line = <FILE>){
		    print OUT $line;
		}
		close(OUT);
		close(FILE);
		unlink($orig);
		rename("outscript",$orig);
		chmod(0755,$orig);
	    }
	    else {
		print $orig, " is not a perl script\n";
		close(FILE);
	    }

	}	
}
closedir(THISDIR);
print "count: ",$count,"\n";
