#!/usr/bin/perl
### doc_leader.pl

# $Id: doc_leader.pl,v 1.1.1.1 2007/04/17 22:28:01 ericmg Exp $
#
# $Log: doc_leader.pl,v $
# Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1.1.1  2007/04/03 03:40:01  ericmg
# initial import into erda insarcvs
#
# Revision 1.1  2005/12/16 18:45:39  bswift
# RSC keyword documentation changes.
#

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;


###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/doc_dem.pl`;
exit 1;
}
@ARGV == 1 or Usage();

$raw_file       = shift;

$common_RSC_Derivation = q[
    Keyword and value are produced by leader2rsc
    which extracts values from CEOS $leader_file
    for fields described by a format_leaderfile_$facility formatfile.

    make_raw.pl determines the $facility and runs
      leader2rsc $leader_file $INT_SCR/format_leaderfile_$facility tmp_IMAGERY.raw.rsc
    and later tmp_IMAGERY.raw.rsc becomes ${date}.raw.rsc via
      mv tmp_IMAGERY.raw.rsc ${date}.raw.rsc
    ];

$common_RSC_Comment = q[
    Field documentation from
      http://www.asf.alaska.edu/reference_documents/dataset_references/radarsat/r_data_set_summary_record.html
    which is linked to from
      http://www.asf.alaska.edu/user_serv/ceos_specs.html
    ];



$toss_it = Use_rsc "$raw_file read DATE";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   Part of "Input scene centre time" (INP_SCTIM) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => String,
 RSC_Format => 'YYMMDD',
);


$toss_it = Use_rsc "$raw_file read FIRST_LINE_YEAR";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   Part of "Input scene centre time" (INP_SCTIM) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => String,
 RSC_Format => 'YYYY',
);


$toss_it = Use_rsc "$raw_file read FIRST_LINE_MONTH_OF_YEAR";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   Part of "Input scene centre time" (INP_SCTIM) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => String,
 RSC_Format => 'MM',
);


$toss_it = Use_rsc "$raw_file read FIRST_LINE_DAY_OF_MONTH";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   Part of "Input scene centre time" (INP_SCTIM) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => String,
 RSC_Format => 'DD',
);


$toss_it = Use_rsc "$raw_file read I_BIAS";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   "I channel DC bias" (I_BIAS) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => Real,
 RSC_Unit => 'needs further investigation',
);


$toss_it = Use_rsc "$raw_file read Q_BIAS";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   "Q channel DC bias" (Q_BIAS) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => Real,
 RSC_Unit => 'needs further investigation',
);


$toss_it = Use_rsc "$raw_file read PROCESSING_FACILITY";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   "Processing facility identifier" (FAC_ID) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => String,
 RSC_Format => 'A16',
);


$toss_it = Use_rsc "$raw_file read PROCESSING_SYSTEM";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   "Processing system identifier" (SYS_ID) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => String,
 RSC_Format => 'A8',
);


$toss_it = Use_rsc "$raw_file read PROCESSING_VERSION";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
   "Processing version identifier" (VER_ID) field,
   in the "Data Set Summary Record".
   ],
 RSC_Derivation => $common_RSC_Derivation ,
 RSC_Comment => $common_RSC_Comment ,
 RSC_Type => String,
 RSC_Format => 'A8',
);


=pod

=head1 USAGE

B<doc_leader.pl> I<raw_file>

=head1 FUNCTION

Reads keywords in I<date.raw>.rsc to produce standard documentation,
since these keywords are created by the leader2rsc application
and not by "Use_rsc" operations in the perl scripts.

=head1 ROUTINES CALLED

=head1 CALLED BY

=head1 FILES USED

=head1 FILES CREATED

=head1 HISTORY

 $Log: doc_leader.pl,v $
 Revision 1.1.1.1  2007/04/17 22:28:01  ericmg
 initial import into erda insarcvs

 Revision 1.1.1.1  2007/04/03 03:40:01  ericmg
 initial import into erda insarcvs

 Revision 1.1  2005/12/16 18:45:39  bswift
 RSC keyword documentation changes.


=head1 LAST UPDATE

 $Id: doc_leader.pl,v 1.1.1.1 2007/04/17 22:28:01 ericmg Exp $

=cut
