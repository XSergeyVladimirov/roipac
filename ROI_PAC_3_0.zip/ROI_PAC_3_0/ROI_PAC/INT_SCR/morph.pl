#!/usr/bin/perl 
### morph.pl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{
`$INT_SCR/pod2man.pl  $INT_SCR/morph.pl`;
    exit 1;
}

@ARGV == 3  or Usage();
@args  = @ARGV;

$infile       = shift;
$infile_morph = shift;
$offsetfile0  = shift;

##### presumes that one has run offset.pl on the 
##### two correlation files and has NOT culled the file

#####################################
Message "culling offset field";
#####################################

$cullfile = "cull_morph.off";
`$INT_BIN/fitoff $offsetfile0 $cullfile 1.5 0.05 50 > cull.out`;

#####################################
Message "extracting affine transformation parameters and registering simulation ";
#####################################

($m11, $m12, $m21, $m22, $t1, $t2) = split /\s+/, `$INT_SCR/find_affine.pl cull.out`;
Status "find_affine.pl";

`$INT_SCR/rect.pl $infile $infile_morph $m11, $m12, $m21, $m22, $t1, $t2`;

#####################

exit 0;

=pod

=head1 USAGE

B<morph.pl> I<date>
Usage: morph.pl prefix unculled_offsets

Will look locally for:  infile(.rsc)
	                offset file

=head1 FUNCTION

Morphs an unwrapped file to a different coordinate system.

=head1 ROUTINES CALLED

=head1 CALLED BY

=head1 FILES USED

=head1 FILES CREATED

=head1 HISTORY

Perl  Script : Mark Simons, September 15, 1998

=head1 LAST UPDATE

Mark Simons, September 15, 1998

=cut
