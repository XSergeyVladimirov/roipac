#!/usr/bin/perl
###resamp.pl 

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/resamp.pl`;
exit 1;
}
@ARGV >= 5 or Usage();
@args = @ARGV;
 
$date1    = shift;
$date2    = shift;
$look_r   = shift or $look_r = 1;
$look_z   = shift or $look_z = $look_r*4;
$MPI_PARA   = shift;
$NUM_PROC   = shift;
$ROMIO      = shift;
$file1    = "$date1.slc";
$file2    = "$date2.slc";
$cullfile = "$date1-${date2}_cull.off";
$intfile  = "$date1-$date2.int";
$ampfile  = "$date1-$date2.amp";

#################
Message "Checking I/O";
#################
@Infiles  = ($file1, "$file1.rsc", 
             $file2, "$file2.rsc",
	     $cullfile, "$cullfile.rsc");
@Outfiles = ($intfile, "$intfile.rsc", 
             $ampfile, "$ampfile.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log("resamp.pl", @args);

##########################################
Message "Reading resource files: $file1.rsc and $file2.rsc";
##########################################
$width1         = Use_rsc "$file1 read WIDTH";
$length         = Use_rsc "$file1 read FILE_LENGTH";
$ymin           = Use_rsc "$file1 read YMIN";
$ymax           = Use_rsc "$file1 read YMAX";
$xmin           = Use_rsc "$file1 read XMIN ";
$xmax1           = Use_rsc "$file1 read XMAX ";
$wavelength     = Use_rsc "$file1 read WAVELENGTH";
$rng_pixel_size = Use_rsc "$file1 read RANGE_PIXEL_SIZE";
$az_pixel_size  = Use_rsc "$file1 read AZIMUTH_PIXEL_SIZE";
$delta_line_utc = Use_rsc "$file1 read DELTA_LINE_UTC";
$first_line_utc = Use_rsc "$file1 read FIRST_LINE_UTC";
$last_line_utc  = Use_rsc "$file1 read LAST_LINE_UTC";
$dop_rng0       = Use_rsc "$file1 read DOPPLER_RANGE0";
$dop_rng1       = Use_rsc "$file1 read DOPPLER_RANGE1";
$dop_rng2       = Use_rsc "$file1 read DOPPLER_RANGE2";
$dop_rng3       = Use_rsc "$file1 read DOPPLER_RANGE3";
$starting_rng1  = Use_rsc "$file1 read STARTING_RANGE";

$xmax2          = Use_rsc "$file2 read XMAX";
$ymax2          = Use_rsc "$file2 read YMAX";
$width2         = Use_rsc "$file2 read WIDTH";
$starting_rng2  = Use_rsc "$file2 read STARTING_RANGE";

#$dop0 = $dop_rng0+($dop_rng1+$dop_rng2*$starting_rng)*$starting_rng;
#$dop1 = ($dop_rng1+2*$dop_rng2*$starting_rng*$rng_pixel_size)*$rng_pixel_size;
#$dop2 = $dop_rng2*$rng_pixel_size*$rng_pixel_size;
$dop0 = $dop_rng0;
$dop1 = $dop_rng1;
$dop2 = $dop_rng2;
$dop3 = $dop_rng3;


#################################
Message "Computing new lengths";
#################################
open CULL, "$cullfile" or die "Can't open $cullfile";

while (<CULL>){
  @line = split /\s+/, $_;
  push @Y, $line[4]; 
}
close (CULL);

# Gets median of values
$dy = Median(\@Y);
$dy = int($dy);
if ($dy < 0){ ### Second scene starts later than first scene
  $new_ymin       = $ymin - $dy;
  $first_line_utc = $first_line_utc - $dy*$delta_line_utc;
}
else{ ### Second scene starts earlier than first scene
  $new_ymin = $ymin;
}

if ($ymax > $ymax2 - $dy) {
  $new_ymax      = $ymax2 - $dy;
# $last_line_utc = $last_line_utc - $dy*$delta_line_utc;
  $last_line_utc = $last_line_utc - ($ymax-($ymax2-$dy))*$delta_line_utc;
}
else {
  $new_ymax = $ymax;
}

$new_length = $new_ymax - $new_ymin + 1;

$new_center_line_utc = ($first_line_utc + $last_line_utc)/2;

#############################################
Message "Writing resource file: $intfile.rsc";
#############################################
$int_length = int($new_length / $look_z);
$int_width  = int(Min($width1,$width2)     / $look_r);
$int_ymin   = 0;
$int_ymax   = $int_length - 1;
$int_xmin   = int($xmin       / $look_r);
$int_xmax   = int(Min($xmax1,$xmax2)       / $look_r);
$int_rpix   = $rng_pixel_size * $look_r;
$int_azpx   = $az_pixel_size  * $look_z;
$int_dt     = $delta_line_utc * $look_z;

Use_rsc "$intfile write FILE_LENGTH             $int_length";
Use_rsc "$intfile write STARTING_RANGE1         $starting_rng1";
Doc_rsc(
 RSC_Tip => 'Scene 1 starting range',
 RSC_Doc => q[
   Starting Ranges for SLCs, based on RDF usage in diffnsim.pl and phase2base.pl.
   ],
 RSC_Derivation => q[
   Value of STARTING_RANGE keyword from scene 1 SLC file.
   ],
 RSC_Comment => q[
   Values from two scenes seem to be identical.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);

Use_rsc "$intfile write STARTING_RANGE         $starting_rng1";
Doc_rsc(
 RSC_Tip => 'Interferogram starting range',
 RSC_Doc => q[
   Starting Ranges for interferogram should be same as scene 1 SLC.
   ],
 RSC_Derivation => q[
   Value of STARTING_RANGE keyword from scene 1 SLC file.
   ],
 RSC_Comment => q[
   Values from two scenes usually, but not always identical.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


Use_rsc "$intfile write STARTING_RANGE2         $starting_rng2";
Doc_rsc(
 RSC_Tip => 'Scene 2 starting range',
 RSC_Doc => q[
   Starting Ranges for SLCs, based on RDF usage in diffnsim.pl and phase2base.pl.
   ],
 RSC_Derivation => q[
   Value of STARTING_RANGE keyword from scene 2 SLC file.
   ],
 RSC_Comment => q[
   Values from two scenes seem to be identical.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);

Use_rsc "$intfile write STARTING_RANGE2         $starting_rng2";

Use_rsc "$intfile write WIDTH                   $int_width ";
Use_rsc "$intfile write XMIN                    $int_xmin";
Use_rsc "$intfile write XMAX                    $int_xmax";
Use_rsc "$intfile write YMIN                    $int_ymin ";
Use_rsc "$intfile write YMAX                    $int_ymax ";
Use_rsc "$intfile write RANGE_PIXEL_SIZE        $int_rpix";
Use_rsc "$intfile write AZIMUTH_PIXEL_SIZE      $int_azpx";
Use_rsc "$intfile write DELTA_LINE_UTC          $int_dt";
Use_rsc "$intfile write FIRST_LINE_UTC          $first_line_utc";
Use_rsc "$intfile write CENTER_LINE_UTC         $new_center_line_utc";
Use_rsc "$intfile write LAST_LINE_UTC           $last_line_utc";
Use_rsc "$intfile write SLC_RELATIVE_YMIN       $new_ymin";
Use_rsc "$intfile write RLOOKS                  $look_r";
Use_rsc "$intfile write ALOOKS                  $look_z";

# this grabs other info out of the *ampcor*.rsc file
`$INT_SCR/use_rsc.pl $intfile merge $cullfile`;
#############################################
Message "Writing resource file: $ampfile.rsc";
#############################################
`cp $intfile.rsc $ampfile.rsc`;

##################################################
Message "Writing resamp input file: $date1-${date2}_resamp.in";
##################################################

$new_ymin++; ### since resamp_roi can't start at line 0

open RESAMP, ">$date1-${date2}_resamp.in" or die "Can't write to $date1-${date2}_resamp.in\n";
print RESAMP <<END;

Image Offset File Name                                  (-)     = $cullfile
Display Fit Statistics to Screen                        (-)     = No Fit Stats    
Number of Fit Coefficients                              (-)     = 6
SLC Image File 1                                        (-)     = $file1
Number of Range Samples Image 1                         (-)     = $width1
SLC Image File 2                                        (-)     = $file2
Number of Range Samples Image 2                         (-)     = $width2
Output Interferogram File                               (-)     = $intfile
Multi-look Amplitude File                               (-)     = $ampfile
Starting Line, Number of Lines, and First Line Offset   (-)     = $new_ymin    $new_length 1
Doppler Cubic Fit Coefficients - PRF Units              (-)     = $dop0 $dop1 $dop2 $dop3 
Radar Wavelength                                        (m)     = $wavelength
Slant Range Pixel Spacing                               (m)     = $rng_pixel_size
Number of Range and Azimuth Looks                       (-)     = $look_r $look_z
Flatten with offset fit?                                (-)     = No 

END
    close(RESAMP);
###################################################
    
if($MPI_PARA eq "yes" and $NUM_PROC > 1) {
  ##### use these two lines if you do not want or cannot choose processors, or
  Message  "mpirun -np $NUM_PROC $INT_BIN/mpi_resamp_roi  $date1-${date2}_resamp.in $ROMIO > $date1-${date2}_resamp.out";
  `mpirun -np $NUM_PROC $INT_BIN/mpi_resamp_roi  $date1-${date2}_resamp.in $ROMIO > $date1-${date2}_resamp.out`;
  ##### use these two lines if you do want to choose processors
  ##### you will need to have a file named machines.LINUX under your home directo
ry
  ##### that lists all the IP's of the machines you want to choose
  ##Message "mpirun -nolocal -machinefile ~/machines.LINUX -np $NUM_PROC $INT_BIN/mpi_resamp_roi $date1-${date2}_resamp.in $ROMIO > $date1-${date2}_resamp.out";
  ##`mpirun -nolocal -machinefile ~/machines.LINUX -np $NUM_PROC $INT_BIN/mpi_resamp_roi $date1-${date2}_resamp.in $ROMIO > $date1-${date2}_resamp.out`;
}
else {
  print  "$INT_BIN/resamp_roi  $date1-${date2}_resamp.in > $date1-${date2}_resamp.out";
  `$INT_BIN/resamp_roi $date1-${date2}_resamp.in > $date1-${date2}_resamp.out`;
}
Status "resamp_roi";

exit 0;

=pod

=head1 USAGE

B<resamp.pl> I<date1 date2 look_r look_z>

date1: the SLC is I<date1>.slc

date2: the SLC is I<date2>.slc

look_r: looks to take in range(default is 1)

look_z: looks to take in azimuth(default is 4*I<look_r>)

=head1 FUNCTION

Uses 2 SLCs and an offset field to generate interferogram and amplitude file

=head1 ROUTINES CALLED

resamp_roi

=head1 CALLED BY

process.pl

=head1 FILES USED

I<date1>.slc

I<date2>.slc

I<date1>.slc.rsc

I<date2>.slc.rsc

I<date1>-I<date2>_cull.off

I<date1>-I<date2>_cull.off.rsc

=head1 FILES CREATED

I<date1>-I<date2>.int

I<date1>-I<date2>.amp

I<date1>-I<date2>.int.rsc

I<date1>-I<date2>.amp.rsc

I<date1>-I<date2>_resamp.in

I<date1>-I<date2>_resamp.out

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

Rowena Lohman, Jun 10, 1998

=head1 LAST UPDATE

Eric Fielding, Jan. 12, 2006

=cut
