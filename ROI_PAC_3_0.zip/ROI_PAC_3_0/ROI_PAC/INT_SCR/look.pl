#!/usr/bin/perl
###look.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/look.pl`;
exit 1;
}
@ARGV > 0 or Usage();
@args = @ARGV;

### Get arguments and check if default # looks are needed
$infile     = shift;
$Rlooks     = shift;
$Alooks     = shift;

$Rlooks or $Rlooks = 4;
$Alooks or $Alooks = $Rlooks;

$infile =~ /\.(slc|int|cor|unw|amp|hgt|msk|dem|byt)$/ or Usage();
$prefix = $`;
$suffix = $1;

### Extract file suffix, prefix and total number of looks
if ($infile =~ m!_(\d+)rlks!){
  $totallooks = $Rlooks*$1;
  $outfile = "$`"."_$totallooks"."rlks$'";
}
else {
  $totallooks = $Rlooks;
  $outfile = $prefix."_".$Rlooks."rlks.$suffix";
}
if ($Rlooks == 1 and $Alooks == 1){
  exit 0;
}

#################
Message "Checking I/O";
#################
@Infiles  = ($infile, "$infile.rsc");
@Outfiles = ($outfile,"$outfile.rsc");
&IOcheck(\@Infiles, \@Outfiles);
Log ("look.pl", @args);

### Obtain old .rscfile data
$width              = Use_rsc "$infile read WIDTH";
$length             = Use_rsc "$infile read FILE_LENGTH";
$xmin               = Use_rsc "$infile read XMIN";
$xmax               = Use_rsc "$infile read XMAX";
$ymin               = Use_rsc "$infile read YMIN";
$ymax               = Use_rsc "$infile read YMAX";

if ($suffix =~ /(dem|dte|dtm)/){
  $oldRlooks          = Use_rsc "$infile read RLOOKS";
  if ($oldRlooks) {
    $oldAlooks          = Use_rsc "$infile read ALOOKS";
  }
  else{
    $oldRlooks = 1;
    $oldAlooks = 1;
  }
}
else{
  $start              = Use_rsc "$infile read FILE_START";
  $delta_line_utc     = Use_rsc "$infile read DELTA_LINE_UTC";
  $oldRlooks          = Use_rsc "$infile read RLOOKS";
  $oldAlooks          = Use_rsc "$infile read ALOOKS";
  $oldRlooks == 0 and die "Need to fix $infile.rsc for looks\n";
  $range_pixel_size   = Use_rsc "$infile read RANGE_PIXEL_SIZE";
  $azimuth_pixel_size = Use_rsc "$infile read AZIMUTH_PIXEL_SIZE";

  $range_pixel_size   = $range_pixel_size*$Rlooks;
  $azimuth_pixel_size = $azimuth_pixel_size*$Alooks;
  $delta_line_utc     = $delta_line_utc*$Alooks;
  Use_rsc "$outfile write DELTA_LINE_UTC     $delta_line_utc";
}

unless ($range_pixel_size){
  $xstep              = Use_rsc "$infile read X_STEP";
  $ystep              = Use_rsc "$infile read Y_STEP";
}

### Write new .rscfile
Use_rsc "$outfile merge $infile";

$newwidth           = int($width/$Rlooks);
$newlength          = int($length/$Alooks);
$xmin               = int($xmin/$Rlooks);
$xmax               = int($xmax/$Rlooks);
$ymin               = int($ymin/$Alooks);
$ymax               = int($ymax/$Alooks);
$xstep              = $xstep*$Rlooks;
$ystep              = $ystep*$Alooks;
$newRlooks          = $oldRlooks*$Rlooks;
$newAlooks          = $oldAlooks*$Alooks;

Use_rsc "$outfile write WIDTH              $newwidth";
Use_rsc "$outfile write FILE_LENGTH        $newlength";
Use_rsc "$outfile write FILE_START         $start";
Use_rsc "$outfile write XMIN               $xmin";
Use_rsc "$outfile write XMAX               $xmax";
Use_rsc "$outfile write YMIN               $ymin";
Use_rsc "$outfile write YMAX               $ymax";
Use_rsc "$outfile write DELTA_LINE_UTC     $delta_line_utc";
Use_rsc "$outfile write RLOOKS             $newRlooks";
Use_rsc "$outfile write ALOOKS             $newAlooks";

if ($range_pixel_size) {
  Use_rsc "$outfile write RANGE_PIXEL_SIZE   $range_pixel_size";
  Use_rsc "$outfile write AZIMUTH_PIXEL_SIZE $azimuth_pixel_size";
}
else {
  Use_rsc "$outfile write X_STEP             $xstep";
  Use_rsc "$outfile write Y_STEP             $ystep";
}

################
Message "Wrote new rscfile";
################
if ($suffix eq "hgt"){
  $azimuth_pixel_grnd = Use_rsc "$infile read AZIMUTH_PIXEL_GROUND";
  $azimuth_pixel_grnd = $azimuth_pixel_grnd*$Rlooks;
  Use_rsc "$outfile write AZIMUTH_PIXEL_GROUND $azimuth_pixel_grnd";
Doc_rsc(
 RSC_Tip => '',
 RSC_Doc => q[
    Uninitialized keyword.
   ],
 RSC_Derivation => q[
    Value is 0 because look.pl is reading keyword
    that has not been written prior to look.pl being called.

    Only occurs when file with 'hgt' $suffix given to look.pl
   ],
 RSC_Comment => q[
    Value does not appear to be used anywhere.
   ],
 RSC_Type => Real,
 RSC_Unit => 'SI:meter',
);


}

################
Message "Using lookdown routine";
### Use one of the lookdown programs, depending on the suffix

if ($suffix eq "amp"){
  open LOOK, "|$INT_BIN/rilooks";
  print LOOK "$infile
$outfile
$width  $length
$Rlooks $Alooks\n" or die "Lookdown failed: $!\n";
  close(LOOK);
}
elsif ($suffix =~ /int/){
  open LOOK, "|$INT_BIN/cpxlooks";
  print LOOK "$infile
$outfile
$width  $length
$Rlooks $Alooks
0 0\n" or die "Lookdown failed: $!\n";
  close(LOOK);
}
elsif ($suffix =~/slc/){
  open LOOK, "|$INT_BIN/powlooks";
  print LOOK "$infile
$outfile
$width $length
$Rlooks $Alooks
0 0\n" or die "Lookdown failed: $!\n";
  close(LOOK);
}
elsif ($suffix =~ /(cor|hgt|unw|msk)/){
  `$INT_BIN/nbymhgt $infile $outfile $width $Rlooks $Alooks`;
  Status "nbymhgt";
}
elsif ($suffix =~ /(dem|dte|dtm)/){
  `$INT_BIN/nbymdem $infile  \\
                    $outfile \\
                    $width   \\
                    $Rlooks  \\
                    $Alooks`;
  Status "nbymdem";
}
elsif ($suffix =~ /(byt)/){
  `$INT_BIN/nybmbyt $infile  \\
                    $outfile \\
                    $width   \\
                    $length  \\
                    $Rlooks  \\
                    $Alooks`;
  Status "nbymbyt";
}
       
`rm -f core`;
`rm -f keywords`;
exit 0;
=pod

=head1 USAGE

B<look.pl> I<imagefile [looks in range] [looks in azimuth]>

default number of looks in range = 4

default number of looks in azimuth = looks in range

 Recognizes: *.slc
             *.int
       	     *.cor
	     *.unw
	     *.amp
	     *.hgt
	     *.msk
             *.dem
             *.dte
             *.dtm
             *.byt

=head1 FUNCTION

Takes specified number of looks down on imagefile

=head1 ROUTINES CALLED

rilooks 

nbymhgt

cpxlooks

powlooks

=head1 CALLED BY

process.pl

make_sim.pl

=head1 FILES USED

I<imagefile>

I<imagefile>.rsc

=head1 FILES CREATED

I<imagefile>_I<looks>rlks

I<imagefile>_I<looks>rlks.rsc

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Rowena Lohman, Oct 13, 1999

=cut
