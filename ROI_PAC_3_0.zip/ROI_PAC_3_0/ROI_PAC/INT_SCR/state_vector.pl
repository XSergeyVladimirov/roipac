#!/usr/bin/perl
### state_vector.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN SAR_ODR_DIR SAR_PRC_DIR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check

sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/state_vector.pl`;
exit 1;
}
@ARGV >= 4 or Usage();
Log ("state_vector.pl", @ARGV);

### Obtain arguments from command line
$date       = shift;
$utc        = shift;
$sat        = shift;
$orbit_type = shift;
$hdrdate    = shift;

if (($orbit_type eq "PRC") & ($SAR_PRC_DIR eq "REMOTE")){
  $string=`$INT_SCR/orbit_client.pl $date $utc $sat $orbit_type $hdrdate`;
  
  ### Convert lat lon to radian if necessary ( kludge ) ### 
  
  $Pi =  4 * atan2( 1, 1 );
  @Data = split( /\s+/, $string );
  if( ( abs($Data[2]) > $Pi ) || ( abs($Data[3]) > 2*$Pi ) ){
  	$Data[2] *= $Pi / 180;
  	$Data[3] *= $Pi / 180;
  	$string =  join( " ", @Data ) . "\n\n";
  }

  print "$string\n"; 
}

elsif (($orbit_type eq "ODR") & ($SAR_ODR_DIR eq "REMOTE")){
  $string=`$INT_SCR/orbit_client.pl $date $utc $sat $orbit_type $hdrdate`;
  print "$string\n";
}

elsif ($orbit_type eq "HDR"){
  $hdrfile = "hdr_data_points_$hdrdate.rsc";
  if (-r "hdr_data_points_$hdrdate.rsc"){
   $string = `$INT_BIN/HDR2polynom $hdrfile $utc`;
### Return vector values
   print "HDR 0 0 0 0 $string\n";
  }
  else{
   print STDERR "$hdrfile file not found\n";
   exit 1;
  }
}

elsif ($orbit_type eq "ODR"){
  $orbit_dir  = "$SAR_ODR_DIR/$sat";
###force to particular ODR file if SAR_ODR_FILE set
  $orbit_dir = "+".$orbit_dir."/".$ENV{"SAR_ODR_FILE"}
  	if ($ENV{"SAR_ODR_FILE"} ne "");
###Convert to MJD format for better precision in getorb
  $_ = $date;
  /(\d\d\d\d)(\d\d)(\d\d)/;
  $year  = $1;
  $month = $2;
  $day   = $3;
### convert and add factor for getorb MJD format
  $epoch    = `$INT_BIN/YYYYMMDD2Jul $year $month $day $utc`+51544.5;

  ($q0, $q1, $success, $lat, $lon, $h, $x0, $y0, $z0) = split /\s+/,
  `$INT_BIN/getorb mjd=$epoch $orbit_dir 2>/dev/null`;
  if( $success > 0 ) { die "'getorb mjd=$epoch $orbit_dir' failed in state_vector.pl: $!\n";}
  if( $success < 0 ) { $success = 0; Log( "getorb interpolating outside of precise arc");}
  Status "getorb";
### new epoch, one second later
  $epoch   = $epoch+1/86400;
  ($q0,$q1,$success,$junk,$junk,$junk, $x1, $y1, $z1) = split /\s+/,
  `$INT_BIN/getorb mjd=$epoch $orbit_dir 2>/dev/null`;
  if ( $success > 0 ){ die "getorb failed in state_vector.pl: $!\n";}
  elsif( $success < 0 ){ $success = 0; Log("getorb interpolating outside of precise arc");}
  Status "getorb";
  $success == 0 or die "getorb failed in state_vector.pl: $!\n";
### velocity
  $vx = $x1- $x0;
  $vy = $y1- $y0;
  $vz = $z1- $z0;
### Return vector values
  print "ODR $success $lat $lon $h $x0 $y0 $z0 $vx $vy $vz\n";
}


elsif ($orbit_type eq "PRC"){
### Change date format
  $orbit_dir or $orbit_dir = "$SAR_PRC_DIR/$sat";
  $YYYY =  $date;
  $YYYY =~ s/....$//;
  $MM   =  $date;
  $MM   =~ s/^....//;
  $MM   =~ s/..$//;
  $DD   =  $date;
  $DD   =~ s/^......//;

### Choose PRC file
  $filename = `$INT_SCR/select_PRC_date.pl $orbit_dir \\
                                           $YYYY \\
                                           $MM \\
                                           $DD \\
                                           $utc`;
  Status "select_PRC_date.pl";
  chomp($filename);
  if ($filename =~ /\.Z$/){
      `cp $filename tmp_orbit.Z`;
#      `uncompress -f tmp_orbit.Z`; 
     system('uncompress -f tmp_orbit.Z')==0 || system('gunzip -f tmp_orbit.Z')==0 
            || die "Can't uncompress tmp_orbit.Z\n";
  }
  elsif ($filename =~ /\.gz$/){
      `cp $filename tmp_orbit.gz`;
      `gunzip -f tmp_orbit.gz`;      
  }
  elsif ( ! ($file =~ /\..*$/)){
      `cp $filename tmp_orbit`;
  }
  $string = `$INT_BIN/PRC2polynom tmp_orbit \\
                                  $utc \\
                                  $DD \\
                                  $MM \\
                                  $YYYY 2>/dev/null`;
  Status "PRC2polynom";
  open (POLY, ">tmp_poly.rsc") or die "Can't write to tmp_poly.rsc\n";
  print POLY "$string";
  close(POLY);
  $string = `$INT_SCR/polynom2pos.pl tmp_poly $utc`;
  Status "polynom2pos.pl";

### Return vector values
  print "$string";
  `rm -f tmp_orbit tmp_poly.rsc 2>/dev/null`;
}

else{ Usage();} ### orbit not (PRC or ODR or HDR)
exit(0);

=pod

=head1 USAGE

B<state_vector.pl> I<date time satellite orbit_type>

	    date: YYYYMMDD
	    time: seconds UTC
	    sat: ERS1 or ERS2
	    orbit_type: PRC (precision orbit) or ODR (Delft)
	                or HDR (state vectors in header)

=head1 FUNCTION

Gives satellite position and velocity at requested epoch

=head1 ROUTINES CALLED

getorb

select_PRC_date.pl

PRC2polynom

HDR2polynom

polynom2pos.pl

=head1 CALLED BY

baseline.pl

make_raw.pl

make_orrm.pl

inverse3d.pl

orbit_client.pl

=head1 FILES USED

PRC and ODR orbit information files 
(Found in $SAR_PRC_DIR or $SAR_ODR_DIR
or remotely downloaded from a server)
or HDR information stored in ./hdr_data_points.rsc

=head1 FILES CREATED

none 

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
Frederic Crampe, Oct 29, 1999

=head1 LAST UPDATE

Frederic Crampe, Oct 29, 1999

=cut
