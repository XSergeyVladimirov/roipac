#!/usr/bin/perl

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

$orbit_name = shift;
$num_dop_lines = shift or $num_dop_lines=10000;
$ambiguity_forced = shift;  # optional forcing for ambiguity

$file_length = Use_rsc "$orbit_name.raw read FILE_LENGTH";
$xmin = Use_rsc "$orbit_name.raw read XMIN";
$xmax = Use_rsc "$orbit_name.raw read XMAX";
$width = Use_rsc "$orbit_name.raw read WIDTH";
$prf = Use_rsc "$orbit_name.raw read PRF";

$line_mid=int($file_length/2);
$half_num = int($num_dop_lines/2);

if ($line_mid > $half_num + 100 ) {
  $line_0=$line_mid - $half_num;
  
} else {
  $line_0 = 100;
  $num_dop_lines = $file_length - 200;
}
$i_bias = Use_rsc "$orbit_name.raw read I_BIAS";

if ($xmin > 0) {
  $line_header = $xmin - 1;
}
else {$line_header = 0;}
$lastbyte=$xmax;  # the right edge seems to be all data

open DOP, ">dopiq.in" or die "Can't write to dopiq.in\n";

print DOP <<END;
$orbit_name.raw
$width,$line_header,$lastbyte
$line_0,$num_dop_lines
$i_bias,$prf
END
close(DOP);

print "running dopiq-new on $num_dop_lines lines of $orbit_name.raw\n";

`$INT_BIN/dopiq-new < dopiq.in`;

$DopUnwStr = `$INT_SCR/DopUnw.pl dop.out`;
$DopUnwStr =~ /Quadratic doppler:\s+(\S+)\s+(\S+)\s+(\S+)/;
@QuadDopCoeff = ( $1, $2, $3 );

$dop_orig = $QuadDopCoeff[0];
$dop_rng1 = $QuadDopCoeff[1];
$dop_rng2 = $QuadDopCoeff[2];

print "quadratic Doppler fit $dop_orig $dop_rng1 $dop_rng2\n";

$sat = Use_rsc "$orbit_name.raw read PLATFORM";
$type = Use_rsc "$orbit_name.raw read RAW_TYPE";


if ($sat eq "RSAT-1") {  # need to apply Doppler ambiguity

  if ($type eq "STF") {
    # calculate near-range Doppler ambiguity--STF products

    $nsamples = ($xmax - $line_header)/2;

    $dar_doppler_center = Use_rsc "$orbit_name.raw read DAR_DOPPLER";

    # convert center swath Doppler from .par to near range edge Doppler
    $dar_doppler=$dar_doppler_center-int($nsamples/2)*$dop_rng1*$prf-int($nsamples/2)*int($nsamples/2)*$dop_rng2*$prf;

  }
  elsif ($type eq "CEOS") {
    $dar_doppler = Use_rsc "$orbit_name.raw read DAR_NEAR_DOPPLER";
  }
  # number of ambiguities
  $nambiguity = int($dar_doppler/$prf);
  # add ambiguity
  $dop_rng0=$nambiguity+$dop_orig;
  $dar_doppler_adim=$dar_doppler/$prf;
  print STDERR "Header Doppler=$dar_doppler_adim (Hz/PRF) Ambiguity=$nambiguity => Doppler0=$dop_rng0\n";
  # check if ambiguity worked, fix if not
  if ($ambiguity_forced){$nambiguity=$ambiguity_forced;}
  elsif (($dar_doppler_adim-$dop_rng0)>0.5){$nambiguity=$nambiguity+1;}
  elsif (($dar_doppler_adim-$dop_rng0)<-0.5){$nambiguity=$nambiguity-1;}
  $dop_rng0=$nambiguity+$dop_orig;
  print STDERR "Header Doppler=$dar_doppler_adim (Hz/PRF) Corrected_Ambiguity=$nambiguity => Doppler0=$dop_rng0\n";
}
else {  ## assume zero ambiguity for other satellites such as Envisat
$dop_rng0 = $dop_orig;
}

print STDERR "updating $orbit_name.raw Doppler\n";

Use_rsc "$orbit_name.raw write DOPPLER_AMBGTY  $nambiguity";
Use_rsc "$orbit_name.raw write DOPPLER_RANGE0  $dop_rng0";
Use_rsc "$orbit_name.raw write DOPPLER_RANGE1  $dop_rng1";
Use_rsc "$orbit_name.raw write DOPPLER_RANGE2  $dop_rng2";
Use_rsc "$orbit_name.raw write DOPPLER_RANGE3  0.";

$new_dar_doppler_center=($dop_rng0+int($nsamples/2)*$dop_rng1)*$prf;

$height = Use_rsc "$orbit_name.raw read HEIGHT";
$starting_range  = Use_rsc "$orbit_name.raw read STARTING_RANGE";
$velocity_mid = Use_rsc "$orbit_name.raw read VELOCITY";
$wavelength = Use_rsc "$orbit_name.raw read WAVELENGTH";
$pi                       = atan2(1,1)*4;
$r2d                      = 180/$pi;
$sin_theta = sqrt( 1 - ($height / $starting_range)**2 );
$fd = $dop_rng0 * $prf;
$sin_squint = $fd / ( 2 * $velocity_mid * $sin_theta ) * $wavelength;
$squint_rad = atan2( $sin_squint, sqrt( 1 - $sin_squint ** 2 ) );
$squint_deg = $squint_rad * $r2d;
Use_rsc "$orbit_name.raw write SQUINT          $squint_deg";

#$new_squint = asin($wavelength*$new_dar_doppler_center/(2*$veff*sin($lka*$DTR)))*$RTD;
#Use_rsc "${orbit_name}.raw write SQUINT       $new_squint";

exit 0;
