#!/usr/bin/perl
### dem2diff.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/dem2diff.pl`;
exit 1;
}

@ARGV == 23 or Usage();

@args = @ARGV;

$DoItFrom         = shift;
$EndItAt          = shift;
$DEM              = shift;    
$Sim              = shift;      
$SimDir           = shift;     
$IntDir           = shift;     
$im12             = shift;      
$Rlooks_sim       = shift;  
$Rlooks_small     = shift; 
$twopassBorbLsim  = shift;
$SynthIntBorbLsim = shift;
$hgt_radar_geom   = shift;
$simLsim          = shift;
$simLsml          = shift;
$corLsim          = shift;
$corLsml          = shift;
$aff_name         = shift;
$baseline_file    = shift;  
$OrbitType        = shift;  
$do_sim           = shift;
$MPI_PARA         = shift;
$NUM_PROC         = shift;
$ROMIO            = shift;

##########################################################################
Message "Making the Simulation for baseline reestimation and 2 pass approach";
##########################################################################
if ($DoItFrom eq "begin_sim"){
  
  if ($DEM eq "NULL") { 
    Message "STOPPING:  No DEM available";
    exit 1;
  }

  chdir $IntDir;
  if ($do_sim eq "yes") {
  `$INT_SCR/make_sim.pl  $Sim         \\
                         $SimDir      \\
                         $im12        \\
                         $Rlooks_sim  \\
                         $Rlooks_small\\
                         $OrbitType   \\
                         $DEM         `; 
                         Status "make_sim.pl";
  }     

  Link_here "$SimDir/$simLsim.hgt*";
  Link_here "$SimDir/$simLsml.hgt*";
  
  `$INT_SCR/synth_offset.pl $simLsim.hgt \\
                            $corLsim.cor \\
                            $MPI_PARA    \\
                            $NUM_PROC    \\
                            $ROMIO      `;
                            Status "synth_offset.pl"; 
 
  $DoItFrom="done_sim_off";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";
}  
                    
########################################################################
Message "Morphing simulation and doing 2-pass";
########################################################################
if ($DoItFrom eq "done_sim_off"){

  chdir $IntDir;

  `$INT_SCR/synth2radar.pl $simLsim.hgt \\
                           $aff_name    \\
                           $hgt_radar_geom.hgt`;
                           Status "synth2radar.pl";  

  `$INT_SCR/diffnsim.pl $im12.int              \\
                         $hgt_radar_geom.hgt   \\
                         $twopassBorbLsim.int  \\
                         $SynthIntBorbLsim.unw \\
                         $Rlooks_sim           \\
                         $baseline_file        \\
                         $OrbitType            \\
                         y                    `; 
                         Status "diffnsim.pl";

  $DoItFrom = "done_sim_removal";
  $EndItAt eq $DoItFrom and exit 0;
}       
               
exit 0; 

=pod

=head1 USAGE

B<dem2diff.pl> 

=head1 FUNCTION

Make simulation, gets offsets, morphs, and removes DEM from INT.

=head1 ROUTINES CALLED

filter.pl

make_mask.pl

unwrap.pl

=head1 CALLED BY

process_XXX.pl

=head1 FILES USED

I<process_infile>


=head1 HISTORY

Perl  Script : Mark Simons, May 10, 1999
Mark Simons, Mark Simons, May 10, 1999

=head1 LAST UPDATE

Gilles Peltzer, August 2004

=cut
