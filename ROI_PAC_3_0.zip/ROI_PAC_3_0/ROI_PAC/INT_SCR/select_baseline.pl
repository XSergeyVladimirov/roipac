#!/usr/bin/perl
### select_baseline.pl
### Usage: chomp(($a, $b, $c) = `select_baseline.pl baseline_file BaseType`);
$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/select_baseline.pl`;
exit 1;
}
@ARGV ==2 or Usage();

$baseline_file = shift;
$BaseType = shift;
$bh            = Use_rsc "$baseline_file read H_BASELINE_TOP_${BaseType}";
$bhrate        = Use_rsc "$baseline_file read H_BASELINE_RATE_${BaseType}";
$bhacc         = Use_rsc "$baseline_file read H_BASELINE_ACC_${BaseType}";
$bv            = Use_rsc "$baseline_file read V_BASELINE_TOP_${BaseType}";
$bvrate        = Use_rsc "$baseline_file read V_BASELINE_RATE_${BaseType}";
$bvacc         = Use_rsc "$baseline_file read V_BASELINE_ACC_${BaseType}";

print "$bh
$bhrate
$bhacc
$bv
$bvrate
$bvacc\n";

=pod

=head1 USAGE

B<select_baseline.pl> I<baseline_file BaseType>

=head1 FUNCTION

Returns baseline values
H_BASELINE_TOP_<BaseType>
H_BASELINE_RATE_<BaseType>
H_BASELINE_ACC_<BaseType>
V_BASELINE_TOP_<BaseType>
V_BASELINE_RATE_<BaseType>
V_BASELINE_ACC_<BaseType>
separated by newlines

=head1 ROUTINES CALLED

none

=head1 CALLED BY

everything

=head1 FILES USED

I<baseline_file>.rsc

=head1 FILES CREATED

none

=head1 HISTORY

Perl  Script : Rowena LOHMAN 11/12/98

=head1 LAST UPDATE

Rowena LOHMAN 11/12/98

=cut

