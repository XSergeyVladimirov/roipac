#!/usr/bin/perl
### offset.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/offset.pl`;
exit 1;
}
@ARGV >= 3 or Usage();
@args = @ARGV;


$file1       = shift;
$file2       = shift;
$offset_name = shift;
$pa          = shift or $pa       = 1;
$datatype    = shift or $datatype = "rmg";
$DX          = shift or $DX       = 0;
$DY          = shift or $DY       = 0;
$NX          = shift or $NX       = 30;
$NY          = shift or $NY       = 30;
$FFT_L       = shift or $FFT_L    = 64;
$D_MAX       = shift or $D_MAX    = 32;
$MPI_PARA    = shift;
$NUM_PROC    = shift;
$ROMIO       = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ($file1, $file2,     "$file1.rsc",      "$file2.rsc");
@Outfiles = ("$offset_name.off", "$offset_name.in", "$offset_name.out");
&IOcheck(\@Infiles, \@Outfiles);
Log("offset.pl", @args);

#################
Message "Reading resource file: $file1.rsc";
#################
$orbit_number       = Use_rsc "$file1 read ORBIT_NUMBER";
$width              = Use_rsc "$file1 read WIDTH";
$length_1           = Use_rsc "$file1 read FILE_LENGTH";
$date1              = Use_rsc "$file1 read DATE";

######################################
Message "Reading resource file: $file2.rsc";
######################################
$orbit_number_2 = Use_rsc "$file2 read ORBIT_NUMBER"; 
$width_2        = Use_rsc "$file2 read WIDTH";  
$date2          = Use_rsc "$file2 read DATE";

$length=$length_1;
#################################################
Message "Writing resource file: $offset_name.off.rsc";
#################################################
Use_rsc "$offset_name.off write ORBIT_NUMBER $orbit_number-$orbit_number_2";
Use_rsc "$offset_name.off write DATE12 $date1-$date2";
Doc_rsc(
 RSC_Tip => 'Date of two scenes',
 RSC_Doc => q[
   Date of each scene separated with a dash ('-') character.
   ],
 RSC_Derivation => q[
   Concatenation of DATE keyword values
   ],
 RSC_Comment => q[
   Value does not appear to be used anywhere.
   Is only propagated in geocode.pl
   ],
 RSC_Type => String,
 RSC_Format => 'YYMMDD-YYMMDD'
);

Use_rsc "$offset_name.off merge $file1";


##########################################
Message "Writing input_file: $offset_name.in";
##########################################
if ($datatype eq "rmg") {$s1 = 0; $s2 = 1;}  # reduced to avoid using bad matches EJF 2005/8/26
if ($datatype eq "cpx") {$s1 = 0; $s2 = 1;}
if ($DY < 0)            {$firstline = int(10-$DY);}
if ($DX < 0)            {$firstpix = int(10-$DX);}

# set firstline to 200 instead of 1 
$firstline or $firstline = 1;
$firstpix or $firstpix = 1;
$num  = int($length/$NY);
$num2 = int($width/$NX);

$iDY = int($DY);
$iDX = int($DX);

if ($datatype eq "rmg"){
open (OFF, ">$offset_name.in") or die "Can't write to $offset_name.in\n";
print OFF <<END;
                 AMPCOR INPUT FILE

DATA TYPE

Data Type for Reference Image Real or Complex                   (-)    =  RMG1   ![Complex , Real]
Data Type for Search Image Real or Complex                      (-)    =  RMG1   ![Complex , Real]

INPUT/OUTPUT FILES

Reference Image Input File                                      (-)    =  $file1
Search Image Input File                                         (-)    =  $file2
Match Output File                                               (-)    =  $offset_name.off

MATCH REGION

Number of Samples in Reference/Search Images                    (-)    =  $width $width_2
Start, End and Skip Lines in Reference Image                    (-)    =  $firstline $length $num
Start, End and Skip Samples in Reference Image                  (-)    =  $firstpix $width $num2

MATCH PARAMETERS

Reference Window Size Samples/Lines                             (-)    =  $FFT_L $FFT_L
Search Pixels Samples/Lines                                     (-)    =  $D_MAX $D_MAX
Pixel Averaging Samples/Lines                                   (-)    =  1 1
Covariance Surface Oversample Factor and Window Size            (-)    =  64 16
Mean Offset Between Reference and Search Images Samples/Lines   (-)    =  $iDX $iDY

MATCH THRESHOLDS AND DEBUG DATA

SNR and Covariance Thresholds                                   (-)    =  $s1 $s2
Debug and Display Flags T/F                                     (-)    =  f f
END
    close(OFF);
}
if ($datatype eq "cpx"){
open (OFF, ">$offset_name.in") or die "Can't write to $offset_name.in\n";
print OFF <<END;
                 AMPCOR INPUT FILE

DATA TYPE

Data Type for Reference Image Real or Complex                   (-)    =  Complex   ![Complex , Real]
Data Type for Search Image Real or Complex                      (-)    =  Complex   ![Complex , Real]

INPUT/OUTPUT FILES

Reference Image Input File                                      (-)    =  $file1
Search Image Input File                                         (-)    =  $file2
Match Output File                                               (-)    =  $offset_name.off

MATCH REGION

Number of Samples in Reference/Search Images                    (-)    =  $width $width_2
Start, End and Skip Lines in Reference Image                    (-)    =  $firstline $length $num
Start, End and Skip Samples in Reference Image                  (-)    =  $firstpix $width $num2

MATCH PARAMETERS

Reference Window Size Samples/Lines                             (-)    =  $FFT_L $FFT_L
Search Pixels Samples/Lines                                     (-)    =  $D_MAX $D_MAX
Pixel Averaging Samples/Lines                                   (-)    =  $pa $pa
Covariance Surface Oversample Factor and Window Size            (-)    =  64 16
Mean Offset Between Reference and Search Images Samples/Lines   (-)    =  $iDX $iDY

MATCH THRESHOLDS AND DEBUG DATA

SNR and Covariance Thresholds                                   (-)    =  $s1 $s2
Debug and Display Flags T/F                                     (-)    =  f f
END
    close(OFF);
}

################################################################

if($MPI_PARA eq "yes" and $NUM_PROC > 1) {
  ##### use these two lines if you do not want or cannot choose processors, or
  #Message "mpirun -np $NUM_PROC $INT_BIN/mpi_ampcor $offset_name.in rdf > $offset_name.out";
  #`mpirun -np $NUM_PROC $INT_BIN/mpi_ampcor $offset_name.in rdf > $offset_name.out`;
  ##### use these two lines if you do want to choose processors
  ##### you will need to have a file named machines.LINUX under your home directory
  ##### that lists all the IP's of the machines you want to choose
  Message "mpirun -nolocal -machinefile ~/machines.LINUX -np $NUM_PROC $INT_BIN/mpi_ampcor $offset_name.in rdf > $offset_name.out";
  `mpirun -nolocal -machinefile ~/machines.LINUX -np $NUM_PROC $INT_BIN/mpi_ampcor $offset_name.in rdf > $offset_name.out`;
}
else {
  Message "$INT_BIN/ampcor $offset_name.in rdf > $offset_name.out";
  `$INT_BIN/ampcor        $offset_name.in rdf > $offset_name.out`;
}
Status "ampcor";

`mv $offset_name.off tmp`;
open TMP, "tmp"               or die "Can't read tmp\n";
open OFF, ">$offset_name.off" or die "Can't write to $offset_name.off\n";
while (<TMP>){
    unless($_ =~ /\*/) {print OFF $_}
}
close (TMP);
close (OFF);
`rm -f tmp`;
exit 0;

=pod

=head1 USAGE

B<offset.pl> I<file1 file2 offsetfile [pixavg][datatype][dx][dy][nx][ny][FFT_L][D_MAX]>

 pixavg   = 1,2
 datatype = cpx or rmg
   dx, dy = guessed offset in range, azimuth [0,0]
   nx, ny = number of steps in pixels, lines
   FFT_l  = window size
   D_MAX  = Maximum offset

=head1 FUNCTION

Computes the offset field between two files

=head1 ROUTINES CALLED

ampmag

ampcor

=head1 CALLED BY

make_offset.pl

synth2radar.pl

=head1 FILES USED

I<file1>

I<file1>.rsc

I<file2>

I<file2>.rsc

=head1 FILES CREATED

I<offsetfile>.off

I<offsetfile>.off.rsc

I<offsetfile>.in

I<offsetfile>.out

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98

Perl  Script : Rowena LOHMAN 04/18/98

=head1 LAST UPDATE

Frederic CRAMPE, Oct 21, 1998

=cut
