#!/usr/bin/perl
### process_2pass.pl

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/process_2pass.pl`;
exit 1;
}
@ARGV >= 1 or Usage();
$processfile = shift;
$DoItFrom    = shift or $DoItFrom = "raw";
$EndItAt     = shift or $EndItAt  = "done";

$DoItFrom =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb|full_res|seismic|begin_filt|filtered|make_mask|unwrapped|done_sim_off|done_sim_removal|redo_base|use_sim_base|synth_offset|sim_removal|sim_removal_bsim|unwrapped_bsim)$/ or Usage();

$EndItAt  =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb|full_res|seismic|begin_filt|filtered|make_mask|unwrapped|done_sim_off|done_sim_removal|redo_base|use_sim_base|synth_offset|sim_removal|sim_removal_bsim|unwrapped_bsim|done)$/ or Usage();

##########################################################################
Message "Read the inputfile";
##########################################################################
open IN, "$processfile" or die "Can't read $processfile\n";
while (chomp($line = <IN>)){
  $line =~ /=/ or next;
  $line =~ s/\s//g; ###Remove all whitespace
  ($keyname, $value) = split /=/, $line;

  if ($value =~ /,/){ ### more than one value, i.e. models
    @values = split /,/, $value;
    $i=0;
    foreach $val (@values){
      $$keyname[$i] = $val;
      $i++;
    }
  }
  else{
    $$keyname = $value;
  }
}

##########################################################################
Message "Define Variables";
##########################################################################
chomp($dir0=`pwd`);
#### Variables that can be set in int_date1_date2.proc
$SimDir             or $SimDir             = "SIM";
$DEM                or $DEM                = "NULL";
$GeoDir             or $GeoDir             = "GEO";
$FilterStrength     or $FilterStrength     = 0.75;
$UnwrappedThreshold or $UnwrappedThreshold = 0.1;
$OrbitType          or $OrbitType          = "ODR";
$BaselineType       or $BaselineType       = $OrbitType;
$Rlooks_sim         or $Rlooks_sim         = 4;
$Rlooks_int         or $Rlooks_int         = $Rlooks_sim;
$Rlooks_unw         or $Rlooks_unw         = $Rlooks_sim;
$Rlooks_sml         or $Rlooks_sml         = 16;
$pixel_ratio        or $pixel_ratio        = 5;
$Alooks_sml         or $Alooks_sml         = $Rlooks_sml*$pixel_ratio;
$usergivendop1      or $usergivendop1      = 0;
$usergivendop2      or $usergivendop2      = 0;
$unw_seedx          or $unw_seedx          = -9999;
$unw_seedy          or $unw_seedy          = -9999;
$x_start            or $x_start            = 0.01;
$y_start            or $y_start            = 0.01;
$Threshold_mag      or $Threshold_mag      = 5.0e-5;
$Threshold_ph_grd   or $Threshold_ph_grd   = 0;
$sigma_thresh       or $sigma_thresh       = 1.0;
$smooth_width       or $smooth_width       = 5;
$slope_width        or $slope_width        = 5;
$concurrent_roi     or $concurrent_roi     = "no";
$mapping            or $mapping            = "dem_based";
$cleanup            or $cleanup            = "no";
$CO_MODEL           or $CO_MODEL           = "NULL";
$INTER_MODEL        or $INTER_MODEL        = "NULL";
$Filt_method        or $Filt_method        = "psfilt"; #could be: adapt_filt
$unw_method         or $unw_method         = "old";    #could be: icu
$flattening         or $flattening         = "topo";  #could be: topo
$do_sim             or $do_sim	           = "yes";    #could be: no ,GP 5.12.04
$do_mod             or $do_mod	           = "yes";    #could be: no ,GP 11.10.04
$unw_mod            or $unw_mod            = "yes";    #could be: no ,GP 11.10.04
$MAN_CUT            or $MAN_CUT            = "NULL";   #filename of man_cut (SIM)
$BaselineOrder      or $BaselineOrder      = "QUAD";   #could be: LIN
$MPI_PARA           or $MPI_PARA           = "no";
$NUM_PROC           or $NUM_PROC           = 1;
$ROMIO              or $ROMIO              = "no";
$ref_height         or $ref_height         = 0. ;

$im1 or $im1 = $SarDir1;
$im2 or $im2 = $SarDir2;

$im1 =~ s!.*\/!!g;
$im2 =~ s!.*\/!!g;

$im12 or $im12 = "$im1-$im2";

$slc1 = "$im1.slc";
$slc2 = "$im2.slc";

$Sim = $SimDir;
$Sim =~ s!.*\/!!g;

if ($Rlooks_int > 1){$Lint = "_${Rlooks_int}rlks";}
else{$Lint = "";}
if ($Rlooks_sim > 1){$Lsim = "_${Rlooks_sim}rlks";}
else{$Lsim = "";}
if ($Rlooks_unw > 1){$Lunw = "_${Rlooks_unw}rlks";}
else{$Lunw = "";}
if ($Rlooks_sml > 1){$Lsml = "_${Rlooks_sml}rlks";}
else{$Lsml = "";}

if ( ($CO_MODEL ne "NULL") || ($INTER_MODEL ne "NULL") ){$MODEL = "TRUE";}
else{$MODEL = "NULL";}

$int2simlook = $Rlooks_sim / $Rlooks_int;
$sim2unwlook = $Rlooks_unw / $Rlooks_sim;
$aff2geolook = $Rlooks_unw / $Rlooks_sim;
$cor_tag     = int($UnwrappedThreshold*100);

$slc1Lsml        = "${im1}${Lsml}.slc";
$slc2Lsml        = "${im2}${Lsml}.slc";
$baseline_file   = "${im1}_${im2}_baseline.rsc";
$flatBorb        = "flat_${OrbitType}_$im12";
$flatBorbLint    = "${flatBorb}${Lint}";
$flatsimLint     = "flat_SIM_$im12${Lint}";
$flatsimLsim     = "flat_SIM_$im12${Lsim}";
$twopassBorbLsim = "$im12-sim_${OrbitType}${Lsim}";
$twopassBorbLunw = "$im12-sim_${OrbitType}${Lunw}";
$twopassBsimLsim = "$im12-sim_SIM${Lsim}";
$twopassBsimLunw = "$im12-sim_SIM${Lunw}";
$corLint         = "${im12}${Lint}";
$corLsim         = "${im12}${Lsim}";
$corLunw         = "${im12}${Lunw}";
$corLsml         = "${im12}${Lsml}";
$ampLint         = "${im12}${Lint}";
$ampLsim         = "${im12}${Lsim}";
$ampLunw         = "${im12}${Lunw}";
$RampBorb        = "ramp_$OrbitType";
$cullLsim        = "${im12}_cull.off";
$cullLunw        = "${im12}_cull.off";
$maskBorbLunw    = "phase_var_${OrbitType}${Lunw}";
$maskBsimLunw    = "phase_var_SIM${Lunw}";

# files related to simulation
$SynthIntBorbLsim = "radar_${OrbitType}${Lsim}";
$SynthIntBorbLunw = "radar_${OrbitType}${Lunw}";
$SynthIntBsimLsim = "radar_SIM${Lsim}";
$SynthIntBsimLunw = "radar_SIM${Lunw}";
$HgtRadarGeomLsim = "radar${Lsim}";
$HgtRadarGeomLunw = "radar${Lunw}";
$simLsim          = "${Sim}${Lsim}";
$simLsml          = "${Sim}${Lsml}";
$baseestmsk       = "baseest${Lunw}.msk";
$lowcorBorbLunw   = "low_cor_${OrbitType}${Lunw}";
$aff_name         = "${im12}${Lsim}_SIM.aff";

# files related to coseismic&interseismic models
$SynthQuakeLunw   = "quakes${Lunw}";
$SynthModelLunw   = "models${Lunw}";
$twopassModelLunw = "$im12-sim_${OrbitType}-models${Lunw}";
$unwModelLunw     = "filt_${im12}-sim_SIM${Lunw}_c${cor_tag}";

# files for filtering
if (($MODEL eq "NULL") || ($unw_mod eq "no")){
  $tobefiltered = $twopassBorbLunw;
  $totalLunw    = "total_${im12}${Lunw}";
  $unwBsimLunw  = "filt_${im12}-sim_SIM${Lunw}_c${cor_tag}";
}
else{
  $tobefiltered = $twopassModelLunw;
  $totalLunw    = "total_${im12}-models${Lunw}";
  $unwBsimLunw  = "filt_${im12}-sim_SIM${Lunw}-models_c${cor_tag}";
}
$filtBorbLunw    = "filt_${tobefiltered}";
$unwBorbLunw     = "${filtBorbLunw}_c${cor_tag}";

# files for geocoding
$geocoding_lookupfile = "geomap${Lunw}.trans";
$outgeocoded          = "geo_${im12}.unw";
if ($flattening ne "topo"){
   $tobegeocoded="$unwBorbLunw.unw";
   }
else{
   if (($MODEL eq "NULL") || ($unw_mod eq "no")){$tobegeocoded="$unwBsimLunw.unw";}
   else{$tobegeocoded="$unwModelLunw.unw";}
   }

chdir $dir0;
chdir $SarDir1;
chomp($SarDir1=`pwd`);
chdir $dir0; 
chdir $SarDir2;
chomp($SarDir2=`pwd`);
chdir $dir0;
unless(-d $IntDir) {`mkdir $IntDir`;}
chdir $IntDir;
chomp($IntDir=`pwd`);
chdir $dir0;

if ($DEM ne "NULL"){
  unless(-d $SimDir) {`mkdir $SimDir`;}
  chdir $SimDir;
  chomp($SimDir=`pwd`);
  chdir $dir0;
  unless(-d $GeoDir) {`mkdir $GeoDir`;}
  chdir $GeoDir;
  chomp($GeoDir=`pwd`);
}  

if (-r "$SarDir1/hdr_data_points_$im1.rsc"){
  `cp $SarDir1/hdr_data_points_$im1.rsc $IntDir/`;
  `cp $SarDir1/hdr_data_points_$im1.rsc $SimDir/`;
  `cp $SarDir1/hdr_data_points_$im1.rsc $GeoDir/`;
}
elsif (-r "$IntDir/hdr_data_points_$im1.rsc"){
  `cp $IntDir/hdr_data_points_$im1.rsc $SimDir/`;
  `cp $IntDir/hdr_data_points_$im1.rsc $GeoDir/`;
}
if (-r "$SarDir2/hdr_data_points_$im2.rsc"){
  `cp $SarDir2/hdr_data_points_$im2.rsc $IntDir/`;
}  

##########################################################################
Message "Go from raw to slc to int and cor (also flattens with orbits)";
##########################################################################
if ($DoItFrom =~ /^(raw|roi_prep|orbbase|slcs|offsets|resamp|flatorb)$/){

`$INT_SCR/raw2ampintcor.pl $DoItFrom         \\
                           $EndItAt          \\
                           $dir0             \\
                           $SarDir1          \\
                           $SarDir2          \\
                           $IntDir           \\
                           $im1              \\
                           $im2              \\
                           $im12             \\
                           $slc1             \\
                           $slc2             \\
                           $baseline_file    \\
                           $usergivendop1    \\
                           $usergivendop2    \\
                           $OrbitType        \\
                           $BaselineType     \\
                           $Rlooks_int       \\
                           $Rlooks_sml       \\
                           $Alooks_sml       \\
                           $slc1Lsml         \\
                           $slc2Lsml         \\
                           $pixel_ratio      \\
                           $x_start          \\
                           $y_start          \\
                           $concurrent_roi   \\
                           $flatBorb         \\
                           $flatBorbLint     \\
                           $RampBorb         \\
                           $corLint          \\
                           $cleanup          \\
                           $MPI_PARA         \\
                           $NUM_PROC         \\
                           $ROMIO            \\
                           $ref_height       `;

                           Status "raw2ampintcor.pl";
  $DoItFrom="full_res";
  $EndItAt =~/^($DoItFrom|roi_prep|orbbase|slcs|offsets|resamp|flatorb)$/ and die "Ended at $EndItAt\n";
}
 

##########################################################################
Message "Making the Simulation for baseline reestimation and 2 pass approach";
##########################################################################
if ($DoItFrom =~ /^(full_res|done_sim_off)$/){
  
  chdir $IntDir;

  `$INT_SCR/look.pl $im12.cor \\
                    $Rlooks_sim`; 
                    Status "look.pl";

  $EndItAt2  = "done";

  if ($DoItFrom eq "full_res"        ){$DoItFrom2 = "begin_sim";} 
  if ($DoItFrom eq "done_sim_off"    ){$DoItFrom2 = "done_sim_off";} 
  if ($EndItAt  eq "done_sim_off"    ){$EndItAt2  = "done_sim_off";} 
  if ($EndItAt  eq "done_sim_removal"){$EndItAt2  = "done_sim_removal";} 

  `$INT_SCR/dem2diff.pl $DoItFrom2        \\
                        $EndItAt2         \\
                        $DEM              \\
                        $Sim              \\
                        $SimDir           \\
                        $IntDir           \\
                        $im12             \\
                        $Rlooks_sim       \\
                        $Rlooks_sml       \\
                        $twopassBorbLsim  \\
                        $SynthIntBorbLsim \\
                        $HgtRadarGeomLsim \\
                        $simLsim          \\
                        $simLsml          \\
                        $corLsim          \\
                        $corLsml          \\
                        $aff_name         \\
                        $baseline_file    \\
                        $OrbitType        \\
                        $do_sim           \\
                        $MPI_PARA         \\
                        $NUM_PROC         \\
                        $ROMIO        `;

                      Status "dem2diff.pl";

  `$INT_SCR/look.pl $twopassBorbLsim.int \\
                    $sim2unwlook`; 
                    Status "look.pl";

  `$INT_SCR/look.pl $SynthIntBorbLsim.unw \\
                    $sim2unwlook`; 
                    Status "look.pl";

  `$INT_SCR/look.pl $HgtRadarGeomLsim.hgt \\
                    $sim2unwlook`; 
                    Status "look.pl";


  $DoItFrom="seismic";
  $EndItAt =~/^($DoItFrom|done_sim_off|done_sim_removal)$/ and die "Ended at $EndItAt\n";
}

##########################################################################
Message "Making the deformation models for baseline reestimation";
##########################################################################
if ($DoItFrom eq "seismic"){
  if ($MODEL ne "NULL"){
    chdir $IntDir;
    `$INT_SCR/radarseismodel.pl $CO_MODEL             \\
                                $INTER_MODEL          \\
                                $geocoding_lookupfile \\
                                $SynthIntBorbLunw.unw \\
                                $aff_name             \\
                                $GeoDir               \\
                                $OrbitType            \\
                                $DEM                  \\
                                $aff2geolook          \\
                                $SynthQuakeLunw.unw   \\
                                $SynthModelLunw.unw   \\
                                $im1                  \\
				$do_mod               \\
                                $do_sim               \\
				$SimDir`;
                                Status "radarseismodel.pl";
# added do_sim parameter
                                
    `$INT_SCR/removeModel.pl    $twopassBorbLunw.int  \\
                                $SynthModelLunw.unw   \\
                                $twopassModelLunw.int`;
                                Status "removeModel.pl";
  }

  $DoItFrom="begin_filt";
  $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";   
}

##########################################################################
Message "Filtering, making the mask, unwrapping";
##########################################################################
if ($DoItFrom =~ /^(begin_filt|filtered|make_mask)$/){

  $DoItFrom2 = "begin_filt";
  $EndItAt2  = "done";
 
  if ($DoItFrom eq "filtered"   ){$DoItFrom2 = "done_filt";} 
  if ($DoItFrom eq "make_mask"  ){$DoItFrom2 = "make_mask";} 
  if ($EndItAt  eq "filtered"   ){$EndItAt2  = "done_filt";} 
  if ($EndItAt  eq "make_mask"  ){$EndItAt2  = "make_mask";} 
  if ($EndItAt  eq "unwrapped"  ){$EndItAt2  = "unwrapped";} 
   
   chdir $IntDir;
  `$INT_SCR/look.pl $im12.cor \\
                    $Rlooks_unw`; 
                    Status "look.pl";

  `$INT_SCR/look.pl $im12.amp \\
                    $Rlooks_unw`; 
                    Status "look.pl";

  if ($MAN_CUT ne "NULL"){
     `$INT_SCR/rect_cut.pl  $MAN_CUT                       \\
                            manual_cut.in                  \\
			    $im12`;
                            Status "rect_cut.pl";
  }	       

  `$INT_SCR/int2filtmaskunwrap.pl $DoItFrom2        \\
                                $EndItAt2           \\
                                $IntDir             \\
                                $tobefiltered       \\
                                $corLunw            \\
                                $ampLunw            \\
                                $filtBorbLunw       \\
                                $unwBorbLunw        \\
                                $maskBorbLunw       \\
                                $Filt_method        \\
                                $FilterStrength     \\
                                $Threshold_mag      \\
                                $Threshold_ph_grd   \\
                                $smooth_width       \\
                                $slope_width        \\
                                $sigma_thresh       \\
                                $UnwrappedThreshold \\
                                $unw_seedx          \\
                                $unw_seedy          \\
                                $unw_method         `; 
    
                                Status "int2filtmaskunwrap.pl";
  $DoItFrom="unwrapped";
  $EndItAt =~/^($DoItFrom|filtered|make_mask)$/ and die "Ended at $EndItAt\n";
}       
 
 
if ($flattening eq "topo"){              
##########################################################################
Message "Baseline Re-estimation";
##########################################################################
  if ($DoItFrom eq "unwrapped"){

      chdir $IntDir;
                     
      if($unw_method eq "old"){
	  #Put low correlation area at 0 in low_cor.msk
	  `$INT_SCR/add_rmg.pl $maskBorbLunw.msk   \\
                       $unwBorbLunw.unw    \\
                       $lowcorBorbLunw.msk \\
                       0 1`; 
	  Status "add_rmg.pl";

	  #modify mask to have zero value where there is no simulation info
	  `$INT_SCR/add_rmg.pl $lowcorBorbLunw.msk   \\
                       $SynthIntBorbLunw.unw \\
                       $baseestmsk           \\
                       0 1`; 
	  Status "add_rmg.pl";
	  #modify mask to have zero value where there is no seimic model info
	  if ($MODEL ne "NULL"){
	      `mv $baseestmsk tmpmsk.unw`;
	      `mv $baseestmsk.rsc tmpmsk.unw.rsc`;
	      `$INT_SCR/add_rmg.pl tmpmsk.unw            \\
                         $SynthModelLunw.unw   \\
                         $baseestmsk           \\
                         0 1`; 
	      Status "add_rmg.pl";
	      `rm tmpmsk.unw*`;
	  }	       
	  
      }else{
	  #modify mask to have zero value where there is no simulation info
	  `$INT_SCR/add_rmg.pl $maskBorbLunw.msk   \\
                       $SynthIntBorbLunw.unw \\
                       $baseestmsk           \\
                       0 1`; 
	  Status "add_rmg.pl";
      }
      
      #modify mask to have zero value where there is no seimic model info
      if ($MODEL ne "NULL"){
	  `mv $baseestmsk tmpmsk.unw`;
	  `mv $baseestmsk.rsc tmpmsk.unw.rsc`;
	  `$INT_SCR/add_rmg.pl tmpmsk.unw            \\
                         $SynthModelLunw.unw   \\
                         $baseestmsk           \\
                         0 1`; 
	  Status "add_rmg.pl";
	  `rm tmpmsk.unw*`;
      }	       

      #add simulated topo and unwrapped 2 pass difference 
      `$INT_SCR/add_rmg.pl $unwBorbLunw.unw      \\
                       $SynthIntBorbLunw.unw \\
                       $totalLunw.unw        \\
                       1 1`; 
      Status "add_rmg.pl";
      
      #get new baselines based on total unwrapped and simulation
      $num      = $Rlooks_unw * $pixel_ratio;
      
      #remove model if not done before
      if (($MODEL ne "NULL") && ($unw_mod eq "no")){
	  `$INT_SCR/add_rmg.pl $totalLunw.unw        \\
                       $SynthModelLunw.unw   \\
                       pha4baseest.unw       \\
                       -1 1`; 
	  Status "add_rmg.pl";
      }else{
	  `cp $totalLunw.unw pha4baseest.unw`;
	  `cp $totalLunw.unw.rsc pha4baseest.unw.rsc`;
      }
      
      `$INT_SCR/phase2base.pl $cullLunw             \\
                          pha4baseest.unw        \\
                          $baseestmsk           \\
                          $UnwrappedThreshold   \\
                          $HgtRadarGeomLunw.hgt \\
                          $Rlooks_unw           \\
                          $num                  \\
                          $baseline_file        \\
                          $OrbitType            \\
                          SIM                   \\
                          $BaselineOrder`; 
      Status "phase2base.pl";  
      
      $DoItFrom="redo_base";
      $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";   
  }

##########################################################################
Message "Use Bsim to re-remove topo from unwrapped pair";
##########################################################################

########################################################################
Message "re-doing 2-pass (based on old unwrapped file!)";
########################################################################
if ($DoItFrom eq "redo_base"){

    chdir $IntDir;
    
    `$INT_SCR/diffnsim.pl  $im12.int             \\
                         $HgtRadarGeomLsim.hgt \\
                         $twopassBsimLsim.int  \\
                         $SynthIntBsimLsim.unw \\
                         $Rlooks_sim           \\
                         $baseline_file        \\
                         SIM                   \\
                         y                    `; 
    Status "diffnsim.pl";
    
    $DoItFrom="sim_removal_bsim";
    $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";   
}

##########################################################################
Message "Create tobegeocoded=$tobegeocoded file";
##########################################################################
  if ($DoItFrom eq "sim_removal_bsim"){

      chdir $IntDir;
  
      `$INT_SCR/look.pl $SynthIntBsimLsim.unw \\
                    $sim2unwlook`; 
      Status "look.pl";
      
      `$INT_SCR/add_rmg.pl $totalLunw.unw        \\
                       $SynthIntBsimLunw.unw \\
                       $unwBsimLunw.unw      \\
                       -1 1`;
      Status "add_rmg.pl";
      
      if (($MODEL ne "NULL") && ($unw_mod eq "yes")){
	  `$INT_SCR/add_rmg.pl $unwBsimLunw.unw      \\
                         $SynthModelLunw.unw   \\
                         $unwModelLunw.unw     \\
                         1 1`;
	  Status "add_rmg.pl";
      }

      $DoItFrom="unwrapped_bsim";
      $EndItAt eq $DoItFrom and die "Ended at $EndItAt\n";
  }
}

##########################################################################
Message "Geocoding";
##########################################################################
if ($DoItFrom eq "unwrapped_bsim" or $DoItFrom eq "unwrapped"){

  chdir $IntDir;

  `$INT_SCR/radar2geo.pl $mapping              \\
                         $GeoDir               \\
                         $im1                  \\
                         $OrbitType            \\
                         $DEM                  \\
                         $aff_name             \\
                         $aff2geolook          \\
                         $geocoding_lookupfile \\
                         $tobegeocoded         \\
                         $outgeocoded          \\
                         $do_sim               \\
                         $SimDir`; 
                         Status "radar2geo.pl";

  if ($MODEL ne "NULL"){
   `$INT_SCR/geomodel.pl $SynthModelLunw.unw   \\
                         $SynthQuakeLunw.unw   \\
                         $tobegeocoded         \\
                         $maskBorbLunw.msk     \\
                         $geocoding_lookupfile \\
                         geo_$im12`;
                         Status "geomodel.pl";
# $baseestmsk does not exist with flattening=orbit EJF 05/8/24
  }
  $DoItFrom="done";
}

##########################################################################
Message "That\'s all folks";
##########################################################################
exit 0;

=pod

=head1 USAGE

B<process_2pass.pl> I<process_infile> [DoItFrom EndItAt]

 DoItFrom = point in process.pl to start
 EndItAt = point in process.pl to end
 Can be: raw, roi_prep, orbbase, slcs, offsets, resamp, flatorb, full_res, filtered, make_mask, unwrapped, simulation, morph_sim, redo_base or use_sim_base
 EndItAt can also be synth_offset

process_infile

 ###Required
 SarDir1     = name of image directory 1
 SarDir2     = name of image directory 2
 IntDir      = name of interferogram directory
 ###Optional (with default values)
 SimDir             = SIM
 DEM                = NULL
 GeoDir             = GEO
 FilterStrength     = 0.75
 UnwrappedThreshold = 0.73
 OrbitType          = ODR
 BaselineType       = OrbitType
 Rlooks_int         = 4
 Rlooks_sim         = Rlooks_int
 Rlooks_sml         = 16
 pixel_ratio        = 5
 Alooks_sml         = Rlooks_sml*pixel_ratio
# these next four defaults are calculated for each SAR mode
 before_z_ext       = 80% of synthetic aperture
 after_z_ext        = 80% of synthetic aperture
 near_rng_ext       = 50% of chirp length
 far_rng_ext        = 50% of chirp length
 usergivendop1      = 0
 usergivendop2      = 0
 unw_seedx          = -9999
 unw_seedy          = -9999
 x_start            = 0.01
 y_start            = 0.01
 flattening         = orbit
 Threshold_mag      = 5.0e-5
 Threshold_ph_grd   = 0
 sigma_thresh       = 1.0
 smooth_width       = 5
 slope_width        = 5
 concurrent_roi     = no
 mapping            = dem_based
 cleanup            = no
 CO_MODEL           = NULL
 INTER_MODEL        = NULL
 Filt_method        = psfilt
 flattening         = topo
 do_sim 	    = yes
 do_mod 	    = yes
 unw_mod	    = yes
  
=head1 FUNCTION

Goes from the raw ERS data to geocoded interferogram without topo

Required input file in the processing input file.
Script reads the inputfile extracting available parameters or
using defaults if parameter is unavailable.
None of the required inputs are file names, although the
directory to the raw data is required. Generate file names of
all of the intermediate and output files.

This script will do the full 2 pass processing including:
- Going from raw pulse to SLC to interferogram and correlation
  (also flattening the interferogram with the nominal orbits),
- Making the Simulation for baseline reestimation and 2 pass approach,
- Making the deformation models for baseline reestimation,
- Filtering, making the mask, unwrapping,
- Re-estimating the interferometric baseline,
- Re-doing 2-pass interferometry (based on old unwrapped file!), and
- Geocoding the output products.

Optional keywords indicate where to start and to end in this process.
Default is to do all the steps.

=head1 ROUTINES CALLED

pod2man.pl

raw2ampintcor.pl

look.pl

int2filtmaskunwrap.pl

diffnsim.pl

radar2geo.pl

phase2base.pl

add_rmg.pl

radarseismodel.pl

removeModel.pl

geomodel.pl

=head1 CALLED BY

none

=head1 FILES USED

I<process_infile>

I<date1>.raw

I<date1>.raw.rsc

I<date2>.raw

I<date2>.raw.rsc

=head1 FILES CREATED

im12
slc1 
slc2
Sim
slc1Lsml
slc2Lsml
baseline_file
flatBorb
flatBorbLint
flatsimLint
flatsimLsim
twopassBorbLsim
twopassBorbLunw
twopassBsimLsim
twopassBsimLunw
corLint
corLsim
corLunw
corLsml
ampLint
ampLsim
ampLunw
RampBorb
cullLsim
cullLunw
maskBorbLunw
maskBsimLunw
SynthIntBorbLsim
SynthIntBorbLunw
SynthIntBsimLsim
SynthIntBsimLunw
HgtRadarGeomLsim
HgtRadarGeomLunw
simLsim
simLsml
baseestmsk
lowcorBorbLunw
aff_name
SynthQuakeLunw
SynthModelLunw
twopassModelLunw
unwModelLunw
tobefiltered
totalLunw
unwBsimLunw
filtBorbLunw
unwBorbLunw
geocoding_lookupfile
outgeocoded
tobegeocoded
hdr_data_points_$im1.rsc
hdr_data_points_$im2.rsc

=head1 NOTES

Note that input file is NOT in RDF format since input file
can not have units the way that the PERL script is currently
written!

=head1 HISTORY

Perl  Script : Mark Simons 05/08/99
Modification: Mark Simons, 23/08/99
Modification: Frederic Crampe, 09/08/99
Modification: Frederic Crampe, 10/06/99
Modification: Mark Simons, 05/01/01
updated POD info - Elaine Chapin 26/Nov/2003
change to radarseismodel.pl call 2005/8/19 Zhenhong Li and Eric Fielding

=head1 LAST UPDATE

Eric Fielding 2005/8/19

=cut
