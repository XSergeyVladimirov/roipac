#!/usr/bin/perl
### inverse3d.pl

# fixed calculation of track angle FR & EJF 98/11/4
# removed call to mosaicker and added optional parameters for SCH output size and spacing EJF 98/11/6
# changed output file names, SCH hdr output EJF 98/11/26

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

use Env qw(INT_SCR INT_BIN);
use IO::File;
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/inverse3d.pl`;
exit 1;
}
@ARGV >= 3 or Usage();
@args = @ARGV;

$phase       = shift;
$correlation = shift;
$baseline    = shift;
$orbit_type  = shift or $orbit_type = "PRC";
$out_width   = shift or $out_width = 1500;
$out_spacing = shift or $out_spacing = 100;

$spac_i = int($out_spacing);
$sch_name = "sch";

#################
Message "Checking I/O";
#################
@Infiles  = ($phase, $correlation, $baseline);
@Outfiles = ("$sch_name.cor", "$sch_name.err",
	     "$sch_name.hdr" );

&IOcheck(\@Infiles, \@Outfiles);
Log("inverse3d.pl", @args);

##########################################
Message "Reading resource file: $phase.rsc";
##########################################

$width           = Use_rsc "$phase read WIDTH";
$length          = Use_rsc "$phase read FILE_LENGTH";
$start           = Use_rsc "$phase read FILE_START";
$xmin            = Use_rsc "$phase read XMIN";
$xmax            = Use_rsc "$phase read XMAX";
$ymin            = Use_rsc "$phase read YMIN";
$ymax            = Use_rsc "$phase read YMAX";
$height_top      = Use_rsc "$phase read HEIGHT";
$height_ds       = Use_rsc "$phase read HEIGHT_DS";
$height_dds      = Use_rsc "$phase read HEIGHT_DDS";
$cross_top       = Use_rsc "$phase read CROSSTRACK_POS";
$cross_ds        = Use_rsc "$phase read CROSSTRACK_POS_DS";
$cross_dds       = Use_rsc "$phase read CROSSTRACK_POS_DDS";
$atvel_top       = Use_rsc "$phase read ALONGTRACK_VELOCITY";
$atvel_ds        = Use_rsc "$phase read ALONGTRACK_VELOCITY_DS";
$ctvel_top       = Use_rsc "$phase read CROSSTRACK_VELOCITY";
$ctvel_ds        = Use_rsc "$phase read CROSSTRACK_VELOCITY_DS";
$vvel_top        = Use_rsc "$phase read VERT_VELOCITY";
$vvel_ds         = Use_rsc "$phase read VERT_VELOCITY_DS";
$rt              = Use_rsc "$phase read EARTH_RADIUS";
$r0              = Use_rsc "$phase read STARTING_RANGE";
$r0_raw          = Use_rsc "$phase read RAW_DATA_RANGE";
$range_offset    = Use_rsc "$phase read RANGE_OFFSET";
$wavelength      = Use_rsc "$phase read WAVELENGTH";
$dr              = Use_rsc "$phase read RANGE_PIXEL_SIZE";
$dz              = Use_rsc "$phase read AZIMUTH_PIXEL_SIZE";
$radius          = Use_rsc "$phase read EARTH_RADIUS";
$first_line_utc  = Use_rsc "$phase read FIRST_LINE_UTC";
$center_line_utc = Use_rsc "$phase read CENTER_LINE_UTC";
$delta_line_utc  = Use_rsc "$phase read DELTA_LINE_UTC";
$dop_rng0        = Use_rsc "$phase read DOPPLER_RANGE0";
$dop_rng1        = Use_rsc "$phase read DOPPLER_RANGE1";
$dop_rng2        = Use_rsc "$phase read DOPPLER_RANGE2";
$dop_rng3        = Use_rsc "$phase read DOPPLER_RANGE3";
$squint          = Use_rsc "$phase read SQUINT";
$velocity        = Use_rsc "$phase read VELOCITY";
$prf             = Use_rsc "$phase read PRF";
$year            = Use_rsc "$phase read FIRST_LINE_YEAR";
$month           = Use_rsc "$phase read FIRST_LINE_MONTH_OF_YEAR";
$day             = Use_rsc "$phase read FIRST_LINE_DAY_OF_MONTH";
$sat             = Use_rsc "$phase read PLATFORM";
$antenna_side    = Use_rsc "$phase read ANTENNA_SIDE";
$PegLon          = Use_rsc "$phase read LONGITUDE";
$PegLat          = Use_rsc "$phase read LATITUDE";
$PegHdg          = Use_rsc "$phase read HEADING";
$PegUtc          = Use_rsc "$phase read PEG_UTC";
$slc_offset      = Use_rsc "$phase read SLC_RELATIVE_YMIN";

# this should be the effective number of looks (actual looks plus filtering)
#    but this is not recorded in .rsc files EJF 98/12/8
$eff_looks = 80;   #  1x5 times about 3x3?

$PegLine = int( ( $PegUtc - $first_line_utc ) / $delta_line_utc );

#########################################
Message "Reading resource file: $baseline";

$hb          = Use_rsc "$baseline read H_BASELINE_TOP_SIM"; 
$hbr         = Use_rsc "$baseline read H_BASELINE_RATE_SIM"; 
$vb          = Use_rsc "$baseline read V_BASELINE_TOP_SIM"; 
$vbr         = Use_rsc "$baseline read V_BASELINE_RATE_SIM"; 
$phase_const = Use_rsc "$baseline read PHASE_CONST_SIM";
 
$numlines = $ymax-$ymin;
$endsamp  = $xmax-$xmin;
$xmin++;
$ymin++;
    
( $AmpFile = $correlation ) =~ s/\.cor/\.amp/;

$az_ground_spacing = $dz * $radius / ( $height_top + $radius );

$InvRdfStr = "                           INVERSE3D INPUT FILE

INPUT FILE DATA

Data Take Identification                               (-)      = ERS Tandem
Data Take Date                                         (-)      = May 15, 1996

Separated or RMG Input Files                           (-)      =      RMG                     ![Separated , RMG]
Unwrapped Interferogram File Name                      (-)      =      $phase           !unwrapped pahse data
Correlation File Name                                  (-)      =      $correlation        !Correlation data
Magnitude File Name                                    (-)      =      $AmpFile        !Magnitude data

GENERAL INFO

Height of Terrain                                      (m)      =       0.                 !
Height Variation of Terrain                            (m)      =       1000.                 !

RADAR PARAMTERS

Radar Wavelength                                       (m)      =       $wavelength              !SRTM
Repeat Pass or Single Antenna Transmit                 (-)      =  Repeat Pass ![Single Antenna Transmit , Repeat Pass]
Radar PRF                                              (Hz)     =       $prf              !PRF
Doppler as a Function of Range Fit Parameters          (-)      =   $dop_rng0 $dop_rng1 $dop_rng2 $dop_rng3            !Cubic Poly
Doppler Fit Referenced to First or Center Range Bin    (-)      =   First Range Bin        ![First Range Bin , Center Range Bin]
Radar Look Direction                                   (-)      =       Right               ![Left , Right]
Starting Range                                         (m)      =     $r0              !
Number of Range Samples                                (-)      =      $width                !
Start and End Sample to Process                        (-)      =     1 $width               !
Start and Number Lines to Process                      (-)      =     1 $numlines               !

DATA INFORMATION

Correlation Threshold                                  (-)      =       .1                 !values below not  mapped
Range and Along Track Spacing in Interferogram        (m,m)     =     $dr $az_ground_spacing           !along track GROUND spacing
Line Offset Between Reference SLC Start and Interferogram Start (-) = $slc_offset
Reverse Sign of Unwrapped Phases                       (-)      =     Preserve             ![Preserve , Reverse]
Want Help Finding Absolute Phase Constant              (-)      =      No Help             ![Help Wanted , No Help] 
Phase Constant for Height Reconstruction              (rad)     =     $phase_const    !phase ADDED to unwrapped phase
Number of Looks in Interferogram                       (-)      =     $eff_looks                 !Number of interferometric looks

SPACECRAFT DATA

Use Simple Orbit Parameters or Use Orbit File          (-)      =    Simple Orbit Data     ![Simple Orbit Data , Use Orbit File] 
Spacecraft Altitude, Altitude Rate, & Acceleration  (m,-,-)     =    $height_top $height_ds $height_dds    !rate is m/m and m/m^2
Spacecraft Cross Track, Cross Track Rate, & Acceleration (m,-,-) =   $cross_top  $cross_ds  $cross_dds     !rate is m/m and m/m^2
Spacecraft Along Track Velocity and Rate              (m/s,-)   =    $atvel_top  $atvel_ds                 !rate is m/s/m
Spacecraft Cross Track Velocity and Rate              (m/s,-)   =    $ctvel_top  $ctvel_ds                 !rate is m/s/m
Spacecraft Vertical Velocity and Rate                 (m/s,-)   =    $vvel_top    $vvel_ds                  !rate is m/s/m
Spacecraft Along Track Velocity                       (m/s)     =    $velocity               !             
Name of Emphemeris File                                (-)      =     No File              !

BASELINE DATA

Use Simple Baseline Parameters or Use Baseline File   (-)       =  Simple Baseline Data    ![Simple Baseline Data , Use Baseline File] 
Initial Cross Track Baseline and Rate                 (m,-,-)     =  $hb $hbr 0.  !rates in m/m etc
Initial Vertical Baseline and Rate                    (m,-,-)     =  $vb $vbr 0.    !rates in m/m etc
Name of Baseline File                                 (-)       =   No File                !
Make Target Dependent Baseline Correction             (-)       =   Target Dependent       ![Target Dependent , Target Indpendent]

MAPPING PARAMETERS

Output Map Pixel Spacing Range & Azimuth             (m,m)      =     90 90                !SRTM Parameters
Cross Track & Along Track Adjustments                (m,m)      =      0  0                !can use to adjust default selections
Cross Track Map Size in Pixels                        (-)       =      0 ! 1801
Use SCH Coordinates                                   (-)       =    Use SCH               ![Use SCH , No SCH]
Peg Point Data - Lat, Lon & Hdg                   (deg,deg,deg) =    $PegLat $PegLon $PegHdg       !
Local Radius of Curvature                            (m)        =    $rt              !only if No SCH
Regridding Method for Heights                        (-)        =  Nearest Neighbor        ![Nearest Neighbor, Simplical, Surface Fit, MAP]
Regridding Method for Amplitudes                     (-)        =  Nearest Neighbor        ![Nearest Neighbor, Simplical, Surface Fit, MAP]
Regridding Method for Correlation                    (-)        =  Nearest Neighbor        ![Nearest Neighbor, Simplical, Surface Fit, MAP]
Regridding Method for Height Errors                  (-)        =  Nearest Neighbor        ![Nearest Neighbor, Simplical, Surface Fit, MAP]
Regridding Method for Look up Table                  (-)        =  Nearest Neighbor        ![Nearest Neighbor, Simplical, Surface Fit, MAP]
Adaptive or Fixed Weighting                          (-)        =     Fixed                ![Fixed , Adaptive]
Maximum Box Size                                     (-)        =       4                  !pixels between -value to value used 
Number of Exponents	                             (-)        =       1                  !Number up to maximal number of exponents
Exponent Value 1                                     (-)        =       2.                 !value used (need not be integer)
Number of Scales	                             (-)        =       1                  !number of scale values
Scale Value 1                                        (-)        =       0.                 !scale value for weights
Scale for Non-Height Data                            (-)        =       1.                 !scale for non-height data (e.g. amplitudes)
Exponent for Non-Height Data                         (-)        =       1.                 !exponents for non-height data (e.g. amplitudes)
Layers from Box Edge Where Need Data                 (-)        =       2                  !missing point around edge
Slope Correct Image Data                             (-)        =  No Slope Correction
Radiometric Range Correction Exponent                (-)        =   2.0000000000 !
Renormalize Area Projection in Image Data            (-)        =  No Renormalization
Atmospheric Correction Applied                       (-)        =  Yes
Phase Screen Active                                  (-)        = No
Reference Line for SCH Coordinates                   (-)        = $PegLine

NULL VALUE ASSIGNMENTS

Null Value to Use in Height Map                      (-)        =     -10000               !No value indicator
Null Value to Use in Amplitude Map                   (-)        =       0
Null Value to Use in Correlation Map                 (-)        =       0
Null Value to Use in Height Error Map                (-)        =      -1
Null Value to Use in Curvature Maps                  (-)        =     -100.
Null Value to Use in Slope Map                       (-)        =       0            
Null Value to Use in Lookup Table                    (-)        =     -10000

OUTPUT DATA SELECTION

Generate Output Height Data                          (-)        =      Yes                 ![Yes , No]
Generate Output Amplitude Data                       (-)        =      Yes                 ![Yes , No]
Generate Output Correlation Data                     (-)        =      Yes                 ![Yes , No] 
Generate Output Error Map Data                       (-)        =      Yes                 ![Yes , No]
Generate Output Slope Data                           (-)        =      Yes                 ![Yes , No]
Generate Output Curvature Data                       (-)        =      Yes                 ![Yes , No]
Generate Orthorectification Lookup Table             (-)        =      Yes                 ![Yes , No]
Dump Map Debug Data                                  (-)        =      No                 ![Yes , No]

OUTPUT FILES

Separated or RMG Output Files                        (-)        =    Separated                             ![Separated , RMG]
Annotation File Name                                 (-)        =    $sch_name.ann              !
Height Map File Name                                 (-)        =    $sch_name.hgt              !
Amplitude File Name                                  (-)        =    $sch_name.mag              !
Correlation Map File Name                            (-)        =    $sch_name.cor              !
Height Error Map File Name                           (-)        =    $sch_name.err              !
Slope Map File Name                                  (-)        =    $sch_name.slp              !
Cross Slope Curvature Map File Name                  (-)        =    $sch_name.xsc              !
Along Slope Curvature Map File Name                  (-)        =    $sch_name.asc              !
Orthorectification Lookup Table File Name            (-)        =    $sch_name.lut              ! 
Mosaic Header File Name                              (-)        =    $sch_name.mos

Number of Debug Subroutines Listed                   (-)        =    0
";

open( IN, ">inverse3d.rdf" );
print IN $InvRdfStr;
close( IN );

#`$INT_BIN/inverse3d inverse3d.in > inverse3d.out`;
`$INT_BIN/inverse3d inverse3d.rdf > inverse3d.out`;
Status "inverse3d";

exit 0;
=pod


=head1 USAGE

B<inverse3d.pl> I<unwrapped_phase correlation baseline> [orbit_type sch_out_width sch_out_spacing]

unwrapped_phase: unwrapped total phase (not flattened) {filename with .unw}
    correlation: correlation RMG file {name with .cor}
       baseline: baseline resource file {name with .rsc}
     orbit_type: PRC or ODR orbits [default is PRC]
  sch_out_width: optional output SCH file width [default 1500 pixels]
sch_out_spacing: optional SCH spacing [default 100 m]

=head1 FUNCTION

reconstruct height map in SCH coordinates from unwrapped phase and baseline
  also determines appropriate SCH peg point and track angle

=head1 ROUTINES CALLED

inverse3d

=head1 CALLED BY

dem.pl

=head1 FILES USED

I<unwrapped_phase>
I<correlation>
I<baseline>
I<orbit_type> orbits (to calculate peg point and track angle)

=head1 FILES CREATED

sch_${out_spac}m.amp
sch_${out_spac}m.cor
sch_${out_spac}m.err
sch_${out_spac}m.hgt
sch_${out_spac}m.hdr

e.g. sch_100m.hgt for 100 m output spacing

=head1 HISTORY

Shell Script : Francois ROGEZ 96/98
Perl  Script : Rowena LOHMAN 04/18/98
updated: Frederic CRAMPE, May 22, 1998
updated to only create SCH output and add generality: Eric Fielding 98/11/6
updated Eric Fielding, 8 December 1998

=head1 LAST UPDATE

updated Francois Rogez, 20 March 2003

=cut
