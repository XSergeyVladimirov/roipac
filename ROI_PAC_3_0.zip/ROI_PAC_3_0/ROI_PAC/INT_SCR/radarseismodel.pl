#!/usr/bin/perl
# *** JPL/Caltech Repeat Orbit Interferometry (ROI) Package ***

$] >= 5.004 or die "Perl version must be >= 5.004 (Currently $]).\n";

### radarseismodel.pl

use Env qw(INT_BIN INT_SCR);
use lib "$INT_SCR";  #### Location of Generic.pm
use Generic;

###Usage info/check
sub Usage{

`$INT_SCR/pod2man.pl  $INT_SCR/radarseismodel.pl`;
exit 1;
}

@ARGV == 15 or Usage();
@args = @ARGV;

$In_CoModel    = shift;  
$In_InterModel = shift; 
$trans         = shift; 
$look          = shift;
$aff           = shift;
$geo_dir       = shift;
$OrbitType     = shift;
$DEM           = shift;
$aff2geolooks  = shift;
$OutQuake      = shift;
$OutData       = shift;
$hdrdate       = shift;
$do_mod        = shift;
$do_sim        = shift;
$SimDir        = shift;

#################
Message "Checking I/O";
#################
@Infiles  = ($look,$aff);
@Outfiles = ($OutData);
&IOcheck(\@Infiles, \@Outfiles);
Log("radarseismodel.pl", @args); 

#############################################
Message "Read Coseismic and Interseismic models names";
#############################################
@dir   = qw(E N U);

$co_number    = 0;
$beg          = 0;
$counter      = 0;

if ($In_CoModel ne "NULL")
 { 
 @coseismic = split /:/, $In_CoModel;
 $co_number = $#coseismic + 1;
 }
if ($In_InterModel ne "NULL")
 { 
 @interseismic = split /:/, $In_InterModel;
 }

@seismic = (@coseismic,@interseismic);

if ($do_mod eq "yes"){
#############################################
Message "Making mapping file";
#############################################
`$INT_SCR/make_geomap.pl $geo_dir      \\
                         $look         \\
                         $trans        \\
                         $OrbitType    \\
                         $DEM          \\
                         $aff          \\
                         $aff2geolooks \\
                         $hdrdate      \\
                         $do_sim       \\
			 $SimDir`;
                         
Link_here "$geo_dir/$trans*";
}

#########################################
Message "Create a radar image from model data";
#########################################
foreach $seismic (@seismic)
        {
        @name   = split /\//,$seismic;
        $signal = $name[-1];
        $counter++;

	if ($do_mod eq "yes"){
	
        foreach $dir (@dir)
                {
	        if (-r "${seismic}${dir}")
                   {
                   `$INT_SCR/geo2radar.pl $trans              \\
                                          ${seismic}${dir}    \\
                                          $look               \\
                                          ${signal}sim_${dir}`;
#                                          Status "geo2radar.pl";
		   `cp $look.rsc ${signal}sim_${dir}.rsc`;
                   }
                }
        if (-r "${seismic}U")
         {
         `$INT_SCR/disp2phase.pl ${signal}sim_phs      \\
                                 $look                  \\
                                 ${signal}sim_E        \\
                                 ${signal}sim_N        \\
                                 ${signal}sim_U`;
#                                 Status "disp2phase.pl";
#         `rm ${signal}sim_E* ${signal}sim_N* ${signal}sim_U*`;
         }
        else
         {
         `$INT_SCR/disp2phase.pl ${signal}sim_phs      \\
                                 $look                  \\
                                 ${signal}sim_E        \\
                                 ${signal}sim_N`;
                                 Status "disp2phase.pl";
#         `rm ${signal}sim_E* ${signal}sim_N*`;
         }

	$sim_width = Use_rsc "$look read WIDTH";
        $sim_length= Use_rsc "$look read FILE_LENGTH";
       
        `$INT_BIN/rmg2mag_phs    $look     \\
    				 pwr       \\
                                 /dev/null \\
                                 $sim_width`;
#				 Status "rmg2mag_phs";

        `$INT_BIN/mag_phs2rmg    ${signal}sim_phs    \\
    				 ${signal}sim_phs    \\
                                 ${signal}sim_rmg    \\
                                 $sim_width`;
#				 Status "mag_phs2rmg";

        `cp $look.rsc ${signal}sim_rmg.rsc`;
#        `rm ${signal}sim_phs`;
        
# use smaller window for coseismic models and more range looks
        if ($counter <= $co_number and $sim_width < 2000) {
	   $window =35;
	   $percent=0.1;   # interpolate more sparse areas
           $padsize=3;   # less padding for smaller windows
           }
   	else {  # use a bigger window for interseismic and fewer range looks
           $window =100;
           $percent=0.;
           $padsize=10;  # need more padding for big windows
           }
        

# changed to RDF format 2004/01/17 EJF
# increased pad size to work better with 2rlks interferograms EJF 2005/2/25
# changed to variable pad size to work better with small windows EJF 2006/3/30
open RESAMP, ">Aik_resamplebis.in" or die "Can't write to Aik_resampbis.in\n";
print RESAMP <<END;
RMG input file                             (-)    =  ${signal}sim_rmg
RMG output file                            (-)    =  ${signal}tmp_rmg
Number of pixels across                    (-)    =  $sim_width 
Number of pixels down                      (-)    =  $sim_length
Start and end pixels to process across     (-,-)  =  1 $sim_width
Start and end pixels to process down       (-,-)  =  1 $sim_length
Block size                                 (-)    =  $window
Pad size                                   (-)    =  10
Threshold                                  (-)    =  $percent
Number of points for partials              (-)    =  3
Print flag                                 (-)    =  0
END
close(RESAMP);

        `cp ${signal}sim_rmg.rsc ${signal}tmp_rmg.rsc`;
        `cp ${signal}sim_rmg.rsc ${signal}rad.unw.rsc`;

        `$INT_BIN/Aik_resample Aik_resamplebis.in`;
        Status "Aik_resample";

#        `rm ${signal}sim_rmg*`;

        `$INT_BIN/rmg2mag_phs    ${signal}tmp_rmg \\
    				 /dev/null        \\
                                 phase            \\
                                 $sim_width`;
#				 Status "rmg2mag_phs";

        `$INT_BIN/mag_phs2rmg    pwr              \\
    				 phase            \\
                                 ${signal}rad.unw \\
                                 $sim_width`;
#				 Status "mag_phs2rmg";

        `rm pwr phase`;				 
#        `rm ${signal}tmp_rmg*`;
    
#        shift the model back into simu geometry and place file in SIM directory 
        `$INT_SCR/inv_affine.pl  $aff   \\
	                         inv_aff`;
	
        open IN, "inv_aff" or die "Can't read $infile\n";
	$line    = <IN>;
	($m11, $m12, $m21, $m22, $t1, $t2) = split /\s+/, $line;


        `$INT_SCR/rect.pl        ${signal}rad.unw   \\
	                         ${signal}sim.unw   \\
				 $m11, $m12, $m21, $m22, $t1, $t2`; 
                                 Status "rect.pl";
				 	           
	`mv ${signal}sim.unw* ${SimDir}`;
        }
    
        if ($do_mod eq "no"){
#       Shift model file in SIM directory to radar geometry

        open IN, "$aff" or die "Can't read $infile\n";
	$line    = <IN>;
	($m11, $m12, $m21, $m22, $t1, $t2) = split /\s+/, $line;


        `$INT_SCR/rect.pl        ${SimDir}/${signal}sim.unw   \\
	                         ${signal}rad.unw             \\
				 $m11, $m12, $m21, $m22, $t1, $t2`; 
        }

        if ($beg == 0){
           `$INT_SCR/add_rmg.pl ${signal}rad.unw \\
                                ${signal}rad.unw \\
                                tmp_model          \\
                                -1 0`; 
                                Status "add_rmg.pl";
                                $beg = 1;}
        else{
           `cp $OutData tmp_model`;
           `cp $OutData.rsc tmp_model.rsc`;}


	if ($counter <= $co_number){
	   $coeff = 1;}
   	else{
           $coeff = Use_rsc "${signal}rad.unw read TIME_SPAN_YEAR";
	   Use_rsc "$OutData.rsc write TIME_SPAN_YEAR $coeff";
           if ($co_number != 0){
              system "cp $OutData $OutQuake";
              system "cp $OutData.rsc $OutQuake.rsc";}
           }


	`$INT_SCR/add_rmg.pl tmp_model            \\
                             ${signal}rad.unw     \\
                             $OutData             \\
                             $coeff 0`; 
#                             Status "add_rmg.pl";

#        `rm tmp_model*`;

            

        }


exit 0;

=pod

=head1 USAGE

B<radarseismodel.pl> I<In_CoModel In_InterModel trans look aff OutData>

=head1 FUNCTION

builds the radar files corresponding to seismic deformation models

=head1 ROUTINES CALLED

geo2radar.pl

disp2phase.pl

rmg2mag_phs

mag_phs2rmg

Aik_resample

rect.pl

add_rmg.pl

=head1 CALLED BY

process.pl

=head1 FILES USED

I<trans>

I<look>

I<look>.rsc

I<aff>

I<seismicdir>

I<seismicdir>.rsc

=head1 FILES CREATED

I<OutData>

I<OutData>.rsc

I<signalrad.unw>

I<signalrad.unw>.rsc

rect.in

Aik_resamplebis.in

=head1 HISTORY

Perl  Script : Frederic CRAMPE 05/22/98
Frederic CRAMPE, Aug 26, 1999
Updated Aik_resample input to RDF format, commented status checks EJF 2004/01/17
Commented status checks based on EJF, Zhenhong Li, 16 Aug 2005
Call make_geomap.pl properly, Zhenhong Li, 16 Aug 2005
integrated changes EJF 2005/8/19

=head1 LAST UPDATE

Eric Fielding 2006/3/30

=cut
