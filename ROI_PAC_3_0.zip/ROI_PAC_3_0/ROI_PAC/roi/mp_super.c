#include <limits.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/prctl.h>
#include <sys/schedctl.h>
#include <sys/stat.h>
#include <sys/sysmp.h>
#include <sys/pda.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "utilities.h"

extern	int	errno;

#define	SUPER_INFO	(0)	/* prints error status for system calls */
#define	DRIVER_INFO	(0)	/* prints out where each process lives */
#define	USE_ISOLATE	(0)	/* isolates processors to MUSTRUN processes */
#define	USE_RESTRICT	(0)	/* restricts processors to MUSTRUN processes */
#define	USE_MUSTRUN	(1)	/* locks each process to 1 processor */
#define	USE_RESIDENT	(1)	/* makes processes immune to swapout */
#define	USE_SLICE	(400)	/* process's time slice in clock ticks */
#define	USE_NDPRI	(35)	/* process's priority:
				     30--39:	above normal
				     40--127:	normal range
				    128--254:	below normal	*/

#define	TRUE		(1)
#define	FALSE		(0)
#define MAX_THREADS	(64)
static	int		p_num[MAX_THREADS];
static	struct pda_stat	*pstat;
static	int		nprocs, nthreads;

static	struct run_options {
  int	info;		/* prints out return values of system calls */
  int	dump;		/* dumps out assignment of threads to processors */
  int	isolate;	/* restricts processors to MUSTRUN processes */
  int	restrict;	/* restricts processors to MUSTRUN processes */
  int	mustrun;	/* locks each process to 1 processor */
  int	resident;	/* makes processes immune to swapout */
  int	slice;		/* process's time slice in clock ticks */
  int	ndpri;		/* process's priority:
				     30--39:	above normal
				     40--127:	normal range
				    128--254:	below normal	*/
} options = {	SUPER_INFO,
		DRIVER_INFO,
		USE_ISOLATE,
		USE_RESTRICT,
		USE_MUSTRUN,
		USE_RESIDENT,
		USE_SLICE,
		USE_NDPRI
	    };

/*
 * p_setup - find processors to run our threads on
 *
 * Parameters:
 *    nth 	- number of threads to find processors for
 */
int
p_setup_(

int	*nthp)

{
  return (p_setup(*nthp));
}

int
p_setup(

int	nth)

{
  int			ip, ith;
  struct pda_stat	*p;

  /*
   * Reset options from environment variables, if present.
   */

  {
    char			*opt;

    opt = getenv("MP_SUPER_INFO");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.info     = TRUE;
      } else {
	options.info     = atoi(opt);
      }
    }

    opt = getenv("MP_SUPER_DUMP");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.dump     = TRUE;
      } else {
	options.dump     = atoi(opt);
      }
    }

    opt = getenv("MP_SUPER_ISOLATE");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.isolate  = TRUE;
      } else {
	options.isolate  = atoi(opt);
      }
    }

    opt = getenv("MP_SUPER_RESTRICT");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.restrict = TRUE;
      } else {
	options.restrict = atoi(opt);
      }
    }

    opt = getenv("MP_SUPER_MUSTRUN");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.mustrun  = TRUE;
      } else {
	options.mustrun  = atoi(opt);
      }
    }

    opt = getenv("MP_SUPER_RESIDENT");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.resident = TRUE;
      } else {
	options.resident = atoi(opt);
      }
    }

    opt = getenv("MP_SUPER_SLICE");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.slice    = USE_SLICE;
      } else {
	options.slice    = atoi(opt);
	if (options.slice < 0) options.slice = 0;
      }
    }

    opt = getenv("MP_SUPER_NDPRI");
    if (opt != NULL) {
      if (strlen(opt) == 0) {
	options.ndpri    = USE_NDPRI;
      } else {
	options.ndpri    = atoi(opt);
	if (options.ndpri < 30) options.ndpri = 0;
      }
    }

  }

  /* This is the number of physically attached processors.
   */
  nprocs   = sysmp(MP_NPROCS);
  nthreads = nth;
  if (nth > nprocs) {
    return (-1);
  }

  /* Since procesors can be turned off, we ask the system for the
   * pda_stat structure for each phyically available processor.
   * This tells us what the physical processor number of each
   * logical processor is.  We need the physical number in order
   * to assign threads to particular processors.
   */
  pstat = (struct pda_stat *) calloc(nprocs, sizeof(struct pda_stat));
  sysmp(MP_STAT, pstat);

  ith = 0;
  if (nprocs > 16) {

    /* Get ordinary processors first, skipping every other
     * processor so that for up to 8 processors, each is on
     * a separate processor board.  For an 18 processor
     * system, this algorithm skips processor 0, which is
     * advantageous since it it frequently handles network
     * duties and other daemon tasks.
     */
    for (ip=nprocs-1,p=pstat+ip; ip>=0 && ith<nth; ip-=2,p-=2) {
      if (!(p->p_flags & PDAF_CLOCK) &&
  	  !(p->p_flags & PDAF_FASTCLOCK) &&
  	   (p->p_flags & PDAF_ENABLED) &&
  	  !(p->p_flags & PDAF_ISOLATED) &&
  	  !(p->p_flags & PDAF_NONPREEMPTIVE)) {
        p_num[ith++] = p->p_cpuid;
      }
    }
    for (ip=nprocs-2,p=pstat+ip; ip>=0 && ith<nth; ip-=2,p-=2) {
      if (!(p->p_flags & PDAF_CLOCK) &&
	  !(p->p_flags & PDAF_FASTCLOCK) &&
	   (p->p_flags & PDAF_ENABLED) &&
	  !(p->p_flags & PDAF_ISOLATED) &&
	  !(p->p_flags & PDAF_NONPREEMPTIVE)) {
        p_num[ith++] = p->p_cpuid;
      }
    }

  } else {

    int	partner, i, j, ok, thiscpu;
    int	npb = 2;			/* for Power Challenge */

    /* Get ordinary processors first, making sure each is on a
     * separate board before allocating two on the same board.
     */
    for (ip=nprocs-1,p=pstat+ip; ip>=0 && ith<nth; ip--,p--) {
      if (!(p->p_flags & PDAF_CLOCK) &&
	  !(p->p_flags & PDAF_FASTCLOCK) &&
	   (p->p_flags & PDAF_ENABLED) &&
	  !(p->p_flags & PDAF_ISOLATED) &&
	  !(p->p_flags & PDAF_NONPREEMPTIVE)) {
        for (i=0, ok=1; i<ith; i++) {
          for (j=1; j<npb; j++) {	/* makes sure no threads have been  */
            partner = p->p_cpuid^j;	/* assigned to a processor on this  */
            if (p_num[i] == partner) {	/* board                            */
              ok = 0;
              break;
            }
          }
        }
        if (ok) p_num[ith++] = p->p_cpuid;
      }
    }
    for (ip=nprocs-1,p=pstat+ip; ip>=0 && ith<nth; ip--,p--) {
      if (!(p->p_flags & PDAF_CLOCK) &&
          !(p->p_flags & PDAF_FASTCLOCK) &&
           (p->p_flags & PDAF_ENABLED) &&
          !(p->p_flags & PDAF_ISOLATED) &&
          !(p->p_flags & PDAF_NONPREEMPTIVE)) {
        thiscpu = p->p_cpuid;
        for (i=0, ok=1; i<ith; i++) {
          if (p_num[i] == thiscpu) {	/* makes sure no thread has already */
            ok = 0;			/* been assigned to this processor  */
            break;
          }
        }
        if (ok) p_num[ith++] = p->p_cpuid;
      }
    }
  }

  /* Next the clock processors.
   */
  for (ip=nprocs-1,p=pstat+ip;ip>=0 && ith<nth; --ip,--p) {
    if ((p->p_flags & PDAF_CLOCK) ||
	(p->p_flags & PDAF_FASTCLOCK)) p_num[ith++] = p->p_cpuid;
  }

  /* Finally, get restricted processors.
   */
  for (ip=nprocs-1,p=pstat+ip; ip>=0 && ith<nth; --ip,--p) {
    if (!(p->p_flags & PDAF_ENABLED)) p_num[ith++] = p->p_cpuid;
  }

  /* There must have been a problem if the number of put into
   * the p_num[] list is less than was requested.
   */
  return ((ith < nth) ? -1 : 0);
}

/*
 * mp_super_
 *
 * Parameters:
 *    ith	- thread number
 */
void
mp_super_(

int	*ithp)

{
  mp_super(*ithp);
}

void
mp_super(

int	ith)

{
  int	ier;

  /* The master thread now has to check whether p_setup() has
   * assigned it to the same processor as the operating system.
   * If not, the OS's choice needs to be found and the list of
   * thread-to-processor assignments adjusted.
   */
  if (ith == 0) {

    int		ip, thiscpu, ith, itmp;
    char	*opt;

    /*
     * Make sure we really can assign the master thread
     * to the processor we want.  If we can't, find one
     * that will work.
     */

    /* We can only have a problem if the ccsync register is
     * being used.  If the following environment variable is
     * set, the ccsync register isn't being used, so all the
     * code to check where the master thread is running can
     * be skipped.
     */
    opt = getenv("_MP_DONT_USE_CCSYNC");
    if (opt == NULL) {

      /* The only way I know to determine whether the master thread
       * can run on a particular processor is to try to MUSTRUN it
       * to that processor.  If this call succeeds, the assignment
       * is OK; in addition, we just leave the thread locked
       * onto that processor since the ccsync register doesn't
       * allow it to go anywhere else anyway.
       */
      ier = sysmp(MP_MUSTRUN, p_num[0]);

      if (ier < 0) {

	/* The one we wanted isn't available, so now search one by one
	 * through all the attached processors in the machine.
	 */
	ip = nprocs-1;
	do {
	  ier = sysmp(MP_MUSTRUN, pstat[ip].p_cpuid);
	  if (ier == 0) {
	    break;
	  }
	  ip--;
	} while (ip >= 0);

	if (ier < 0) {

	  fprintf(stderr,"Unable to locate processor running master thread\n");
	  exit(1);

	} else {

	  /* We found the CPU where the master thread is running.
	   * Now see if we are planning assigning another thread
	   * to it.
	   */
	  thiscpu = pstat[ip].p_cpuid;
	  for (ith=1; ((p_num[ith]!=thiscpu) && (ith<nthreads)); ith++);

	  if (ith == nthreads) {

	    /* No other thread is assigned to this cpu, so we only
	     * have to change the assignment for thread 0 to this
	     * new CPU.
	     */
	    p_num[0] = thiscpu;

	  } else {

	    /* We couldn't assign the master thread to p_num[0], so we have
	     * assigned it to p_num[ith].  This means that the ith thread
	     * should now be assigned to p_num[0].
	     */
	    itmp       = p_num[0];
	    p_num[0]   = p_num[ith];
	    p_num[ith] = itmp;
	  }
	}
      }
    }

    free(pstat);

    /* Dump out the assignment of threads to processors, if requested.
     */
    if (options.dump) {
      printf("UID: %d, Effective UID: %d\n",getuid(),geteuid());
      printf("Options in effect:\n"); {
	printf("\tINFO:      %s\n", options.info     ? "YES" : "NO");
	printf("\tDUMP:      %s\n", options.dump     ? "YES" : "NO");
	printf("\tISOLATE:   %s\n", options.isolate  ? "YES" : "NO");
	printf("\tRESTRICT:  %s\n", options.restrict ? "YES" : "NO");
	printf("\tMUSTRUN:   %s\n", options.mustrun  ? "YES" : "NO");
	printf("\tRESIDENT:  %s\n", options.resident ? "YES" : "NO");
	printf("\tSLICE:     %d\n", options.slice                  );
	printf("\tNDPRI:     %d\n", options.ndpri                  );
      }
      for(ith=0; ith<nthreads; ++ith) {
	printf("Thread %2d on processor %2d\n",ith,p_num[ith]);
      }
    }

  }

  /* Wait for the master thread to finish fixing up the assignment
   * of threads to processors.
   */
  if (nthreads > 1) mp_barrier_();

  if (options.info) {
    if (nthreads > 1) mp_setlock_();
    printf("mp_super thread %d\n",ith);
  }

  if (options.mustrun) {
    ier = sysmp(MP_MUSTRUN, p_num[ith]);
    if (options.info) {
      printf("\tsysmp(MP_MUSTRUN,%d) returned %d\n",p_num[ith],ier);
      if (ier < 0) {
        printf("\t\terror # %d\n",errno);
        perror("\t\tMP_MUSTRUN");
      }
    }
  }

  if (options.resident) {
    ier = prctl(PR_RESIDENT);
    if (options.info) {
      printf("\tprctl(PR_RESIDENT) returned %d\n",ier);
      if (ier < 0) {
        printf("\t\terror # %d\n",errno);
        perror("\t\tPR_RESIDENT");
      }
    }
  }

  if (options.slice) {
    ier = schedctl(SLICE,0,USE_SLICE);
    if (options.info) {
      printf("\tschedctl(SLICE,0,%d) returned %d\n",USE_SLICE,ier);
      if (ier < 0) {
        printf("\t\terror # %d\n",errno);
        perror("\t\tSLICE");
      }
    }
  }

  if (options.ndpri) {
    ier = schedctl(NDPRI,0,USE_NDPRI);
    if (options.info) {
      printf("\tschedctl(NDPRI,0,%d) returned %d\n",USE_NDPRI,ier);
      if (ier < 0) {
        printf("\t\terror # %d\n",errno);
        perror("\t\tNDPRI");
      }
    }
  }

  if (options.isolate) {
    ier = sysmp(MP_ISOLATE, p_num[ith]);
    if (options.info) {
      printf("\tsysmp(MP_ISOLATE,%d) returned %d\n",p_num[ith],ier);
      if (ier < 0) {
        printf("\t\terror # %d\n",errno);
        perror("\t\tMP_ISOLATE");
      }
    }
  }

  if (options.restrict) {
    ier = sysmp(MP_RESTRICT, p_num[ith]);
    if (options.info) {
      printf("\tsysmp(MP_RESTRICT,%d) returned %d\n",p_num[ith],ier);
      if (ier < 0) {
        printf("\t\terror # %d\n",errno);
        perror("\t\tMP_RESTRICT");
      }
    }
  }

  if (options.info) {
    if (nthreads > 1) mp_unsetlock_();
  }

  return;
}

/*
 * Undo damage from using super stuff
 *
 * Parameters:
 *    ith	- thread number
 */
void
mp_unsuper_(

int	*ithp)

{
  mp_unsuper(*ithp);
}

void
mp_unsuper(

int	ith)

{
  int ier;

  if (options.info) {
    if (nthreads > 1) mp_setlock_();
    printf("mp_unsuper thread %d\n",ith);
  }

  if (options.isolate) {
    ier = sysmp(MP_UNISOLATE,p_num[ith]);
    if (options.info) {
      printf("\tsysmp(MP_UNISOLATE,%d) returned %d\n",p_num[ith],ier);
      if (ier < 0) {
	printf("\t\terror # %d\n",errno);
	perror("\t\tMP_UNISOLATE");
      }
    }
  }

  if (options.restrict) {
    ier = sysmp(MP_EMPOWER,p_num[ith]);
    if (options.info) {
      printf("\tsysmp(MP_EMPOWER,%d) returned %d\n",p_num[ith],ier);
      if (ier < 0) {
	printf("\t\terror # %d\n",errno);
	perror("\t\tMP_EMPOWER");
      }
    }
  }

  if (options.info) {
    if (nthreads > 1) mp_unsetlock_();
  }

  return;
}
