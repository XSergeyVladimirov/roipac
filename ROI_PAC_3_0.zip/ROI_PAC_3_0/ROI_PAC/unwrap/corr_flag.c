#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

#define PLUS 1
#define MINU 2
#define CHG  3
#define GUID 4
#define LSNR 8
#define VIST 16
#define BRPT 32
#define CUT  64
#define LAWN 128
#define TREE 128

#define REL_BEGIN 0		/* fseek relative to beginning of file */
#define REL_CUR   1		/* fseek relative to current position */
#define REL_EOF   2		/* fseek relative to end of file */

#define Max(a,b)  ( ( (a) > (b) ) ? (a) : (b) )
#define Min(a,b)  ( ( (a) < (b) ) ? (a) : (b) )
#define Abs(a)    ( ((a) > 0) ? (a) : (-a) )

#define PI	3.1415926535 
#define TWO_PI  6.283185308

main(int argc, char **argv)
{
    double thr;			/* correlation threshold */
    float **cc, *ccb;		/* correlation data */

    int nlines;			/* number of lines in the file */
    int start=1;		/* starting line */
    int xmin=0;			/* window column minima */
    int ymin=0;			/* window row minima*/
    int width, ymax, xmax;	/* interferogram width, window maxima (relative to start) */
    int xw,yh;			/* width, height of processed region */
    int offs;			/* offset number of lines to read from start of file*/
    int i,j;

    unsigned char *fbf;		/* flag array */
    unsigned char **fb;		/* set of pointers to the rows of flag array */
    unsigned char *bz;
    FILE *flag_file, *c_file;
   
   fprintf(stdout,"*** correlation threshold for phase unwrapping v1.1 8-aug-94 clw ***\n") ;

 if(argc < 5) {
    fprintf(stdout,"\nusage: %s <corr_file> <flag_file> <width> <corr_thr> [start] [xmin] [xmax] [ymin] [ymax]\n\n",argv[0]) ;
    
    fprintf(stdout, "input parameters: \n");
    fprintf(stdout, "  corr_file      interferometric correlation file\n");
    fprintf(stdout, "  flag_file      phase unwrapping flag filename \n");     
    fprintf(stdout, "  width          number of samples/row\n");
    fprintf(stdout, "  corr_thr       correlation threshold (0 --> 1.0)\n");
    fprintf(stdout, "  start          starting line (default = 1)\n");
    fprintf(stderr, "  xmin           starting range pixel offset (default = 0)\n");    
    fprintf(stderr, "  xmax           last range pixel offset (default = width-1)\n");    
    fprintf(stderr, "  ymin           starting azimuth row offset, relative to start (default = 0)\n");    
    fprintf(stderr, "  ymax           last azimuth row offset, relative to start (default = nlines-1)\n\n");           
    exit(1) ;
  } 
 
  c_file = fopen(argv[1],"r"); 
  if (c_file == NULL){
    fprintf(stderr, "cannot open correlation file!\n");
    exit(-1);
  }

  sscanf(argv[3],"%d",&width);  
  xmax=width-1;				 	/* default value of xmax */
  sscanf(argv[4],"%lf",&thr);			/* correlation threshold */
  fprintf(stdout,"line width, correlation threshold: %d  %8.3lf\n",width, thr);

  fseek(c_file, 0L, REL_EOF);			/* determine # lines in the file */
  nlines=(int)ftell(c_file)/(8*width);
  fprintf(stdout,"#lines in the correlation file: %d\n",nlines); 
  rewind(c_file);

  if(argc >5)sscanf(argv[5],"%d",&start);	/* starting line */
  ymax=nlines-start;				/* default value of ymax */
  if(argc >6)sscanf(argv[6],"%d",&xmin);	/* window to process */
  if(argc >7)sscanf(argv[7],"%d",&xmax);
  if(argc >8)sscanf(argv[8],"%d",&ymin);
  if(argc >9)sscanf(argv[9],"%d",&ymax);
   										
  if (ymax > nlines-start){
    ymax = nlines-start;
    fprintf(stdout,"insufficient #lines in the file, ymax: %d\n",ymax);
  }

  if (xmax > width-1) xmax=width-1;	/* check to see if xmax within bounds */

  xw=xmax-xmin+1;	/* width of each line to process */
  yh=ymax-ymin+1;	/* height of array */
  offs=start+ymin-1;	/* first line of file to start reading/writing */

  bz = (unsigned char *)malloc(sizeof(unsigned char)*width);
  if(bz ==  NULL) {
    fprintf(stdout,"failure to allocate space null line\n");
    exit(1) ;
  }
  for (i=0; i < width; i++) bz[i]=LSNR;
  ccb = (float *) malloc(sizeof(float)*2*width*yh);
  if(ccb ==  NULL) {
    fprintf(stdout,"failure to allocate space for correlation data\n");
    exit(1) ;
  }

  fbf = (unsigned char *) malloc(sizeof(unsigned char)*width*yh);
  if(fbf == (unsigned char *) NULL) {
    fprintf(stdout,"failure to allocate space for flag array\n");
    exit(1) ;
  }

  fb=(unsigned char **)malloc(sizeof(unsigned char**)*yh);		/* row pointers of flag data */
  cc = (float **) malloc(sizeof(float*)*yh);				/* row pointers of corr data */
  if(cc ==  NULL || fb == NULL) {
    fprintf(stdout,"failure to allocate space for line pointers!\n");
    exit(1) ;
  }
  
  for (i=0; i< yh; i++){
    fb[i] = (unsigned char *)(fbf + i*width + xmin);
    cc[i] =  (float *)(ccb + 2*i*width + width+xmin);
  }
      
  flag_file = fopen(argv[2],"r+"); 
  if (flag_file == NULL){
      fprintf(stdout, "flag file does not exist, creating file: %s\n",argv[2]);
      flag_file = fopen(argv[2],"w"); 
      for (i=0; i< width*yh; i++)fbf[i]=LSNR;		/* initialize all points to LSNR */
  }
  else{
    fprintf(stdout, "reading flag file: %s\n",argv[2]);
    fseek(flag_file, offs*width, REL_BEGIN); 		/*seek start line of flag file  */
    fread((char *)fbf, sizeof(char), yh*width, flag_file); 
    rewind(flag_file);
    for (i=0; i < width*yh; i++){fbf[i] |= LSNR; fbf[i] &= ~LAWN;};	/* clear LAWN flag, logical OR with LSNR */
  }
  
/**************** Read in correlation data *********************/
   
  fprintf(stdout,"reading correlation data file...\n");
  fseek(c_file, offs*width*2*sizeof(float), REL_BEGIN); 
  fread((char *)ccb, sizeof(float), 2*yh*width, c_file); 
 
  fprintf(stdout,"setting low SNR flag...\n");
 
  for (i=0; i < yh; i++) {
    for (j=0; j < xw; j++) { 
      if (cc[i][j] > thr)fb[i][j] &= ~LSNR;	/* unset LSNR flag */;
    }
  }
       
/************** write out flag array *************/

  fprintf(stdout,"writing output file...\n");
  if (ymin > 0){
    for (i=0; i < ymin; i++) fwrite((char *)bz , sizeof(unsigned char), width, flag_file);
  }
  fwrite((char *)fbf, sizeof(unsigned char), yh*width, flag_file); 
  return(0); 
}
