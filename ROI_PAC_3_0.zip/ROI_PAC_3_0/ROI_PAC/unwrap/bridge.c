#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

static double nintarg; 
#define nint(a) ( ((nintarg=(a)) >= 0.0 )?(int)(nintarg+0.5):(int)(nintarg-0.5) )

#define SCROLL_WIDTH	21	/* width of scrollbar */
#define WIN_WIDTH_MAX 	960
#define WIN_HEIGHT_MAX	768
#define LR_NORMAL 1		/* normal display */
#define LR_REV	 -1		/* display reverse of each line, left to right */

#define PLUS 1
#define MINU 2
#define CHG  3
#define GUID 4
#define LSNR 8
#define VIST 16
#define BRPT 32
#define CUT  64
#define LAWN 128
#define TREE 128

#define REL_BEGIN 0		/* fseek relative to beginning of file */
#define REL_CUR   1		/* fseek relative to current position */
#define REL_EOF   2		/* fseek relative to end of file */

#define Max(a,b)  ( ( (a) > (b) ) ? (a) : (b) )
#define Min(a,b)  ( ( (a) < (b) ) ? (a) : (b) )
#define Abs(a)    ( ((a) > 0) ? (a) : (-a) )
#define SQR(a)	  ( (a)*(a) )

#define PI	3.14159265359 
#define TWO_PI  6.28318530718
#define RTD	57.2957795131	/* radians to degrees */
#define DTR	.0174532925199	/* degrees to radians */
#define C	2.99792458e8

#define MAX_CRAB 40000			/* maximum size of ping-pong list for growth of crabgrass */

typedef struct{int x,y;}Xpoint;
typedef struct{float re,im;}fcomplex;

int ii[2][MAX_CRAB], jj[2][MAX_CRAB];	/* arrays for keeping locations of points for crabgrass */
int nn[2];				/* array containing lengths of the ping-pong lists */
int npu;				/* number of points unwrapped */
Xpoint bridge[2];			/* bridge for phase unwrapping */

void crab_step(unsigned char **, float **,  int, int, int, int);

#ifdef DISPLAY
void dunwbr(char*, char*, int*, int*, int*, int*);
#endif

unsigned char *fbf;

void start_timing();					/* timing routines */
void stop_timing();

int main(int argc, char **argv)
{
    double frac;		/* fraction of image which was unwrapped */
    double p_min,p_max;		/* minimum and maximum phase values */
    double p0,p1;		/* phases on either side of a bridge */	

    float *buf, *buf_out;	/* single row complex data, output line */
    float **phase, *ph;		/* phase array for unwrapping */

    int nl1,nl2,nl3,nlines;	/* number of lines in the files */
    int npu1;			/* number of pixels previously unwrapped */
    int xmin=0;			/* window column minima*/
    int ymin=0;			/* window row minima*/
    int width, ymax, xmax;	/* interferogram width, window maxima (relative to start) */
    int yh;			/* height of processed region */
    int xinit,yinit;		/* initial starting point for phase unwrapping */
    int i,j;			/* loop counters */
    int m;			/* current ping-pong list */
    int pp;			/* ping-pong counter */
    int ppd;			/* ping-pong iteration for display */
    int lc;			/* output line counter */
    int npt;			/* number of points with valid phase values */
    int nrev;			/* number of multiples of 2PI for each bridge */
    int ww, wh, cv_width, cv_height;  	/* Xview variables */
 


    unsigned char **gzw, *fbf;	/* set of pointers to the rows of flag array */
    static char br[120];	/* bridge data */
    FILE *int_file, *flag_file, *unw_file, *br_file;
   
  fprintf(stderr,"*** phase unwrap new regions with bridges v1.0 clw ***\n") ;
  if(argc < 5){
    fprintf(stderr,"\nusage: %s <int_file> <flagfile> <unwrapfile> <bridge> <width> [xmin] [xmax] [ymin] [ymax]\n\n",argv[0]) ;
    
    fprintf(stderr,"input parameters: \n");
    fprintf(stderr,"  int_file       interferogram filename\n");     
    fprintf(stderr,"  flagfile       unwrapping flag filename\n");     
    fprintf(stderr,"  unwrapfile     unwrapped phase filename\n");
    fprintf(stderr,"  bridge         bridge data filename\n");    
    fprintf(stderr,"  width          number of samples/row\n");
    fprintf(stderr,"  xmin           starting range pixel offset (default = 0)\n");    
    fprintf(stderr,"  xmax           last range pixel offset (default=width-1)\n");    
    fprintf(stderr,"  ymin           starting azimuth row offset, relative to start (default = 0)\n");    
    fprintf(stderr,"  ymax           last azimuth row offset, relative to start (default = nlines-1)\n");    
    exit(-1);
  }
  start_timing();
  int_file = fopen(argv[1],"r"); 
  if (int_file == NULL){fprintf(stderr,"ERROR: cannot open interferogram file: %s\n",argv[1]); exit(-1);}
  flag_file = fopen(argv[2],"r+"); 
  if (flag_file == NULL){fprintf(stderr,"ERROR: cannot open flag file: %s\n",argv[2]); exit(-1);}
  unw_file = fopen(argv[3],"r+"); 
  if (unw_file == NULL){fprintf(stderr,"ERROR: cannot create upwrapped phase file: %s\n",argv[3]); exit(-1);}
  br_file = fopen(argv[4],"r"); 
  if (unw_file == NULL){fprintf(stderr,"ERROR: cannot open bridge data file: %s\n",argv[4]); exit(-1);}

  sscanf(argv[5],"%d",&width);  		/* value width */
  xmax=width-1;				 	/* default value of xmax */
 
  fseek(int_file, 0L, REL_EOF);			/* determine # lines in the file */
  fseek(unw_file, 0L, REL_EOF);
  fseek(flag_file, 0L, REL_EOF);
  nl1=(int)ftell(int_file)/(width*sizeof(fcomplex));
  nl2=(int)ftell(unw_file)/(width*sizeof(float));
  nl3=(int)ftell(flag_file)/(width*sizeof(char ));
  fprintf(stderr,"#lines interferogram, unwrapped phase, flag file: %6d %6d %6d\n",nl1,nl2,nl3);
  nlines=nl3; 
  rewind(int_file);
  rewind(unw_file);
  rewind(flag_file);

  ymax=nlines-1;				/* default value of ymax */
  if(argc >6)sscanf(argv[6],"%d",&xmin);
  if(argc >7)sscanf(argv[7],"%d",&xmax);
  if(argc >8)sscanf(argv[8],"%d",&ymin);   						
  if(argc >9)sscanf(argv[9],"%d",&ymax);   						
				
  if (ymax > nlines-1){
    ymax = nlines-1;
    fprintf(stderr,"WARNING: insufficient #lines in the file, ymax: %d\n",ymax);
  }

  if (xmax > width-1) xmax=width-1;		/* check that xmax within bounds */

  yh=ymax-ymin+1;				/* height of array */
  fprintf(stderr,"array width,height (x,y):    %6d %6d\n",width,yh);

/******************* Allocate memory *********************/  

  ph = (float *) malloc(sizeof(float)*width*yh);
  if(ph == NULL){fprintf(stderr,"ERROR: failure to allocate space for phase array\n"); exit(-1);}

  buf = (float *)malloc(2*sizeof(float)*width);
  if(buf == NULL){fprintf(stderr,"ERROR: failure to allocate space for input line buffer\n"); exit(-1);}

  buf_out = (float *)malloc(sizeof(float)*width);
  if(buf_out == NULL){fprintf(stderr,"ERROR: failure to allocate space output line buffer\n"); exit(-1);}

  fbf = (unsigned char *)malloc(sizeof(unsigned char)*width*yh);
  if(fbf == NULL){fprintf(stderr,"ERROR: failure to allocate space for flag array\n"); exit(-1);}

  phase = (float **)malloc(sizeof(float *)*yh);				/* allocate  phase pointers */
  gzw = (unsigned char **)malloc(sizeof(unsigned char *)*yh); 		/* allocate flag pointers */
  if(gzw == NULL || phase == NULL){fprintf(stderr,"ERROR: memory allocation of line pointers!\n"); exit(-1);}

  for (i=0; i < yh; i++)phase[i] = (float *)(ph + i*width);		/* setup pointers */
  for (i=0; i < yh; i++)gzw[i] = (unsigned char *)(fbf + i*width);

  fprintf(stderr,"initializing phase array...\n");
  for(i=0; i < yh; i++){for (j=0; j < width; j++)phase[i][j]=0.0;}
  for(i=0; i < 120; i++)br[i]=0;

/**************** Read input data files ******************/

  cv_height=yh;
  cv_width=width;
  ww=Min(WIN_WIDTH_MAX,cv_width+SCROLL_WIDTH);
  wh=Min(WIN_HEIGHT_MAX,cv_height+SCROLL_WIDTH);

  fprintf(stdout,"interferogram file: %s\n",argv[1]);
  fprintf(stdout,"unwrapping flag file: %s\n",argv[2]);
  fprintf(stdout,"unwrapped phase file: %s\n",argv[3]);

  fseek(flag_file, ymin*width*sizeof(unsigned char), REL_BEGIN);      
  fseek(int_file, ymin*width*sizeof(fcomplex), REL_BEGIN);
  fseek(unw_file, ymin*width*sizeof(float), REL_BEGIN);

  fread((char *)fbf, sizeof(unsigned char), width*yh, flag_file);	/* read unwrapping flag data */
  fread((char *)ph, sizeof(float), width*yh, unw_file);			/* read unwrapped data */
  for (npu1=0,i=0; i < yh*width; i++)if((fbf[i] & LAWN) != 0)npu1++;	/* number of points already unwrapped */
  fprintf(stdout,"\nnumber of points unwrapped: %d\n",npu1);
  rewind(flag_file);
  rewind(unw_file);

  for(npt=0,i=0; i < yh; i++){						/* initialize point counters */
    fread((char *)buf, sizeof(float), 2*width, int_file);
    if(i%100 == 0)fprintf(stderr,"\rinterferogram line: %6d",i);
    for(j=0; j < width; j++){
      if(buf[2*j] != 0.0){						/* point with valid phase value */
        if((j >= xmin) && (j <= xmax))npt++;				/* number of points to be unwrapped */
        if ((gzw[i][j] & LAWN) == 0)phase[i][j]=atan2((double)buf[2*j+1],(double)buf[2*j]); 
      } 
    }
  }

  fprintf(stdout,"\ntotal number of lines: %d\n",i);
  fprintf(stdout,"number of valid phase data samples: %8d\n",npt);
  frac = npu1/(float)(npt);
  fprintf(stdout,"fraction of the phase image unwrapped: %8.5f\n",frac);

/******** grow crabgrass *********/

  while(fgets(br,120,br_file) != NULL){
    sscanf(br,"%d %d %d %d %d",&bridge[0].x, &bridge[0].y, &bridge[1].x, &bridge[1].y, &nrev);
    fprintf(stdout,"\nbridge starting point (x,y): %6d  %6d\n",bridge[0].x, bridge[0].y); 
    fprintf(stdout,"bridge end point (x,y):      %6d  %6d\n",bridge[1].x, bridge[1].y); 
    fprintf(stdout,"number of multiples of 2PI to add: %3d\n",nrev);

    if ((gzw[bridge[0].y][bridge[0].x] & LAWN) == 0){
      fprintf(stderr,"ERROR: starting point not unwrapped: %6d %6d\n",bridge[0].x,bridge[0].y);
      continue;
    }
    if ((gzw[bridge[1].y][bridge[1].x] & LSNR) != 0){
      fprintf(stderr,"ERROR: destination marked as LSNR: %6d %6d\n",bridge[1].x,bridge[1].y);
      continue;
    }

    xinit=bridge[1].x;
    yinit=bridge[1].y; 						

    while((gzw[yinit][xinit] & CUT) != 0){xinit++; yinit++;} 		/* initial point cannot be on a CUT */
    fprintf(stdout,"actual starting point for new region (x,y): %6d  %6d\n",xinit,yinit); 

    p0 = (double)phase[bridge[0].y][bridge[0].x]; 			/* unwrap the phase for this point */
    p1 = (double)phase[yinit][xinit];      
    phase[yinit][xinit] += TWO_PI*(nint((p0-p1)/TWO_PI)+nrev);  	/* across the bridge */
    fprintf(stdout,"phase (unwrapped side): %9.3f\n",p0);
    fprintf(stdout,"phase on the other side of the bridge (wrapped, unwrapped):  %9.3f %9.3f\n",p1,phase[yinit][xinit]);
    fflush(stdout);


    pp=0;								/* initalize ping-pong counter */
    nn[0]=1; nn[1]=0;							/* initial list lengths */
    npu=0;								/* number of pixels unwrapped */
    m=0;								/* current ping-pong list */
    ii[0][0]=yinit; jj[0][0]=xinit;					/* initialize list with the seed */

    while(nn[m] != 0){							/* continue as long as list not zero length */
      crab_step(gzw,phase,xmin,xmax,yh,m); 
      m=1-m;								/* ping-pong */
      if (pp%100 == 0){fprintf(stderr,"\rbuffer ping-pongs, list size:  %6d  %6d ", pp, nn[m]); fflush(stderr);}
      pp++;								/* increment ping-pong step counter */
    }

#ifdef DISPLAY
    dunwbr(argv[1],(char *)fbf,&cv_width,&cv_height,&ww, &wh);
#endif
  
    fprintf(stdout,"\ntotal buffer ping-pongs: %d\n",pp);
    npu1 += npu;
    frac = npu1/(float)(npt);
    fprintf(stdout,"number of phase samples unwrapped for this region:  %8d\n",npu); 
    fprintf(stdout,"total number of phase samples unwrapped:  %8d\n",npu1); 
    fprintf(stdout,"fraction of the phase image unwrapped:    %8.5f\n",frac);

  }
  p_min=p_max=0.0;

  for(i=0; i < yh; i++){						/* determine min and max phase values */
    for(j=xmin; j <= xmax; j++) {
      if(phase[i][j] < p_min) p_min=phase[i][j];
      if(phase[i][j] > p_max) p_max=phase[i][j];
    }
  }

  fprintf(stdout,"minimum phase, maximum phase:  %12.3f   %12.3f\n",p_min,p_max);
  fprintf(stdout,"phase difference:              %12.3f\n",p_max-p_min);
  fflush(stdout);


  for (i=0; i < width; i++)buf[i]=0.0;					/* generate NULL line */
  fprintf(stderr,"writing output unwrapped phase: %s\n",argv[3]);

  for (i=0; i < ymin; i++)fwrite((char *)buf,sizeof(float),width,unw_file); /* write ymin lines */
  lc=ymin;

  for (i=0; i < yh; i++){
    for (j=0; j < width; j++){
      if ((j >= xmin) && (j < xmax) && ((gzw[i][j]&LAWN) != 0)){	/* check if on the LAWN too */
        buf_out[j] = phase[i][j];
      }
      else {
        buf_out[j]=0.0;
      }
    }   
    fwrite((char *)buf_out,sizeof(float),width,unw_file);		/* writout unwrapped phase */
    lc++;
  }

  for (i=0; i < width; i++)buf[i]=0.0;					/* generate NULL line */
  for (i=lc; i < nlines; i++){						/* fill in the rest of the file */
    fwrite((char *)buf,sizeof(float),width,unw_file);
    lc++;
  }
  
  fprintf(stderr,"writing flag file: %s\n",argv[2]);
  fseek(flag_file, ymin*width*sizeof(unsigned char), REL_BEGIN); 	/* seek starting line of flag file */
  fwrite((char *)fbf, sizeof(unsigned char), yh*width, flag_file);	/* writeout the updated flag file */
  fprintf(stdout,"# output lines: %d\n",lc); 
  stop_timing();
  return(0);  
}

void crab_step(unsigned char **gzw, float **phase, int xmin, int xmax, int data_h, int m)
{
  int i,j,k,l,i1,j1;
  double u;
  static int dir_x[]={ 0, 0,-1, 1};   
  static int dir_y[]={-1, 1, 0, 0};	 
  
  if(nn[m]==0) return;  			/* if list zero length */
  nn[1-m]=0;					/* initialize new list length */

  for(k=0; k < nn[m]; k++) {			/* go through the list, growing around each pixel if possible */
    i=ii[m][k]; j=jj[m][k];			/* x and y of point on the list */
    u=(double)phase[i][j];

    for(l=0; l < 4; l++) {			/* check 4 nearest neighbors */
      i1=i+dir_x[l]; j1=j+dir_y[l];		/* location of new pixel for unwrapping */

      if((i1 < 0) || (i1 >= data_h) || (j1 < xmin) || (j1 >= xmax)) continue; 	/* check new pixel outside of boundries */
      if((gzw[i1][j1] & (LAWN | LSNR)) != 0) continue; 				/* check if already grown or LSNR, don't unwrap if true */

      phase[i1][j1] += TWO_PI*nint((u-(double)phase[i1][j1])/TWO_PI); 	/* unwrap the phase */
      gzw[i1][j1] |= LAWN;						/* set unwrapped flag bit to LAWN */
      npu++;								/* increment number of pixels unwrapped */

      if((gzw[i1][j1] & CUT) != 0) continue; 			/* check if unwrapped pixel on a CUT, if true, don't put on the list */

      if((nn[1-m] < MAX_CRAB)){ 				/* check of ping-pong list length exceeded */			
        ii[1-m][nn[1-m]]=i1; jj[1-m][nn[1-m]]=j1; 		/* place this pixel onto the new list */
        nn[1-m]++;						/* increment the length counter of the new list */
      }
      else{
        fprintf(stderr,"WARNING: Subroutine crab_step, ping-pong table overflow...\n"); 
        return;							/* grow the new list */
      }
    }
  }
}


#include <sys/types.h>
#include <sys/time.h>
#include <sys/times.h>
#include <unistd.h>
#include <limits.h>

struct tms buffer;
int user_time, system_time, start_time;

void start_timing()
{
  start_time = (int) times(&buffer);
  user_time = (int) buffer.tms_utime;
  system_time = (int) buffer.tms_stime;
}

void stop_timing()
{
  int  end_time,elapsed_time;
  int clk_tck;

  clk_tck = (int)sysconf(_SC_CLK_TCK);

  end_time = (int) times(&buffer);
  user_time = (int) (buffer.tms_utime - user_time);
  system_time = (int) (buffer.tms_stime - system_time);
  elapsed_time = (end_time - start_time);

  fprintf(stdout,"\n\nuser time    (s):  %10.3f\n", (double)user_time/clk_tck);
  fprintf(stdout,"system time  (s):  %10.3f\n", (double)system_time/clk_tck); 
  fprintf(stdout,"elapsed time (s):  %10.3f\n\n", (double) elapsed_time/clk_tck);
}

