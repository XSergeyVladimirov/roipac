#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

static double nintarg; 
#define nint(a) ( ((nintarg=(a)) >= 0.0 )?(int)(nintarg+0.5):(int)(nintarg-0.5) )

#define PLUS 1
#define MINU 2
#define CHG  3
#define GUID 4
#define LSNR 8
#define VIST 16
#define BRPT 32
#define CUT  64
#define LAWN 128
#define TREE 128

#define REL_BEGIN 0		/* fseek relative to beginning of file */
#define REL_CUR   1		/* fseek relative to current position */
#define REL_EOF   2		/* fseek relative to end of file */
#define NEW_FILE  1		/* new flag file */
#define OLD_FILE  0		/* old flag file */

#define Max(a,b)  ( ( (a) > (b) ) ? (a) : (b) )
#define Min(a,b)  ( ( (a) < (b) ) ? (a) : (b) )
#define Abs(a)    ( ((a) > 0) ? (a) : (-a) )

#define PI	3.1415926535 
#define TWO_PI  6.283185308
#define RTD	57.2957795131	/* radians to degrees */
#define DTR	.0174532925199	/* degrees to radians */
#define C	2.99792458e8

void mk_res(float *, unsigned char *, int, int, int, int, int, int*, int*) ;

void start_timing();					/* timing routines */
void stop_timing();
	
main(int argc, char **argv)
{
    float *buf, *phase;		/* interferogram line buffer, phase array */	
    double frac;		/* fraction of image which is residues */	
    int nlines;			/* number of lines in the file */
    int xmin=0;			/* window column minima */
    int ymin=0;			/* window row minima */
    int width, ymax, xmax;	/* interferogram width, window maxima */
    int offs;			/* offset number of lines to read from start of file*/
    int xw,yh;			/* width, height of processed region */
    int i,j;
    int ff;			/* file flag (NEW or OLD ) */
    int np_res, nm_res;		/* number of positive and negative residues */
    unsigned char *fbf, *bufz;	/* flag array, buffer with zeroes*/
    FILE *int_file, *flag_file;
   
  fprintf(stdout,"*** phase residues v2.1 1-dec-94 clw/par ***\n") ;
  if(argc < 4) {
    fprintf(stderr,"\nusage: %s <interferogram> <flagfile> <width> [xmin] [xmax] [ymin] [ymax]\n\n",argv[0]) ;
    
    fprintf(stderr, "input parameters: \n");
    fprintf(stderr, "  interferogram  complex image data\n");     
    fprintf(stderr, "  flagfile       flag filename \n");     
    fprintf(stderr, "  width          number of samples/row\n");     
    fprintf(stderr, "  xmin           offset to starting range pixel(default = 0)\n");    
    fprintf(stderr, "  xmax           offset last range pixel (default = width-1)\n");    
    fprintf(stderr, "  ymin           offset to starting azimuth row (default = 0)\n");    
    fprintf(stderr, "  ymax           offset to last azimuth row (default = nlines-1)\n\n");    
    exit(-1);
  }

  int_file = fopen(argv[1],"r"); 
  if (int_file == NULL){fprintf(stderr,"cannot open interferogram file: %s\n",argv[1]); exit(-1);}

  sscanf(argv[3],"%d",&width);  
  xmax = width - 1;	 
 
  fseek(int_file, 0L, REL_EOF);
  nlines=(int)ftell(int_file)/(width*2*sizeof(float));
  fprintf(stdout,"#lines in the file: %d\n",nlines); 
  rewind(int_file);

  flag_file = fopen(argv[2],"r+"); 
  if (flag_file != NULL) ff=OLD_FILE;
  else {
    fprintf(stderr,"cannot open output flag file, creating new file: %s\n",argv[2]);
    flag_file = fopen(argv[2],"w");
    if(flag_file == NULL){fprintf(stderr,"cannot create new flag file: %s\n",argv[2]); exit(-1);}
    ff=NEW_FILE;         
  }

  ymax=nlines-1;				/* default value of ymax */
  if(argc >4)sscanf(argv[4],"%d",&xmin);	/* window to process */
  if(argc >5)sscanf(argv[5],"%d",&xmax);
  if(argc >6)sscanf(argv[6],"%d",&ymin);
  if(argc >7)sscanf(argv[7],"%d",&ymax);
  
  if (ymax > nlines-1){
    ymax = nlines-1; 
    fprintf(stderr,"insufficient #lines in the file, resetting length: %d\n",ymax);
  }

  if(xmax > width-1){
    xmax=width-1;
    fprintf(stderr,"file has insufficient width, resetting width: %d\n",xmax);
  }

  yh=ymax-ymin+1;		/* height of array */ 
  xw=xmax-xmin+1;		/* width of array */ 
  offs=ymin;			/* first line of file to start reading/writing */

  fprintf(stdout,"flag array width, height: %d %d\n",xw,yh);

/************** memory allocation ***************/ 
  start_timing();
  buf = (float *)malloc(2*sizeof(float)*width);
  if(buf == NULL){fprintf(stderr,"failure to allocate space for input line buffer\n"); exit(-1);}

  bufz = (unsigned char *)malloc(width);
  if(bufz == NULL){fprintf(stderr,"failure to allocate space for null output line\n"); exit(-1);}
  for (j=0; j < width; j++)bufz[j]=0;		/* initialize buffer row array */

  phase = (float *) malloc(sizeof(float)*width*yh);
  if(phase == NULL){fprintf(stderr,"failure to allocate space for phase data\n"); exit(-1);}

  fbf = (unsigned char *) malloc (sizeof(unsigned char)*width*yh);
  if(fbf == NULL){fprintf(stderr,"failure to allocate space for flag array\n"); exit(-1);}

  if(ff == NEW_FILE){
    fprintf(stderr,"initializing flag array...\n");
    for (i=0; i < yh; i++){				/* initialize flag array */
      for (j=0; j < width; j++){
        fbf[i*width+j]=0;
      }
    }
  }
  else {
    fprintf(stderr,"reading flag array...\n");
    fseek(flag_file, offs*width*sizeof(unsigned char), REL_BEGIN);  
    fread((char *)fbf, sizeof(unsigned char), width*yh, flag_file); 
  }

/**************** Read in data, convert to phase *********************/
   
  fseek(int_file, offs*width*2*sizeof(float), REL_BEGIN); 	/*seek start line */

  for (i=0; i < yh; i++){
    if (i%100 == 0){fprintf(stdout,"\rreading input line %d", i); fflush(stdout);}
    fread((char *)buf, sizeof(float), 2*width, int_file);	/* read next line */

    for (j=0; j < width; j++) {
      if((buf[2*j]==0.) && (buf[2*j+1]==0.)) phase[i*width+j]=0.;/* phase undefined */
      else phase[i*width+j] = atan2(buf[2*j+1],buf[2*j]);
    }
  }

/************************ find residues ******************************/

  fprintf(stdout,"\ncalculating residues...\n");
  mk_res(phase, fbf, width, xmin, xmax, ymin, ymax, &np_res, &nm_res);

  frac = (double)(np_res+nm_res)/fabs((double)(xw*yh));

  fprintf(stderr,"\nnumber of positive residues: %d\n",np_res);
  fprintf(stderr,"number of negative residues: %d\n",nm_res);
  fprintf(stderr,"total number of residues:    %d\n",np_res+nm_res);
  fprintf(stderr,"fraction residues:           %8.5f\n",frac);

/********************** write out flag array *************************/

  fprintf(stderr,"writing flag array...\n");
  
  if (ff == OLD_FILE) fseek(flag_file, offs*width*sizeof(unsigned char), REL_BEGIN);
  else for (i=0; i< ymin; i++) fwrite((char *)bufz, sizeof(unsigned char), width, flag_file);	/* write out blank lines */ 
  
  fwrite((char *)fbf, sizeof(unsigned char), yh*width, flag_file); 

  stop_timing();
  return(0);  
}  

void mk_res(float *phase, unsigned char *flags, int width, int xmin, 
            int xmax, int ymin, int ymax, int *n_m, int *n_p) 
{

  int i,j,k,l,offs,offt,offb,yh;

  static int ioft[4] = {0, 1, 1, 0} ;   /* row index offset for top of difference */
  static int joft[4] = {1, 1, 0, 0} ;   /* col index offset for top of difference */
  static int iofb[4] = {0, 0, 1, 1} ;   /* row index offset for bottom of difference */
  static int jofb[4] = {0, 1, 1, 0} ;   /* col index offset for bottom of difference */

  *n_m=0;					/* initialize residue counters */
  *n_p=0;
   
  yh=ymax-ymin+1;				/* height of array */ 
  if (xmax >= width-1) xmax = width-1;		 
 
  for (i=0; i < yh-1; i++) {			/* 1 pixel border at the end */
    if (i%100 == 0) fprintf(stderr,"\rprocessing line %d", i);
    offs=i*width;				/* offset for address in array */

    for (j=xmin; j < xmax-1; j++) {		/* 1 pixel border at the left edge */
      for(k=0, l=0; l < 4; l++) {
	offt = offs+ioft[l]*width + j + joft[l];
	offb = offs+iofb[l]*width + j + jofb[l];
	k += nint((double)(phase[offt]-phase[offb])/TWO_PI) ;
      }

      if (k != 0) {				/* residue? */		
	if (k >0) {
          (*n_p)++;				/* increment positive residue counter */
          flags[offs+j]=(flags[offs+j] | PLUS) & ~GUID; /* set flag PLUS, clear GUID */
        }
	else {
          (*n_m)++;				/* increment negative residue counter */
          flags[offs+j]=(flags[offs+j] | MINU) & ~GUID; /* set flag MINU, clear GUID */
        }
      }	 
    }
  }
}

#include <sys/types.h>
#include <sys/time.h>
#include <sys/times.h>
#include <unistd.h>
#include <limits.h>

struct tms buffer;
int user_time, system_time, start_time;

void start_timing()
{
  start_time = (int) times(&buffer);
  user_time = (int) buffer.tms_utime;
  system_time = (int) buffer.tms_stime;
}

void stop_timing()
{
  int  end_time,elapsed_time;
  int clk_tck;

  clk_tck = (int)sysconf(_SC_CLK_TCK);

  end_time = (int) times(&buffer);
  user_time = (int) (buffer.tms_utime - user_time);
  system_time = (int) (buffer.tms_stime - system_time);
  elapsed_time = (end_time - start_time);

  fprintf(stdout,"\n\nuser time    (s):  %10.3f\n", (double)user_time/clk_tck);
  fprintf(stdout,"system time  (s):  %10.3f\n", (double)system_time/clk_tck); 
  fprintf(stdout,"elapsed time (s):  %10.3f\n\n", (double) elapsed_time/clk_tck);
}

